# 第十五周作业二 · 情感陪伴 Agent 的 Docker 镜像打包

作业原文：

> 作业2: 使用 dockerfile 打包镜像，基于作业1的 openai-agents 版本的代码，编写 dockerfile，
> 通过 docker 或 阿里云镜像服务镜像打包。

## 一、交付物

```
15-江洋明-第十五周作业/作业二/
├── README.md                       ← 本文件
├── Dockerfile                      ← 作业交付物本体
├── docker-compose.yml              ← 一条命令起服务
├── scripts/
│   ├── build_image.sh              # 构建（bash）
│   ├── build_image.ps1             # 构建（PowerShell）
│   ├── push_image.sh               # 推送到镜像仓库（本地 registry / 阿里云 ACR）
│   └── capture_evidence.py         # 真跑一遍 docker 命令，产出交付截图
└── docs/
    ├── 01-镜像构建与运行.md
    ├── 02-阿里云ACR推送.md
    └── screenshots/
        ├── 01-镜像构建.{txt,png}
        ├── 02-容器运行与健康检查.{txt,png}
        ├── 03-容器内接口自检.{txt,png}
        ├── 04-推送到镜像仓库.{txt,png}
        └── 05-从仓库拉取镜像.{txt,png}
```

**截图不是摆拍** —— `scripts/capture_evidence.py` 真的执行 `docker build` / `docker run` /
`docker push` / `docker pull`，把命令的原始输出整段贴进截图里，
包括 digest、镜像大小、健康状态这些关键行。

## 二、镜像信息

| 项 | 值 |
| --- | --- |
| 镜像名 | `emotion-agent:v1` |
| 基础镜像 | `python:3.13-slim` |
| 运行用户 | `appuser`（非 root） |
| 暴露端口 | `8016` |
| 入口 | `CMD ["python", "-X", "utf8", "-m", "emotion_agents"]` |
| 健康检查 | `HEALTHCHECK` 打 `http://127.0.0.1:8016/api/health` |
| 磁盘占用 / 内容大小 | 319MB / 71.6MB |
| digest | `sha256:4f35fb1df3a69fd1688a0795f2db4ee9b09e70d6e4af0dc472eeb4e5f4c8e860` |

## 三、构建上下文不是本目录 —— 这是最容易踩的坑

`Dockerfile` 放在「作业二」目录里，但**构建上下文是「作业一/openai-agents」** ——
因为要 `COPY` 进去的源码、前端、依赖清单都在那边。

```bash
cd "<第十五周作业根目录>"
docker build -f "作业二/Dockerfile" -t emotion-agent:v1 "作业一/openai-agents"
```

对应地，**`.dockerignore` 必须放在构建上下文根目录**
（`作业一/openai-agents/.dockerignore`），**不是**放在 Dockerfile 旁边 ——
Docker 只认上下文根目录那一份。

直接用封装好的脚本（自动处理中文路径）：

```bash
bash 作业二/scripts/build_image.sh              # 构建 emotion-agent:v1
bash 作业二/scripts/build_image.sh --no-cache   # 不走缓存
powershell -ExecutionPolicy Bypass -File 作业二/scripts/build_image.ps1
```

> BuildKit 对中文路径（`E:\个人\…`）的 `COPY` 没有任何问题，已实测通过。

## 四、镜像分层

```dockerfile
FROM python:3.13-slim
ENV PYTHONUNBUFFERED=1 PYTHONDONTWRITEBYTECODE=1 PIP_NO_CACHE_DIR=1 …
WORKDIR /app

COPY requirements-runtime.txt ./                       # 依赖单独一层
RUN pip install --no-cache-dir -r requirements-runtime.txt

COPY src ./src                                         # 代码层
COPY frontend ./frontend                               # 前端单文件
COPY scripts/vendor_vue.py ./scripts/vendor_vue.py
RUN python scripts/vendor_vue.py || echo "[提示] …"     # 前端 Vue 本地化，离线可用

RUN useradd --create-home --shell /bin/bash appuser \
    && chown -R appuser:appuser /app                    # 非 root
ENV HOME=/home/appuser PYTHONPATH=/app/src WEB_HOST=0.0.0.0 WEB_PORT=8016
USER appuser

EXPOSE 8016
HEALTHCHECK --interval=30s --timeout=5s --start-period=15s --retries=3 \
    CMD python -c "import sys,urllib.request; …"
CMD ["python", "-X", "utf8", "-m", "emotion_agents"]
```

三个关键决策：

| 决策 | 原因 |
| --- | --- |
| 依赖单独一层 | 改代码不会让 pip 重装依赖，命中缓存时秒级重建 |
| 构建期下载 Vue 到 `frontend/vendor/` | 容器内无外网时前端也能跑（`index.html` 本地优先 + `onerror` 回退 CDN） |
| `HOME=/home/appuser` + 非 root | openai-agents 会往 `~/.traces` 写 trace，`HOME` 不对会直接权限报错 |
| 健康检查用 `python -c` 而不是 `curl` | `python:3.13-slim` 里没有 curl |

## 五、密钥不进镜像

- `EMOTION_AGENT_API_KEY` 一律通过 `docker run -e` 或 `--env-file` 传；
- `.env` 被 `.dockerignore` 排除，**不会**被 `COPY` 进镜像；
- 镜像里除了代码就是依赖，没有任何密钥。

## 六、运行

```bash
# 方式一：docker run
docker run -d --name emotion-agent -p 8016:8016 \
  -e EMOTION_AGENT_API_KEY=你的key \
  -e EMOTION_AGENT_BASE_URL=https://api.deepseek.com/v1 \
  emotion-agent:v1

# 方式二：docker compose（在本目录执行）
# 先准备 .env（内容同 作业一/openai-agents/.env.example），再：
docker compose up -d --build
docker compose logs -f
docker compose down
```

起来之后：

```bash
curl -s http://127.0.0.1:8016/api/health
# {"status":"ok","api_key_present":true,…,"implementation":"openai-agents"}

docker ps --filter name=emotion-agent
# emotion-agent  emotion-agent:v1  Up 6 seconds (healthy)  0.0.0.0:8016->8016/tcp
```

浏览器打开 `http://127.0.0.1:8016` 就是完整的前端页面（18814 字节）。

> 本机 8000 端口被别的容器长期占用，所以容器映射到 **8016**。

## 七、推送到镜像仓库

### 本机 registry（用来验证整条链路，本机就能跑通）

```bash
docker run -d --name local-registry -p 5000:5000 registry:2
docker tag emotion-agent:v1 localhost:5000/emotion-agent:v1
docker push localhost:5000/emotion-agent:v1
docker rmi localhost:5000/emotion-agent:v1     # 删掉本地镜像
docker pull localhost:5000/emotion-agent:v1     # 再拉回来
```

实测结果（见 `docs/screenshots/04-`、`05-`）：

```
v1: digest: sha256:4f35fb1df3a69fd1688a0795f2db4ee9b09e70d6e4af0dc472eeb4e5f4c8e860 size: 856
$ curl -s http://127.0.0.1:5000/v2/_catalog
{"repositories":["emotion-agent"]}
$ curl -s http://127.0.0.1:5000/v2/emotion-agent/tags/list
{"name":"emotion-agent","tags":["v1"]}
```

### 阿里云 ACR

命令与上面**完全一样**，只是地址换成 ACR 的域名：

```bash
export REGISTRY_USER=你的账号
export REGISTRY_PASSWORD=你的密码
bash 作业二/scripts/push_image.sh \
  --registry registry.cn-hangzhou.aliyuncs.com \
  --namespace <你的命名空间> \
  --repo emotion-agent --tag v1
```

完整步骤（控制台建仓库、登录、私有镜像实例的额外配置）见 **`docs/02-阿里云ACR推送.md`**。

## 八、重新生成交付截图

```bash
cd 作业二
python -X utf8 scripts/capture_evidence.py            # 全流程
python -X utf8 scripts/capture_evidence.py --no-cache  # 构建不走缓存（截图里能看到每层真的执行）
```

脚本会真的跑一遍 docker 命令，把输出写成 `.txt`，再用 Chromium 渲染成 `.png`。

## 九、更多文档

- `docs/01-镜像构建与运行.md` —— 构建、运行、排查的完整步骤；
- `docs/02-阿里云ACR推送.md` —— 推送到阿里云镜像服务 ACR 的完整流程。
