# 构建情感陪伴 Agent 镜像（第十五周作业二）· PowerShell 版
#
# 【关键】构建上下文是「作业一/openai-agents」，不是本目录 ——
# 要 COPY 进去的源码、前端、依赖清单都在那边；
# 而 Dockerfile 放在「作业二」里（作业交付物本体）。
#
# 用法：
#   powershell -ExecutionPolicy Bypass -File scripts\build_image.ps1
#   powershell -ExecutionPolicy Bypass -File scripts\build_image.ps1 -Image emotion-agent:v2
#   powershell -ExecutionPolicy Bypass -File scripts\build_image.ps1 -NoCache
param(
    [string]$Image = "emotion-agent:v1",
    [switch]$NoCache
)

$ErrorActionPreference = "Stop"

# 本脚本所在目录的上一级 = 作业二
$作业二Dir = Split-Path -Parent $PSScriptRoot
$作业一Dir = Split-Path -Parent $作业二Dir

# 构建上下文
$Context = Join-Path $作业一Dir "作业一\openai-agents"
# Dockerfile（在上下文之外，docker build -f 支持）
$Dockerfile = Join-Path $作业二Dir "Dockerfile"

Write-Host "构建上下文：$Context"
Write-Host "Dockerfile：$Dockerfile"
Write-Host "镜像标签：  $Image"
Write-Host ""

# 前端 Vue 本地化：离线部署时容器里没有 CDN。
# 拉不到也不中断 —— index.html 会回退到 CDN。
Write-Host "[准备] 本地化前端 Vue（离线可用）…"
try {
    python -X utf8 (Join-Path $Context "scripts\vendor_vue.py")
} catch {
    Write-Host "  跳过（无外网），运行时回退 CDN"
}
Write-Host ""

$buildArgs = @("build")
if ($NoCache) { $buildArgs += "--no-cache" }
$buildArgs += @("-f", $Dockerfile, "-t", $Image, $Context)

& docker @buildArgs
if ($LASTEXITCODE -ne 0) {
    throw "docker build 失败（退出码 $LASTEXITCODE）"
}

Write-Host ""
Write-Host "构建完成：$Image" -ForegroundColor Green
docker images $Image
