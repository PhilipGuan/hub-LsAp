#!/usr/bin/env bash
# 构建情感陪伴 Agent 镜像（第十五周作业二）。
#
# 【关键】构建上下文是「作业一/openai-agents」，不是本目录 ——
# 要 COPY 进去的源码、前端、依赖清单都在那边；
# 而 Dockerfile 放在「作业二」里（作业交付物本体）。
#
# 用法：
#   bash scripts/build_image.sh                       # 构建 emotion-agent:v1
#   bash scripts/build_image.sh emotion-agent:v2     # 指定 tag
#   bash scripts/build_image.sh --no-cache            # 不走缓存
set -euo pipefail

作业二_DIR="$(cd "$(dirname "$0")/.." && pwd)"
作业一_DIR="$(cd "$作业二_DIR/.." && pwd)"

# 构建上下文
CONTEXT="$作业一_DIR/作业一/openai-agents"
# Dockerfile（在上下文之外，docker build -f 支持）
DOCKERFILE="$作业二_DIR/Dockerfile"

IMAGE="emotion-agent:v1"
NO_CACHE=""

while [[ $# -gt 0 ]]; do
    case "$1" in
        --no-cache) NO_CACHE="--no-cache"; shift ;;
        -h|--help) sed -n '2,14p' "$0"; exit 0 ;;
        *) IMAGE="$1"; shift ;;
    esac
done

echo "构建上下文：$CONTEXT"
echo "Dockerfile：$DOCKERFILE"
echo "镜像标签：  $IMAGE"
echo

# 前端 Vue 本地化：离线部署时容器里没有 CDN。
# 拉不到也不中断 —— index.html 会回退到 CDN。
echo "[准备] 本地化前端 Vue（离线可用）…"
python -X utf8 "$CONTEXT/scripts/vendor_vue.py" || echo "  跳过（无外网），运行时回退 CDN"
echo

docker build $NO_CACHE -f "$DOCKERFILE" -t "$IMAGE" "$CONTEXT"

echo
echo "构建完成：$IMAGE"
docker images "$IMAGE"
