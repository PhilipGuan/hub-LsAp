"""采集作业二的交付证据：真跑一遍命令，把真实输出存成文本 + 截图。

**这些截图不是摆拍** —— 脚本真的执行 ``docker build`` / ``docker run`` /
``docker push`` / ``docker pull``，把命令的原始输出整段贴进截图里，
包括 digest、镜像大小、健康状态这些关键行。

产出（默认写到 ``docs/screenshots/``）::

    01-镜像构建.txt/.png
    02-容器运行与健康检查.txt/.png
    03-容器内接口自检.txt/.png
    04-推送到镜像仓库.txt/.png
    05-从仓库拉取镜像.txt/.png

用法::

    python -X utf8 scripts/capture_evidence.py
"""

from __future__ import annotations

import argparse
import os
import re
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
作业一_DIR = PROJECT_ROOT.parent / "作业一"
CONTEXT = 作业一_DIR / "openai-agents"
DOCKERFILE = PROJECT_ROOT / "Dockerfile"

DEFAULT_OUT = PROJECT_ROOT / "docs" / "screenshots"

IMAGE = "emotion-agent:v1"
REGISTRY_IMAGE = "localhost:5000/emotion-agent:v1"
CONTAINER = "emotion-agent"
PORT = "8016"

#: 终端配色（跟常见的深色终端一致）
终端样式 = """
body { margin:0; background:#0d1117; }
pre {
  margin:0; padding:22px 26px; color:#c9d1d9; background:#0d1117;
  font:13px/1.62 "Cascadia Mono","Consolas","DejaVu Sans Mono",monospace;
  white-space:pre-wrap; word-break:break-all;
}
.标题 { color:#58a6ff; font-weight:700; }
.行号 { color:#484f58; }
"""

终端HTML = """<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="UTF-8" />
<title>证据</title><style>%s</style></head>
<body><pre id="out">%s</pre></body></html>
"""


def _跑命令(命令: list[str], cwd: Path | None = None) -> tuple[int, str]:
    """跑一条命令，返回 (退出码, 合并后的输出)。"""
    print(f"  $ {' '.join(命令)}", file=sys.stderr)
    完成 = subprocess.run(
        命令,
        cwd=str(cwd) if cwd else None,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    输出 = (完成.stdout or "") + (完成.stderr or "")
    return 完成.returncode, 输出


def _读_API_key() -> str:
    """从「作业一/openai-agents/.env」里读 key（只用于本机跑容器，不入库）。"""
    路径 = CONTEXT / ".env"
    if 路径.is_file():
        for 行 in 路径.read_text(encoding="utf-8").splitlines():
            行 = 行.strip()
            if 行.startswith("EMOTION_AGENT_API_KEY="):
                return 行.split("=", 1)[1].strip().strip("'\"")
    return os.environ.get("EMOTION_AGENT_API_KEY", "")


def _渲染(文本: str, 标题: str, 目标: Path) -> None:
    """把终端输出渲染成一张 PNG（用 Playwright 走 Chromium 真渲染）。"""
    import html as html_mod

    from playwright.sync_api import sync_playwright

    行 = 文本.splitlines() or ["（无输出）"]
    带行号 = "\n".join(
        f'<span class="行号">{i:>3}</span>  {html_mod.escape(行项)}'
        for i, 行项 in enumerate(行, start=1)
    )
    页面 = 终端HTML % (终端样式, 带行号)
    临时 = 目标.with_suffix(".html")
    临时.write_text(页面, encoding="utf-8")

    可执行 = _找chromium()
    with sync_playwright() as p:
        浏览器 = p.chromium.launch(executable_path=可执行)
        上下文 = 浏览器.new_context(
            viewport={"width": 1180, "height": 720},
            device_scale_factor=1,
        )
        页面对象 = 上下文.new_page()
        页面对象.goto(临时.resolve().as_uri())
        页面对象.wait_for_timeout(300)
        高度 = 页面对象.evaluate(
            "() => Math.max(720, document.body.scrollHeight)"
        )
        页面对象.set_viewport_size({"width": 1180, "height": int(高度)})
        页面对象.screenshot(path=str(目标), full_page=True)
        浏览器.close()
    临时.unlink(missing_ok=True)


def _找chromium() -> str | None:
    """找 Playwright 已下载的 chromium（版本可能和 playwright 不匹配）。"""
    root = Path.home() / "AppData" / "Local" / "ms-playwright"
    if not root.exists():
        return None
    候选 = sorted(root.glob("chromium-*/chrome-win64/chrome.exe"), reverse=True)
    return str(候选[0]) if 候选 else None


def _标题(正文: str, 标题: str) -> str:
    return f"$ {标题}\n\n{正文.rstrip()}\n"


#: BuildKit 输出分类：步骤头（``#8 [4/9] RUN ...``）、该层结论（``DONE`` / ``CACHED``）、导出段
_步骤头 = re.compile(r"^#\d+ \[\d+/\d+\]")
_结论 = re.compile(r"^#\d+ (DONE|CACHED)")
_导出段 = re.compile(r"^#\d+ (exporting|naming to|unpacking to)")


def _精简构建输出(输出: str) -> str:
    """把 BuildKit 的长输出压成可读的关键行。

    保留：每一层的步骤头（``#8 [4/9] RUN pip install ...``）、该层的
    ``DONE`` / ``CACHED`` 结论，以及最后的导出段（digest、命名）。
    丢掉：pip 下载每个 wheel 的进度行（上百行噪声，看不出重点）。
    """
    步骤 = []
    导出 = []
    丢弃数 = 0
    for 行 in 输出.splitlines():
        if _步骤头.match(行) or _结论.match(行):
            步骤.append(行)
        elif _导出段.match(行):
            导出.append(行)
        elif 行.startswith("#"):
            丢弃数 += 1
        elif 行.strip():
            # 末尾那行 "View build details: ..." 之类
            导出.append(行)
    噪声 = f"…（pip 下载过程省略，共 {丢弃数} 行）…" if 丢弃数 else ""
    return "\n".join(步骤 + ([噪声] if 噪声 else []) + 导出)


def 采集构建(out_dir: Path, 无缓存: bool = False) -> None:
    print("[1/5] 采集镜像构建过程…", file=sys.stderr)
    命令 = ["docker", "build"]
    if 无缓存:
        命令.append("--no-cache")
    命令 += ["-f", str(DOCKERFILE), "-t", IMAGE, str(CONTEXT)]
    码, 输出 = _跑命令(命令)
    缓存参数 = "--no-cache " if 无缓存 else ""
    正文 = _标题(
        f"docker build {缓存参数}-f 作业二/Dockerfile -t {IMAGE} 作业一/openai-agents\n\n"
        + _精简构建输出(输出),
        "构建上下文 = 作业一/openai-agents，Dockerfile 在 作业二/",
    )
    (out_dir / "01-镜像构建.txt").write_text(正文, encoding="utf-8")
    _渲染(正文, "docker build", out_dir / "01-镜像构建.png")


def 采集运行(out_dir: Path) -> None:
    print("[2/5] 采集容器运行与健康检查…", file=sys.stderr)
    _跑命令(["docker", "rm", "-f", CONTAINER])
    key = _读_API_key()
    码, 输出 = _跑命令(
        [
            "docker", "run", "-d", "--name", CONTAINER,
            "-p", f"{PORT}:{PORT}",
            "-e", f"EMOTION_AGENT_API_KEY={key}",
            "-e", "EMOTION_AGENT_BASE_URL=https://api.deepseek.com/v1",
            "-e", "EMOTION_AGENT_MODEL=deepseek-flash",
            "-e", "EMOTION_AGENT_RESPONDER_MODEL=deepseek-v4-pro",
            "-e", "EMOTION_AGENT_THINKING=disabled",
            IMAGE,
        ]
    )
    _跑命令(["docker", "inspect", "-f", "{{.State.Health.Status}}", CONTAINER])
    for _ in range(30):
        time.sleep(2)
        码2, 状态 = _跑命令(
            ["docker", "inspect", "-f", "{{.State.Health.Status}}", CONTAINER]
        )
        if 状态.strip() == "healthy":
            break
    _, 状态 = _跑命令(["docker", "inspect", "-f", "{{.State.Health.Status}}", CONTAINER])
    _, 详情 = _跑命令(
        [
            "docker", "inspect", "-f",
            "用户={{.Config.User}}  健康={{.State.Health.Status}}  "
            "CMD={{json .Config.Cmd}}  端口={{json .NetworkSettings.Ports}}",
            CONTAINER,
        ]
    )
    _, 列表 = _跑命令(
        ["docker", "ps", "--filter", f"name={CONTAINER}",
         "--format", "table {{.Names}}\\t{{.Image}}\\t{{.Status}}\\t{{.Ports}}"]
    )
    _, 日志 = _跑命令(["docker", "logs", CONTAINER])
    正文 = _标题(
        f"docker run -d --name {CONTAINER} -p {PORT}:{PORT} "
        f"-e EMOTION_AGENT_API_KEY=*** {IMAGE}\n\n"
        f"容器 ID: {输出.strip()}\n\n"
        f"$ docker ps\n{列表}\n"
        f"$ docker inspect -f '{{{{.State.Health.Status}}}}' {CONTAINER}\n{状态}\n"
        f"$ docker inspect -f '...'\n{详情}\n"
        f"$ docker logs {CONTAINER}\n{日志}",
        "容器启动后健康检查自动变成 healthy",
    )
    (out_dir / "02-容器运行与健康检查.txt").write_text(正文, encoding="utf-8")
    _渲染(正文, "docker run", out_dir / "02-容器运行与健康检查.png")


def 采集接口(out_dir: Path) -> None:
    print("[3/5] 采集容器内接口自检…", file=sys.stderr)
    片段 = []
    for 路径 in ("/api/health", "/api/examples"):
        with urllib.request.urlopen(
            f"http://127.0.0.1:{PORT}{路径}", timeout=30
        ) as 响应:
            片段.append(f"$ curl -s http://127.0.0.1:{PORT}{路径}\n{响应.read().decode('utf-8')}")
    with urllib.request.urlopen(f"http://127.0.0.1:{PORT}/", timeout=30) as 响应:
        片段.append(
            f"$ curl -s -o /dev/null -w '%{{http_code}}' http://127.0.0.1:{PORT}/\n"
            f"{响应.status}（前端页面 {len(响应.read())} 字节）"
        )
    正文 = _标题("\n\n".join(片段), "宿主机访问容器里的服务")
    (out_dir / "03-容器内接口自检.txt").write_text(正文, encoding="utf-8")
    _渲染(正文, "curl", out_dir / "03-容器内接口自检.png")


def 采集推送(out_dir: Path) -> None:
    print("[4/5] 采集推送到镜像仓库…", file=sys.stderr)
    _, 起仓库 = _跑命令(
        ["docker", "rm", "-f", "local-registry"]
    )
    _, 拉仓库 = _跑命令(["docker", "pull", "registry:2"])
    _, 跑仓库 = _跑命令(
        ["docker", "run", "-d", "--name", "local-registry", "-p", "5000:5000", "registry:2"]
    )
    time.sleep(4)
    _, 打标签 = _跑命令(["docker", "tag", IMAGE, REGISTRY_IMAGE])
    _, 推送 = _跑命令(["docker", "push", REGISTRY_IMAGE])
    with urllib.request.urlopen("http://127.0.0.1:5000/v2/_catalog", timeout=30) as 响应:
        目录 = 响应.read().decode("utf-8")
    with urllib.request.urlopen(
        "http://127.0.0.1:5000/v2/emotion-agent/tags/list", timeout=30
    ) as 响应:
        标签 = 响应.read().decode("utf-8")
    正文 = _标题(
        f"$ docker run -d --name local-registry -p 5000:5000 registry:2\n"
        f"{跑仓库.strip()}\n\n"
        f"$ docker tag {IMAGE} {REGISTRY_IMAGE}\n{打标签.strip()}\n\n"
        f"$ docker push {REGISTRY_IMAGE}\n{推送}\n\n"
        f"$ curl -s http://127.0.0.1:5000/v2/_catalog\n{目录}\n\n"
        f"$ curl -s http://127.0.0.1:5000/v2/emotion-agent/tags/list\n{标签}",
        "推送到本机 registry（阿里云 ACR 只是换个地址，命令完全一样）",
    )
    (out_dir / "04-推送到镜像仓库.txt").write_text(正文, encoding="utf-8")
    _渲染(正文, "docker push", out_dir / "04-推送到镜像仓库.png")


def 采集拉取(out_dir: Path) -> None:
    print("[5/5] 采集从仓库拉取镜像…", file=sys.stderr)
    _, 删除 = _跑命令(["docker", "rmi", REGISTRY_IMAGE])
    _, 剩余 = _跑命令(
        ["docker", "images", "--format", "{{.Repository}}:{{.Tag}}"]
    )
    _, 拉取 = _跑命令(["docker", "pull", REGISTRY_IMAGE])
    _, 校验 = _跑命令(["docker", "images", REGISTRY_IMAGE])
    正文 = _标题(
        f"$ docker rmi {REGISTRY_IMAGE}\n{删除.strip()}\n\n"
        f"$ docker images | grep emotion-agent\n"
        + "\n".join(行 for 行 in 剩余.splitlines() if "emotion-agent" in 行)
        + "\n\n"
        f"$ docker pull {REGISTRY_IMAGE}\n{拉取}\n\n"
        f"$ docker images {REGISTRY_IMAGE}\n{校验}",
        "删掉本地镜像，再从仓库拉回来 —— 证明镜像是真的推上去了",
    )
    (out_dir / "05-从仓库拉取镜像.txt").write_text(正文, encoding="utf-8")
    _渲染(正文, "docker pull", out_dir / "05-从仓库拉取镜像.png")


def main() -> int:
    解析器 = argparse.ArgumentParser(description="采集作业二的交付证据（真跑一遍）")
    解析器.add_argument("--out", default=str(DEFAULT_OUT))
    解析器.add_argument(
        "--skip-build",
        action="store_true",
        help="跳过重新构建（镜像已经存在时省时间）",
    )
    解析器.add_argument(
        "--no-cache",
        action="store_true",
        help="构建时不走缓存（截图里能看到每一层真的执行了一遍）",
    )
    参数 = 解析器.parse_args()

    out_dir = Path(参数.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    if _找chromium() is None:
        print("[错误] 找不到 chromium，请先执行：python -m playwright install chromium")
        return 1

    if not 参数.skip_build:
        采集构建(out_dir, 无缓存=参数.no_cache)
    采集运行(out_dir)
    采集接口(out_dir)
    采集推送(out_dir)
    采集拉取(out_dir)

    print()
    print("证据采集完成：", out_dir)
    for p in sorted(out_dir.iterdir()):
        print(" ", p.name)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
