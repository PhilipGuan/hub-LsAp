#!/usr/bin/env bash
# 推送镜像到镜像仓库（第十五周作业二）。
#
# 两种目标：
#   A) 本机 registry（用来验证「构建 → 打标签 → 推送 → 拉取」整条链路，本机就能跑通）
#        bash scripts/push_image.sh --local
#   B) 阿里云 ACR（作业原文的「阿里云镜像服务」）
#        bash scripts/push_image.sh \
#            --registry registry.cn-hangzhou.aliyuncs.com \
#            --namespace <你的命名空间> \
#            --repo emotion-agent --tag v1
#
# 凭据只从环境变量 / 交互输入拿，**绝不写进脚本**：
#   REGISTRY_USER / REGISTRY_PASSWORD（阿里云用的是 AccessKey 账号密码，
#   不是阿里云 AccessKeyId/AccessKeySecret —— 除非你专门开了「专有实例」）
set -euo pipefail

REGISTRY=""
NAMESPACE=""
REPO="emotion-agent"
TAG="v1"
LOCAL_IMAGE="emotion-agent:v1"
DO_LOCAL=0

while [[ $# -gt 0 ]]; do
    case "$1" in
        --local) DO_LOCAL=1; shift ;;
        --registry) REGISTRY="$2"; shift 2 ;;
        --namespace) NAMESPACE="$2"; shift 2 ;;
        --repo) REPO="$2"; shift 2 ;;
        --tag) TAG="$2"; shift 2 ;;
        --source) LOCAL_IMAGE="$2"; shift 2 ;;
        -h|--help) sed -n '2,16p' "$0"; exit 0 ;;
        *) echo "未知参数：$1" >&2; exit 1 ;;
    esac
done

if [[ $DO_LOCAL -eq 1 ]]; then
    # 本机 registry：地址固定 localhost:5000，不需要登录（本机 insecure registry）。
    REGISTRY="localhost:5000"
    NAMESPACE=""
fi

if [[ -z "$REGISTRY" ]]; then
    echo "请指定目标仓库：--local 或 --registry <host> --namespace <ns>" >&2
    exit 1
fi

if [[ -n "$NAMESPACE" ]]; then
    TARGET="$REGISTRY/$NAMESPACE/$REPO:$TAG"
else
    TARGET="$REGISTRY/$REPO:$TAG"
fi

echo "源镜像：$LOCAL_IMAGE"
echo "目标：  $TARGET"
echo

# 登录（目标不是本机 registry 时）
if [[ "$REGISTRY" != "localhost:5000" ]]; then
    if [[ -z "${REGISTRY_USER:-}" || -z "${REGISTRY_PASSWORD:-}" ]]; then
        echo "请先设置 REGISTRY_USER / REGISTRY_PASSWORD 环境变量，或用 docker login 手动登录。" >&2
        exit 1
    fi
    # --password-stdin：不把密码留在 shell 历史和进程参数里。
    printf '%s' "$REGISTRY_PASSWORD" | docker login "$REGISTRY" \
        --username "$REGISTRY_USER" --password-stdin
    echo
fi

docker tag "$LOCAL_IMAGE" "$TARGET"
docker push "$TARGET"

echo
echo "推送完成：$TARGET"
echo "拉取验证：docker pull $TARGET"
