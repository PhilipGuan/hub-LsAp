# 02 · 推送到阿里云镜像服务（ACR）

作业原文说「通过 docker 或 阿里云镜像服务镜像打包」——本项目两条路都准备了：

| 路线 | 状态 | 证据 |
| --- | --- | --- |
| **本地 registry**（`registry:2` 跑在本机 5000 端口） | ✅ **已实测跑通** | `docs/screenshots/04-推送到镜像仓库.png`、`05-从仓库拉取镜像.png` |
| **阿里云 ACR**（`registry.cn-<region>.aliyuncs.com`） | 命令完全一样，**凭据到位后执行** | 本文 §四 |

推送到 ACR 的命令和推送到本机 registry **一模一样**，只有地址不同。
所以本地这条链路一旦跑通，换个地址就能直接推到阿里云。

---

## 一、本地 registry 的实测记录（已验证）

### 1.1 起一个本机仓库

```bash
docker run -d --name local-registry -p 5000:5000 registry:2
```

### 1.2 打标签 + 推送

```bash
docker tag emotion-agent:v1 localhost:5000/emotion-agent:v1
docker push localhost:5000/emotion-agent:v1
```

实测输出（`docs/screenshots/04-推送到镜像仓库.png`）：

```
The push refers to repository [localhost:5000/emotion-agent]
37fb86c2a767: Pushed
f5272667e273: Pushed
44136fa355b3: Pushed
…
v1: digest: sha256:4f35fb1df3a69fd1688a0795f2db4ee9b09e70d6e4af0dc472eeb4e5f4c8e860 size: 856
```

推送完成后到仓库的 HTTP API 里确认：

```
$ curl -s http://127.0.0.1:5000/v2/_catalog
{"repositories":["emotion-agent"]}

$ curl -s http://127.0.0.1:5000/v2/emotion-agent/tags/list
{"name":"emotion-agent","tags":["v1"]}
```

### 1.3 删掉本地镜像再拉回来

这一步是**关键证据**：只有镜像真的推到了仓库，才能拉回来。

```bash
docker rmi localhost:5000/emotion-agent:v1
# Untagged: localhost:5000/emotion-agent:v1

docker images | grep emotion-agent
# emotion-agent:v1            ← 本地那份还在（这是「带 registry 前缀」的那一份）

docker pull localhost:5000/emotion-agent:v1
# v1: Pulling from emotion-agent
# Digest: sha256:4f35fb1df3a69fd1688a0795f2db4ee9b09e70d6e4af0dc472eeb4e5f4c8e860
# Status: Downloaded newer image for localhost:5000/emotion-agent:v1

docker images localhost:5000/emotion-agent:v1
# IMAGE                             ID             DISK USAGE   CONTENT SIZE   EXTRA
# localhost:5000/emotion-agent:v1   4f35fb1df3a6        319MB         71.6MB   U
```

> `docker images` 里能看到 **两个** `emotion-agent:v1` —— 一个是本地的 `emotion-agent:v1`，
> 一个是仓库里的 `localhost:5000/emotion-agent:v1`。它们**内容相同**（同一个 digest），
> 但 tag 指向不同，所以要带仓库地址才区分得开。

---

## 二、阿里云 ACR 控制台准备

> 这一节需要你自己的阿里云账号与凭据。**凭据不要写进任何提交到仓库的文件。**

### 2.1 开通容器镜像服务

1. 打开 [容器镜像服务 ACR 控制台](https://cr.console.aliyun.com/)；
2. 首次进入需要先**开通服务**（个人版免费）；
3. 选择实例类型：
   - **个人版** —— 免费，用阿里云账号 + 「固定密码」推送；
   - **企业版** —— 需 RAM 子账号 + AccessKey 授权，有更多配额与地域能力。

### 2.2 建命名空间

左侧导航 → **命名空间** → 创建命名空间（例如 `personal`）。

### 2.3 建镜像仓库

左侧导航 → **镜像仓库** → 创建镜像仓库：

| 项 | 建议填法 |
| --- | --- |
| 命名空间 | 上一步建的 |
| 仓库名称 | `emotion-agent` |
| 仓库类型 | **私有**（作业演示用；若要对外免密拉取才选公共） |
| 存储类型 | 本地存储（默认即可） |

创建完成后，仓库详情页会给出**专属的推送地址**，形如：

```
registry.cn-hangzhou.aliyuncs.com/<你的命名空间>/emotion-agent
```

### 2.4 记下登录用的账号

| 实例类型 | `docker login` 的 `--username` 用什么 |
| --- | --- |
| 个人版 | 你的**阿里云账号名**（不是 AccessKey） |
| 企业版 | 授权的 **RAM 子账号名** |

密码在 ACR 控制台 → **访问凭证** 页面设置/查看（个人版的「固定密码」）。

> 企业版也可以用 **AccessKeyId / AccessKeySecret** 配 `aliyun` CLI 或 `docker login` 的
> `--password-stdin`，但**不要**把 AccessKey 写进脚本或提交到仓库。

---

## 三、推送脚本

`作业二/scripts/push_image.sh` 已经把「登录 + 打标签 + 推送 + 校验」串好了：

```bash
# A) 本机 registry（已实测）
bash 作业二/scripts/push_image.sh --local

# B) 阿里云 ACR
export REGISTRY_USER=你的账号
export REGISTRY_PASSWORD=你的密码
bash 作业二/scripts/push_image.sh \
    --registry registry.cn-hangzhou.aliyuncs.com \
    --namespace <你的命名空间> \
    --repo emotion-agent \
    --tag v1
```

脚本行为：

| 情况 | 动作 |
| --- | --- |
| `--local` | 目标固定为 `localhost:5000`，跳过登录（本机 insecure registry） |
| 目标是远端 | 先 `docker login` —— 密码用 `--password-stdin` 从环境变量喂进去，**不留在 shell 历史和进程参数里** |
| 无论哪种 | `docker tag` → `docker push`，最后打印拉取验证命令 |

支持的参数：

```
--registry <host>       仓库域名，如 registry.cn-hangzhou.aliyuncs.com
--namespace <ns>        命名空间（个人版一般就是 <账号名>）
--repo <name>           仓库名，默认 emotion-agent
--tag <tag>             标签，默认 v1
--source <image:tag>    源镜像，默认 emotion-agent:v1
--local                 等价于 --registry localhost:5000
```

### 等价的手工命令

不想用脚本的话，直接敲这几条也一样：

```bash
docker login --username=<账号> registry.cn-hangzhou.aliyuncs.com
# Password: <密码>

docker tag emotion-agent:v1 \
    registry.cn-hangzhou.aliyuncs.com/<命名空间>/emotion-agent:v1

docker push registry.cn-hangzhou.aliyuncs.com/<命名空间>/emotion-agent:v1
```

推送成功后，控制台的「镜像版本」列表里就能看到 `v1` 这个 tag。

---

## 四、推完之后

### 4.1 从 ACR 拉回来验证

```bash
docker rmi registry.cn-hangzhou.aliyuncs.com/<命名空间>/emotion-agent:v1
docker pull registry.cn-hangzhou.aliyuncs.com/<命名空间>/emotion-agent:v1
docker run -d --name emotion-agent -p 8016:8016 \
    -e EMOTION_AGENT_API_KEY=<key> \
    registry.cn-hangzhou.aliyuncs.com/<命名空间>/emotion-agent:v1
```

### 4.2 免密拉取（可选）

若把仓库类型设为**公共**，并在该仓库的「访问控制」里允许匿名拉取，
那么别人不登录也能 `docker pull`。

> 本项目**默认用私有仓库** —— 镜像本身不含密钥，但公开一个可运行的服务镜像仍需要自己评估风险。

### 4.3 专有实例（可选）

如果用的是 ACR **专有实例**，推送/拉取地址会是一个 VPC 内的**专有域名**
（形如 `registry-vpc.<region>.aliyuncs.com`），只能在同 VPC 内访问。
这种情况请按控制台给出的地址替换 `--registry` 的值，其余命令不变。

---

## 五、常见问题

| 现象 | 原因 | 处理 |
| --- | --- | --- |
| `unauthorized: incorrect username or password` | 用户名填成了 AccessKey / 账号名写错 | 个人版用**阿里云账号名**，企业版用 **RAM 子账号名** |
| `denied: requested access to the resource is denied` | RAM 子账号没有 ACR 权限 | 给子账号加 `AliyunACRFullAccess` 等权限 |
| `repository does not exist` | 命名空间 / 仓库名 / 区域不对 | 逐字核对控制台给出的完整推送地址 |
| `toomanyrequests` | 拉取频率超限 | 等一会儿重试；企业版提配额 |
| `no basic auth credentials` | 没登录就 push/pull | 先 `docker login` |

---

## 六、证据清单

| 文件 | 内容 |
| --- | --- |
| `docs/screenshots/04-推送到镜像仓库.png` | 本机 registry 的完整推送过程 + digest + 仓库 catalog |
| `docs/screenshots/05-从仓库拉取镜像.png` | `docker rmi` → `docker pull` → `docker images` 的完整记录 |

拿到阿里云 ACR 凭据后，把 §三 的命令跑一遍，
把 `docker push` 的输出（含 `digest:` 那行）截图存到同目录即可。
