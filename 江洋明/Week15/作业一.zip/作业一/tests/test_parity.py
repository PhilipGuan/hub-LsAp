"""跨版本一致性测试（不 import 任何项目模块也能跑的那部分）。

作业一要求「分别用 langgraph 和 openai-agents 实现**同样的逻辑**」。
光看代码说不算数，这里用**可执行的断言**把它钉住：

1. **7 个共用文件逐字一致** —— 数据契约、提示词、兜底文案、HTTP 层
   两边一个字节都不能差，否则「两版等价」就是空话；
2. **目录里没有「未认领的新文件」** —— 谁改了什么，一眼能看出来；
3. **前端协议一致** —— 两份 html 抽出来的接口地址、SSE 事件名、DOM id
   必须完全一样（前端代码可以整份复制过去跑）；
4. **同一份假数据，两版产出同一个结果** —— 真正的「等价」。

这个文件**故意不 import 两个版本的包**（除了第 4 条），
前 3 条纯靠读文件就能跑 —— 改坏了一个版本的提示词，另一个版本的 CI 也会红。
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

import pytest

作业一_ROOT = Path(__file__).resolve().parents[1]
LANGGRAPH_DIR = 作业一_ROOT / "langgraph"
AGENTS_DIR = 作业一_ROOT / "openai-agents"

LANGGRAPH_PKG = "emotion_langgraph"
AGENTS_PKG = "emotion_agents"

#: 两版**必须逐字一致**的文件（相对 ``src/<包名>/``）。
COMMON_FILES = (
    "config.py",
    "models.py",
    "prompts.py",
    "logging_config.py",
    "sentiment_utils.py",
    "api/app.py",
    "api/schemas.py",
)

#: 各版本**允许自己不一样**的文件（框架相关的实现部分）。
FRAMEWORK_FILES = {
    LANGGRAPH_PKG: {
        "__init__.py",
        "__main__.py",
        "cli.py",
        "llm.py",
        "workflow.py",
        "api/__init__.py",
        "graph/__init__.py",
        "graph/build.py",
        "graph/nodes.py",
        "graph/routing.py",
        "graph/state.py",
    },
    AGENTS_PKG: {
        "__init__.py",
        "__main__.py",
        "cli.py",
        "llm.py",
        "workflow.py",
        "api/__init__.py",
        "agents/__init__.py",
        "agents/responder.py",
        "agents/sentiment.py",
    },
}


def _相对文件列表(版本目录: Path, 包名: str) -> set[str]:
    """列出 ``src/<包名>/`` 下的所有 ``.py`` 文件（相对路径）。"""
    包目录 = 版本目录 / "src" / 包名
    return {
        str(p.relative_to(包目录)).replace("\\", "/")
        for p in 包目录.rglob("*.py")
        if "__pycache__" not in p.parts
    }


# ---------------------------------------------------------------- 1. 逐字一致


@pytest.mark.parametrize("相对路径", COMMON_FILES)
def test_共用文件两版逐字一致(相对路径: str):
    左 = (LANGGRAPH_DIR / "src" / LANGGRAPH_PKG / 相对路径).read_bytes()
    右 = (AGENTS_DIR / "src" / AGENTS_PKG / 相对路径).read_bytes()
    assert 左 == 右, f"{相对路径} 两版不一致，diff 一下就知道差在哪"


def test_共用文件清单没有漏():
    """清单本身就是契约 —— 有人把新文件加进共用区，得在这里登记。"""
    assert len(COMMON_FILES) == 7


# ---------------------------------------------------------------- 2. 没有未认领的新文件


@pytest.mark.parametrize(
    ("版本目录", "包名"),
    [(LANGGRAPH_DIR, LANGGRAPH_PKG), (AGENTS_DIR, AGENTS_PKG)],
)
def test_目录里没有未认领的新文件(版本目录: Path, 包名: str):
    允许 = set(COMMON_FILES) | FRAMEWORK_FILES[包名]
    实际 = _相对文件列表(版本目录, 包名)
    未认领 = 实际 - 允许
    assert not 未认领, f"{包名} 里有未登记的文件：{sorted(未认领)}"
    缺失 = 允许 - 实际
    assert not 缺失, f"{包名} 里少了文件：{sorted(缺失)}"


def test_两版的框架专属文件_正好覆盖两个不同的框架():
    """两个框架的文件都在，但**不重叠** —— 说明确实各写各的，不是复制粘贴。"""
    左 = FRAMEWORK_FILES[LANGGRAPH_PKG]
    右 = FRAMEWORK_FILES[AGENTS_PKG]
    共同 = 左 & 右
    # 只有入口文件是共用的（同名但内容不同：包名不一样）。
    允许共同 = {"__init__.py", "__main__.py", "cli.py", "llm.py", "workflow.py", "api/__init__.py"}
    assert 共同 <= 允许共同, f"框架专属文件不该重叠：{sorted(共同 - 允许共同)}"
    assert "graph/nodes.py" in 左
    assert "agents/sentiment.py" in 右


# ---------------------------------------------------------------- 3. 前端协议一致


def _前端(版本目录: Path) -> str:
    return (版本目录 / "frontend" / "index.html").read_text(encoding="utf-8")


def _抽_接口地址(html: str) -> set[str]:
    return set(re.findall(r"""fetch\(\s*['"]([^'"]+)['"]""", html))


def _抽_SSE事件名(html: str) -> set[str]:
    return set(re.findall(r"""event\s*===\s*['"]([a-z]+)['"]""", html))


def _抽_DOM_id(html: str) -> set[str]:
    return set(re.findall(r"""\bid="([^"]+)""", html))


def test_前端调用的接口两版一致():
    左 = _抽_接口地址(_前端(LANGGRAPH_DIR))
    右 = _抽_接口地址(_前端(AGENTS_DIR))
    assert 左 == 右
    assert {"/api/analyze", "/api/health", "/api/examples"} <= 左


def test_前端处理的_SSE_事件名两版一致():
    左 = _抽_SSE事件名(_前端(LANGGRAPH_DIR))
    右 = _抽_SSE事件名(_前端(AGENTS_DIR))
    assert 左 == 右
    assert 左 == {"stage", "final", "error"}


def test_前端的_DOM_id_两版一致():
    assert _抽_DOM_id(_前端(LANGGRAPH_DIR)) == _抽_DOM_id(_前端(AGENTS_DIR))


def test_前端标题标明了各自的实现():
    左 = _前端(LANGGRAPH_DIR)
    右 = _前端(AGENTS_DIR)
    assert "LangGraph 版" in 左
    assert "openai-agents 版" in 右


# ---------------------------------------------------------------- 4. 同一份假数据 → 同一个结果


def _加路径() -> None:
    """把两版的 src 挂到 sys.path（不依赖根 pyproject 的 pythonpath 设置）。"""
    for 目录 in (LANGGRAPH_DIR / "src", AGENTS_DIR / "src"):
        路径 = str(目录)
        if 路径 not in sys.path:
            sys.path.insert(0, 路径)


@pytest.mark.parametrize(
    ("极性", "期望分支"),
    [
        ("positive", "encourage"),
        ("negative", "comfort"),
        ("neutral", "acknowledge"),
    ],
)
def test_两版对同一句话给出同一个结果(极性: str, 期望分支: str):
    _加路径()
    import asyncio

    from emotion_agents import workflow as agents_workflow
    from emotion_agents.models import SentimentResult as AgentsSentiment
    from emotion_langgraph import workflow as graph_workflow
    from emotion_langgraph.graph.nodes import GraphDeps
    from emotion_langgraph.models import SentimentResult as GraphSentiment

    原话, 置信度, 理由 = {
        "positive": ("今天终于把方案改完了，太开心了", 0.92, "表达得很轻快"),
        "negative": ("面试又挂了，我已经很失望", 0.85, "连续受挫"),
        "neutral": ("明天上午十点的项目评审", 0.6, "在陈述事实"),
    }[极性]
    回应文本 = f"这是{期望分支}分支的回应。"

    # --- LangGraph 版：节点是同步的，链的 invoke 直接返回结果 ---
    class _假链:
        def __init__(self, 产出) -> None:
            self.产出 = 产出

        def invoke(self, payload):
            return self.产出(payload)

    graph_workflow.configure(
        GraphDeps(
            sentiment_chain=_假链(
                lambda p: GraphSentiment(
                    label=极性, confidence=置信度, reason=理由
                )
            ),
            responder_chains={期望分支: _假链(lambda p: 回应文本)},
        )
    )

    # --- openai-agents 版：Agent 是异步的 ---
    async def _识别(文本: str):
        return AgentsSentiment(label=极性, confidence=置信度, reason=理由)

    async def _回应(文本: str, 识别):
        return 期望分支, 回应文本

    agents_workflow.configure(
        agents_workflow.AgentDeps(sentiment=_识别, responder=_回应)
    )

    try:
        图结果 = asyncio.run(graph_workflow.analyze_once(原话))
        agent结果 = asyncio.run(agents_workflow.analyze_once(原话))
    finally:
        graph_workflow.configure(None)
        agents_workflow.configure(None)

    assert 图结果.mode == 期望分支
    assert agent结果.mode == 期望分支
    # 除耗时外，字段逐一相等。
    assert 图结果.text == agent结果.text
    assert 图结果.sentiment.label == agent结果.sentiment.label
    assert 图结果.sentiment.confidence == agent结果.sentiment.confidence
    assert 图结果.sentiment.reason == agent结果.sentiment.reason
    assert 图结果.response == agent结果.response
    assert [s.stage for s in 图结果.trace] == [s.stage for s in agent结果.trace]
    assert [s.label for s in 图结果.trace] == [s.label for s in agent结果.trace]
    assert [s.detail for s in 图结果.trace] == [s.detail for s in agent结果.trace]


def test_两版的实现名不同_但接口相同():
    _加路径()
    from emotion_agents import workflow as agents_workflow
    from emotion_langgraph import workflow as graph_workflow

    assert graph_workflow.IMPLEMENTATION_NAME == "langgraph"
    assert agents_workflow.IMPLEMENTATION_NAME == "openai-agents"
    # 对上层暴露的四个函数签名必须一致。
    for 名 in ("analyze_stream", "analyze_once", "detect_sentiment", "respond"):
        assert callable(getattr(graph_workflow, 名))
        assert callable(getattr(agents_workflow, 名))
