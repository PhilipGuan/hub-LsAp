"""HTTP 层的单元测试（不需要 API Key）。"""

from __future__ import annotations

import json

import pytest
from fastapi.testclient import TestClient

from emotion_agents import workflow
from emotion_agents.api.app import app
from emotion_agents.config import settings
from emotion_agents.models import SentimentResult

from conftest import build_fake_deps


@pytest.fixture
def client() -> TestClient:
    return TestClient(app)


def _读帧(原文: str) -> list[tuple[str, dict]]:
    """把 SSE 原文拆成 ``(事件名, 数据)`` 列表。"""
    frames: list[tuple[str, dict]] = []
    for block in 原文.split("\n\n"):
        block = block.strip()
        if not block:
            continue
        event = ""
        data_lines: list[str] = []
        for line in block.split("\n"):
            if line.startswith("event:"):
                event = line[len("event:") :].strip()
            elif line.startswith("data:"):
                data_lines.append(line[len("data:") :].strip())
        frames.append((event, json.loads("\n".join(data_lines))))
    return frames


def test_健康检查_不泄露密钥(client: TestClient):
    resp = client.get("/api/health")
    assert resp.status_code == 200
    data = resp.json()
    assert data["status"] in ("ok", "degraded")
    assert data["api_key_present"] == bool(settings.api_key)
    assert data["implementation"] == "openai-agents"
    if settings.api_key:
        assert settings.api_key not in resp.text


def test_健康检查_不返回任何密钥字段(client: TestClient):
    data = client.get("/api/health").json()
    assert "api_key" not in data
    assert set(data) == {
        "status",
        "api_key_present",
        "base_url",
        "sentiment_model",
        "responder_model",
        "thinking",
        "implementation",
    }


def test_预置示例_三条(client: TestClient):
    data = client.get("/api/examples").json()
    assert len(data["examples"]) == 3
    titles = [item["title"] for item in data["examples"]]
    assert titles == ["正向示例", "负向示例", "中性示例"]


def test_前端页面能打开(client: TestClient):
    resp = client.get("/")
    assert resp.status_code == 200
    assert "情感陪伴" in resp.text


def test_空文本被拒绝(client: TestClient):
    assert client.post("/api/analyze", json={"text": ""}).status_code == 422


def test_只跑进程1的端点(client: TestClient):
    workflow.configure(
        build_fake_deps(
            [SentimentResult(label="negative", confidence=0.87, reason="连续受挫")]
        )
    )
    resp = client.post("/api/sentiment", json={"text": "面试又挂了"})
    assert resp.status_code == 200
    data = resp.json()["sentiment"]
    assert data["label"] == "negative"
    assert data["confidence"] == pytest.approx(0.87)


def test_只跑进程2的端点(client: TestClient):
    workflow.configure(build_fake_deps([]))
    resp = client.post(
        "/api/respond",
        json={
            "text": "面试又挂了",
            "sentiment": {"label": "negative", "confidence": 0.9, "reason": "连续受挫"},
        },
    )
    assert resp.status_code == 200
    data = resp.json()
    assert data["mode"] == "comfort"
    assert data["response"] == "连着四次被拒，难受是正常的。"


def test_流式分析_事件顺序与帧格式(client: TestClient):
    workflow.configure(
        build_fake_deps(
            [SentimentResult(label="positive", confidence=0.93, reason="表达得很轻快")]
        )
    )
    with client.stream("POST", "/api/analyze", json={"text": "今天真开心"}) as resp:
        assert resp.status_code == 200
        assert resp.headers["content-type"].startswith("text/event-stream")
        raw = "".join(resp.iter_text())

    # 帧格式必须是 event: xxx\ndata: {...}\n\n
    assert raw.startswith("event: stage\ndata: {")
    assert raw.endswith("\n\n")

    frames = _读帧(raw)
    assert [name for name, _ in frames] == ["stage", "stage", "final"]
    assert frames[0][1]["stage"] == "sentiment"
    assert frames[1][1]["stage"] == "respond"

    final = frames[-1][1]
    assert final["mode"] == "encourage"
    assert final["sentiment"]["label"] == "positive"
    assert final["response"] == "你把方案改完了，太棒了。"
    assert len(final["trace"]) == 2
    # stage 的取值只有两个，不允许把 Agent 名漏到前端协议里。
    assert frames[0][1]["stage"] in ("sentiment", "respond")
    assert frames[1][1]["stage"] in ("sentiment", "respond")


def test_流式分析_理由里有换行也不会把帧拆坏(client: TestClient):
    workflow.configure(
        build_fake_deps(
            [
                SentimentResult(
                    label="negative", confidence=0.7, reason="第一行\n第二行"
                )
            ]
        )
    )
    with client.stream("POST", "/api/analyze", json={"text": "难受"}) as resp:
        raw = "".join(resp.iter_text())

    frames = _读帧(raw)
    assert len(frames) == 3
    assert frames[-1][1]["sentiment"]["reason"] == "第一行\n第二行"
    # 每一帧都必须是「event 行 + data 行 + 空行」三行结构。
    for block in raw.strip().split("\n\n"):
        assert len(block.strip().split("\n")) == 2


def test_流式分析_进程1失败时仍然给出完整结果(client: TestClient):
    class _炸的假实现:
        async def __call__(self, text):
            raise RuntimeError("进程1 故意炸了")

    deps = build_fake_deps([])
    deps.sentiment = _炸的假实现()
    workflow.configure(deps)

    with client.stream("POST", "/api/analyze", json={"text": "面试又挂了，我很失望"}) as resp:
        raw = "".join(resp.iter_text())

    frames = _读帧(raw)
    # 进程1 失败会走关键词兜底，所以不会出错事件；这里确认链路仍然给完整结果。
    assert frames[-1][0] == "final"
    assert frames[-1][1]["sentiment"]["label"] == "negative"


def test_流式分析_编排层抛异常时给_error_事件(client: TestClient, monkeypatch):
    async def _炸了(text):
        raise RuntimeError("编排层故意炸了")
        yield  # pragma: no cover - 让它成为异步生成器

    monkeypatch.setattr(workflow, "analyze_stream", _炸了)

    with client.stream("POST", "/api/analyze", json={"text": "难受"}) as resp:
        raw = "".join(resp.iter_text())

    frames = _读帧(raw)
    assert frames[-1][0] == "error"
    assert "编排层故意炸了" in frames[-1][1]["message"]
