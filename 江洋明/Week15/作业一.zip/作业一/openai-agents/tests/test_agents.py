"""openai-agents 版特有的单元测试。

盯的是三件**踩过坑**的事：

1. 工具内必须完成归一化（模型可能返回中文标签、95 这样的百分数）；
2. 工具**绝不能抛异常** —— 抛了工具就不算执行成功，整条链路断掉；
3. 模型不调工具 / 调用失败时，必须有界重试 + 关键词兜底。
"""

from __future__ import annotations

import asyncio
import json

import pytest
from agents.tool_context import ToolContext

from emotion_agents.agents import responder as responder_module
from emotion_agents.agents import sentiment as sentiment_module
from emotion_agents.agents.responder import (
    RESPONDER_BY_LABEL,
    build_responder_agent,
    pick_mode,
)
from emotion_agents.agents.sentiment import (
    TOOL_NAME,
    _parse_tool_output,
    build_sentiment_agent,
    build_sentiment_tool,
    run_sentiment,
)
from emotion_agents.models import SentimentResult
from emotion_agents.prompts import FALLBACK_RESPONSE


def _调工具(工具, 参数: dict) -> str:
    """直接调用 ``@function_tool`` 包装出来的工具。"""

    async def _跑():
        ctx = ToolContext(
            context=None,
            tool_name=TOOL_NAME,
            tool_call_id="call_test",
            tool_arguments="{}",
        )
        return await 工具.on_invoke_tool(ctx, json.dumps(参数, ensure_ascii=False))

    return asyncio.run(_跑())


class _假的结果:
    """模拟 ``Runner.run`` 的返回值。"""

    def __init__(self, final_output) -> None:
        self.final_output = final_output


# ---------------------------------------------------------------- 进程1 的工具


def test_工具把中文标签和百分数置信度归一化():
    工具 = build_sentiment_tool("工作被否了")
    原始 = _调工具(工具, {"label": "沮丧", "confidence": 95, "reason": "工作被否了"})
    结果 = json.loads(原始)
    assert 结果["label"] == "negative"
    assert 结果["confidence"] == pytest.approx(0.95)
    assert 结果["reason"] == "工作被否了"


def test_工具返回值是单行合法_json():
    工具 = build_sentiment_tool("面试又挂了，我很失望")
    原始 = _调工具(
        工具, {"label": "negative", "confidence": 0.8, "reason": "第一行\n第二行"}
    )
    # 换行被 json.dumps 转义成 \n，帧不会被拆坏。
    assert "\n" not in 原始
    assert json.loads(原始)["reason"] == "第一行\n第二行"


def test_工具内异常被吞掉_返回关键词兜底(monkeypatch):
    def _炸(*args, **kwargs):
        raise ValueError("归一化故意炸了")

    monkeypatch.setattr(sentiment_module, "build_sentiment_result", _炸)
    工具 = build_sentiment_tool("面试又挂了，我很失望")
    结果 = json.loads(_调工具(工具, {"label": "positive", "confidence": 1, "reason": "x"}))
    # 兜底用的是**闭包里带进来的用户原话**，不是模型给的理由。
    assert 结果["label"] == "negative"
    assert "兜底" in 结果["reason"]


def test_工具的_schema_参数是宽松的_str():
    工具 = build_sentiment_tool("随便")
    schema = 工具.params_json_schema
    assert schema["properties"]["label"]["type"] == "string"
    # 关键：不能是 enum —— 模型返回中文时会被 pydantic 校验拦下，工具就不执行了。
    assert "enum" not in schema["properties"]["label"]
    assert 工具.name == TOOL_NAME


def test_识别_agent_在第一个工具调用后停止():
    agent = build_sentiment_agent("今天真开心")
    assert agent.tool_use_behavior == "stop_on_first_tool"
    assert len(agent.tools) == 1
    assert agent.tools[0].name == TOOL_NAME
    assert agent.name == "进程1·情感识别"


# ---------------------------------------------------------------- 解析层


def test_解析工具输出_非法_json_返回_none():
    assert _parse_tool_output("这不是 JSON") is None
    assert _parse_tool_output(None) is None
    assert _parse_tool_output("[1, 2]") is None


def test_解析工具输出_合法_json_返回_dict():
    assert _parse_tool_output('{"label": "positive"}') == {"label": "positive"}
    assert _parse_tool_output({"label": "positive"}) == {"label": "positive"}


# ---------------------------------------------------------------- 进程1 的重试与兜底


def test_进程1_调用失败时重试并走关键词兜底(monkeypatch):
    调用次数 = []

    class _炸的Runner:
        @staticmethod
        async def run(*args, **kwargs):
            调用次数.append(1)
            raise RuntimeError("模型炸了")

    monkeypatch.setattr(sentiment_module, "Runner", _炸的Runner)
    monkeypatch.setattr(sentiment_module, "build_run_config", lambda *a, **k: None)

    结果 = asyncio.run(run_sentiment("面试又挂了，我很失望"))
    # 失败一次 + 重试一次 = 两次调用。
    assert len(调用次数) == 2
    assert 结果.label == "negative"
    assert "兜底" in 结果.reason


def test_进程1_模型没调工具时重试并走关键词兜底(monkeypatch):
    class _不调工具的Runner:
        @staticmethod
        async def run(*args, **kwargs):
            # final_output 是 SDK 的错误字符串，不是工具返回值。
            return _假的结果("Tool 'submit_sentiment' not found")

    monkeypatch.setattr(sentiment_module, "Runner", _不调工具的Runner)
    monkeypatch.setattr(sentiment_module, "build_run_config", lambda *a, **k: None)

    结果 = asyncio.run(run_sentiment("今天太顺利了，很开心"))
    assert 结果.label == "positive"
    assert "兜底" in 结果.reason


def test_进程1_拿到工具结果时直接返回(monkeypatch):
    class _调工具的Runner:
        @staticmethod
        async def run(*args, **kwargs):
            return _假的结果(
                json.dumps({"label": "negative", "confidence": 0.91, "reason": "受挫"})
            )

    monkeypatch.setattr(sentiment_module, "Runner", _调工具的Runner)
    monkeypatch.setattr(sentiment_module, "build_run_config", lambda *a, **k: None)

    结果 = asyncio.run(run_sentiment("面试又挂了"))
    assert 结果.label == "negative"
    assert 结果.confidence == pytest.approx(0.91)
    assert 结果.reason == "受挫"


# ---------------------------------------------------------------- 进程2 的路由与兜底


@pytest.mark.parametrize(
    ("极性", "期望分支"),
    [
        ("positive", "encourage"),
        ("negative", "comfort"),
        ("neutral", "acknowledge"),
    ],
)
def test_按极性选分支(极性: str, 期望分支: str):
    assert pick_mode(极性) == 期望分支


def test_未知极性落到陪伴分支():
    assert pick_mode("看不懂") == "acknowledge"
    assert RESPONDER_BY_LABEL["neutral"] == "acknowledge"


@pytest.mark.parametrize(
    ("分支", "期望名"),
    [
        ("encourage", "进程2·鼓励"),
        ("comfort", "进程2·排解"),
        ("acknowledge", "进程2·陪伴"),
    ],
)
def test_回应_agent_按分支命名(分支: str, 期望名: str):
    agent = build_responder_agent(分支)
    assert agent.name == 期望名
    # 进程2 不需要工具。
    assert agent.tools == []


def test_进程2_调用失败时走兜底文案(monkeypatch):
    class _炸的Runner:
        @staticmethod
        async def run(*args, **kwargs):
            raise RuntimeError("模型炸了")

    monkeypatch.setattr(responder_module, "Runner", _炸的Runner)
    monkeypatch.setattr(responder_module, "build_run_config", lambda *a, **k: None)

    分支, 回应 = asyncio.run(
        responder_module.run_responder(
            "面试又挂了", SentimentResult(label="negative", confidence=0.9, reason="受挫")
        )
    )
    assert 分支 == "comfort"
    assert 回应.startswith(FALLBACK_RESPONSE["comfort"])
    assert "生成失败" in 回应


def test_进程2_返回空内容时走兜底文案(monkeypatch):
    class _空内容的Runner:
        @staticmethod
        async def run(*args, **kwargs):
            return _假的结果("   ")

    monkeypatch.setattr(responder_module, "Runner", _空内容的Runner)
    monkeypatch.setattr(responder_module, "build_run_config", lambda *a, **k: None)

    分支, 回应 = asyncio.run(
        responder_module.run_responder(
            "今天真开心", SentimentResult(label="positive", confidence=0.9, reason="轻快")
        )
    )
    assert 分支 == "encourage"
    assert 回应 == FALLBACK_RESPONSE["encourage"]
