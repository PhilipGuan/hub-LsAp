"""标签归一化与关键词兜底的单元测试。

这两块是进程1 的「三道保险」的核心，必须有单独的测试盯着。
"""

from __future__ import annotations

import pytest

from emotion_agents.sentiment_utils import (
    build_sentiment_result,
    keyword_sentiment,
    normalize_confidence,
    normalize_label,
)


@pytest.mark.parametrize(
    ("原始值", "期望"),
    [
        ("positive", "positive"),
        ("negative", "negative"),
        ("neutral", "neutral"),
        ("POSITIVE", "positive"),
        ("  Negative  ", "negative"),
    ],
)
def test_英文枚举直通(原始值: str, 期望: str):
    assert normalize_label(原始值) == 期望


@pytest.mark.parametrize(
    ("原始值", "期望"),
    [
        ("沮丧", "negative"),
        ("负面", "negative"),
        ("悲伤", "negative"),
        ("开心", "positive"),
        ("积极", "positive"),
        ("中性", "neutral"),
        ("平和", "neutral"),
    ],
)
def test_中文标签归一化(原始值: str, 期望: str):
    assert normalize_label(原始值) == 期望


@pytest.mark.parametrize(
    ("原始值", "期望"),
    [("", "neutral"), (None, "neutral"), ("看不懂", "neutral")],
)
def test_无法识别时落到中性(原始值, 期望: str):
    assert normalize_label(原始值) == 期望


@pytest.mark.parametrize(
    ("原始值", "期望"),
    [
        (0.95, 0.95),
        (1.0, 1.0),
        (95, 0.95),
        (100, 1.0),
        (1.5, 0.015),
        (150, 1.0),
        (-1, 0.0),
        ("不是数字", 0.5),
        (None, 0.5),
    ],
)
def test_置信度归一化(原始值, 期望: float):
    assert normalize_confidence(原始值) == pytest.approx(期望)


def test_关键词兜底_识别负向():
    result = keyword_sentiment("面试又挂了，我已经很失望了")
    assert result.label == "negative"
    assert 0 < result.confidence <= 0.9
    assert "兜底" in result.reason


def test_关键词兜底_识别正向():
    result = keyword_sentiment("今天太顺利了，终于搞定了，很开心")
    assert result.label == "positive"


def test_关键词兜底_没有情绪词时是中性():
    result = keyword_sentiment("明天上午十点开会")
    assert result.label == "neutral"
    assert result.confidence == pytest.approx(0.3)


def test_拼装识别结果_标签与置信度都会被修正():
    result = build_sentiment_result("沮丧", 95, "  工作被否了  ")
    assert result.label == "negative"
    assert result.confidence == pytest.approx(0.95)
    assert result.reason == "工作被否了"


def test_拼装识别结果_非字符串标签不崩():
    result = build_sentiment_result(None, None, None)
    assert result.label == "neutral"
    assert result.confidence == pytest.approx(0.5)
    assert result.reason == ""
