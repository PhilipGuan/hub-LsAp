"""编排层（workflow.py）的单元测试。"""

from __future__ import annotations

import asyncio

import pytest

from emotion_agents import workflow
from emotion_agents.models import SentimentResult

from conftest import build_fake_deps


def _收集事件(协程):
    """把异步生成器的事件全部收集成列表。"""

    async def _跑():
        return [event async for event in 协程]

    return asyncio.run(_跑())


def test_事件顺序是_两个阶段加最终结果():
    workflow.configure(
        build_fake_deps(
            [SentimentResult(label="positive", confidence=0.9, reason="轻快")]
        )
    )
    events = _收集事件(workflow.analyze_stream("今天真开心"))
    assert [event.event for event in events] == ["stage", "stage", "final"]
    assert events[0].data["stage"] == "sentiment"
    assert events[1].data["stage"] == "respond"
    final = events[-1].data
    assert final["mode"] == "encourage"
    assert final["sentiment"]["label"] == "positive"
    assert len(final["trace"]) == 2


def test_阶段文案与两版契约一致():
    workflow.configure(
        build_fake_deps(
            [SentimentResult(label="negative", confidence=0.9, reason="受挫")]
        )
    )
    events = _收集事件(workflow.analyze_stream("面试又挂了"))
    assert events[0].data["label"] == "进程1 · 情感识别中…"
    assert events[1].data["label"] == "进程2 · 生成排解回应…"


def test_正向走鼓励分支():
    workflow.configure(
        build_fake_deps(
            [SentimentResult(label="positive", confidence=0.9, reason="轻快")]
        )
    )
    result = asyncio.run(workflow.analyze_once("今天真开心"))
    assert result.mode == "encourage"
    assert result.response == "你把方案改完了，太棒了。"
    assert result.trace[0].stage == "sentiment"
    assert result.trace[1].stage == "respond"


def test_负向走排解分支():
    workflow.configure(
        build_fake_deps(
            [SentimentResult(label="negative", confidence=0.85, reason="连续受挫")]
        )
    )
    result = asyncio.run(workflow.analyze_once("面试又挂了，我已经很失望"))
    assert result.mode == "comfort"
    assert result.response == "连着四次被拒，难受是正常的。"


def test_中性走陪伴分支():
    workflow.configure(
        build_fake_deps(
            [SentimentResult(label="neutral", confidence=0.6, reason="在陈述事实")]
        )
    )
    result = asyncio.run(workflow.analyze_once("明天上午十点的项目评审"))
    assert result.mode == "acknowledge"


def test_只跑进程1():
    workflow.configure(
        build_fake_deps(
            [SentimentResult(label="negative", confidence=0.8, reason="受挫")]
        )
    )
    result = asyncio.run(workflow.detect_sentiment("面试又挂了"))
    assert result.label == "negative"
    assert result.confidence == pytest.approx(0.8)


def test_只跑进程2():
    workflow.configure(build_fake_deps([]))
    mode, response = asyncio.run(
        workflow.respond(
            "面试又挂了",
            SentimentResult(label="negative", confidence=0.8, reason="受挫"),
        )
    )
    assert mode == "comfort"
    assert response == "连着四次被拒，难受是正常的。"


def test_进程2收到的是进程1的识别结果():
    deps = build_fake_deps(
        [SentimentResult(label="negative", confidence=0.85, reason="连续受挫")]
    )
    workflow.configure(deps)
    asyncio.run(workflow.analyze_once("面试又挂了，我已经很失望"))
    原话, 识别结果 = deps.responder.calls[0]
    assert 原话 == "面试又挂了，我已经很失望"
    assert 识别结果.label == "negative"
    assert 识别结果.reason == "连续受挫"
    assert 识别结果.confidence == pytest.approx(0.85)


def test_一次性分析_与流式分析结果一致():
    workflow.configure(
        build_fake_deps(
            [
                SentimentResult(label="neutral", confidence=0.6, reason="陈述"),
                SentimentResult(label="neutral", confidence=0.6, reason="陈述"),
            ]
        )
    )
    once = asyncio.run(workflow.analyze_once("明天上午十点开会"))
    events = _收集事件(workflow.analyze_stream("明天上午十点开会"))
    assert events[-1].data == once.model_dump()
