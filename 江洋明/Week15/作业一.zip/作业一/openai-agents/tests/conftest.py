"""测试夹具：手写的假实现，不连模型、不需要 API Key。

手写 Fake 而不是用 mock 框架，是因为这里的「假实现」本身就是被测契约的一部分：
它记录调用参数、按预设顺序返回结果、数量不符就报错 ——
这样测试能顺带验证「到底调了几次、传了什么」。
"""

from __future__ import annotations

import pytest

from emotion_agents import workflow
from emotion_agents.agents.responder import pick_mode
from emotion_agents.models import SentimentResult
from emotion_agents.workflow import AgentDeps


class FakeSentimentAgent:
    """进程1 的假实现：按预设顺序返回识别结果。

    预设里放异常对象时，会在调用处抛出 —— 用来测兜底路径。
    """

    def __init__(self, results: list) -> None:
        self._results = list(results)
        self.calls: list[str] = []

    async def __call__(self, text: str) -> SentimentResult:
        self.calls.append(text)
        if not self._results:
            raise AssertionError("FakeSentimentAgent 的预设结果已经用完了")
        result = self._results.pop(0)
        if isinstance(result, Exception):
            raise result
        return result


class FakeResponderAgent:
    """进程2 的假实现：按识别结果选分支，返回预置文本。"""

    def __init__(self, responses: dict[str, str]) -> None:
        self.responses = dict(responses)
        self.calls: list[tuple[str, SentimentResult]] = []

    async def __call__(
        self, text: str, sentiment: SentimentResult
    ) -> tuple[str, str]:
        self.calls.append((text, sentiment))
        mode = pick_mode(sentiment.label)
        return mode, self.responses.get(mode, "")


DEFAULT_RESPONSES = {
    "encourage": "你把方案改完了，太棒了。",
    "comfort": "连着四次被拒，难受是正常的。",
    "acknowledge": "评审在三楼，时间是十点。",
}


def build_fake_deps(
    sentiment_results: list,
    responses: dict[str, str] | None = None,
) -> AgentDeps:
    """构造一份假的编排层依赖。"""
    sentiment = FakeSentimentAgent(sentiment_results)
    responder = FakeResponderAgent(responses or DEFAULT_RESPONSES)
    return AgentDeps(sentiment=sentiment, responder=responder)


@pytest.fixture(autouse=True)
def _reset_workflow():
    """每个用例结束后把依赖恢复成默认实现。"""
    yield
    workflow.configure(None)


@pytest.fixture
def positive_result() -> SentimentResult:
    return SentimentResult(label="positive", confidence=0.92, reason="表达了完成后的轻松")


@pytest.fixture
def negative_result() -> SentimentResult:
    return SentimentResult(label="negative", confidence=0.88, reason="连续受挫的自述")
