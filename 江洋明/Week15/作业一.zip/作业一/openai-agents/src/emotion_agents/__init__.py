"""情感陪伴 Agent —— openai-agents 版。

作业原文要求的四个进程，在本包里是这样落的：

- **前端进程** —— ``frontend/index.html``（单文件 Vue 3，零构建）；
- **后端进程** —— ``api/app.py``（FastAPI，收前端输入、串流程、SSE 推流）；
- **进程1 情感识别** —— ``agents/sentiment.py`` 的 ``进程1·情感识别`` Agent
  （``@function_tool`` + ``tool_use_behavior="stop_on_first_tool"``）；
- **进程2 鼓励/排解** —— ``agents/responder.py`` 的 ``进程2·鼓励`` / ``进程2·排解``
  / ``进程2·陪伴`` 三个 Agent，由 ``workflow.py`` 里的 ``RESPONDER_BY_LABEL`` 分派。

编排入口是 ``workflow.py``（与 LangGraph 版同名同签名）。
"""

from __future__ import annotations

__version__ = "1.0.0"

__all__ = ["__version__"]
