"""openai-agents 版的模型客户端工厂（DeepSeek 适配）。

三个**实测得到**的约束，缺一个就跑不通：

1. **必须显式构造 ``AsyncOpenAI``**。``AsyncOpenAI()`` 的默认超时是 600 秒 ——
   一次卡死的请求能把整个 SSE 流挂住十分钟。显式传 ``timeout`` 与 ``max_retries``。

2. **必须用 ``OpenAIChatCompletionsModel`` + ``AsyncOpenAI`` 配对**。
   openai-agents 的默认模型走 Responses API，DeepSeek 没有这个端点。

3. **必须关掉思考模式**。``extra_body={"thinking": {"type": "disabled"}}`` ——
   DeepSeek 默认开思考模式，而思考模式拒绝强制 ``tool_choice``
   （服务端报 ``Thinking mode does not support this tool_choice``）。
"""

from __future__ import annotations

from functools import lru_cache

from agents import ModelSettings, RunConfig
from agents.models.openai_chatcompletions import OpenAIChatCompletionsModel
from openai import AsyncOpenAI

from .config import settings


class MissingAPIKeyError(RuntimeError):
    """未配置 API key。"""


def require_api_key() -> str:
    """取 API key，没配就抛出可读的错误。"""
    api_key = settings.api_key.strip()
    if not api_key:
        raise MissingAPIKeyError(
            "缺少 API key。请设置环境变量 EMOTION_AGENT_API_KEY（或 OPENAI_API_KEY），"
            "或在当前目录复制 .env.example 为 .env 并填写。"
        )
    return api_key


@lru_cache(maxsize=4)
def build_client() -> AsyncOpenAI:
    """构造（并缓存）一个 AsyncOpenAI 客户端。"""
    return AsyncOpenAI(
        api_key=require_api_key(),
        base_url=settings.base_url,
        timeout=settings.request_timeout_seconds,
        max_retries=settings.max_retries,
    )


@lru_cache(maxsize=8)
def build_model(model: str) -> OpenAIChatCompletionsModel:
    """构造（并缓存）一个 Chat Completions 模型的封装。"""
    return OpenAIChatCompletionsModel(model=model, openai_client=build_client())


def build_model_settings(
    temperature: float = 0.0, *, tool_choice: str | None = None
) -> ModelSettings:
    """构造模型参数。

    ``tool_choice`` 传工具名时会**强制**模型调用那个工具 ——
    关掉思考模式后 DeepSeek 接受这个参数，
    把「模型不调工具直接回文本」从静默错答变成可见的服务端报错。
    """
    return ModelSettings(
        temperature=temperature,
        tool_choice=tool_choice,
        extra_body={"thinking": {"type": settings.thinking_mode}},
    )


def build_run_config(
    model: str,
    *,
    temperature: float = 0.0,
    tool_choice: str | None = None,
    workflow_name: str = "",
) -> RunConfig:
    """构造 RunConfig —— 模型与参数都在这里给，Agent 上就不用重复指定。"""
    return RunConfig(
        model=build_model(model),
        model_settings=build_model_settings(temperature, tool_choice=tool_choice),
        # 再关一次 tracing：RunConfig 上的开关比全局开关更靠近调用点。
        tracing_disabled=True,
        workflow_name=workflow_name,
    )


__all__ = [
    "MissingAPIKeyError",
    "build_client",
    "build_model",
    "build_model_settings",
    "build_run_config",
    "require_api_key",
]
