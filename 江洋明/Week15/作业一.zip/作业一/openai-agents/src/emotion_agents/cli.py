"""命令行入口。

两种用法：

- ``python -m emotion_agents`` —— 启动 Web 服务（前端进程 + 后端进程）。
- ``python -m emotion_agents analyze "今天真开心"`` —— 跑一次分析，
  **结果 JSON 走 stdout，日志走 stderr**，方便脚本里直接取 JSON。
"""

from __future__ import annotations

import argparse
import asyncio
import json
import sys

from .config import settings
from .logging_config import setup_logging
from .workflow import IMPLEMENTATION_NAME, analyze_once


def _force_utf8() -> None:
    """Windows 控制台默认是 GBK，切到 UTF-8 免得中文日志炸掉。"""
    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is not None:
            try:
                reconfigure(encoding="utf-8", errors="replace")
            except (ValueError, OSError):
                pass


def browse_url(host: str, port: int) -> str:
    """给人看的访问地址。

    监听 ``0.0.0.0`` 时 ``0.0.0.0`` 本身不是能打开的地址 ——
    浏览器要连的是本机回环地址，或者局域网 IP。
    """
    if host in ("0.0.0.0", "::", ""):
        return f"http://127.0.0.1:{port}"
    return f"http://{host}:{port}"


def _serve(args: argparse.Namespace) -> None:
    import uvicorn

    print(
        f"[{IMPLEMENTATION_NAME}] 打开 {browse_url(args.host, args.port)}",
        file=sys.stderr,
    )
    uvicorn.run(
        "emotion_agents.api.app:app",
        host=args.host,
        port=args.port,
        reload=args.reload,
    )


def _analyze(text: str) -> int:
    setup_logging(settings.log_level)
    result = asyncio.run(analyze_once(text))
    print(json.dumps(result.model_dump(), ensure_ascii=False, indent=2))
    return 0


def main() -> None:
    _force_utf8()
    parser = argparse.ArgumentParser(
        description="情感陪伴 Agent（openai-agents 版）：进程1 情感识别，进程2 鼓励/排解"
    )
    sub = parser.add_subparsers(dest="command")

    serve_parser = sub.add_parser("serve", help="启动 Web 服务（默认）")
    serve_parser.add_argument(
        "--host",
        default=settings.web_host,
        help="监听地址，默认 127.0.0.1（要局域网访问用 0.0.0.0）",
    )
    serve_parser.add_argument(
        "--port", type=int, default=settings.web_port, help="监听端口"
    )
    serve_parser.add_argument(
        "--reload", action="store_true", help="改代码自动重启（开发用）"
    )
    serve_parser.set_defaults(func=_serve)

    analyze_parser = sub.add_parser("analyze", help="跑一次分析，结果 JSON 走 stdout")
    analyze_parser.add_argument("text", help="用户输入的原话")
    analyze_parser.set_defaults(func=lambda args: _analyze(args.text))

    # 不带子命令时默认 serve。
    args = parser.parse_args()
    if getattr(args, "func", None) is None:
        args = parser.parse_args(["serve"])

    raise SystemExit(args.func(args) or 0)


if __name__ == "__main__":
    main()
