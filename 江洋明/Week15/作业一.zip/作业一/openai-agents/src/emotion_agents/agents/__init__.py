"""openai-agents 版的 Agent 定义。

放在 ``__init__.py`` 里做两件事，是因为它们是**全局开关**，必须在任何
Agent 被构造之前生效：

1. ``set_default_openai_api("chat_completions")`` ——
   openai-agents 默认走 OpenAI 的 Responses API，
   而 DeepSeek 只有 ``/v1/chat/completions``，不改的话直接 404。

2. ``set_tracing_disabled(True)`` ——
   openai-agents 默认把每次运行的 trace 导到 OpenAI 的 tracing 后端，
   那需要另一个 API key + 外网。不关掉的话每次运行都会尝试上报并刷警告。

本包里的三个 Agent：

- ``sentiment`` —— 进程1，情感识别（用 ``@function_tool`` 拿结构化结果）；
- ``responder`` —— 进程2，正向鼓励 / 负向排解 / 中性陪伴（三个独立 Agent）。
"""

from __future__ import annotations

from agents import set_default_openai_api, set_tracing_disabled

set_default_openai_api("chat_completions")
set_tracing_disabled(True)

__all__ = ["set_default_openai_api", "set_tracing_disabled"]
