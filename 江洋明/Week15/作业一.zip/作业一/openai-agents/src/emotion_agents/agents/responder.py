"""进程2：鼓励 / 排解 / 陪伴 Agent。

三个分支是**三个独立的 Agent**，而不是一个 Agent 加三段提示词 ——
这样「正向走鼓励、负向走排解」在代码上就是三张不同的表，
路由逻辑（``RESPONDER_BY_LABEL``）也是一张一眼能看懂的字典。

作业原文只规定了「正向则鼓励，负面则排解」；
``neutral`` → ``acknowledge``（陪伴）是按同构模式补齐的第三条分支，
详见 README「中性分支」一节。

与 LangGraph 版的对应关系：

===========================  ==============================
LangGraph 版                  openai-agents 版
===========================  ==============================
条件边 ``route_after_sentiment``  ``RESPONDER_BY_LABEL``
节点 ``encourage``            Agent ``进程2·鼓励``
节点 ``comfort``              Agent ``进程2·排解``
节点 ``acknowledge``          Agent ``进程2·陪伴``
===========================  ==============================
"""

from __future__ import annotations

from typing import Any

from agents import Agent, Runner

from ..config import settings
from ..llm import build_run_config
from ..logging_config import get_logger
from ..models import MODE_CN, ResponseMode, SentimentResult
from ..prompts import FALLBACK_RESPONSE, RESPONDER_SYSTEM, build_respond_human

logger = get_logger("agents.responder")

#: 情感极性 → 分支。
#:
#: 作业原文只规定了「正向则鼓励，负面则排解」；
#: ``neutral`` → ``acknowledge``（陪伴）是按同构模式补齐的第三条分支。
RESPONDER_BY_LABEL: dict[str, ResponseMode] = {
    "positive": "encourage",
    "negative": "comfort",
    "neutral": "acknowledge",
}


def pick_mode(label: str) -> ResponseMode:
    """按情感极性选分支。

    未知极性一律落到 ``acknowledge``（陪伴）——
    保守起见，既不做鼓励也不做排解。和 LangGraph 版的条件边行为一致。
    """
    return RESPONDER_BY_LABEL.get(label, "acknowledge")


def build_responder_agent(mode: ResponseMode) -> Agent:
    """构造进程2 某分支的 Agent。

    进程2 不需要工具 —— 它的产出就是一段中文回应。
    """
    return Agent(
        name=f"进程2·{MODE_CN[mode]}",
        instructions=RESPONDER_SYSTEM[mode],
    )


def _extract_text(final_output: Any) -> str:
    """把 Agent 的产出统一成字符串。"""
    if isinstance(final_output, str):
        return final_output
    if isinstance(final_output, dict):
        for key in ("text", "response", "content"):
            value = final_output.get(key)
            if isinstance(value, str):
                return value
        return ""
    return str(final_output or "")


async def run_responder(
    text: str, sentiment: SentimentResult
) -> tuple[ResponseMode, str]:
    """跑进程2，返回 ``(分支, 回应)``。

    失败时用共用的兜底文案，保证链路总能给出完整结果。
    """
    mode = pick_mode(sentiment.label)
    agent = build_responder_agent(mode)
    config = build_run_config(
        settings.responder_model,
        temperature=0.7,
        workflow_name=f"进程2 {MODE_CN[mode]}",
    )
    human = build_respond_human(
        text, sentiment.label, sentiment.reason, sentiment.confidence
    )

    try:
        result = await Runner.run(agent, human, run_config=config, max_turns=3)
    except Exception as exc:  # noqa: BLE001 - 任何失败都要有兜底
        logger.warning("生成%s回应失败：%s", MODE_CN[mode], exc)
        return mode, (
            f"{FALLBACK_RESPONSE[mode]}"
            f"（生成失败：{type(exc).__name__}）"
        )

    response = _extract_text(result.final_output).strip()
    if not response:
        logger.warning("进程2 返回了空内容，走兜底文案")
        response = FALLBACK_RESPONSE[mode]

    logger.info("进程2 完成：%s（%d 字）", mode, len(response))
    return mode, response


__all__ = [
    "RESPONDER_BY_LABEL",
    "build_responder_agent",
    "pick_mode",
    "run_responder",
]
