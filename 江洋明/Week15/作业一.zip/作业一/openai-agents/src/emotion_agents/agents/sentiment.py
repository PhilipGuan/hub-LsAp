"""进程1：情感识别 Agent。

openai-agents 版的两个关键实测约束（都是踩出来的，别改）：

1. **不能用 ``Agent(output_type=PydanticModel)``**。
   那条路径会向服务端发 ``response_format={"type": "json_schema", ...}``，
   DeepSeek 直接返回 400 ``This response_format type is unavailable now``。
   → 改用 ``@function_tool``：模型必须调用 ``submit_sentiment`` 工具，
   工具的返回值就是 ``result.final_output``。

2. **工具签名要宽松**。
   ``@function_tool`` 默认 ``strict_mode=True``，参数会被 pydantic 校验。
   签名里写 ``Literal["positive", "negative", "neutral"]`` 的话，
   模型一旦返回「沮丧」，校验失败 → 工具不执行 →
   ``final_output`` 变成 SDK 的错误字符串 → 整条链路断掉。
   → 签名一律用 ``str``，归一化写在工具体内
   （用两版共用的 ``sentiment_utils``）。

三道保险（详见 README「进程1 的健壮性」）：

1. 工具内归一化 + 异常兜底（核心）；
2. 强制 ``tool_choice`` —— 模型不调工具就从「静默错答」变成「可见报错」；
3. 解析层重试 + 关键词兜底。
"""

from __future__ import annotations

import json
from typing import Any

from agents import Agent, Runner, function_tool

from ..config import settings
from ..llm import build_run_config
from ..logging_config import get_logger
from ..models import SentimentResult
from ..prompts import SENTIMENT_SYSTEM, build_sentiment_human
from ..sentiment_utils import build_sentiment_result, keyword_sentiment

logger = get_logger("agents.sentiment")

#: 工具名。强制 ``tool_choice`` 用它。
TOOL_NAME = "submit_sentiment"

#: 最多重试几次（每次重试都是一次完整的模型调用）。
MAX_RETRIES = 1


def build_sentiment_tool(text: str):
    """构造进程1 的工具。

    用闭包把**用户原话**带进工具体 —— 关键词兜底需要它，
    而让模型自己把原话再抄一遍是不可靠的。
    """

    @function_tool
    def submit_sentiment(label: str, confidence: float, reason: str) -> str:
        """提交情感识别结果。

        Args:
            label: 情感极性，取 positive（正向）/ negative（负向）/ neutral（中性）
            confidence: 置信度，0 到 1 之间的小数
            reason: 判断理由，一句话中文，指出触发情绪的具体词语或事件
        """
        try:
            result = build_sentiment_result(label, confidence, reason)
        except Exception as exc:  # noqa: BLE001 - 工具里绝不能抛，抛了工具就不算执行成功
            logger.warning("识别结果归一化失败，转关键词兜底：%s", exc)
            result = keyword_sentiment(
                text,
                reason=f"识别结果异常（{type(exc).__name__}），已用关键词兜底",
            )
        return json.dumps(result.model_dump(), ensure_ascii=False)

    return submit_sentiment


def build_sentiment_agent(text: str) -> Agent:
    """构造进程1 的 Agent。

    ``tool_use_behavior="stop_on_first_tool"`` 是关键 ——
    不加的话模型调完工具还会接着说一段话，
    ``final_output`` 拿到的就是那段闲聊而不是工具返回值。
    """
    tool = build_sentiment_tool(text)
    return Agent(
        name="进程1·情感识别",
        instructions=SENTIMENT_SYSTEM,
        tools=[tool],
        tool_use_behavior="stop_on_first_tool",
    )


def _parse_tool_output(final_output: Any) -> dict | None:
    """把 ``final_output`` 解析成 dict；不是合法 JSON 就返回 ``None``。

    工具没执行时 ``final_output`` 是 SDK 的错误字符串，
    ``json.loads`` 会抛 —— 这里统一转成 ``None`` 交给上层重试/兜底。
    """
    if isinstance(final_output, dict):
        return final_output
    if not isinstance(final_output, str):
        return None
    try:
        payload = json.loads(final_output)
    except (TypeError, ValueError):
        return None
    return payload if isinstance(payload, dict) else None


async def run_sentiment(text: str) -> SentimentResult:
    """跑进程1，返回情感识别结果。

    失败有界：最多重试 ``MAX_RETRIES`` 次，都失败就走关键词兜底，
    **保证永远能返回一份合法结果**，不会把整条链路带崩。
    """
    agent = build_sentiment_agent(text)
    config = build_run_config(
        settings.sentiment_model,
        temperature=0.0,
        tool_choice=TOOL_NAME,
        workflow_name="进程1 情感识别",
    )

    last_error: Exception | None = None
    for attempt in range(MAX_RETRIES + 1):
        try:
            result = await Runner.run(
                agent,
                build_sentiment_human(text),
                run_config=config,
                # 默认是 10，这里收紧到 3 —— 进程1 只需要「调一次工具」这一轮。
                max_turns=3,
            )
        except Exception as exc:  # noqa: BLE001 - 任何失败都要落到兜底
            last_error = exc
            logger.warning("进程1 第 %d 次调用失败：%s", attempt + 1, exc)
            continue

        payload = _parse_tool_output(result.final_output)
        if payload is None:
            last_error = ValueError(f"工具输出不是合法 JSON：{result.final_output!r}")
            logger.warning("进程1 第 %d 次调用没有拿到工具结果", attempt + 1)
            continue

        sentiment = build_sentiment_result(
            payload.get("label"), payload.get("confidence"), payload.get("reason")
        )
        logger.info("进程1 完成：%s %.2f", sentiment.label, sentiment.confidence)
        return sentiment

    fallback = keyword_sentiment(
        text,
        reason=f"模型调用失败（{type(last_error).__name__}），已用关键词兜底",
    )
    logger.info("进程1 走关键词兜底：%s", fallback.label)
    return fallback


__all__ = [
    "MAX_RETRIES",
    "TOOL_NAME",
    "build_sentiment_agent",
    "build_sentiment_tool",
    "run_sentiment",
]
