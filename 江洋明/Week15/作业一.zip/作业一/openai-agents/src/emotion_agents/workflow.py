"""编排层（后端进程的核心）—— openai-agents 版。

与 LangGraph 版的 ``workflow.py`` **同名同签名**：
``analyze_stream`` / ``analyze_once`` / ``detect_sentiment`` / ``respond``。
这样 ``api/app.py`` 才能在两版之间逐字一致。

**为什么用普通 Python 代码编排，而不是 handoff？**

作业要求的是一条确定的链路：「识别 → 正向鼓励 / 负向排解」。
handoff 把「下一步交给谁」的决定权交给模型，多一层不确定性；
而这里用一张字典（``RESPONDER_BY_LABEL``）做路由，
行为可预测、可单测、可复现 ——
和 LangGraph 版的条件边（``route_after_sentiment``）语义完全对应。

（这也是仓库 Week12 SQL Agent 已经确立的做法：编排用代码，不交给 handoff。）

**兜底放在哪一层？**

LangGraph 版在**节点内**兜底（节点抛异常 → 关键词兜底 / 固定文案）；
openai-agents 版在**编排层**兜底（依赖抛异常 → 同样的关键词兜底 / 固定文案）。
位置不同，但**用户看到的结果逐字一致** ——
这正是「两版等价」要证明的事。
"""

from __future__ import annotations

import time
from collections.abc import AsyncIterator, Awaitable, Callable
from dataclasses import dataclass

from .agents.responder import pick_mode, run_responder
from .agents.sentiment import run_sentiment
from .logging_config import get_logger
from .models import (
    MODE_CN,
    STAGE_LABEL_RESPOND,
    STAGE_LABEL_SENTIMENT,
    STAGE_RESPOND,
    STAGE_SENTIMENT,
    EmotionResult,
    ResponseMode,
    SentimentResult,
    WorkflowEvent,
    build_respond_step,
    build_sentiment_step,
)
from .prompts import FALLBACK_RESPONSE
from .sentiment_utils import keyword_sentiment

logger = get_logger("workflow")

#: 健康检查里报的实现框架名。
IMPLEMENTATION_NAME = "openai-agents"


@dataclass
class AgentDeps:
    """编排层依赖 —— 测试时整体替换成假实现，不需要真的连模型。"""

    #: 进程1：输入原话 → 识别结果
    sentiment: Callable[[str], Awaitable[SentimentResult]]
    #: 进程2：输入原话 + 识别结果 → (分支, 回应)
    responder: Callable[
        [str, SentimentResult], Awaitable[tuple[ResponseMode, str]]
    ]


#: 注入的依赖（测试用）。``None`` 表示用默认实现。
_deps: AgentDeps | None = None


def configure(deps: AgentDeps | None) -> None:
    """注入依赖（测试用）。传 ``None`` 恢复默认实现。"""
    global _deps
    _deps = deps


def default_deps() -> AgentDeps:
    """默认依赖 —— 直接用两个 Agent 的执行入口。"""
    return AgentDeps(sentiment=run_sentiment, responder=run_responder)


def get_deps() -> AgentDeps:
    """取当前依赖。"""
    return _deps if _deps is not None else default_deps()


async def _run_sentiment_safely(text: str) -> SentimentResult:
    """跑进程1，失败时用关键词兜底。

    兜底文案与 LangGraph 版的节点兜底**逐字一致**。
    """
    try:
        return await get_deps().sentiment(text)
    except Exception as exc:  # noqa: BLE001 - 任何失败都要有兜底
        logger.warning("进程1 失败，转关键词兜底：%s", exc)
        return keyword_sentiment(
            text, reason=f"模型调用失败（{type(exc).__name__}），已用关键词兜底"
        )


async def _run_responder_safely(
    text: str, sentiment: SentimentResult
) -> tuple[ResponseMode, str]:
    """跑进程2，失败时用固定文案兜底。

    兜底文案与 LangGraph 版的节点兜底**逐字一致**。
    """
    mode = pick_mode(sentiment.label)
    try:
        return await get_deps().responder(text, sentiment)
    except Exception as exc:  # noqa: BLE001 - 任何失败都要有兜底
        logger.warning("进程2 失败，转兜底文案：%s", exc)
        return mode, (
            f"{FALLBACK_RESPONSE[mode]}（生成失败：{type(exc).__name__}）"
        )


async def analyze_stream(text: str) -> AsyncIterator[WorkflowEvent]:
    """跑完整流程，逐个吐事件。

    事件顺序：``stage(sentiment)`` → ``stage(respond)`` → ``final``。
    和 LangGraph 版**完全一致** —— 同一段前端代码能直接跑在两版上。
    """
    yield WorkflowEvent(
        event="stage",
        data={"stage": STAGE_SENTIMENT, "label": STAGE_LABEL_SENTIMENT},
    )
    sentiment_started = time.perf_counter()
    sentiment = await _run_sentiment_safely(text)
    sentiment_elapsed = int((time.perf_counter() - sentiment_started) * 1000)

    # 路由：正向 → 鼓励，负向 → 排解，中性 → 陪伴。
    mode = pick_mode(sentiment.label)
    action = MODE_CN[mode]
    yield WorkflowEvent(
        event="stage",
        data={
            "stage": STAGE_RESPOND,
            "label": STAGE_LABEL_RESPOND.format(action=action),
        },
    )
    respond_started = time.perf_counter()
    mode, response = await _run_responder_safely(text, sentiment)
    respond_elapsed = int((time.perf_counter() - respond_started) * 1000)

    result = EmotionResult(
        text=text,
        sentiment=sentiment,
        mode=mode,
        response=response,
        trace=[
            build_sentiment_step(sentiment, sentiment_elapsed),
            build_respond_step(mode, response, respond_elapsed),
        ],
    )
    yield WorkflowEvent(event="final", data=result.model_dump())


async def analyze_once(text: str) -> EmotionResult:
    """跑完整流程，一次性拿结果（CLI 用）。

    复用 ``analyze_stream`` —— 保证「一次性」和「流式」两条路径的结果**永远一致**。
    """
    events = [event async for event in analyze_stream(text)]
    if not events or events[-1].event != "final":
        raise RuntimeError("流程没有走完")
    return EmotionResult.model_validate(events[-1].data)


async def detect_sentiment(text: str) -> SentimentResult:
    """**只跑进程1**（情感识别）。"""
    return await _run_sentiment_safely(text)


async def respond(
    text: str, sentiment: SentimentResult
) -> tuple[ResponseMode, str]:
    """**只跑进程2**（正向鼓励 / 负向排解 / 中性陪伴）。"""
    return await _run_responder_safely(text, sentiment)


__all__ = [
    "IMPLEMENTATION_NAME",
    "AgentDeps",
    "analyze_once",
    "analyze_stream",
    "configure",
    "default_deps",
    "detect_sentiment",
    "get_deps",
    "respond",
]
