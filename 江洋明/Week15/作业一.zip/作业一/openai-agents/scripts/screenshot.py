"""用 Playwright 跑一遍前端，生成作业截图。

用法（先起后端，再跑脚本）::

    # 终端 1
    python -X utf8 scripts/launch.py --port 8016
    # 终端 2
    python -X utf8 scripts/screenshot.py --base http://127.0.0.1:8015

产出（默认写到 ``../docs/screenshots/``）::

    01-首页.png
    02-正向-鼓励.png
    03-负向-排解.png
    04-中性-陪伴.png

注意：截图会**真的调用模型**，需要 ``.env`` 里配好 API Key。
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from playwright.sync_api import sync_playwright

PROJECT_ROOT = Path(__file__).resolve().parents[1]

#: 默认输出目录：作业一/docs/screenshots/openai-agents/
DEFAULT_OUT = PROJECT_ROOT.parent / "docs" / "screenshots" / "openai-agents"

#: 侧栏预置示例按钮的顺序：正向 / 负向 / 中性
EXAMPLE_ORDER = ("正向示例", "负向示例", "中性示例")


def find_chromium() -> str | None:
    """找 Playwright 已下载的 chromium。

    版本号可能和当前 playwright 不匹配（实测 1.64.1 只认
    ``chromium_headless_shell-1248``，本机装的是 ``chromium-1217``），
    所以手动定位可执行文件。
    """
    root = Path.home() / "AppData" / "Local" / "ms-playwright"
    if not root.exists():
        return None
    candidates = sorted(
        root.glob("chromium-*/chrome-win64/chrome.exe"), reverse=True
    )
    return str(candidates[0]) if candidates else None


def _wait_for_answer(page, 之前条数: int, timeout: int = 180_000) -> None:
    """等一次完整回答落地。

    完成标志是**执行轨迹又多出 2 条**（进程1 + 进程2）。
    注意不能只等「总数 >= 2」—— 第二轮开始时上一轮的轨迹已经在页面上了，
    条件会立刻成立，截出来的图会是「上一轮 + 这一轮刚发出去」。
    """
    page.wait_for_function(
        "(n) => document.querySelectorAll('.trace-item').length >= n",
        arg=之前条数 + 2,
        timeout=timeout,
    )
    page.wait_for_timeout(400)


def main() -> int:
    parser = argparse.ArgumentParser(description="生成前端交付截图")
    parser.add_argument("--base", default="http://127.0.0.1:8016")
    parser.add_argument("--out", default=str(DEFAULT_OUT))
    args = parser.parse_args()

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    executable = find_chromium()
    if executable is None:
        print("[错误] 找不到 chromium，请先执行：python -m playwright install chromium")
        return 1

    issues: list[str] = []

    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path=executable)
        ctx = browser.new_context(
            viewport={"width": 1440, "height": 900},
            device_scale_factor=1,
            locale="zh-CN",
        )
        page = ctx.new_page()
        page.on("console", lambda msg: print(f"[console] {msg.type}: {msg.text}"))
        page.on("pageerror", lambda exc: issues.append(f"页面异常：{exc}"))

        # ---- 01 首页 ----
        page.goto(args.base, wait_until="networkidle")
        # 等 Vue 挂载完成：加载遮罩 #boot 是脚本在 Vue 起来之后才移除的。
        # （只看 .ex 是不够的 —— Vue 没加载时 v-for 会留下一个空的 .ex 按钮。）
        page.wait_for_selector("#boot", state="detached", timeout=30000)
        page.wait_for_selector(".ex", timeout=15000)
        page.wait_for_timeout(600)
        page.screenshot(path=str(out_dir / "01-首页.png"))
        print("已保存 01-首页.png")

        if page.locator(".ex").count() < 3:
            issues.append("侧栏预置示例少于 3 条")
        pill = page.locator(".pill").first.inner_text() or ""
        if "模型已就绪" not in pill:
            issues.append(f"顶部没有显示「模型已就绪」，实际是「{pill.strip()}」")

        # ---- 02/03/04 三种情绪 ----
        files = ("02-正向-鼓励.png", "03-负向-排解.png", "04-中性-陪伴.png")
        for index, title in enumerate(EXAMPLE_ORDER):
            page.fill("textarea", "")
            之前条数 = page.locator(".trace-item").count()
            page.locator(".ex", has_text=title).first.click()
            _wait_for_answer(page, 之前条数)
            page.screenshot(path=str(out_dir / files[index]))
            print(f"已保存 {files[index]}")

        # 校验：三条回答的徽章都出现了
        badges = page.locator(".badge").all_inner_texts()
        if len(badges) < 6:
            issues.append(f"徽章数量是 {len(badges)}，预期至少 6（每轮 2 个）")

        browser.close()

    if issues:
        print("\n发现问题：", file=sys.stderr)
        for item in issues:
            print(f"  - {item}", file=sys.stderr)
        return 1
    print("\n全部截图完成。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
