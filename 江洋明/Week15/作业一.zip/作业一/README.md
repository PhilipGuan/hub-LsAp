# 第十五周作业一 · 情感陪伴 Agent（LangGraph 版 + openai-agents 版）

作业原文：

> 作业1: 分别使用 langgraph 和 openai-agents 实现如下的逻辑：
> 　进程1，接受请求进行情感识别
> 　进程2，得到识别结果后，正向则鼓励，负面则排解。
> 　后端进程：接受前端输入，串联进程1和进程。
> 　前端进程：用户输入。

## 一、作业原文的四个进程 ↔ 代码位置

这是本作业的**第一屏对照表** —— 作业里点名的每一个进程，在代码里落在哪一行。

| 作业原文的「进程」 | 职责 | LangGraph 版 | openai-agents 版 |
| --- | --- | --- | --- |
| **前端进程** | 用户输入 | `langgraph/frontend/index.html` | `openai-agents/frontend/index.html` |
| **后端进程** | 接受前端输入，串联进程1 与进程2 | `langgraph/src/emotion_langgraph/api/app.py` | `openai-agents/src/emotion_agents/api/app.py` |
| **进程1 · 情感识别** | 接受请求，判定情绪极性 | `graph/nodes.py:sentiment_node`（`build_structured_chain` 结构化输出） | `agents/sentiment.py:run_sentiment`（`@function_tool` + `stop_on_first_tool`） |
| **进程2 · 鼓励 / 排解** | 拿到识别结果，正向鼓励、负向排解 | `graph/nodes.py:responder_node` × 3 分支 + `graph/routing.py` 条件边 | `agents/responder.py:run_responder` × 3 个 Agent + `RESPONDER_BY_LABEL` |
| **（串联关系）** | 后端进程怎么把 1、2 接起来 | `workflow.py:analyze_stream`（图执行） | `workflow.py:analyze_stream`（Python 代码编排） |

两个版本**目录结构、包深度完全对称**（`src/<包名>/...`），因此：

- `config.py` / `models.py` / `prompts.py` / `logging_config.py` / `sentiment_utils.py` /
  `api/app.py` / `api/schemas.py` —— **7 个文件逐字一致**（`tests/test_parity.py` 用字节比对守住）；
- 差异全部收敛在 `graph/`（LangGraph）与 `agents/`（openai-agents）两套框架代码 + 各自的 `workflow.py` / `llm.py`。

```
15-江洋明-第十五周作业/作业一/
├── README.md                   ← 本文件
├── pyproject.toml              ← 跨版本 parity 测试的配置（testpaths 只指向 tests/）
├── tests/test_parity.py        ← 19 个跨版本一致性断言
├── docs/
│   ├── 01-架构与进程映射.md
│   ├── 02-两版实现对照.md        ← 同一句话的双框架实测记录
│   └── screenshots/
│       ├── langgraph/{01-首页,02-正向-鼓励,03-负向-排解,04-中性-陪伴}.png
│       └── openai-agents/{01-首页,02-正向-鼓励,03-负向-排解,04-中性-陪伴}.png
├── langgraph/                  ← 版本一：LangGraph
└── openai-agents/              ← 版本二：openai-agents（作业二的被构建对象）
```

## 二、跑起来

两个版本都是**独立可运行**的工程，各自有 `requirements.txt`、`.env`、`run.bat` / `run.sh`。

```bash
# 版本一：LangGraph（默认 8015）
cd langgraph
pip install -r requirements.txt
cp .env.example .env          # Windows: copy .env.example .env
# 在 .env 里填 EMOTION_AGENT_API_KEY
python -X utf8 scripts/launch.py        # 或直接双击 run.bat

# 版本二：openai-agents（默认 8016）
cd ../openai-agents
pip install -r requirements.txt
cp .env.example .env
python -X utf8 scripts/launch.py
```

浏览器打开启动器打印的地址（`http://127.0.0.1:8015` / `:8016`）。
`scripts/launch.py` 会自动检查 `.env` 与依赖、缺失就自动补装，并自动打开浏览器。

> 本机 8000 端口被别的容器长期占用，所以两个版本分别用 **8015 / 8016**，端口一律从配置读。

命令行也能直接跑一次分析（结果 JSON 走 stdout，日志走 stderr）：

```bash
PYTHONPATH=src python -X utf8 -m emotion_agents analyze "今天终于把方案改完了，太开心了"
```

## 三、后端进程：只做协议转换，不写业务

`api/app.py` 在两个版本之间**逐字一致**，全部业务逻辑在 `workflow.py` 及其下游。

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| GET | `/` | 前端单文件页面 |
| GET | `/api/health` | 健康检查，**只返回有没有配 key，不返回 key** |
| GET | `/api/examples` | 预置示例（前端示例按钮的单一数据源） |
| POST | `/api/analyze` | SSE 流式：进程1 → 进程2 |
| POST | `/api/sentiment` | **只跑进程1** |
| POST | `/api/respond` | **只跑进程2**（入参带识别结果） |

后两个独立端点让「进程1 / 进程2 是两个可独立调用的组件」从口头声明变成**可验证事实** —— 老师可以单独测进程1。

SSE 事件协议（两版一致）：

```
event: stage   data: {"stage":"sentiment","label":"进程1 · 情感识别中…"}
event: stage   data: {"stage":"respond","label":"进程2 · 生成鼓励回应…"}
event: final   data: {EmotionResult 的 JSON}
event: error   data: {"message":"..."}
```

`stage` 的取值**只有 `sentiment` / `respond` 两个** —— 不让框架的节点名（LangGraph）或 Agent 名（openai-agents）漏到前端协议里。

## 四、前端进程：单文件 Vue 3，零构建

- `frontend/index.html` 一个文件搞定，Vue 3 走 CDN，**没有 npm、没有打包步骤**；
- SSE 用 `fetch` + `ReadableStream` + `TextDecoder` **手工分帧**（`EventSource` 不能发 POST）；
- Vue 本地化副本优先（`./vendor/vue.global.prod.js`），`onerror` 时回退 CDN；容器内离线可用；
- 左侧栏直接把「四个进程」的调用关系画出来，回复气泡显示 **情感徽章 + 置信度 + 识别理由 + 回应正文 + 两个进程的执行轨迹时间线**。

## 五、中性分支（作业未定义，按同构补齐）

作业原文只规定「正向则鼓励，负面则排解」两条分支。本实现补了一条同构的第三分支：

| 情感极性（进程1 输出） | 分支（进程2） | 动作 |
| --- | --- | --- |
| `positive` | `encourage` | 鼓励 |
| `negative` | `comfort` | 排解 |
| `neutral` | `acknowledge` | 陪伴（承接内容 + 开放式提问） |

两个枚举**刻意不共用字面量**：`neutral` 是「情感极性」，`acknowledge` 是「走了哪条分支」，混用会让前端映射出歧义。
未知极性一律落到 `acknowledge`（保守：既不鼓励也不排解）。

## 六、进程1 的健壮性：三道保险

DeepSeek 这个 OpenAI 兼容端点上，模型**不保证**按你要求的格式返回。所以进程1 有三层防护：

1. **归一化 + 兜底在工具/结构化输出内部**（核心）
   标签归一化顺序：英文枚举 → 中文别名（「正向」「沮丧」…） → 情绪词扫描 → 中性；
   置信度 `>1 且 ≤100` 视作百分数除以 100，其余截断到 `[0,1]`；
   **任何异常都被吞掉**，工具照样返回一份合法 JSON，绝不让整条链路断掉。
2. **强制 `tool_choice`**（openai-agents 版）
   模型不调工具就从「静默错答」变成「可见的服务端报错」。
3. **有界重试 + 关键词兜底**
   解析失败最多重试 1 次，再失败就扫中文情绪词定极性，`reason` 注明「已用关键词兜底」。

进程2 失败时返回固定兜底文案。**两版兜底文案逐字一致**（放在共用的 `prompts.py` 里）。

## 七、实测踩过的坑（都是 DeepSeek 端的硬约束）

| 现象 | 原因 | 本项目的做法 |
| --- | --- | --- |
| `This response_format type is unavailable now` | `with_structured_output` 默认 `method="json_schema"`，DeepSeek 不支持 | 显式 `method="function_calling"` |
| `This response_format type is unavailable now`（agents 版） | `Agent(output_type=PydanticModel)` 会发 `response_format` | 改用 `@function_tool` + `tool_use_behavior="stop_on_first_tool"` |
| `Thinking mode does not support this tool_choice` | DeepSeek 默认开思考模式，思考模式拒绝强制 tool_choice | 请求体带 `extra_body={"thinking":{"type":"disabled"}}` |
| 工具参数校验失败 → 链路断 | `@function_tool` 默认 `strict_mode=True`，参数用 pydantic 校验 | 工具签名一律用宽松 `str`，归一化写在工体内 |
| `final_output` 拿到的是闲聊不是工具返回值 | 模型调完工具还会接着说话 | `tool_use_behavior="stop_on_first_tool"` |
| 请求挂十分钟 | `AsyncOpenAI()` 默认超时 600s | 显式 `timeout=60, max_retries=1` |
| DeepSeek 没有 Responses API | agents 默认走 Responses | `set_default_openai_api("chat_completions")` + `OpenAIChatCompletionsModel` |
| tracing 往 OpenAI 后端发数据 | agents 默认开启 | `set_tracing_disabled(True)` + `RunConfig(tracing_disabled=True)` |
| LangGraph `aget_state` 抛 `ValueError` | 没配 checkpointer | 终态取**最后一个 `values` chunk** |

## 八、测试

不需要 API Key（模型调用全部 mock）。

```bash
cd langgraph      && python -X utf8 -m pytest -q     # 66 passed
cd openai-agents  && python -X utf8 -m pytest -q     # 79 passed
cd ..             && python -X utf8 -m pytest -q     # 19 passed（跨版本 parity）
python -X utf8 -m ruff check src tests              # 干净
```

跨版本 parity 测试（`tests/test_parity.py`）钉住四件事：

1. **7 个共用文件逐字一致**（字节比对）；
2. **两版目录里没有「未认领的新文件」** —— 谁改了什么一眼能看出来；
3. **前端协议一致** —— 两份 html 抽出的接口地址、SSE 事件名、DOM id 集合完全相同；
4. **同一份假数据，两版产出字段级相等的结果**（除耗时）。

> 注意 pytest 的坑：两版都有 `tests/test_api.py`，同目录下会 `import file mismatch`。
> 所以两版各自在自己的目录里跑，根目录的 `pyproject.toml` 用 `testpaths = ["tests"]` 只跑 parity。

## 九、重新生成交付截图

两个版本各有自己的截图脚本（Playwright + Chromium），默认写到 `作业一/docs/screenshots/<版本>/`：

```bash
cd langgraph
python -X utf8 scripts/launch.py            # 先把服务起起来
python -X utf8 scripts/screenshot.py --base http://127.0.0.1:8015

cd ../openai-agents
python -X utf8 scripts/launch.py            # 8016
python -X utf8 scripts/screenshot.py --base http://127.0.0.1:8016
```

产出四张：首页、正向→鼓励、负向→排解、中性→陪伴。

## 十、更多文档

- `docs/01-架构与进程映射.md` —— 四个进程的完整调用链、时序、状态与契约；
- `docs/02-两版实现对照.md` —— 逐点对照 + **同一句话在两个框架上的实测记录**；
- `../作业二/README.md` —— 作业二：把 openai-agents 版打成 Docker 镜像。
