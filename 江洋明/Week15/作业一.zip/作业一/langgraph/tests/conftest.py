"""测试夹具：手写的假实现，不连模型、不需要 API Key。

手写 Fake 而不是用 mock 框架，是因为这里的「假实现」本身就是被测契约的一部分：
它记录调用参数、按预设顺序返回结果、数量不符就报错 ——
这样测试能顺带验证「到底调了几次、传了什么」。
"""

from __future__ import annotations

import pytest

from emotion_langgraph import workflow
from emotion_langgraph.graph.nodes import GraphDeps
from emotion_langgraph.models import SentimentResult


class FakeSentimentChain:
    """进程1 的假链：按预设顺序返回识别结果。

    预设里放异常对象时，会在调用处抛出 —— 用来测兜底路径。
    """

    def __init__(self, results: list) -> None:
        self._results = list(results)
        self.calls: list[dict] = []

    def invoke(self, payload: dict):
        self.calls.append(payload)
        if not self._results:
            raise AssertionError("FakeSentimentChain 的预设结果已经用完了")
        result = self._results.pop(0)
        if isinstance(result, Exception):
            raise result
        return result


class FakeResponderChain:
    """进程2 的假链：固定返回一段文本，但会记录收到的参数。"""

    def __init__(self, text: str) -> None:
        self.text = text
        self.calls: list[dict] = []

    def invoke(self, payload: dict):
        self.calls.append(payload)
        return self.text


def build_fake_deps(
    sentiment_results: list,
    responses: dict[str, str] | None = None,
) -> GraphDeps:
    """构造一份假的节点依赖。"""
    responses = responses or {
        "encourage": "你把方案改完了，太棒了。",
        "comfort": "连着四次被拒，难受是正常的。",
        "acknowledge": "评审在三楼，时间是十点。",
    }
    return GraphDeps(
        sentiment_chain=FakeSentimentChain(sentiment_results),
        responder_chains={
            mode: FakeResponderChain(text) for mode, text in responses.items()
        },
    )


@pytest.fixture(autouse=True)
def _reset_workflow():
    """每个用例结束后把依赖恢复成默认实现。"""
    yield
    workflow.configure(None)


@pytest.fixture
def positive_result() -> SentimentResult:
    return SentimentResult(label="positive", confidence=0.92, reason="表达了完成后的轻松")


@pytest.fixture
def negative_result() -> SentimentResult:
    return SentimentResult(label="negative", confidence=0.88, reason="连续受挫的自述")
