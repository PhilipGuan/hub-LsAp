"""前端的静态检查。

前端是单文件 ``index.html``，没有构建步骤，所以用静态断言守住几条关键约束：
不许出现硬编码密钥、必须用 fetch + ReadableStream（EventSource 不能发 POST）、
stage 只有两个。
"""

from __future__ import annotations

import re
from pathlib import Path

import pytest

FRONTEND_HTML = Path(__file__).resolve().parents[1] / "frontend" / "index.html"


@pytest.fixture(scope="module")
def html() -> str:
    assert FRONTEND_HTML.is_file(), f"找不到前端文件：{FRONTEND_HTML}"
    return FRONTEND_HTML.read_text(encoding="utf-8")


def test_前端文件存在(html: str):
    assert "<!DOCTYPE html>" in html
    assert 'id="app"' in html


def test_前端没有硬编码密钥(html: str):
    assert "sk-" not in html
    assert "EMOTION_AGENT_API_KEY" not in html
    assert "DEEPSEEK_API_KEY" not in html


def test_用_fetch_加_ReadableStream_而不是_EventSource(html: str):
    assert "fetch(" in html
    assert "getReader()" in html
    assert "TextDecoder" in html
    # EventSource 只能 GET，不能带请求体 —— 用它就发不出 POST。
    assert "new EventSource" not in html


def test_调用的后端接口都在(html: str):
    for path in ("/api/analyze", "/api/health", "/api/examples"):
        assert path in html


def test_阶段只有两个(html: str):
    match = re.search(r"STAGE_ORDER\s*=\s*\[([^\]]*)\]", html)
    assert match is not None, "找不到 STAGE_ORDER"
    items = [item.strip().strip("'\"") for item in match.group(1).split(",")]
    items = [item for item in items if item]
    assert items == ["sentiment", "respond"]


def test_本地_vue_优先_并回退_cdn(html: str):
    assert "./vendor/vue.global.prod.js" in html
    assert "onerror=" in html
    assert "unpkg.com/vue@3" in html
