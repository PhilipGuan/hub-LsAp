"""LangGraph 状态图的单元测试。"""

from __future__ import annotations

import pytest

from emotion_langgraph.graph.build import (
    build_graph,
    build_respond_graph,
    build_sentiment_graph,
)
from emotion_langgraph.graph.routing import route_after_sentiment
from emotion_langgraph.graph.state import GraphState
from emotion_langgraph.models import SentimentResult

from conftest import build_fake_deps


def _state(label: str) -> GraphState:
    return GraphState(text="随便一句话", sentiment=SentimentResult(label=label))


@pytest.mark.parametrize(
    ("极性", "期望节点"),
    [
        ("positive", "encourage"),
        ("negative", "comfort"),
        ("neutral", "acknowledge"),
    ],
)
def test_条件边按极性分叉(极性: str, 期望节点: str):
    assert route_after_sentiment(_state(极性)) == 期望节点


def test_条件边在缺少识别结果时落到陪伴分支():
    assert route_after_sentiment(GraphState(text="没有结果")) == "acknowledge"


def test_全图_正向走鼓励分支():
    deps = build_fake_deps(
        [SentimentResult(label="positive", confidence=0.9, reason="表达得很轻快")]
    )
    graph = build_graph(deps)
    result = graph.invoke({"text": "今天终于搞定了，太开心了"})
    assert result["mode"] == "encourage"
    assert result["sentiment"].label == "positive"
    assert result["response"] == "你把方案改完了，太棒了。"
    assert len(result["trace"]) == 2
    assert result["trace"][0].stage == "sentiment"
    assert result["trace"][1].stage == "respond"


def test_全图_负向走排解分支():
    deps = build_fake_deps(
        [SentimentResult(label="negative", confidence=0.85, reason="连续受挫")]
    )
    graph = build_graph(deps)
    result = graph.invoke({"text": "面试又挂了，我已经很失望"})
    assert result["mode"] == "comfort"
    assert result["response"] == "连着四次被拒，难受是正常的。"


def test_全图_中性走陪伴分支():
    deps = build_fake_deps(
        [SentimentResult(label="neutral", confidence=0.6, reason="在陈述事实")]
    )
    graph = build_graph(deps)
    result = graph.invoke({"text": "明天上午十点的项目评审"})
    assert result["mode"] == "acknowledge"


def test_只跑进程1的图_不产出分支():
    deps = build_fake_deps(
        [SentimentResult(label="neutral", confidence=0.6, reason="在陈述事实")]
    )
    graph = build_sentiment_graph(deps)
    result = graph.invoke({"text": "明天上午十点的项目评审"})
    assert result["sentiment"].label == "neutral"
    assert result.get("mode") is None
    assert result.get("response", "") == ""
    # 进程2 一次都没被调用。
    assert deps.responder_chains["encourage"].calls == []


def test_只跑进程2的图_用已有的识别结果选分支():
    deps = build_fake_deps([])
    graph = build_respond_graph(deps)
    result = graph.invoke(
        {
            "text": "面试又挂了，我已经很失望",
            "sentiment": SentimentResult(label="negative", confidence=0.85, reason="连续受挫"),
        }
    )
    assert result["mode"] == "comfort"
    assert result["response"] == "连着四次被拒，难受是正常的。"
    # 进程1 一次都没被调用。
    assert deps.sentiment_chain.calls == []


def test_模型调用失败时退回关键词兜底():
    deps = build_fake_deps([RuntimeError("模型炸了")])
    graph = build_graph(deps)
    result = graph.invoke({"text": "面试又挂了，我已经很失望"})
    # 关键词兜底识别出负向，并走排解分支。
    assert result["sentiment"].label == "negative"
    assert "兜底" in result["sentiment"].reason
    assert result["mode"] == "comfort"


def test_进程2收到的是进程1的识别结果():
    deps = build_fake_deps(
        [SentimentResult(label="negative", confidence=0.85, reason="连续受挫")]
    )
    graph = build_graph(deps)
    graph.invoke({"text": "面试又挂了，我已经很失望"})
    call = deps.responder_chains["comfort"].calls[0]
    assert call["text"] == "面试又挂了，我已经很失望"
    assert call["label_cn"] == "负向"
    assert call["reason"] == "连续受挫"
    assert call["confidence"] == pytest.approx(0.85)
