"""编排层（workflow.py）的单元测试。"""

from __future__ import annotations

import asyncio

import pytest

from emotion_langgraph import workflow
from emotion_langgraph.models import SentimentResult

from conftest import build_fake_deps


def _收集事件(协程):
    """把异步生成器的事件全部收集成列表。"""

    async def _跑():
        return [event async for event in 协程]

    return asyncio.run(_跑())


def test_事件顺序是_两个阶段加最终结果():
    workflow.configure(
        build_fake_deps(
            [SentimentResult(label="positive", confidence=0.9, reason="轻快")]
        )
    )
    events = _收集事件(workflow.analyze_stream("今天真开心"))
    assert [event.event for event in events] == ["stage", "stage", "final"]
    assert events[0].data["stage"] == "sentiment"
    assert events[1].data["stage"] == "respond"
    final = events[-1].data
    assert final["mode"] == "encourage"
    assert final["sentiment"]["label"] == "positive"
    assert len(final["trace"]) == 2


def test_只跑进程1():
    workflow.configure(
        build_fake_deps(
            [SentimentResult(label="negative", confidence=0.8, reason="受挫")]
        )
    )
    result = asyncio.run(workflow.detect_sentiment("面试又挂了"))
    assert result.label == "negative"
    assert result.confidence == pytest.approx(0.8)


def test_只跑进程2():
    workflow.configure(build_fake_deps([]))
    mode, response = asyncio.run(
        workflow.respond(
            "面试又挂了",
            SentimentResult(label="negative", confidence=0.8, reason="受挫"),
        )
    )
    assert mode == "comfort"
    assert response == "连着四次被拒，难受是正常的。"


def test_一次性分析_与流式分析结果一致():
    workflow.configure(
        build_fake_deps(
            [
                SentimentResult(label="neutral", confidence=0.6, reason="陈述"),
                SentimentResult(label="neutral", confidence=0.6, reason="陈述"),
            ]
        )
    )
    once = asyncio.run(workflow.analyze_once("明天上午十点开会"))
    events = _收集事件(workflow.analyze_stream("明天上午十点开会"))
    assert events[-1].data == once.model_dump()
