"""配置解析的单元测试。"""

from __future__ import annotations

from pathlib import Path

from emotion_langgraph import config


def test_解析_env_文件_忽略注释与空行(tmp_path: Path):
    env_file = tmp_path / ".env"
    env_file.write_text(
        "\n".join(
            [
                "# 这是一行注释",
                "",
                "EMOTION_AGENT_API_KEY=sk-test-123",
                'EMOTION_AGENT_MODEL="deepseek-flash"',
                "EMOTION_AGENT_THINKING='disabled'",
                "不是键值对",
            ]
        ),
        encoding="utf-8",
    )
    values = config._parse_env_file(env_file)
    assert values["EMOTION_AGENT_API_KEY"] == "sk-test-123"
    assert values["EMOTION_AGENT_MODEL"] == "deepseek-flash"
    assert values["EMOTION_AGENT_THINKING"] == "disabled"
    assert "不是键值对" not in values


def test_env_文件不存在时返回空字典(tmp_path: Path):
    assert config._parse_env_file(tmp_path / "不存在.env") == {}


def test_环境变量整体优先于_env_文件(monkeypatch):
    monkeypatch.setenv("OPENAI_API_KEY", "来自环境变量")
    file_env = {"EMOTION_AGENT_API_KEY": "来自文件"}
    # 兼容变量名（OPENAI_API_KEY）在环境变量里，主变量名（EMOTION_AGENT_API_KEY）在文件里
    # → 环境变量赢。
    assert config._env_str(file_env, ("EMOTION_AGENT_API_KEY", "OPENAI_API_KEY")) == (
        "来自环境变量"
    )
    monkeypatch.delenv("OPENAI_API_KEY")
    assert config._env_str(file_env, ("EMOTION_AGENT_API_KEY", "OPENAI_API_KEY")) == (
        "来自文件"
    )


def test_数字解析失败时回落到默认值():
    file_env = {"EMOTION_AGENT_REQUEST_TIMEOUT": "不是数字"}
    assert config._env_float(file_env, ("EMOTION_AGENT_REQUEST_TIMEOUT",), 60.0) == 60.0
    assert config._env_int(file_env, ("EMOTION_AGENT_MAX_RETRIES",), 1) == 1


def test_默认配置_不含密钥且端口不是_8000():
    settings = config.from_env()
    assert settings.base_url == "https://api.deepseek.com/v1"
    assert settings.sentiment_model == "deepseek-flash"
    assert settings.responder_model == "deepseek-v4-pro"
    assert settings.thinking_mode == "disabled"
    # 代码里的默认端口：两版统一 8015（.env 可以改）。
    assert config.Settings().web_port == 8015
    # 本机 8000 端口被别的容器占着，实际生效的端口必须避开。
    assert settings.web_port != 8000
    assert settings.api_key_present == bool(settings.api_key)
