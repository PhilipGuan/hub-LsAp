#!/usr/bin/env bash
# 启动 LangGraph 版的情感陪伴 Agent。
# 用法：./run.sh            本机启动
#       ./run.sh --lan      局域网启动
set -euo pipefail
cd "$(dirname "$0")"
python3 -X utf8 scripts/launch.py "$@"
