@echo off
REM NOTE: keep this file ASCII-only on purpose.
REM cmd.exe mis-parses non-ASCII batch files when code page switching and
REM cd/goto appear together. All Chinese messages live in scripts/launch.py.
cd /d "%~dp0"
python -X utf8 scripts\launch.py %*
