"""情感陪伴 Agent —— LangGraph 版。

作业原文要求的四个进程，在本包里是这样落的：

- **前端进程** —— ``frontend/index.html``（单文件 Vue 3，零构建）；
- **后端进程** —— ``api/app.py``（FastAPI，收前端输入、串流程、SSE 推流）；
- **进程1 情感识别** —— ``graph/nodes.py`` 的 ``sentiment`` 节点；
- **进程2 鼓励/排解** —— ``graph/nodes.py`` 的 ``encourage`` / ``comfort`` / ``acknowledge``
  三个节点，由 ``graph/routing.py`` 的条件边分叉。

编排入口是 ``workflow.py``（与 openai-agents 版同名同签名）。
"""

from __future__ import annotations

__version__ = "1.0.0"

__all__ = ["__version__"]
