"""运行配置。

设计约定（沿用仓库既有做法）：

- **API key 只从环境变量 / ``.env`` 读取**，源码里不出现任何真实密钥；
- 优先级：环境变量 > 项目根 ``.env`` > 上级目录 ``.env``（跨作业便利回退）；
- 所有字段都能用环境变量覆盖，同一份代码既能跑本地也能进容器。

这个文件在 LangGraph 版与 openai-agents 版之间**逐字一致**（两版包深度相同，
都用相对导入，包名不出现在文件里）。
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

#: ``src/<包名>/config.py`` -> ``parents[2]`` 即「作业一/<版本目录>」。
#: （openai-agents 版是 ``src/emotion_agents/config.py``，目录深度完全相同。）
PROJECT_ROOT = Path(__file__).resolve().parents[2]

#: 便利回退的 ``.env`` 列表，按顺序取第一个能提供 key 的文件。
FALLBACK_ENV_FILES: tuple[Path, ...] = (
    PROJECT_ROOT / ".env",
    PROJECT_ROOT.parent / ".env",
)


def _parse_env_file(path: Path) -> dict[str, str]:
    """极简 ``.env`` 解析器。

    只支持 ``KEY=VALUE``，忽略 ``#`` 注释与空行，值两端的引号会被剥掉。
    刻意不引 ``python-dotenv`` —— 这个仓库的既有做法就是手写解析器，
    少一个依赖，容器镜像也小一点。
    """
    result: dict[str, str] = {}
    if not path.is_file():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        key = key.strip()
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
            value = value[1:-1]
        if key:
            result[key] = value
    return result


def _load_env_files() -> dict[str, str]:
    """按优先级合并 ``.env`` 文件（后面的不覆盖前面的）。"""
    merged: dict[str, str] = {}
    for path in reversed(FALLBACK_ENV_FILES):
        merged.update(_parse_env_file(path))
    return merged


def _env_str(
    env: dict[str, str], names: tuple[str, ...], default: str = ""
) -> str:
    """按名字列表取第一个非空值。

    优先级：**环境变量整体优先于 ``.env``**（先在所有名字里找环境变量，
    都找不到再在所有名字里找 ``.env``）。
    这样「本机临时 export 一个兼容变量名」总是能覆盖 ``.env`` 里的主变量名。
    """
    for name in names:
        value = os.environ.get(name, "").strip()
        if value:
            return value
    for name in names:
        value = env.get(name, "").strip()
        if value:
            return value
    return default


def _env_float(
    env: dict[str, str], names: tuple[str, ...], default: float
) -> float:
    """取浮点数，解析失败回落到默认值而不是抛异常。"""
    raw = _env_str(env, names)
    if not raw:
        return default
    try:
        return float(raw)
    except ValueError:
        return default


def _env_int(env: dict[str, str], names: tuple[str, ...], default: int) -> int:
    """取整数，解析失败回落到默认值。"""
    raw = _env_str(env, names)
    if not raw:
        return default
    try:
        return int(raw)
    except ValueError:
        return default


@dataclass(frozen=True)
class Settings:
    """全部运行参数。frozen 是为了避免运行中被偷偷改掉。"""

    api_key: str = ""
    base_url: str = "https://api.deepseek.com/v1"
    sentiment_model: str = "deepseek-flash"
    responder_model: str = "deepseek-v4-pro"
    thinking_mode: str = "disabled"
    request_timeout_seconds: float = 60.0
    max_retries: int = 1
    max_text_chars: int = 2000
    web_host: str = "127.0.0.1"
    web_port: int = 8015
    log_level: str = "INFO"

    @property
    def api_key_present(self) -> bool:
        """只回答「有没有配 key」，不回答「key 是什么」。"""
        return bool(self.api_key)


def from_env() -> Settings:
    """从环境变量与 ``.env`` 构造配置。"""
    env = _load_env_files()
    return Settings(
        api_key=_env_str(
            env,
            (
                "EMOTION_AGENT_API_KEY",
                "OPENAI_API_KEY",
                "DEEPSEEK_API_KEY",
                "LLM_API_KEY",
            ),
        ),
        base_url=_env_str(
            env,
            (
                "EMOTION_AGENT_BASE_URL",
                "OPENAI_BASE_URL",
                "DEEPSEEK_BASE_URL",
                "LLM_BASE_URL",
            ),
            "https://api.deepseek.com/v1",
        ).rstrip("/"),
        sentiment_model=_env_str(
            env, ("EMOTION_AGENT_MODEL",), "deepseek-flash"
        ),
        responder_model=_env_str(
            env, ("EMOTION_AGENT_RESPONDER_MODEL",), "deepseek-v4-pro"
        ),
        thinking_mode=_env_str(
            env, ("EMOTION_AGENT_THINKING",), "disabled"
        ),
        request_timeout_seconds=_env_float(
            env, ("EMOTION_AGENT_REQUEST_TIMEOUT",), 60.0
        ),
        max_retries=_env_int(env, ("EMOTION_AGENT_MAX_RETRIES",), 1),
        max_text_chars=_env_int(env, ("EMOTION_AGENT_MAX_TEXT_CHARS",), 2000),
        web_host=_env_str(env, ("WEB_HOST",), "127.0.0.1"),
        web_port=_env_int(env, ("WEB_PORT",), 8015),
        log_level=_env_str(env, ("EMOTION_AGENT_LOG_LEVEL", "LOG_LEVEL"), "INFO"),
    )


#: 模块级单例：进程内只解析一次。测试用 ``monkeypatch.setattr`` 替换。
settings = from_env()
