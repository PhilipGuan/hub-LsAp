"""情感标签归一化与关键词兜底。

**两个框架版本共用这一份实现** —— 进程1 的健壮性逻辑必须两版完全一致，
否则「两版等价」的对照实验就不成立（LangGraph 版的结构化输出与 openai-agents 版的
工具函数都调用这里的函数）。

这个文件在 LangGraph 版与 openai-agents 版之间**逐字一致**。
"""

from __future__ import annotations

from .models import SentimentResult

#: 合法极性。
VALID_LABELS = ("positive", "negative", "neutral")

#: 英文枚举直通。
ENGLISH_LABELS = frozenset(VALID_LABELS)

#: 中文标签别名 —— 模型偶尔不按枚举返回，会给"正向""负面""沮丧"这类词。
#: 必须**先于关键词扫描**处理：像"负面"这种词本身不在情绪词表里，
#: 走关键词扫描会掉进 neutral。
LABEL_ALIASES: dict[str, str] = {
    "正向": "positive",
    "积极": "positive",
    "乐观": "positive",
    "开心": "positive",
    "高兴": "positive",
    "愉快": "positive",
    "兴奋": "positive",
    "满意": "positive",
    "正面": "positive",
    "负面": "negative",
    "负向": "negative",
    "消极": "negative",
    "沮丧": "negative",
    "难过": "negative",
    "悲伤": "negative",
    "伤心": "negative",
    "生气": "negative",
    "愤怒": "negative",
    "焦虑": "negative",
    "负面情绪": "negative",
    "中性": "neutral",
    "平和": "neutral",
    "中性情绪": "neutral",
    "一般": "neutral",
    "普通": "neutral",
    "无": "neutral",
}

#: 负向情绪词（用于关键词兜底）。
NEGATIVE_WORDS: tuple[str, ...] = (
    "失望", "沮丧", "难过", "伤心", "焦虑", "紧张", "崩溃", "委屈", "愤怒",
    "生气", "烦躁", "痛苦", "疲惫", "孤独", "害怕", "恐惧", "无助", "迷茫",
    "后悔", "糟糕", "糟心", "失败", "搞砸", "讨厌", "受不了", "没意思",
    "压力", "焦虑不安", "低落", "痛苦不堪", "撑不住", "扛不住", "卡住",
)

#: 正向情绪词（用于关键词兜底）。
POSITIVE_WORDS: tuple[str, ...] = (
    "开心", "高兴", "兴奋", "激动", "顺利", "成功", "满意", "喜欢", "感恩",
    "幸福", "轻松", "痛快", "搞定", "完成", "通过", "收获", "进步", "值得",
    "太棒", "真好", "舒服", "期待", "温暖", "治愈", "给力", "漂亮", "搞定",
    "好起来", "有希望", "顺利搞定",
)

#: 关键词兜底时给出的理由。
FALLBACK_REASON = "模型未按格式输出，已用关键词兜底"


def normalize_label(raw: str | None) -> str:
    """把模型给的标签归一化成合法极性。

    顺序：英文枚举 → 中文别名 → 情绪词扫描 → 中性。
    任何输入都返回 ``positive`` / ``negative`` / ``neutral`` 之一，**不抛异常**。
    """
    text = (raw or "").strip()
    if not text:
        return "neutral"

    lowered = text.lower()
    if lowered in ENGLISH_LABELS:
        return lowered

    for alias, label in LABEL_ALIASES.items():
        if alias in text:
            return label

    for word in NEGATIVE_WORDS:
        if word in text:
            return "negative"
    for word in POSITIVE_WORDS:
        if word in text:
            return "positive"

    return "neutral"


def normalize_confidence(raw: object) -> float:
    """把置信度归一化到 ``[0, 1]``。

    规则：

    - 不是数字 → 0.5；
    - ``> 1`` 且 ``<= 100`` → 视为百分数，除以 100；
    - 其他情况 → 截断到 ``[0, 1]``。
    """
    try:
        value = float(raw)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return 0.5
    if value != value:  # NaN
        return 0.5
    if 1.0 < value <= 100.0:
        value = value / 100.0
    return max(0.0, min(1.0, value))


def keyword_sentiment(
    text: str, reason: str = FALLBACK_REASON
) -> SentimentResult:
    """关键词兜底：扫中文情绪词定极性。

    模型没按格式输出（或调用彻底失败）时走这里，保证链路**永远能出一份合法结果**。
    """
    lowered = (text or "").lower()
    negative = sum(1 for word in NEGATIVE_WORDS if word in lowered)
    positive = sum(1 for word in POSITIVE_WORDS if word in lowered)

    if negative == 0 and positive == 0:
        return SentimentResult(label="neutral", confidence=0.3, reason=reason)
    if negative >= positive:
        label = "negative"
        confidence = 0.5 + 0.1 * negative
    else:
        label = "positive"
        confidence = 0.5 + 0.1 * positive
    return SentimentResult(
        label=label,
        confidence=round(min(0.9, confidence), 2),
        reason=reason,
    )


def build_sentiment_result(
    raw_label: object, raw_confidence: object, raw_reason: object
) -> SentimentResult:
    """把模型返回的三个原始字段拼成合法的 :class:`SentimentResult`。"""
    reason = raw_reason if isinstance(raw_reason, str) else ""
    return SentimentResult(
        label=normalize_label(raw_label if isinstance(raw_label, str) else None),
        confidence=normalize_confidence(raw_confidence),
        reason=reason.strip(),
    )


__all__ = [
    "FALLBACK_REASON",
    "LABEL_ALIASES",
    "NEGATIVE_WORDS",
    "POSITIVE_WORDS",
    "VALID_LABELS",
    "build_sentiment_result",
    "keyword_sentiment",
    "normalize_confidence",
    "normalize_label",
]
