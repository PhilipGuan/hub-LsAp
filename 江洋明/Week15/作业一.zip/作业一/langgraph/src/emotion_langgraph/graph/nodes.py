"""图的节点实现。

三个要点：

1. **节点一律写同步函数**。LangGraph 在 ``astream`` 下会把同步节点丢到线程池执行，
   既不阻塞事件循环，又能被 ``invoke`` 同步调用（测试友好）。
   写成 ``async def`` 会让 ``graph.invoke()`` 直接报
   ``TypeError: No synchronous function provided``。

2. **进入节点时推 stage 事件**。用 ``get_stream_writer()`` 往流里写自定义事件，
   它会比同一步的 ``updates`` 更早到达前端 —— 正好对上「进程开始了」的语义。
   （``stream_mode="updates"`` 里的事件是**节点结束后**才有的，
   只靠它的话前端要干等 3~5 秒。）

3. **失败有界**。模型调用异常时退回关键词兜底，保证链路总能出一份合法结果。
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field

from langchain_core.runnables import Runnable
from langgraph.config import get_stream_writer

from ..logging_config import get_logger
from ..models import (
    LABEL_CN,
    MODE_CN,
    STAGE_LABEL_RESPOND,
    STAGE_LABEL_SENTIMENT,
    STAGE_RESPOND,
    STAGE_SENTIMENT,
    ResponseMode,
    SentimentResult,
    build_respond_step,
    build_sentiment_step,
)
from ..prompts import FALLBACK_RESPONSE
from ..sentiment_utils import keyword_sentiment, normalize_confidence, normalize_label
from .state import GraphState

logger = get_logger("graph")

#: stage 事件里用的固定名字 —— 只有两个，别让节点名漏到前端协议里。
#: （定义在共用的 ``models.py`` 里，两个框架版本保证一致。）


@dataclass
class GraphDeps:
    """节点依赖。

    测试时整体替换成假实现，不需要真的连模型。
    """

    #: 输入 ``{"text": str}`` → 输出 ``SentimentResult``
    sentiment_chain: Runnable
    #: mode → （输入 ``{"text","label_cn","reason","confidence"}`` → 输出 ``str``）
    responder_chains: dict[str, Runnable] = field(default_factory=dict)


def emit_stage(stage: str, label: str) -> None:
    """把 stage 事件推进流里。

    ``get_stream_writer()`` 只在图的执行上下文里存在；
    图外直接调用节点（比如单元测试单跑节点）会抛错 —— 吞掉即可，不影响主流程。
    """
    try:
        writer = get_stream_writer()
    except Exception:  # noqa: BLE001 - 图外调用属于正常情况
        return
    writer({"stage": stage, "label": label})


def _to_text(raw: object) -> str:
    """把链路的输出统一成字符串。

    ``prompt | llm`` 的输出是 ``AIMessage``，取它的 ``content``；
    content 偶尔是列表（多模态），那就拼接文本片段。
    """
    if isinstance(raw, str):
        return raw
    content = getattr(raw, "content", None)
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = [
            item.get("text", "") if isinstance(item, dict) else str(item)
            for item in content
        ]
        return "".join(parts)
    return str(raw)


def _as_sentiment(raw: object) -> SentimentResult:
    """把链路产物统一成 ``SentimentResult``。"""
    if isinstance(raw, SentimentResult):
        return raw
    if isinstance(raw, dict):
        return SentimentResult(
            label=normalize_label(raw.get("label")),
            confidence=normalize_confidence(raw.get("confidence")),
            reason=str(raw.get("reason") or ""),
        )
    # 兜底：当成没识别出来
    return keyword_sentiment("")


def make_sentiment_node(deps: GraphDeps):
    """进程1：情感识别节点。"""

    def sentiment_node(state: GraphState) -> dict:
        started = time.perf_counter()
        emit_stage(STAGE_SENTIMENT, STAGE_LABEL_SENTIMENT)
        try:
            raw = deps.sentiment_chain.invoke({"text": state.text})
        except Exception as exc:  # noqa: BLE001 - 任何失败都要有兜底
            logger.warning("情感识别失败，转关键词兜底：%s", exc)
            result = keyword_sentiment(
                state.text, reason=f"模型调用失败（{type(exc).__name__}），已用关键词兜底"
            )
        else:
            result = _as_sentiment(raw)
        elapsed = int((time.perf_counter() - started) * 1000)
        step = build_sentiment_step(result, elapsed)
        logger.info("进程1 完成：%s %.2f", result.label, result.confidence)
        return {"sentiment": result, "trace": [step]}

    return sentiment_node


def make_responder_node(deps: GraphDeps, mode: ResponseMode):
    """进程2：某一分支的回应节点（鼓励 / 排解 / 陪伴）。"""

    def responder_node(state: GraphState) -> dict:
        started = time.perf_counter()
        action = MODE_CN[mode]
        emit_stage(STAGE_RESPOND, STAGE_LABEL_RESPOND.format(action=action))
        sentiment = state.sentiment
        label = sentiment.label if sentiment is not None else "neutral"
        chain = deps.responder_chains.get(mode)
        try:
            if chain is None:
                raise KeyError(f"没有 {mode} 分支的回应链")
            raw = chain.invoke(
                {
                    "text": state.text,
                    "label_cn": LABEL_CN.get(label, "中性"),
                    "reason": sentiment.reason if sentiment else "",
                    "confidence": sentiment.confidence if sentiment else 0.0,
                }
            )
            response = _to_text(raw)
        except Exception as exc:  # noqa: BLE001 - 任何失败都要有兜底
            logger.warning("生成%s回应失败：%s", action, exc)
            response = (
                f"{FALLBACK_RESPONSE[mode]}"
                f"（生成失败：{type(exc).__name__}）"
            )
        elapsed = int((time.perf_counter() - started) * 1000)
        step = build_respond_step(mode, response, elapsed)
        logger.info("进程2 完成：%s（%d 字）", mode, len(response))
        return {"mode": mode, "response": response, "trace": [step]}

    return responder_node


def make_dispatch_node():
    """只做路由的空节点。

    给「只跑进程2」的那张图用：图必须有节点才能挂条件边，
    而这个节点不改状态，只是把控制权交给条件边。
    """

    def dispatch_node(state: GraphState) -> dict:
        emit_stage(STAGE_RESPOND, "进程2 · 准备回应…")
        return {}

    return dispatch_node


__all__ = [
    "STAGE_RESPOND",
    "STAGE_SENTIMENT",
    "GraphDeps",
    "emit_stage",
    "make_dispatch_node",
    "make_responder_node",
    "make_sentiment_node",
]
