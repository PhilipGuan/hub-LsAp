"""图的条件边路由函数。

全部是**纯函数**：输入 ``GraphState``，输出下一个节点名。
把路由从节点里抽出来单独测，是本次用 LangGraph 相对手写状态机的主要收益之一。

「正向 → 鼓励、负向 → 排解」这条规则就落在这一个函数里，
openai-agents 版有一份**语义等价**的实现（``agents/responder.py`` 的
``RESPONDER_BY_LABEL``），两版对照实验时重点核对的就是这里。
"""

from __future__ import annotations

from .state import GraphState

#: 三个分支的节点名。
NEXT_ENCOURAGE = "encourage"
NEXT_COMFORT = "comfort"
NEXT_ACKNOWLEDGE = "acknowledge"

#: 情感极性 → 目标节点名。
#:
#: 作业原文只规定了「正向则鼓励，负面则排解」；
#: ``neutral`` → ``acknowledge``（陪伴）是按同构模式补齐的第三条分支，
#: 详见 README「中性分支」一节。
NODE_BY_LABEL: dict[str, str] = {
    "positive": NEXT_ENCOURAGE,
    "negative": NEXT_COMFORT,
    "neutral": NEXT_ACKNOWLEDGE,
}


def route_after_sentiment(state: GraphState) -> str:
    """识别之后选分支。

    未知极性一律落到 ``acknowledge``（陪伴）——
    保守起见，既不做鼓励也不做排解。
    """
    sentiment = state.sentiment
    label = sentiment.label if sentiment is not None else "neutral"
    return NODE_BY_LABEL.get(label, NEXT_ACKNOWLEDGE)


__all__ = [
    "NEXT_ACKNOWLEDGE",
    "NEXT_COMFORT",
    "NEXT_ENCOURAGE",
    "NODE_BY_LABEL",
    "route_after_sentiment",
]
