"""LangGraph 状态定义。

LangGraph 1.x 原生支持用 Pydantic 模型当状态 schema。
``Annotated[list, add]`` 声明追加语义 —— 每个节点返回自己那一步的 trace，
LangGraph 会把它们合并进累计的 ``trace``。
"""

from __future__ import annotations

from operator import add
from typing import Annotated

from pydantic import BaseModel, Field

from ..models import ResponseMode, SentimentResult, TraceStep


class GraphState(BaseModel):
    """一次「识别 → 回应」的状态。"""

    #: 用户原话
    text: str
    #: 进程1 的产物
    sentiment: SentimentResult | None = None
    #: 进程2 走了哪条分支
    mode: ResponseMode | None = None
    #: 进程2 的产物
    response: str = ""
    #: 两个进程的执行轨迹（跨节点累积）
    trace: Annotated[list[TraceStep], add] = Field(default_factory=list)


__all__ = ["GraphState"]
