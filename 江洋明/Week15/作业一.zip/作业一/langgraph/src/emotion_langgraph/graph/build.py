"""把节点装配成 LangGraph 状态图。

全图（后端进程串联进程1 与进程2）::

    START → sentiment ──positive──▶ encourage   ──▶ END
                      ──negative──▶ comfort     ──▶ END
                      ──neutral───▶ acknowledge ──▶ END

另外两张小图，让「进程1」「进程2」可以**单独跑** ——
这是把作业里「进程1 / 进程2」落成两个独立组件的证据：

- ``sentiment_graph``：``START → sentiment → END``
  —— 供 ``POST /api/sentiment``（只做情感识别）。
- ``respond_graph``：``START → dispatch → 条件边 → 三个分支之一 → END``
  —— 供 ``POST /api/respond``（拿已有的识别结果，只做回应）。

三张图共用同一批节点实现（``make_sentiment_node`` / ``make_responder_node``），
所以「单跑」和「串跑」的行为完全一致。
"""

from __future__ import annotations

from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import Runnable
from langgraph.graph import END, START, StateGraph

from ..config import settings
from ..llm import build_chat_model, build_structured_chain
from ..models import ResponseMode, SentimentResult
from ..prompts import RESPOND_HUMAN, RESPONDER_SYSTEM, SENTIMENT_SYSTEM
from .nodes import (
    GraphDeps,
    make_dispatch_node,
    make_responder_node,
    make_sentiment_node,
)
from .routing import route_after_sentiment
from .state import GraphState

#: 图的递归上限。节点数固定（最多 4 步），10 足够富余。
RECURSION_LIMIT = 10

#: 进程1 的提示词模板（可直接单测，不需要模型）。
SENTIMENT_PROMPT = ChatPromptTemplate.from_messages(
    [
        ("system", SENTIMENT_SYSTEM),
        ("human", "请判断下面这段话的情绪倾向：\n\n<text>\n{text}\n</text>"),
    ]
)

#: 进程2 各分支的提示词模板。三个分支**只有 system 不同**，
#: human 模板完全一致 —— 保证喂给模型的信息在三个分支之间可比。
RESPONDER_PROMPTS: dict[ResponseMode, ChatPromptTemplate] = {
    mode: ChatPromptTemplate.from_messages(
        [
            ("system", RESPONDER_SYSTEM[mode]),
            ("human", RESPOND_HUMAN),
        ]
    )
    for mode in RESPONDER_SYSTEM
}


def build_sentiment_chain() -> Runnable:
    """进程1 的链：输入 ``{"text": ...}``，输出 ``SentimentResult``。

    ``SentimentResult.label`` 是 ``Literal`` 枚举 —— function_calling 的
    JSON Schema 会把它下发给模型，服务端层面就限制了取值，
    所以这里拿到的一定是合法极性。
    """
    structured = build_structured_chain(
        SentimentResult, settings.sentiment_model, temperature=0.0
    )
    return SENTIMENT_PROMPT | structured


def build_responder_chain(mode: ResponseMode) -> Runnable:
    """进程2 某分支的链：输入 ``{"text","label_cn","reason","confidence"}``，输出文本。"""
    llm = build_chat_model(settings.responder_model, temperature=0.7)
    return RESPONDER_PROMPTS[mode] | llm


def default_deps() -> GraphDeps:
    """构造默认依赖（惰性构造链，没 key 时也能导入本模块）。"""
    return GraphDeps(
        sentiment_chain=build_sentiment_chain(),
        responder_chains={
            mode: build_responder_chain(mode) for mode in RESPONDER_SYSTEM
        },
    )


def _add_responder_nodes(
    graph: StateGraph, deps: GraphDeps
) -> None:
    """把三个回应节点挂到图上，并接好到 END 的边。"""
    for mode in RESPONDER_SYSTEM:
        graph.add_node(mode, make_responder_node(deps, mode))
        graph.add_edge(mode, END)
    graph.add_conditional_edges(
        "sentiment",
        route_after_sentiment,
        {mode: mode for mode in RESPONDER_SYSTEM},
    )


def build_graph(deps: GraphDeps | None = None):
    """装配并编译全图（进程1 → 条件边 → 进程2）。"""
    deps = deps if deps is not None else default_deps()

    graph = StateGraph(GraphState)
    graph.add_node("sentiment", make_sentiment_node(deps))
    graph.add_edge(START, "sentiment")
    _add_responder_nodes(graph, deps)
    return graph.compile()


def build_sentiment_graph(deps: GraphDeps | None = None):
    """装配并编译「只跑进程1」的图。"""
    deps = deps if deps is not None else default_deps()

    graph = StateGraph(GraphState)
    graph.add_node("sentiment", make_sentiment_node(deps))
    graph.add_edge(START, "sentiment")
    graph.add_edge("sentiment", END)
    return graph.compile()


def build_respond_graph(deps: GraphDeps | None = None):
    """装配并编译「只跑进程2」的图。

    ``dispatch`` 是个空节点：图必须有节点才能挂条件边，
    它不改状态，只把控制权交给条件边。
    """
    deps = deps if deps is not None else default_deps()

    graph = StateGraph(GraphState)
    graph.add_node("dispatch", make_dispatch_node())
    graph.add_edge(START, "dispatch")
    for mode in RESPONDER_SYSTEM:
        graph.add_node(mode, make_responder_node(deps, mode))
        graph.add_edge(mode, END)
    graph.add_conditional_edges(
        "dispatch",
        route_after_sentiment,
        {mode: mode for mode in RESPONDER_SYSTEM},
    )
    return graph.compile()


__all__ = [
    "RECURSION_LIMIT",
    "RESPONDER_PROMPTS",
    "SENTIMENT_PROMPT",
    "build_graph",
    "build_responder_chain",
    "build_respond_graph",
    "build_sentiment_chain",
    "build_sentiment_graph",
    "default_deps",
]
