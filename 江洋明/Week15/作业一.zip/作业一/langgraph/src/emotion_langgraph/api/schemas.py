"""HTTP 层的请求/响应模型。

这个文件在 LangGraph 版与 openai-agents 版之间**逐字一致**。
"""

from __future__ import annotations

from pydantic import BaseModel, Field

from ..models import ResponseMode, SentimentResult

#: 输入长度上限 —— 与 ``Settings.max_text_chars`` 对齐，避免超长文本打爆模型上下文。
MAX_TEXT_CHARS = 2000


class AnalyzeRequest(BaseModel):
    """``POST /api/analyze`` 的请求体：只传用户原话。"""

    text: str = Field(
        min_length=1,
        max_length=MAX_TEXT_CHARS,
        description="用户输入的原话",
    )


class RespondRequest(BaseModel):
    """``POST /api/respond`` 的请求体：带上进程1 的识别结果，只跑进程2。"""

    text: str = Field(
        min_length=1,
        max_length=MAX_TEXT_CHARS,
        description="用户输入的原话",
    )
    sentiment: SentimentResult = Field(description="进程1 的识别结果")


class SentimentResponse(BaseModel):
    """``POST /api/sentiment`` 的响应：只跑进程1。"""

    sentiment: SentimentResult = Field(description="情感识别结果")


class RespondResponse(BaseModel):
    """``POST /api/respond`` 的响应：只跑进程2。"""

    mode: ResponseMode = Field(description="进程2 走了哪条分支")
    response: str = Field(description="进程2 生成的回应")


class ExampleItem(BaseModel):
    """一个预置示例。"""

    title: str = Field(description="按钮上的文字")
    text: str = Field(description="点下去会填进输入框的内容")


class ExampleList(BaseModel):
    """预置示例列表。"""

    examples: list[ExampleItem] = Field(description="示例列表")


class HealthResponse(BaseModel):
    """健康检查。

    **只回答「有没有配 key」，绝不返回 key 本身。**
    """

    status: str = Field(description="ok / degraded")
    api_key_present: bool = Field(description="是否已配置 API key（不返回 key 内容）")
    base_url: str = Field(description="模型服务地址")
    sentiment_model: str = Field(description="进程1 使用的模型")
    responder_model: str = Field(description="进程2 使用的模型")
    thinking: str = Field(description="思考模式设置")
    implementation: str = Field(
        description="实现框架标识，取自 workflow.IMPLEMENTATION_NAME"
    )
