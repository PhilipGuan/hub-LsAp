"""FastAPI 后端入口（后端进程）。

作业原文对「后端进程」的定义是：**接受前端输入，串联进程1 和进程2**。
所以本文件只做三件事：

1. 收前端输入（``POST /api/analyze``）；
2. 把输入交给编排层 ``workflow``；
3. 把编排层吐出来的事件原样转成 SSE 推给前端。

**这里不写任何业务逻辑。** 情感识别怎么调模型、走了哪条分支，全部在 ``workflow.py``
及其下游的 ``graph/``（LangGraph 版）或 ``agents/``（openai-agents 版）里。

路由表：

=========  ===================  ==========================================
方法      路径                 说明
=========  ===================  ==========================================
GET       ``/``                前端单文件页面
GET       ``/api/health``      健康检查（**不泄露 key**）
GET       ``/api/examples``    预置示例（前端示例按钮的单一数据源）
POST      ``/api/analyze``     SSE 流式分析：进程1 → 进程2
POST      ``/api/sentiment``   **只跑进程1**
POST      ``/api/respond``     **只跑进程2**
=========  ===================  ==========================================

后两个独立端点让「进程1 / 进程2 是两个可独立调用的组件」从口头声明变成**可验证事实**，
老师也可以单独测进程1。

这个文件在 LangGraph 版与 openai-agents 版之间**逐字一致** ——
两个版本的全部差异都收敛在 ``workflow.py`` 与它下游的框架代码里。
"""

from __future__ import annotations

import json
from collections.abc import AsyncIterator
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles

from .. import workflow
from ..config import settings
from ..logging_config import get_logger
from .schemas import (
    AnalyzeRequest,
    ExampleItem,
    ExampleList,
    HealthResponse,
    RespondRequest,
    RespondResponse,
    SentimentResponse,
)

logger = get_logger("api")

#: ``src/<包名>/api/app.py`` -> ``parents[3]`` 即「作业一/<版本目录>」。
#: 前端单文件放在**项目根**下的 ``frontend/``，这样容器里 ``COPY frontend ./frontend`` 才成立。
FRONTEND_DIR = Path(__file__).resolve().parents[3] / "frontend"
INDEX_HTML = FRONTEND_DIR / "index.html"
VENDOR_DIR = FRONTEND_DIR / "vendor"

#: 预置示例 —— 正向 / 负向 / 中性各一条。
#: 放在后端而不是前端，是为了让「示例文案」只有一个数据源，前端只负责渲染。
EXAMPLES: list[ExampleItem] = [
    ExampleItem(
        title="正向示例",
        text="今天终于把拖了三周的方案改完了，提交的那一刻整个人都轻了！",
    ),
    ExampleItem(
        title="负向示例",
        text="面试又挂了，已经是第四次了，我是不是真的什么都不行……",
    ),
    ExampleItem(
        title="中性示例",
        text="明天上午十点的项目评审，会议室在三楼。",
    ),
]


def _sse(event: str, data: dict) -> str:
    """拼一帧 SSE。

    ``json.dumps`` 必须带 ``ensure_ascii=False``（前端要直接显示中文），
    默认的 ``ensure_ascii=True`` 会把中文转成 ``\\uXXXX``，虽然合法但前端要再解一次。
    """
    return f"event: {event}\ndata: {json.dumps(data, ensure_ascii=False)}\n\n"


def create_app() -> FastAPI:
    """构造 FastAPI 应用。"""
    app = FastAPI(
        title="情感陪伴 Agent",
        description=(
            "进程1 负责情感识别，进程2 负责正向鼓励 / 负向排解，"
            "后端进程负责串联，前端进程负责接收用户输入。"
        ),
        version="1.0.0",
    )

    # 前端与后端同源部署时 CORS 其实用不上，但本地用别的端口开前端时会用到。
    # allow_credentials 必须是 False —— 配合 "*" 会被浏览器直接拒绝。
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=False,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    @app.get("/", include_in_schema=False)
    def index() -> FileResponse:
        """前端单文件页面（前端进程）。"""
        if not INDEX_HTML.is_file():
            raise FileNotFoundError(f"找不到前端页面：{INDEX_HTML}")
        return FileResponse(INDEX_HTML)

    @app.get("/api/health", response_model=HealthResponse)
    def health() -> HealthResponse:
        """健康检查。**只返回有没有配 key，不返回 key。**"""
        return HealthResponse(
            status="ok" if settings.api_key_present else "degraded",
            api_key_present=settings.api_key_present,
            base_url=settings.base_url,
            sentiment_model=settings.sentiment_model,
            responder_model=settings.responder_model,
            thinking=settings.thinking_mode,
            implementation=workflow.IMPLEMENTATION_NAME,
        )

    @app.get("/api/examples", response_model=ExampleList)
    def examples() -> ExampleList:
        """预置示例。"""
        return ExampleList(examples=EXAMPLES)

    @app.post("/api/analyze")
    async def analyze(request: AnalyzeRequest) -> StreamingResponse:
        """SSE 流式分析：进程1 → 进程2。

        事件协议：

        - ``stage``：进入某个进程，``{"stage": "sentiment"|"respond", "label": "中文说明"}``
        - ``final``：最终结果，负载是 ``EmotionResult`` 的 JSON
        - ``error``：出错，``{"message": "..."}``
        """

        async def event_stream() -> AsyncIterator[str]:
            try:
                async for event in workflow.analyze_stream(request.text):
                    yield _sse(event.event, event.data)
            except Exception as exc:  # noqa: BLE001 - 流已经开始，只能把错误当事件发出去
                logger.exception("分析流失败：%s", request.text[:30])
                yield _sse("error", {"message": f"处理失败：{exc}"})

        return StreamingResponse(
            event_stream(),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                # 关掉 nginx 缓冲，否则 SSE 会被攒成一坨再吐出来，前端就看不到过程反馈了。
                "X-Accel-Buffering": "no",
            },
        )

    @app.post("/api/sentiment", response_model=SentimentResponse)
    async def sentiment(request: AnalyzeRequest) -> SentimentResponse:
        """**只跑进程1**（情感识别）。"""
        result = await workflow.detect_sentiment(request.text)
        return SentimentResponse(sentiment=result)

    @app.post("/api/respond", response_model=RespondResponse)
    async def respond(request: RespondRequest) -> RespondResponse:
        """**只跑进程2**（拿到识别结果后正向鼓励 / 负向排解）。"""
        mode, response = await workflow.respond(request.text, request.sentiment)
        return RespondResponse(mode=mode, response=response)

    # 本地 vendor 的 Vue 文件（离线可用）；没有就跳过挂载，前端会回退到 CDN。
    if VENDOR_DIR.is_dir():
        app.mount("/vendor", StaticFiles(directory=VENDOR_DIR), name="vendor")

    return app


#: 供 ``uvicorn src.emotion_xxx.api.app:app`` 直接引用。
app = create_app()
