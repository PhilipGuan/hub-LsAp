"""日志配置。

约定：**日志走 stderr，最终结果走 stdout**。
这样 ``python -m emotion_xxx "..." > out.json`` 拿到的就是干净的 JSON。
"""

from __future__ import annotations

import logging
import sys

LOG_FORMAT = "%(asctime)s %(levelname)-7s %(name)s | %(message)s"

#: 本项目所有 logger 的名字前缀，方便 ``logging.getLogger("emotion.xxx")`` 定位。
ROOT_LOGGER_NAME = "emotion"


def setup_logging(level: str = "INFO") -> None:
    """初始化根 logger：单一 stderr handler，重复调用不会叠加。"""
    handler = logging.StreamHandler(sys.stderr)
    handler.setFormatter(logging.Formatter(LOG_FORMAT))

    root = logging.getLogger()
    root.setLevel(level.upper())
    root.handlers.clear()
    root.addHandler(handler)

    # httpx / openai 每次请求都打 INFO 日志，太吵，压到 WARNING。
    for noisy in ("httpx", "httpcore", "openai"):
        logging.getLogger(noisy).setLevel(logging.WARNING)


def get_logger(name: str) -> logging.Logger:
    """取一个带统一前缀的 logger。"""
    if name.startswith(ROOT_LOGGER_NAME):
        return logging.getLogger(name)
    return logging.getLogger(f"{ROOT_LOGGER_NAME}.{name}")
