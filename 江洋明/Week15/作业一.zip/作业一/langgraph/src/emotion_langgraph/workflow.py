"""编排层（后端进程的核心）。

对上层（``api/app.py``）只暴露四个函数，两个框架版本**签名与语义完全一致**：

- ``analyze_stream(text)`` —— SSE 事件流：进程1 → 条件边 → 进程2；
- ``analyze_once(text)`` —— 一次性拿到完整结果；
- ``detect_sentiment(text)`` —— **只跑进程1**（对应 ``POST /api/sentiment``）；
- ``respond(text, sentiment)`` —— **只跑进程2**（对应 ``POST /api/respond``）。

LangGraph 版的三个实现要点：

1. ``graph.astream(input, config, stream_mode=...)`` 的 ``stream_mode`` **只能关键字传**，
   ``recursion_limit`` 放进 ``config``。
2. ``stream_mode`` 同时开 ``updates`` / ``values`` / ``custom``：
   ``custom`` 事件是节点里 ``get_stream_writer()`` 写出来的，
   它**先于**同一步的 ``updates`` 到达 —— 正好用来推 stage
   （只用 ``updates`` 的话，事件是节点结束后才有的，前端要干等 3~5 秒）。
3. **终态取最后一个 ``values`` chunk**。
   不用 ``aget_state``：没有 checkpointer 时它直接抛
   ``ValueError: No checkpointer set``。
"""

from __future__ import annotations

from collections.abc import AsyncIterator
from typing import Any

from .graph.build import (
    RECURSION_LIMIT,
    build_graph,
    build_respond_graph,
    build_sentiment_graph,
)
from .graph.nodes import GraphDeps
from .models import (
    EmotionResult,
    ResponseMode,
    SentimentResult,
    TraceStep,
    WorkflowEvent,
)

#: 健康检查里报的实现框架名。
IMPLEMENTATION_NAME = "langgraph"

#: 注入的依赖（测试用）。``None`` 表示用默认实现。
_deps: GraphDeps | None = None

#: 三张图的缓存。
_graph: Any = None
_sentiment_graph: Any = None
_respond_graph: Any = None


def configure(deps: GraphDeps | None) -> None:
    """注入依赖（测试用）。传 ``None`` 恢复默认实现。"""
    global _deps, _graph, _sentiment_graph, _respond_graph
    _deps = deps
    _graph = None
    _sentiment_graph = None
    _respond_graph = None


def get_graph() -> Any:
    """全图（进程1 → 条件边 → 进程2）。惰性构造，没 key 时导入本模块不报错。"""
    global _graph
    if _graph is None:
        _graph = build_graph(_deps)
    return _graph


def get_sentiment_graph() -> Any:
    """只跑进程1 的图。"""
    global _sentiment_graph
    if _sentiment_graph is None:
        _sentiment_graph = build_sentiment_graph(_deps)
    return _sentiment_graph


def get_respond_graph() -> Any:
    """只跑进程2 的图。"""
    global _respond_graph
    if _respond_graph is None:
        _respond_graph = build_respond_graph(_deps)
    return _respond_graph


def _state_to_dict(state: Any) -> dict:
    """把图的终态统一成 dict（Pydantic 状态 schema 返回的可能是对象）。"""
    if isinstance(state, dict):
        return dict(state)
    dump = getattr(state, "model_dump", None)
    if callable(dump):
        return dump()
    return dict(state)


def _build_result(state: dict) -> EmotionResult:
    """把终态组装成对外的结果对象。"""
    sentiment = state.get("sentiment")
    mode = state.get("mode")
    if sentiment is None or mode is None:
        raise RuntimeError("流程没有走完：缺少 sentiment 或 mode")
    if not isinstance(sentiment, SentimentResult):
        sentiment = SentimentResult.model_validate(sentiment)
    trace = [
        step if isinstance(step, TraceStep) else TraceStep.model_validate(step)
        for step in (state.get("trace") or [])
    ]
    return EmotionResult(
        text=state.get("text", "") or "",
        sentiment=sentiment,
        mode=mode,
        response=state.get("response", "") or "",
        trace=trace,
    )


async def analyze_stream(text: str) -> AsyncIterator[WorkflowEvent]:
    """跑完整流程，逐个吐事件。

    事件顺序：``stage(sentiment)`` → ``stage(respond)`` → ``final``。
    """
    graph = get_graph()
    final_state: dict | None = None
    async for mode, chunk in graph.astream(
        {"text": text},
        {"recursion_limit": RECURSION_LIMIT},
        stream_mode=["updates", "values", "custom"],
    ):
        if mode == "custom":
            yield WorkflowEvent(event="stage", data=dict(chunk))
        elif mode == "values":
            final_state = _state_to_dict(chunk)
    if final_state is None:
        raise RuntimeError("图没有产出终态")
    yield WorkflowEvent(event="final", data=_build_result(final_state).model_dump())


async def analyze_once(text: str) -> EmotionResult:
    """跑完整流程，一次性拿结果（CLI 用）。"""
    graph = get_graph()
    final_state = await graph.ainvoke(
        {"text": text}, {"recursion_limit": RECURSION_LIMIT}
    )
    return _build_result(_state_to_dict(final_state))


async def detect_sentiment(text: str) -> SentimentResult:
    """**只跑进程1**（情感识别）。"""
    graph = get_sentiment_graph()
    final_state = await graph.ainvoke(
        {"text": text}, {"recursion_limit": RECURSION_LIMIT}
    )
    sentiment = _state_to_dict(final_state).get("sentiment")
    if sentiment is None:
        raise RuntimeError("进程1 没有产出结果")
    if not isinstance(sentiment, SentimentResult):
        sentiment = SentimentResult.model_validate(sentiment)
    return sentiment


async def respond(
    text: str, sentiment: SentimentResult
) -> tuple[ResponseMode, str]:
    """**只跑进程2**（正向鼓励 / 负向排解 / 中性陪伴）。"""
    graph = get_respond_graph()
    final_state = await graph.ainvoke(
        {"text": text, "sentiment": sentiment},
        {"recursion_limit": RECURSION_LIMIT},
    )
    state = _state_to_dict(final_state)
    mode = state.get("mode")
    if mode is None:
        raise RuntimeError("进程2 没有产出结果")
    return mode, state.get("response", "") or ""


__all__ = [
    "IMPLEMENTATION_NAME",
    "analyze_once",
    "analyze_stream",
    "configure",
    "detect_sentiment",
    "get_graph",
    "get_respond_graph",
    "get_sentiment_graph",
    "respond",
]
