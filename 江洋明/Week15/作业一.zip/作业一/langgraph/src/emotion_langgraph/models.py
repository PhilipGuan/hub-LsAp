"""两版共用的数据契约。

这个文件在 LangGraph 版与 openai-agents 版之间**逐字一致**，
由 ``作业一/tests/test_parity.py`` 逐字比对守住。

分工原则（与 Week12 SQL Agent 一致）：

- **契约层**用 ``Literal`` 枚举 —— 编译期就能把非法取值挡掉；
- **工具层 / 提示词层**用宽松 ``str`` —— 模型偶尔返回中文标签时不能让它把整条链路打挂，
  归一化逻辑统一放在各自的实现里（LangGraph 版的 structured output、openai-agents 版的 tool）。
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field

#: 情感极性 —— 进程1（情感识别）的输出取值。
SentimentLabel = Literal["positive", "negative", "neutral"]

#: 进程2 走了哪条分支。
#: 注意它**不复用** SentimentLabel 的字面量：``neutral`` 是「情感极性」，
#: ``acknowledge`` 是「走了哪条分支」，两者混用会让前端映射出歧义。
ResponseMode = Literal["encourage", "comfort", "acknowledge"]


class SentimentResult(BaseModel):
    """进程1（情感识别）的产物。"""

    label: SentimentLabel = Field(
        description="情感极性：positive（正向）/ negative（负向）/ neutral（中性）"
    )
    confidence: float = Field(
        default=0.0, ge=0.0, le=1.0, description="置信度，0~1 之间的小数"
    )
    reason: str = Field(default="", description="识别理由（中文，一句话）")


class TraceStep(BaseModel):
    """两个进程中某一步的执行轨迹。"""

    stage: str = Field(description="阶段名：sentiment（进程1）/ respond（进程2）")
    label: str = Field(description="该步的中文名称，用于前端展示")
    status: str = Field(default="done", description="状态：running / done")
    detail: str = Field(default="", description="该步的产出摘要")
    elapsed_ms: int = Field(default=0, description="该步耗时（毫秒）")


class EmotionResult(BaseModel):
    """一次完整的「识别 → 回应」结果。"""

    text: str = Field(description="用户原话")
    sentiment: SentimentResult = Field(description="进程1 的产物")
    mode: ResponseMode = Field(description="进程2 走了哪条分支")
    response: str = Field(default="", description="进程2 的产物（中文回应）")
    trace: list[TraceStep] = Field(
        default_factory=list, description="两个进程的执行轨迹"
    )


class WorkflowEvent(BaseModel):
    """编排层向前端推送的事件。

    两个框架版本的 ``workflow.analyze_stream`` 都产出这个类型，
    于是 ``api/app.py`` 在两版之间逐字一致。
    """

    event: Literal["stage", "final", "error"] = Field(description="事件名")
    data: dict[str, Any] = Field(
        default_factory=dict, description="事件负载"
    )


#: 情感极性 → 中文标签。前端徽章、提示词、trace 文案共用这一张表。
LABEL_CN: dict[str, str] = {
    "positive": "正向",
    "negative": "负向",
    "neutral": "中性",
}

#: 分支 → 中文动作名。
MODE_CN: dict[str, str] = {
    "encourage": "鼓励",
    "comfort": "排解",
    "acknowledge": "陪伴",
}

#: 分支 → 前端徽章配色用的 CSS 类名。
MODE_BADGE: dict[str, str] = {
    "encourage": "badge-encourage",
    "comfort": "badge-comfort",
    "acknowledge": "badge-acknowledge",
}

#: SSE 事件里的 stage 取值 —— **只有两个**，
#: 不允许把框架的节点名 / Agent 名漏到前端协议里。
STAGE_SENTIMENT = "sentiment"
STAGE_RESPOND = "respond"

#: stage 事件里的中文说明。
STAGE_LABEL_SENTIMENT = "进程1 · 情感识别中…"
STAGE_LABEL_RESPOND = "进程2 · 生成{action}回应…"


def build_sentiment_step(sentiment: SentimentResult, elapsed_ms: int) -> TraceStep:
    """组装进程1 的那一步轨迹。

    放在共用的 ``models.py`` 里 —— 两个框架版本的轨迹文案必须**逐字一致**，
    否则「两版等价」的对照实验在展示层就没法对齐了。
    """
    return TraceStep(
        stage=STAGE_SENTIMENT,
        label="进程1 · 情感识别",
        status="done",
        detail=(
            f"识别为{LABEL_CN[sentiment.label]}"
            f"（置信度 {sentiment.confidence:.2f}）"
        ),
        elapsed_ms=elapsed_ms,
    )


def build_respond_step(
    mode: ResponseMode, response: str, elapsed_ms: int
) -> TraceStep:
    """组装进程2 的那一步轨迹。"""
    action = MODE_CN[mode]
    return TraceStep(
        stage=STAGE_RESPOND,
        label=f"进程2 · {action}",
        status="done",
        detail=f"已生成{action}回应（{len(response)} 字）",
        elapsed_ms=elapsed_ms,
    )
