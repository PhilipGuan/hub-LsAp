"""启动前检查 + 启动 Web 服务。

为什么把提示逻辑放在 Python 里，而不是直接写进 ``.bat``？
    Windows 的批处理文件一旦含有非 ASCII 字符，cmd.exe 在
    「切换代码页 + ``cd`` 切目录 + ``goto`` 跳标签」同时出现时，
    会把批处理文件的字节读取位置算错 —— 表现是半行命令被当成命令执行，
    报错形如 ``'xxx' is not recognized as an internal or external command``。

    所以 ``.bat`` / ``.sh`` 里只保留纯 ASCII 的几行（切目录 + 调用本脚本），
    真正带中文的提示、依赖检查、地址打印全部放在这里。

用法::

    python -X utf8 scripts/launch.py                    # 本机启动
    python -X utf8 scripts/launch.py --lan              # 局域网启动
    python -X utf8 scripts/launch.py --port 8015
"""

from __future__ import annotations

import argparse
import os
import shutil
import socket
import subprocess
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent

# 启动前必须能 import 成功的模块 —— 缺了就装依赖
REQUIRED_MODULES = ("fastapi", "uvicorn", "langgraph")
REQUIREMENTS_FILE = "requirements.txt"
ENV_FILE = ".env"
ENV_TEMPLATE = ".env.example"

#: 包名（LangGraph 版）
PACKAGE = "emotion_langgraph"

#: 标题
TITLE = "情感陪伴 Agent（LangGraph 版）"


def _setup_output() -> None:
    """把 stdout 改成行缓冲。

    启动器随后要拉起一个长时间运行的子进程（uvicorn），而 Python 在
    stdout 不是终端时用的是块缓冲 —— 不改的话横幅提示会一直压在缓冲区里，
    直到服务退出才吐出来。
    """
    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is not None:
            try:
                reconfigure(line_buffering=True)
            except (ValueError, OSError):  # pragma: no cover - 极端情况
                pass


def lan_ip() -> str:
    """取本机局域网 IP（连不上网关就返回空串）。"""
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.connect(("10.255.255.255", 1))
        return sock.getsockname()[0]
    except OSError:
        return ""
    finally:
        sock.close()


def _maybe_open_browser(url: str) -> None:
    """顺手打开浏览器；输出被重定向时不弹。"""
    try:
        if not sys.stdout.isatty():
            return
        import webbrowser

        webbrowser.open(url)
    except Exception:  # pragma: no cover - 弹不出来也不该影响服务
        pass


def ensure_env(root: Path = PROJECT_ROOT) -> bool:
    """确保 ``.env`` 存在。返回 True 表示可以继续启动。"""
    env_path = root / ENV_FILE
    if env_path.exists():
        return True

    template = root / ENV_TEMPLATE
    if template.exists():
        shutil.copyfile(template, env_path)
        print("[提示] 未找到 .env，已从 .env.example 复制一份。")
    else:
        print(f"[提示] 未找到 .env，示例模板 {ENV_TEMPLATE} 也不存在。")
    print(f"       请打开 {ENV_FILE} 填入 EMOTION_AGENT_API_KEY 后重新运行。")
    return False


def ensure_deps(root: Path = PROJECT_ROOT) -> bool:
    """确保运行依赖已安装；缺失就执行 ``pip install``。"""
    modules = ", ".join(REQUIRED_MODULES)
    probe = subprocess.run(
        [sys.executable, "-c", f"import {modules}"],
        capture_output=True,
        cwd=str(root),
    )
    if probe.returncode == 0:
        return True

    print("[安装] 依赖缺失，正在安装，请稍候…")
    req = root / REQUIREMENTS_FILE
    if req.exists():
        cmd = [sys.executable, "-m", "pip", "install", "-r", str(req)]
    else:
        cmd = [sys.executable, "-m", "pip", "install", *REQUIRED_MODULES]
    subprocess.run(cmd, cwd=str(root))

    probe = subprocess.run(
        [sys.executable, "-c", f"import {modules}"],
        capture_output=True,
        cwd=str(root),
    )
    if probe.returncode != 0:
        print("[错误] 依赖安装失败，请手动执行：")
        print(f"       {sys.executable} -m pip install -r {REQUIREMENTS_FILE}")
        return False
    return True


def _server_env() -> dict[str, str]:
    """构造子进程环境变量，把 ``src`` 挂到 PYTHONPATH 上。"""
    env = dict(os.environ)
    src = str(PROJECT_ROOT / "src")
    old = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = f"{src}{os.pathsep}{old}" if old else src
    return env


def main(argv: list[str] | None = None) -> int:
    """启动器入口。返回进程退出码。"""
    parser = argparse.ArgumentParser(description=f"{TITLE} · 启动器")
    parser.add_argument("--host", default="127.0.0.1", help="监听地址（默认 127.0.0.1）")
    parser.add_argument("--port", type=int, default=8015, help="监听端口（默认 8015）")
    parser.add_argument(
        "--lan",
        action="store_true",
        help="监听 0.0.0.0 并打印局域网地址（会同时给出「无鉴权」警告）",
    )
    parser.add_argument("--no-preflight", action="store_true", help="跳过依赖检查")
    args = parser.parse_args(argv)

    _setup_output()
    host = "0.0.0.0" if args.lan else args.host

    print("=" * 44)
    if args.lan:
        print(f"  {TITLE} · 局域网启动")
        print("  （监听 0.0.0.0，同网段的设备都能访问）")
    else:
        print(f"  {TITLE} · 本机启动")
        print("  （只监听 127.0.0.1，别的机器访问不了）")
    print("=" * 44)
    print()

    if args.lan:
        print("  [注意] 本项目没有登录鉴权 —— 同一网络里的任何人都能发消息。")
        print("         只在可信网络里用，用完记得关掉。")
        print()

    if not args.no_preflight:
        if not ensure_env():
            return 1
        if not ensure_deps():
            return 1

    print(f"[启动] 本机：    http://127.0.0.1:{args.port}")
    if args.lan:
        ip = lan_ip()
        if ip:
            print(f"        局域网：  http://{ip}:{args.port}")
            print("        （手机和电脑连同一个 Wi-Fi，用手机浏览器打开上面这个地址）")
        else:
            print("        局域网：  取本机 IP 失败，手动用 ipconfig 查一下")
    print("        启动后浏览器会自动打开；打不开就手动复制上面的地址。")
    print()

    _maybe_open_browser(f"http://127.0.0.1:{args.port}")

    cmd = [
        sys.executable,
        "-X",
        "utf8",
        "-m",
        PACKAGE,
        "serve",
        "--host",
        host,
        "--port",
        str(args.port),
    ]
    return subprocess.call(cmd, cwd=str(PROJECT_ROOT), env=_server_env())


if __name__ == "__main__":
    raise SystemExit(main())
