"""把 Vue 3 下载到本地，让前端在离线环境也能用。

**为什么需要它**：``frontend/index.html`` 默认先加载 ``./vendor/vue.global.prod.js``，
加载不到再回退 unpkg CDN。容器内外网不通、或者教室断网时，
如果没做本地化，页面会一直停在「正在加载 Vue 3 …」。

这个脚本**只下载**，**不改写 index.html** —— 因为 index.html 里已经写好了
「本地优先 + onerror 回退 CDN」的加载策略，改写反而多一份状态要维护。

用法::

    python -X utf8 scripts/vendor_vue.py
"""

from __future__ import annotations

import argparse
import urllib.request
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
VENDOR_DIR = PROJECT_ROOT / "frontend" / "vendor"
VENDOR_FILE = VENDOR_DIR / "vue.global.prod.js"

CDN_URL = "https://unpkg.com/vue@3/dist/vue.global.prod.js"


def download() -> int:
    """下载 Vue 到 ``frontend/vendor/``。"""
    VENDOR_DIR.mkdir(parents=True, exist_ok=True)
    print(f"下载 {CDN_URL}")
    request = urllib.request.Request(CDN_URL, headers={"User-Agent": "vendor_vue.py"})
    try:
        with urllib.request.urlopen(request, timeout=60) as response:  # noqa: S310 - 固定 CDN
            payload = response.read()
    except Exception as exc:  # noqa: BLE001 - 离线环境是常态，要给出可读提示
        print(f"[失败] 拿不到 Vue：{exc}")
        print("       容器内外网不通时，请在本机下载后把 frontend/vendor/ 一起拷进镜像。")
        return 1
    VENDOR_FILE.write_bytes(payload)
    print(f"已保存 {VENDOR_FILE}（{len(payload) / 1024:.0f} KB）")
    print("前端现在不再依赖外网。重启服务即可生效。")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="把 Vue 3 本地化，让前端离线可用")
    parser.parse_args()

    if VENDOR_FILE.is_file():
        size_kb = VENDOR_FILE.stat().st_size / 1024
        print(f"已经本地化过了（{size_kb:.0f} KB），无需重复下载。")
        return 0
    return download()


if __name__ == "__main__":
    raise SystemExit(main())
