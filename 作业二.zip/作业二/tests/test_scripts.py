"""启动脚本的回归测试。

三条硬性约束 —— 每一条都是踩过坑才加进来的（详见 docs/deployment.md
「cmd.exe 踩坑」一节）：

1. **``.bat`` 必须是纯 ASCII。**
   cmd.exe 读 UTF-8 批处理文件时，如果同时出现「切换代码页 + ``cd`` 切目录
   + ``goto`` 跳标签」，字节读取位置会算错，把半行命令当成命令执行，
   报 ``'xxx' is not recognized as an internal or external command``。
   实测复现：横幅后的 REM 注释被拦腰截断，
   ``'标签，不用括号块。' is not recognized``。
   规避办法：``.bat`` 里不放任何非 ASCII 字符，中文提示全部交给
   ``scripts/launch.py``（Python 走 WriteConsoleW，不受代码页影响）。

2. **``.bat`` 必须是 CRLF 换行。**
   cmd.exe 对 LF-only 的批处理文件有解析 bug，会把后续行截断
   （实测报 ``'b' 不是内部或外部命令``）。

3. **``.sh`` 必须是 LF 换行。**
   反过来 —— CRLF 的 shell 脚本在 bash 下会报
   ``$'\\r': command not found``。
"""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

import pytest

PROJECT_ROOT = Path(__file__).resolve().parent.parent
SCRIPTS_DIR = PROJECT_ROOT / "scripts"

BAT_FILES = ["start_server.bat", "start_lan.bat"]
SH_FILES = ["start_server.sh", "start_lan.sh"]


def _load_launch_module():
    """按文件路径加载 ``scripts/launch.py``（它不在 ``src`` 包里）。"""

    path = SCRIPTS_DIR / "launch.py"
    spec = importlib.util.spec_from_file_location("_launch_script", path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


@pytest.mark.parametrize("name", BAT_FILES)
def test_bat_文件存在(name: str) -> None:
    assert (PROJECT_ROOT / name).is_file()


@pytest.mark.parametrize("name", SH_FILES)
def test_sh_文件存在(name: str) -> None:
    assert (PROJECT_ROOT / name).is_file()


@pytest.mark.parametrize("name", BAT_FILES)
def test_bat_必须是纯_ascii(name: str) -> None:
    """cmd.exe 踩坑第 1 条：``.bat`` 里出现非 ASCII 字符就可能读错位。"""

    raw = (PROJECT_ROOT / name).read_bytes()
    assert raw.isascii(), f"{name} 含有非 ASCII 字符，中文提示请放到 scripts/launch.py"


@pytest.mark.parametrize("name", BAT_FILES + SH_FILES)
def test_sh_和_bat_都是纯_ascii(name: str) -> None:
    """``.sh`` 同样保持纯 ASCII —— 提示统一由 launch.py 输出。"""

    raw = (PROJECT_ROOT / name).read_bytes()
    assert raw.isascii(), f"{name} 含有非 ASCII 字符，中文提示请放到 scripts/launch.py"


@pytest.mark.parametrize("name", BAT_FILES)
def test_bat_必须是_crlf_换行(name: str) -> None:
    """cmd.exe 踩坑第 2 条：LF-only 的 ``.bat`` 会被 cmd 截断。"""

    raw = (PROJECT_ROOT / name).read_bytes()
    assert b"\r\n" in raw, f"{name} 没有任何 CRLF 换行"
    bare_lf = raw.count(b"\n") - raw.count(b"\r\n")
    assert bare_lf == 0, f"{name} 混入了 {bare_lf} 个 LF-only 换行"


@pytest.mark.parametrize("name", SH_FILES)
def test_sh_必须是_lf_换行(name: str) -> None:
    """CRLF 的 shell 脚本在 bash 下会报 ``$'\\r': command not found``。"""

    raw = (PROJECT_ROOT / name).read_bytes()
    assert b"\r\n" not in raw, f"{name} 混入了 CRLF 换行，bash 下会报错"
    assert raw.count(b"\n") > 0


@pytest.mark.parametrize("name", BAT_FILES)
def test_bat_不含括号块(name: str) -> None:
    """括号块之后 cmd.exe 会用「字符数」而不是「字节数」续读批处理文件。"""

    text = (PROJECT_ROOT / name).read_bytes().decode("ascii")
    assert "(" not in text, f"{name} 含有左括号，请改用 goto + 标签"
    assert ")" not in text, f"{name} 含有右括号，请改用 goto + 标签"


@pytest.mark.parametrize("name", BAT_FILES)
def test_bat_调用_python_启动器(name: str) -> None:
    text = (PROJECT_ROOT / name).read_bytes().decode("ascii")
    assert "scripts\\launch.py" in text
    assert "python -X utf8" in text


@pytest.mark.parametrize("name", SH_FILES)
def test_sh_调用_python_启动器(name: str) -> None:
    text = (PROJECT_ROOT / name).read_bytes().decode("ascii")
    assert "scripts/launch.py" in text
    assert "python -X utf8" in text


@pytest.mark.parametrize("name", BAT_FILES + SH_FILES)
def test_脚本_切到项目根目录(name: str) -> None:
    """脚本必须先切到项目根目录，否则 ``scripts/launch.py`` 找不到。"""

    text = (PROJECT_ROOT / name).read_bytes().decode("ascii")
    assert "%~dp0" in text or 'dirname "$0"' in text


def test_launch_py_存在() -> None:
    assert (SCRIPTS_DIR / "launch.py").is_file()


def test_lan_ip_py_存在() -> None:
    assert (SCRIPTS_DIR / "lan_ip.py").is_file()


def test_缺_env_时自动从模板复制(tmp_path: Path) -> None:
    """``.env`` 缺失 → 复制模板并返回 False（提示用户填 key）。"""

    module = _load_launch_module()
    (tmp_path / ".env.example").write_text("SQL_AGENT_API_KEY=sk-placeholder\n", encoding="utf-8")

    assert module.ensure_env(tmp_path) is False
    created = tmp_path / ".env"
    assert created.is_file()
    assert "SQL_AGENT_API_KEY" in created.read_text(encoding="utf-8")

    # 已经有了就直接放行
    assert module.ensure_env(tmp_path) is True


def test_缺_env_且缺模板时也不崩(tmp_path: Path) -> None:
    module = _load_launch_module()
    assert module.ensure_env(tmp_path) is False
    assert not (tmp_path / ".env").exists()


def test_launch_能解析出宿主机地址() -> None:
    """``lan_ip()`` 不抛异常即可 —— 取不到时返回空串。"""

    module = _load_launch_module()
    ip = module.lan_ip()
    assert isinstance(ip, str)


def test_监听全网段时给的是能打开的地址() -> None:
    """``0.0.0.0`` 不是能打开的地址，提示里要换成回环地址。"""

    from langgraph_web_agent.cli import browse_url

    assert browse_url("0.0.0.0", 8000) == "http://127.0.0.1:8000"
    assert browse_url("::", 8000) == "http://127.0.0.1:8000"
    assert browse_url("127.0.0.1", 8000) == "http://127.0.0.1:8000"
    assert browse_url("192.168.1.5", 9000) == "http://192.168.1.5:9000"


def test_输出被重定向时不弹浏览器(tmp_path: Path) -> None:
    """服务器上跑的时候不该去开浏览器。"""

    module = _load_launch_module()
    # stdout 不是终端时必须直接返回，不抛异常
    module._maybe_open_browser("http://127.0.0.1:8000")

