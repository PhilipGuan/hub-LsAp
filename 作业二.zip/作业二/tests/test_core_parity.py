"""核心代码一致性测试：core/ 必须与作业一逐字一致（config.py 除外）。

这条测试是「两份副本防漂移」的唯一保障 —— 改了一边忘了另一边就会红。
"""

from __future__ import annotations

from pathlib import Path

import pytest

HOMEWORK = Path(__file__).resolve().parents[1]  # 作业二
WEEK = HOMEWORK.parent  # 13-江洋明-第十三周作业
SOURCE = WEEK / "作业一" / "src" / "langgraph_sql_agent"
COPY = HOMEWORK / "src" / "langgraph_web_agent" / "core"

#: 必须逐字一致的文件（config.py 有两处刻意的路径差异，单列在下面）
PARITY_FILES = [
    "__init__.py",
    "models.py",
    "prompts.py",
    "llm.py",
    "logging_config.py",
    "session.py",
    "agents/__init__.py",
    "agents/sql_fixer.py",
    "chains/__init__.py",
    "chains/table_select.py",
    "chains/sql_generate.py",
    "chains/result_summary.py",
    "db/__init__.py",
    "db/catalog.py",
    "db/validator.py",
    "db/executor.py",
    "graph/__init__.py",
    "graph/state.py",
    "graph/routing.py",
    "graph/nodes.py",
    "graph/build.py",
    "tools/__init__.py",
    "tools/db_tools.py",
]


@pytest.mark.parametrize("relative", PARITY_FILES)
def test_核心文件与作业一逐字一致(relative: str):
    source = SOURCE / relative
    copy = COPY / relative
    assert source.exists(), f"作业一缺少文件：{source}"
    assert copy.exists(), f"作业二缺少文件：{copy}"
    assert copy.read_text(encoding="utf-8") == source.read_text(encoding="utf-8"), (
        f"{relative} 与作业一不一致。改了一边必须同步另一边。"
    )


def test_核心目录没有多余的模块():
    """只允许出现已知的模块，多一个文件都要有人认领。"""

    allowed = {Path(item) for item in PARITY_FILES}
    allowed.add(Path("config.py"))
    actual = {
        path.relative_to(COPY)
        for path in COPY.rglob("*.py")
        if "__pycache__" not in path.parts
    }
    assert actual == allowed


def test_config_只有刻意的差异():
    """config.py 允许不同，但差异必须只有下面这几处（逐条列出，不许更多）。

    差异一共两类：
    ① 路径层级 —— 作业二多了一层 ``core/`` 包，所以是 ``parents[3]``；
    ② ``.env`` 回退链 —— 作业二回退到本周的「作业一」。
    注释里的路径与目录名也跟着变，所以一并列进来。
    """

    source = (SOURCE / "config.py").read_text(encoding="utf-8")
    copy = (COPY / "config.py").read_text(encoding="utf-8")

    #: (作业二里的写法, 作业一里的写法) —— 反向替换后必须与作业一逐字相同
    allowed_differences = [
        (
            "# src/langgraph_web_agent/core/config.py -> parents[3] 即「作业二」目录",
            "# src/langgraph_sql_agent/config.py -> parents[2] 即「作业一」目录",
        ),
        ("parents[3]", "parents[2]"),
        (
            "#: 第一项是本作业自己的 .env；第二项是本周「作业一」的 .env，方便本机直接跑通。",
            "#: 第一项是本作业自己的 .env；第二项是同期的「作业二」.env，方便本机直接跑通。",
        ),
        (
            'PROJECT_ROOT.parent / "作业一" / ".env"',
            'PROJECT_ROOT.parent / "作业二" / ".env"',
        ),
    ]

    normalized = copy
    for new, old in allowed_differences:
        assert new in normalized, f"作业二的 config.py 里找不到预期差异：{new}"
        normalized = normalized.replace(new, old)

    assert normalized == source, "config.py 出现了预期之外的差异"


def test_核心包可以导入():
    from langgraph_web_agent.core.graph.build import build_graph
    from langgraph_web_agent.core.session import SessionManager

    assert callable(build_graph)
    assert SessionManager().new_session_id()


def test_核心包的PROJECT_ROOT指向作业二():
    """config.py 的第一处差异：多了一层 core/ 包，层级要 +1。"""

    from langgraph_web_agent.core.config import PROJECT_ROOT

    assert PROJECT_ROOT.name == "作业二"
    assert (PROJECT_ROOT / "data" / "chinook.db").exists()
