"""/api/chat 的 SSE 流式问答测试。LLM 全 mock。"""

from __future__ import annotations

import json

from fastapi.testclient import TestClient


def _parse_sse(text: str) -> list[tuple[str, dict]]:
    """把 SSE 文本解析成 [(event, data), ...]。"""

    events: list[tuple[str, dict]] = []
    for block in text.split("\n\n"):
        block = block.strip()
        if not block:
            continue
        event = "message"
        data_lines: list[str] = []
        for line in block.splitlines():
            if line.startswith("event:"):
                event = line[len("event:") :].strip()
            elif line.startswith("data:"):
                data_lines.append(line[len("data:") :].strip())
        payload = json.loads("\n".join(data_lines)) if data_lines else {}
        events.append((event, payload))
    return events


def test_问答返回阶段事件与最终结果(patched_graph, client: TestClient):
    response = client.post("/api/chat", json={"message": "总共有多少张专辑？"})
    assert response.status_code == 200
    assert response.headers["content-type"].startswith("text/event-stream")

    events = _parse_sse(response.text)
    names = [name for name, _ in events]
    assert "stage" in names
    assert names[-1] == "final"

    stages = [payload["stage"] for name, payload in events if name == "stage"]
    assert "select_tables" in stages
    assert "generate_sql" in stages
    assert "execute" in stages
    assert "summarize" in stages


def test_最终结果包含答案与结果表(patched_graph, client: TestClient):
    response = client.post("/api/chat", json={"message": "总共有多少张专辑？"})
    events = _parse_sse(response.text)
    final = [payload for name, payload in events if name == "final"][-1]
    assert final["answer"] == "共有 347 张专辑。"
    assert final["columns"] == ["TotalAlbums"]
    assert final["rows"] == [["347"]]
    assert final["tables"] == ["albums"]
    assert final["sql"] == "SELECT COUNT(*) AS TotalAlbums FROM albums"
    assert final["session_id"] == "testsession"


def test_空消息被拒绝(client: TestClient):
    response = client.post("/api/chat", json={"message": ""})
    assert response.status_code == 422


def test_缺少消息字段被拒绝(client: TestClient):
    response = client.post("/api/chat", json={})
    assert response.status_code == 422


def test_同一会话第二轮能拿到历史(patched_graph, client: TestClient):
    client.post("/api/chat", json={"session_id": "s1", "message": "总共有多少张专辑？"})
    response = client.post("/api/chat", json={"session_id": "s1", "message": "那按流派呢？"})
    assert response.status_code == 200
    events = _parse_sse(response.text)
    final = [payload for name, payload in events if name == "final"][-1]
    assert final["session_id"] == "s1"


def test_失败时推送_error_事件(monkeypatch, client: TestClient):
    from langgraph_web_agent.api import deps

    def boom():
        raise RuntimeError("图炸了")

    monkeypatch.setattr(deps, "get_graph", boom)
    response = client.post("/api/chat", json={"message": "q"})
    events = _parse_sse(response.text)
    assert events[-1][0] == "error"
    assert "图炸了" in events[-1][1]["message"]
