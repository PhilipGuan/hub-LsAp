"""会话读写与清空接口测试。"""

from __future__ import annotations

from fastapi.testclient import TestClient
from langgraph.checkpoint.memory import MemorySaver


def test_不存在的会话返回空历史(client: TestClient):
    response = client.get("/api/sessions/从没用过")
    assert response.status_code == 200
    payload = response.json()
    assert payload["session_id"] == "从没用过"
    assert payload["turns"] == []


def test_清空会话返回_ok(client: TestClient):
    response = client.delete("/api/sessions/abc")
    assert response.status_code == 200
    assert response.json()["ok"] is True


def test_问答之后能读到会话历史(patched_graph, client: TestClient):
    """跑完一轮问答，会话里应该有一问一答两条记录。"""

    client.post("/api/chat", json={"session_id": "s-history", "message": "总共有多少张专辑？"})
    payload = client.get("/api/sessions/s-history").json()
    turns = payload["turns"]
    assert len(turns) == 2
    assert turns[0]["role"] == "user"
    assert turns[0]["question"] == "总共有多少张专辑？"
    assert turns[1]["role"] == "assistant"
    assert turns[1]["answer"] == "共有 347 张专辑。"
    assert turns[1]["tables"] == ["albums"]
    assert turns[1]["sql"] == "SELECT COUNT(*) AS TotalAlbums FROM albums"


def test_清空会话后历史真的没了(patched_graph, client: TestClient):
    """``history`` 有 add reducer，写空列表清不掉 —— 必须 delete_thread。"""

    client.post("/api/chat", json={"session_id": "s-clear", "message": "总共有多少张专辑？"})
    assert len(client.get("/api/sessions/s-clear").json()["turns"]) == 2

    response = client.delete("/api/sessions/s-clear")
    assert response.status_code == 200
    assert response.json()["ok"] is True
    assert client.get("/api/sessions/s-clear").json()["turns"] == []


def test_会话管理器能读取历史(monkeypatch):
    """直接验证 SessionManager.history 的行为。"""

    from conftest import FakeChain

    from langgraph_web_agent.api import deps
    from langgraph_web_agent.core.chains import StageChains
    from langgraph_web_agent.core.db.executor import SQLExecutor
    from langgraph_web_agent.core.db.validator import SQLValidator
    from langgraph_web_agent.core.graph.build import build_graph
    from langgraph_web_agent.core.graph.nodes import GraphDeps
    from langgraph_web_agent.core.models import FinalAnswer, SQLDraft, TableSelection
    from langgraph_web_agent.core.session import SessionManager

    catalog = deps.get_catalog()
    deps_obj = GraphDeps(
        catalog=catalog,
        validator=SQLValidator(catalog.db_path),
        executor=SQLExecutor(catalog.db_path),
        chains=StageChains(
            select=FakeChain([TableSelection(tables=["albums"], reason="r")]),
            generate=FakeChain([SQLDraft(sql="SELECT COUNT(*) AS n FROM albums")]),
            summarize=FakeChain([FinalAnswer(answer="a")]),
        ),
    )
    graph = build_graph(deps_obj, checkpointer=MemorySaver())
    manager = SessionManager(MemorySaver())
    config = manager.config("s1")
    graph.invoke({"question": "第一问"}, config)

    turns = manager.history(graph, "s1")
    assert len(turns) == 2
    assert turns[0].role == "user"
    assert turns[1].role == "assistant"
