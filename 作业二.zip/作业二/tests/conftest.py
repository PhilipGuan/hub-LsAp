"""公共测试夹具。"""

from __future__ import annotations

from pathlib import Path

import pytest
from fastapi.testclient import TestClient
from langgraph.checkpoint.memory import MemorySaver

from langgraph_web_agent.core.config import settings
from langgraph_web_agent.core.db.catalog import SchemaCatalog
from langgraph_web_agent.core.models import FinalAnswer, SQLDraft, TableSelection


@pytest.fixture(scope="session")
def db_path() -> Path:
    path = settings.db_path
    assert path.exists(), f"找不到数据库：{path}"
    return path


@pytest.fixture(scope="session")
def catalog(db_path: Path) -> SchemaCatalog:
    return SchemaCatalog(db_path)


@pytest.fixture
def client() -> TestClient:
    """FastAPI 测试客户端。

    这里不 mock LLM —— 真正的调用在 ``/api/chat`` 的测试里通过替换
    ``langgraph_web_agent.api.deps.get_graph`` 完成。
    """

    from langgraph_web_agent.api.app import app

    return TestClient(app)


class FakeChain:
    """替代一条 LCEL 链。"""

    def __init__(self, outputs):
        self.outputs = list(outputs)
        self.calls: list[dict] = []

    def invoke(self, payload):
        self.calls.append(payload)
        index = len(self.calls) - 1
        if index >= len(self.outputs):
            raise AssertionError(
                f"链被调用了 {len(self.calls)} 次，但只准备了 {len(self.outputs)} 个结果"
            )
        return self.outputs[index]


class FakeFixer:
    """替代修复 Agent。"""

    def __init__(self, drafts):
        self.drafts = list(drafts)
        self.calls: list[dict] = []

    def invoke(self, payload, config=None):
        self.calls.append(payload)
        index = len(self.calls) - 1
        if index >= len(self.drafts):
            raise AssertionError("修复 Agent 被调用次数超出预设")
        return {"structured_response": self.drafts[index]}


@pytest.fixture
def happy_selection() -> TableSelection:
    return TableSelection(tables=["albums"], reason="统计专辑数", confidence=0.95)


@pytest.fixture
def happy_draft() -> SQLDraft:
    return SQLDraft(sql="SELECT COUNT(*) AS TotalAlbums FROM albums")


@pytest.fixture
def happy_summary() -> FinalAnswer:
    return FinalAnswer(answer="数据库中共有 347 张专辑。", evidence=["TotalAlbums = 347"])


class FakeManager:
    """固定 session id 的会话管理器替身。

    **必须和图共用同一个 checkpointer** —— 会话历史存在 checkpointer 里，
    两者不是同一个的话，``/api/chat`` 写进去的历史 ``/api/sessions`` 读不到。
    """

    def __init__(self, checkpointer):
        self.checkpointer = checkpointer

    def new_session_id(self) -> str:
        return "testsession"

    def config(self, session_id: str) -> dict:
        return {"configurable": {"thread_id": session_id}}

    def clear(self, session_id: str) -> None:
        self.checkpointer.delete_thread(session_id)


@pytest.fixture
def happy_deps(catalog: SchemaCatalog, db_path):
    """两条链各准备 2 份结果 —— 同一会话里的两轮请求各消耗一份。"""

    from langgraph_web_agent.core.chains import StageChains
    from langgraph_web_agent.core.db.executor import SQLExecutor
    from langgraph_web_agent.core.db.validator import SQLValidator
    from langgraph_web_agent.core.graph.nodes import GraphDeps

    return GraphDeps(
        catalog=catalog,
        validator=SQLValidator(db_path),
        executor=SQLExecutor(db_path),
        chains=StageChains(
            select=FakeChain(
                [
                    TableSelection(tables=["albums"], reason="r"),
                    TableSelection(tables=["albums"], reason="r"),
                ]
            ),
            generate=FakeChain(
                [
                    SQLDraft(sql="SELECT COUNT(*) AS TotalAlbums FROM albums"),
                    SQLDraft(sql="SELECT COUNT(*) AS TotalAlbums FROM albums"),
                ]
            ),
            summarize=FakeChain(
                [
                    FinalAnswer(answer="共有 347 张专辑。"),
                    FinalAnswer(answer="共有 347 张专辑。"),
                ]
            ),
        ),
        fixer=FakeFixer([]),
    )


@pytest.fixture
def patched_graph(happy_deps, monkeypatch):
    """把 api.deps.get_graph 换成用假链编译的图。"""

    from langgraph_web_agent.api import deps
    from langgraph_web_agent.core.graph.build import build_graph

    checkpointer = MemorySaver()
    graph = build_graph(happy_deps, checkpointer=checkpointer)
    manager = FakeManager(checkpointer)
    monkeypatch.setattr(deps, "get_graph", lambda: graph)
    monkeypatch.setattr(deps, "get_session_manager", lambda: manager)
    return graph
