"""健康检查与数据库结构接口测试。"""

from __future__ import annotations

from fastapi.testclient import TestClient


def test_健康检查返回模型配置但不泄露_key(client: TestClient):
    response = client.get("/api/health")
    assert response.status_code == 200
    payload = response.json()
    assert payload["status"] == "ok"
    assert "api_key" not in payload
    assert isinstance(payload["api_key_present"], bool)
    assert payload["db_tables"] == 11


def test_数据库结构接口返回全部业务表(client: TestClient):
    response = client.get("/api/schema")
    assert response.status_code == 200
    payload = response.json()
    names = [table["name"] for table in payload["tables"]]
    assert "albums" in names
    assert "tracks" in names
    # sqlite_sequence / sqlite_stat1 这类内部表不应出现
    assert not any(name.startswith("sqlite_") for name in names)
    assert payload["total_rows"] > 0


def test_表结构里含有字段信息(client: TestClient):
    payload = client.get("/api/schema").json()
    albums = next(t for t in payload["tables"] if t["name"] == "albums")
    assert albums["row_count"] == 347
    assert any(column["name"] == "AlbumId" for column in albums["columns"])


def test_首页返回前端页面(client: TestClient):
    """前端是单文件 index.html，根路径直接返回它。"""

    response = client.get("/")
    assert response.status_code == 200
    assert "text/html" in response.headers["content-type"]


def test_本地_vue_目录存在时会挂载静态路由():
    """离线部署（scripts/vendor_vue.py）后，前端要能从 /vendor/ 拿到 Vue。

    ``vendor/`` 目录不存在时**不能**挂载 —— StaticFiles 在目录缺失时会直接
    抛错，那会让默认部署（没跑过 vendor_vue.py）起不来。
    """

    from langgraph_web_agent.api.app import VENDOR_DIR

    if not VENDOR_DIR.is_dir():
        # 默认部署：没挂载也正常
        from langgraph_web_agent.api.app import app

        assert not any(
            getattr(route, "path", "") == "/vendor" for route in app.routes
        )
        return

    # 本地化过：目录必须被挂上
    from fastapi.testclient import TestClient

    from langgraph_web_agent.api.app import app

    assert any(getattr(route, "path", "") == "/vendor" for route in app.routes)
    with TestClient(app) as client:
        response = client.get("/vendor/vue.global.prod.js")
        assert response.status_code == 200
        assert len(response.content) > 100_000
