"""前端单文件的静态检查。

前端是 ``frontend/index.html`` —— 一个零构建的 Vue 3 单文件页面。
这里用静态检查代替浏览器端测试：断言关键结构、接口引用和 SSE 实现方式都在，
避免有人把流式实现改成 ``EventSource``（它不能发 POST）或者漏掉某个接口。
"""

from __future__ import annotations

import re
from pathlib import Path

import pytest

FRONTEND_HTML = Path(__file__).resolve().parents[1] / "frontend" / "index.html"


@pytest.fixture(scope="module")
def html() -> str:
    assert FRONTEND_HTML.is_file(), f"找不到前端页面：{FRONTEND_HTML}"
    return FRONTEND_HTML.read_text(encoding="utf-8")


def test_页面是_vue3_单文件应用(html: str):
    assert '<div id="app">' in html
    assert "vue.global.prod.js" in html
    assert "createApp" in html
    # 只有一个外部脚本 —— Vue，不引构建工具。
    # 允许 CDN 或本地化后的路径（scripts/vendor_vue.py 会把 CDN 换成本地副本）。
    scripts = re.findall(r'<script[^>]*\bsrc="([^"]+)"', html)
    assert scripts in (
        ["https://unpkg.com/vue@3/dist/vue.global.prod.js"],
        ["./vendor/vue.global.prod.js"],
    ), f"前端的 script src 不对：{scripts}"


def test_引用了后端接口(html: str):
    for path in ("/api/chat", "/api/schema", "/api/health", "/api/sessions/"):
        assert path in html, f"前端没有引用后端接口 {path}"


def test_流式实现用的是_fetch_加_ReadableStream(html: str):
    """``EventSource`` 只能 GET，不能发 POST —— 问答必须用 fetch + ReadableStream。"""

    assert "fetch(" in html
    assert "getReader()" in html
    # 只看「有没有用」，注释里提到名字不算。
    assert "new EventSource(" not in html
    assert "text/event-stream" not in html  # 这是响应头，不是前端该出现的东西


def test_会话存在_localStorage(html: str):
    assert "localStorage" in html
    assert "sqlagent.session" in html


def test_结果表格与_sql_都在页面上(html: str):
    assert "<table>" in html
    assert "m.columns" in html
    assert "m.rows" in html
    assert "m.sql" in html


def test_加载遮罩在_app_外面(html: str):
    """``#app`` 里的内容会被 Vue 当成 in-DOM 模板编译。

    加载遮罩如果放在 ``#app`` 里面，这段「正在加载 Vue 3」会跟着模板一起
    被渲染出来，浮在页面左上角（实测踩过）。所以它必须是 ``#app`` 的兄弟节点，
    由脚本在挂载成功后移除。
    """

    assert 'id="boot"' in html
    assert html.index('id="boot"') < html.index('<div id="app">')
    assert "getElementById('boot')" in html


def test_没有把_api_key_写进前端(html: str):
    """前端是公开静态文件，里面不能出现任何 key 字面量。

    ``api_key_present`` 是 ``/api/health`` 的响应字段名（只表示"配没配"），
    不算泄露；真正不能出现的是 key 本身或读 key 的环境变量名。
    """

    for forbidden in ("DEEPSEEK_API_KEY", "OPENAI_API_KEY", "SQL_AGENT_API_KEY", "sk-"):
        assert forbidden not in html, f"前端里出现了 {forbidden}"
