# 作业二设计文档 · LangGraph SQL Agent 的对话式前端

> 配套实现：`13-江洋明-第十三周作业/作业二/`
> 上游：本周「作业一」的 LangGraph 状态图（`作业一/src/langgraph_sql_agent/`）
> 作业原文：**作业2: 给作业1，给一个前端，用户在网页输入文本通过对话查询到sql agent 执行结果。**

---

## 1. 目标与约束

### 1.1 目标

在作业一的 LangGraph SQL Agent 之上加一个 Web 层，让用户**用自然语言对话**查到 Chinook 数据库的结果，
并且能**看到过程**（Agent 在选表、在写 SQL、在校验、在执行），而不只是拿到一个答案。

### 1.2 硬约束

| 约束 | 来源 | 落地方式 |
| --- | --- | --- |
| 不改动作业一的核心逻辑 | 换框架/换前端不该动安全边界 | `core/` 是逐字副本 + 一致性测试 |
| 安全边界不能被 Web 层削弱 | 作业一的 README「安全边界」表 | Web 层只做协议转换，不碰 DB 层 |
| API key 不进代码、不进仓库 | 仓库级约定 | 只从环境变量 / `.env` 读；`.env` 在 `.gitignore` |
| 交付要有截图 | 本课程历届作业惯例 | `scripts/screenshot.py` 自动生成 4 张 |
| 注释 / 提示词 / 面向用户的回答用中文 | 仓库级约定 | 全仓库中文 |

### 1.3 非目标（明确不做）

- 不做用户登录 / 鉴权 —— 本机演示。
- 不做会话持久化到磁盘 —— `MemorySaver` 够用。
- 不做多用户隔离。
- 不做前端构建工程 —— 单文件 + CDN，零构建。

---

## 2. 总体架构

```mermaid
graph TD
    subgraph 浏览器
        UI[frontend/index.html<br/>Vue 3 CDN 单文件]
        LS[(localStorage<br/>会话 id 列表)]
    end
    subgraph Web 层
        API[api/app.py<br/>FastAPI 路由 + SSE]
        DEP[api/deps.py<br/>图 / 目录 / 会话历史]
        SCH[api/schemas.py<br/>Pydantic 契约]
    end
    subgraph 核心层（作业一副本）
        G[graph/build.py<br/>StateGraph 编译]
        N[graph/nodes.py<br/>8 个节点]
        CH[chains/*<br/>选表 / 生成 SQL / 汇总]
        AG[agents/sql_fixer.py<br/>create_agent 子图]
        DB[db/*<br/>目录 / 校验器 / 执行器]
    end
    SQLITE[(chinook.db)]
    LLM[DeepSeek<br/>OpenAI 兼容端点]

    UI -->|fetch POST /api/chat| API
    UI -->|fetch GET /api/*| API
    UI <--> LS
    API --> DEP
    API --> G
    SCH -.约束.-> API
    G --> N
    N --> CH --> LLM
    N --> AG --> LLM
    N --> DB --> SQLITE
    DEP --> G
```

### 2.1 三层职责

**前端层**（`frontend/index.html`）

- 只有一个 `setup()`，状态全部在 `setup()` 的闭包里。
- 只做三件事：发请求、解析 SSE、渲染。
- **不做任何业务判断** —— 不判断 SQL 对不对、不重试、不拼提示词。

**Web 层**（`api/`）

- HTTP ↔ 图调用之间的翻译层。
- 唯一的「业务」是把图的输出拍平成前端要的形状（`_build_chat_result`）。
- 依赖注入集中在 `deps.py`，测试时整块替换。

**核心层**（`core/`）

- 作业一原样拷贝，管选表、生成、校验、执行、汇总、多轮上下文。
- Web 层**一行都没改**（除了 `config.py` 的两处路径）。

### 2.2 为什么核心层要整份复制，而不是抽公共包

三个方案：

| 方案 | 优点 | 缺点 |
| --- | --- | --- |
| A. 抽成 `sql_agent_core` 公共包，两个作业都依赖 | DRY | 作业要**独立提交**，公共包得单独发仓库或做 git submodule —— 老师那边解压就能跑的要求直接不满足 |
| B. 作业二 `from 作业一.src...` 跨目录 import | DRY | 交付目录不完整，拷走就坏 |
| C. **完整复制 + 一致性测试**（采用） | 每个目录都能独立跑、独立提交 | 有一份重复代码 |

选 C。重复的代价用**测试**补回来：`tests/test_core_parity.py` 逐字比对两个目录，
差异只允许出现在白名单里。改了核心忘了同步，测试立刻红。

---

## 3. API 设计

### 3.1 总览

| 方法 | 路径 | 作用 | 需要 key | 流式 |
| --- | --- | --- | --- | --- |
| `GET` | `/` | 返回 `frontend/index.html` | 否 | 否 |
| `GET` | `/api/health` | 健康检查 + provider 状态 | 否 | 否 |
| `GET` | `/api/schema` | 表结构概览 | 否 | 否 |
| `POST` | `/api/chat` | 问答 | 是 | **是（SSE）** |
| `GET` | `/api/sessions/{sid}` | 会话历史 | 否 | 否 |
| `DELETE` | `/api/sessions/{sid}` | 清空会话 | 否 | 否 |

**只有 `POST /api/chat` 需要 key**，因为只有它会调模型。
其余接口全部直接读本地状态 —— 页面加载时前端会并发打 `/api/health` 和 `/api/schema`，
没配 key 也能看到完整的数据库概览。

### 3.2 `POST /api/chat`

**请求**

```json
{ "session_id": "a3cf10", "message": "总共有多少张专辑？" }
```

| 字段 | 类型 | 约束 | 说明 |
| --- | --- | --- | --- |
| `session_id` | `string \| null` | ≤ 64 字符 | 不传或传 `null` → 服务端新建 |
| `message` | `string` | 1 ~ 2000 字符 | 自然语言问题 |

**响应**：`text/event-stream`。错误语义：

| 情况 | 表现 |
| --- | --- |
| 参数不合法（空 message / 超过 2000 字） | `422`，FastAPI 默认错误体（**不**走 SSE） |
| 图跑完但没有产出 | SSE `error` 事件，`message="查询没有产生结果。"` |
| 图中途抛异常 | SSE `error` 事件，`message=f"处理失败：{exc}"`，服务端同时 `logger.exception` |
| 请求被客户端取消 | `AbortError`，前端静默丢弃 |

> SSE 一旦开始推流就没法再改状态码，所以**所有**运行期错误都以 `error` 事件收尾，
> 而不是抛 HTTP 错误。参数错误发生在开流之前，用 422。

### 3.3 `GET /api/sessions/{sid}`

返回：

```json
{
  "session_id": "a3cf10",
  "turns": [
    {"role": "user",      "question": "总共有多少张专辑？", "answer": "", "tables": [], "sql": ""},
    {"role": "assistant", "question": "总共有多少张专辑？", "answer": "总共有 347 张专辑。",
     "tables": ["albums"], "sql": "SELECT COUNT(*) AS TotalAlbums FROM albums"}
  ]
}
```

**实现上有个坑**：`GET /api/sessions` 走的是 `deps.get_session_turns()`，
它**直接读 checkpointer**，不经过图。

原因：要建图就得构造 LLM 链，而构造链需要 API key —— 但「查看历史」这件事本身不需要模型。
如果这个接口走 `deps.get_graph()`，没配 key 的环境就查不了自己的历史。

读法：

```python
snapshot = checkpointer.get_tuple(config)          # CheckpointTuple
channel_values = snapshot.checkpoint["channel_values"]
history = channel_values.get("history") or []
```

注意 `CheckpointTuple` **没有** `.values` 属性（实测 `AttributeError`），
channel 值在 `snapshot.checkpoint["channel_values"]` 里。

### 3.4 `DELETE /api/sessions/{sid}`

内部调 `SessionManager.clear()` → `checkpointer.delete_thread(sid)`。

**不能用 `graph.update_state(config, {"history": []})`** ——
`history` 声明了 `add` reducer，空列表等于「追加零条」，历史一条都不会少。
实测踩过，测试 `test_清空会话后历史真的没了` 专门盯这条。

---

## 4. SSE 事件协议

### 4.1 帧格式

```
event: <事件名>
data: <JSON 一行>

```

（两个换行结束一帧。）

### 4.2 三种事件

| 事件 | 触发时机 | data 字段 |
| --- | --- | --- |
| `stage` | 每进入一个图节点 | `stage`（节点名）、`label`（中文标签）、`session_id` |
| `final` | 图跑完 | `ChatResult` 全量（见下） |
| `error` | 运行期异常 | `message`（含原始异常文本）、`session_id` |

`final` 的 data：

```json
{
  "session_id": "a3cf10",
  "answer": "总共有 347 张专辑。",
  "sql": "SELECT COUNT(*) AS TotalAlbums FROM albums",
  "tables": ["albums"],
  "columns": ["TotalAlbums"],
  "rows": [["347"]],
  "row_count": 1,
  "truncated": false,
  "repair_attempts": 0,
  "evidence": ["TotalAlbums = 347"],
  "caveats": [],
  "error": null
}
```

### 4.3 为什么用 `stream_mode="updates"`

LangGraph 的 `astream` 有三种模式：

| 模式 | 产出 | 能不能用来做阶段进度 |
| --- | --- | --- |
| `values` | 每步之后的**完整状态** | 能，但体积大（每步都推一遍完整 history） |
| `updates` | `{节点名: 该节点的状态增量}` | **能，且最省** —— 拿到节点名就知道走到哪了 |
| `messages` | LLM 的 token 流 | 不能 —— 只有 LLM 输出，没有图的结构 |

选 `updates`：阶段进度需要的只是「现在在哪个节点」，`updates` 正好直接给节点名。

```python
async for chunk in graph.astream({"question": ...}, config, stream_mode="updates"):
    for node_name in chunk:
        if node_name.startswith("__"):   # __start__ / __end__ 是 LangGraph 的伪节点
            continue
        yield _sse("stage", {"stage": node_name, ...})
```

### 4.4 一个 LangGraph 1.x 的坑

`recursion_limit` **必须放在 config 字典里**，不能当第三个位置参数：

```python
# 对
config = {**manager.config(session_id), "recursion_limit": RECURSION_LIMIT}
graph.astream({"question": ...}, config, stream_mode="updates")

# 错 —— TypeError: astream() takes from 3 to 4 positional arguments
graph.astream({"question": ...}, config, "updates", RECURSION_LIMIT)
```

作业一的 CLI 也踩过同一个坑（`cli.py:_run_turns`），两处都用 config 写法。

### 4.5 节点 → 中文标签

`api/app.py:STAGE_LABELS`：

| 节点 | 标签 |
| --- | --- |
| `capture_question` | 正在理解问题… |
| `select_tables` | 正在选择数据表… |
| `generate_sql` | 正在生成 SQL… |
| `validate` | 正在校验 SQL… |
| `execute` | 正在执行查询… |
| `repair` | 正在修复 SQL… |
| `summarize` | 正在整理结果… |
| `finalize` | 正在生成回答… |

---

## 5. 多轮会话

### 5.1 三方配合

```
浏览器 localStorage                服务端 MemorySaver              LangGraph
─────────────────────             ─────────────────────           ──────────
sqlagent.session  ──session_id──▶  thread_id ──────────────────▶  checkpoint
sqlagent.sessions ──列表────────▶                                       │
（会话 id + 标题）                                                      ▼
                                                                    state.history
                                                                    （问答轮次）
```

- **`history`** 在作业一的状态里声明了 `add` reducer —— 每轮往**后追加**，
  两个节点各写一条（user 一条、assistant 一条），所以一轮问完是 2 条。
- 选表 / 生成 SQL / 汇总三条链都把 `history` 拼进提示词，模型因此看得见上一轮说了什么。
- 前端第二次提问带同一个 `session_id` → 同一个 `thread_id` → 图从 checkpoint 恢复。

### 5.2 生命周期

| 动作 | 前端 | 服务端 |
| --- | --- | --- |
| 首次提问 | 不带 `session_id` | 生成 `session_id`，回传在 `stage` / `final` 事件里 |
| 后续提问 | 带同一个 `session_id` | 同一个 `thread_id`，恢复历史 |
| 新建会话 | 清空 `session_id` 和消息区 | 旧线程仍在（可从列表切回） |
| 清空会话 | `DELETE /api/sessions/{sid}` | `delete_thread` —— 整个线程删掉 |
| 服务重启 | 列表还在（localStorage） | **历史没了**（`MemorySaver` 在内存里） |

### 5.3 「切回旧会话」的显示范围

服务端的历史轮次只存**问题、答案、用到的表、SQL**，
**不存结果表格** —— 表格数据留在 checkpoint 的 `state.execution` 里，
但把它塞进 `history` 会让提示词越来越长。

所以从会话列表切回来时，看到问答和 SQL，**看不到当时的表格**（重新提问一次就有）。
这是有意的取舍，写在 README 的「已知限制」里。

---

## 6. 前端设计

### 6.1 为什么是单文件 + CDN

| 方案 | 结论 |
| --- | --- |
| Vue CLI / Vite 工程 | 老师那边要 `npm install && npm run build`，解压即跑的要求不满足 |
| **CDN 单文件（采用）** | 改完刷新就生效；只有 1 个 `<script src>`；缺点是依赖外网 |
| React | 本课程栈是 LangChain 系，前端用 Vue 更一致 |

`vue.global.prod.js` 是**带运行时编译器**的完整版 —— 这点很重要，
因为本项目用的是 **in-DOM 模板**（模板直接写在 `#app` 里），
运行时编译器会把 `#app` 的 `innerHTML` 当模板编译。

> **踩过的坑**：加载遮罩一开始放在 `#app` 里面，结果这段「正在加载 Vue 3」
> 被当成模板的一部分渲染出来，浮在页面左上角（见 `tests/test_frontend.py::test_加载遮罩在_app_外面`）。
> 现在遮罩是 `#app` 的**兄弟节点**，由脚本 `document.getElementById('boot').remove()` 移除。

### 6.2 状态模型

`setup()` 里全部状态：

| 变量 | 类型 | 说明 |
| --- | --- | --- |
| `messages` | `ref([])` | 消息数组，每条是 `{role, text/answer, stages, sql, tables, columns, rows, ...}` |
| `draft` | `ref('')` | 输入框内容 |
| `busy` | `ref(false)` | 正在等后端 |
| `sessionId` | `ref('')` | 当前会话 id（同时写进 localStorage） |
| `schema` | `ref({tables: []})` | 数据库概览 |
| `health` | `ref({})` | 健康状态 |
| `sessions` | `ref([])` | 会话列表（localStorage） |

`messages` 里每条消息的 `stages` 是个小数组：

```js
{ key: 'select_tables', label: '正在选择数据表…', state: 'on' | 'done', order: 2 }
```

`order` 用来判断「前面的节点已经跑完了」，`state` 决定标签配色（灰 / 蓝 / 绿）。

### 6.3 SSE 解析

**不能用 `EventSource`** —— 它只能发 GET，而问答必须发 POST（请求体带问题）。
所以用 `fetch` + `ReadableStream`：

```js
const resp = await fetch('/api/chat', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ session_id: sessionId.value || null, message: question }),
  signal: controller.signal
});
const reader = resp.body.getReader();
const decoder = new TextDecoder();
let buffer = '';
while (true) {
  const { done, value } = await reader.read();
  if (done) break;
  buffer += decoder.decode(value, { stream: true });
  let idx;
  while ((idx = buffer.indexOf('\n\n')) >= 0) {     // 以空行切帧
    const raw = buffer.slice(0, idx);
    buffer = buffer.slice(idx + 2);
    handleFrame(parseSSE(raw));
  }
}
```

要点：

- **按 `\n\n` 切帧**，不能假设一次 `read()` 就是一个完整帧 —— TCP 分片是随机的。
- `decoder.decode(value, { stream: true })`：多字节字符可能被切在两帧中间，
  不加 `stream: true` 会在中文处出现乱码。
- `TextDecoder` 保持实例、不要每帧新建。

### 6.4 组件划分

单文件里没有组件拆分，靠**区块**划分（CSS class 区分）：

| 区块 | class | 内容 |
| --- | --- | --- |
| 侧栏 | `.sidebar` | 会话列表 + 数据库表 |
| 顶栏 | `.topbar` | 状态灯 + 会话操作 |
| 消息区 | `.messages` | 消息流 |
| 气泡 | `.bubble` | 阶段标签 / 正文 / 表格 / SQL |
| 输入区 | `.composer` | textarea + 发送按钮 |

### 6.5 表格渲染

结果行是 `list[list[str]]`（和 `ExecutionResult.rows` 一致），列名在 `columns` 里。

```html
<thead><tr><th v-for="c in m.columns" :key="c">{{ c }}</th></tr></thead>
<tbody>
  <tr v-for="(r, ri) in m.rows" :key="ri">
    <td v-for="(cell, ci) in r" :key="ci">{{ cell }}</td>
  </tr>
</tbody>
```

`rows` 是二维数组，所以 `v-for` 用双层索引（`ri` / `ci`）做 key。

---

## 7. 核心代码的复用策略

### 7.1 复制了什么

`作业一/src/langgraph_sql_agent/` → `作业二/src/langgraph_web_agent/core/`

**24 个模块，23 个逐字一致**，只有 `config.py` 不同。

### 7.2 两处刻意的差异

| 位置 | 作业一 | 作业二 | 为什么 |
| --- | --- | --- | --- |
| `config.py:PROJECT_ROOT` | `parents[2]` | `parents[3]` | 作业二多一层 `langgraph_web_agent/` 包 |
| `config.py:_FALLBACK_ENV_FILES` | `PROJECT_ROOT.parent / "作业二" / ".env"` | `PROJECT_ROOT.parent / "作业一" / ".env"` | 各自回退到对方的 `.env`，本机调试方便 |

`diff -r` 的完整输出（去掉 `__pycache__`）：

```
Only in 作业一/src/langgraph_sql_agent: __main__.py
Only in 作业一/src/langgraph_sql_agent: cli.py
Files 作业一/.../config.py and 作业二/.../core/config.py differ
```

`cli.py` / `__main__.py` 不复制：作业一是命令行工具，作业二是 Web 服务，
入口逻辑完全不同（作业二有自己的一套 `cli.py` / `__main__.py`）。

### 7.3 一致性测试

`tests/test_core_parity.py` 做四件事：

1. **逐字比对**：对每个模块，把作业二的版本和作业一的版本做文本比对，
   要求**完全相等**，且**文件清单**也完全相等（不多不少）。
2. **差异白名单**：`config.py` 允许的 4 处差异（2 处代码 + 2 处注释），
   测试先把作业二的写法**替换回**作业一的写法，再要求整体相等 ——
   白名单之外多出任何差异都会红。
3. **PROJECT_ROOT 指向检查**：断言作业二的 `PROJECT_ROOT` 落在「作业二」目录下，
   且 `data/chinook.db` 就在那儿。
4. **可导入性冒烟**：核心包能正常 import，`build_graph` 可调用，`SessionManager` 能发号。

---

## 8. 安全边界

Web 层**没有削弱**作业一的任何一条边界：

| 边界 | 实现位置 | Web 层做了什么 |
| --- | --- | --- |
| 数据库只读 | `core/db/catalog.py:make_readonly_url`、`core/db/executor.py:_readonly_uri` | 什么都没做（照抄） |
| 校验器不执行 SQL | `core/db/validator.py`（只 `EXPLAIN`） | 什么都没做 |
| 拒绝写操作 | `core/db/validator.py`（只放行 `SELECT` / `WITH`） | 什么都没做 |
| LLM 不批准自己的 SQL | `core/graph/nodes.py` | 什么都没做 |
| 修复轮数上限 3 | `core/graph/build.py` | 什么都没做 |
| `recursion_limit=25` | `core/graph/build.py` | 照抄，但**放在 config 字典里**（见 §4.4） |
| 结果截断 200 行 / 2000 字符 | `core/config.py` | 什么都没做 |
| 查询超时 5 秒 | `core/db/executor.py` | 什么都没做 |
| key 不硬编码 | `core/config.py` | 照抄 |
| key 不外泄 | — | **`/api/health` 只返回 `api_key_present`（布尔），不返回 key** |
| 前端不含 key | — | `tests/test_frontend.py` 静态检查 |

**Web 层新增的边界**：

- `message` 长度上限 2000 字（`ChatRequest` 的 `max_length`）。
- `session_id` 长度上限 64 字符。
- 前端**没有**任何鉴权 —— 本机演示用，见「已知限制」。

---

## 9. 实测记录

### 9.1 真实 SSE 流（第一轮）

```
$ curl -sN -X POST http://127.0.0.1:8021/api/chat \
    -H "Content-Type: application/json" --data-binary @req1.json

event: stage
data: {"stage": "start", "label": "已收到问题…", "session_id": "demo1"}
event: stage
data: {"stage": "capture_question", "label": "正在理解问题…", "session_id": "demo1"}
event: stage
data: {"stage": "select_tables", "label": "正在选择数据表…", "session_id": "demo1"}
event: stage
data: {"stage": "generate_sql", "label": "正在生成 SQL…", "session_id": "demo1"}
event: stage
data: {"stage": "validate", "label": "正在校验 SQL…", "session_id": "demo1"}
event: stage
data: {"stage": "execute", "label": "正在执行查询…", "session_id": "demo1"}
event: stage
data: {"stage": "summarize", "label": "正在整理结果…", "session_id": "demo1"}
event: stage
data: {"stage": "finalize", "label": "正在生成回答…", "session_id": "demo1"}
event: final
data: {"session_id": "demo1", "answer": "总共有 347 张专辑。",
       "sql": "SELECT COUNT(*) AS TotalAlbums FROM albums", "tables": ["albums"],
       "columns": ["TotalAlbums"], "rows": [["347"]], "row_count": 1, "truncated": false,
       "repair_attempts": 0, "evidence": ["TotalAlbums = 347"], "caveats": [], "error": null}
```

### 9.2 第二轮（上下文生效）

问题：**「那按专辑数量排名前 3 的艺术家呢？」**

```json
{
  "answer": "按专辑数量排名前 3 的艺术家依次为：Iron Maiden（21 张）、Led Zeppelin（14 张）、Deep Purple（11 张）。",
  "sql": "SELECT a.Name AS ArtistName, COUNT(al.AlbumId) AS AlbumCount\nFROM artists a\nJOIN albums al ON al.ArtistId = a.ArtistId\nGROUP BY a.ArtistId, a.Name\nORDER BY AlbumCount DESC, a.Name ASC\nLIMIT 3",
  "tables": ["albums", "artists"],
  "columns": ["ArtistName", "AlbumCount"],
  "rows": [["Iron Maiden", "21"], ["Led Zeppelin", "14"], ["Deep Purple", "11"]],
  "caveats": ["统计仅包含在 albums 表中有专辑记录的艺术家（内连接），无专辑的艺术家不计入"]
}
```

「那」能被理解成「接着上一轮的专辑说」—— 因为 `history` 里有上一轮。
模型还自己加了一条 caveat 说明内连接的语义边界。

### 9.3 会话历史接口

```
$ curl -s http://127.0.0.1:8021/api/sessions/demo1

user      | 总共有多少张专辑？               | []                     |
assistant | 总共有多少张专辑。               | ['albums']             | SELECT COUNT(*) AS TotalAlbums FROM albums
user      | 那按专辑数量排名前 3 的艺术家呢？ | []                     |
assistant | 按专辑数量排名前 3 的艺术家依次为… | ['albums', 'artists'] | SELECT a.Name AS ArtistName, …
```

一轮 = 2 条（user + assistant），符合 `history` 的 `add` reducer 语义。

### 9.4 截图

| 文件 | 内容 |
| --- | --- |
| `docs/01-首页与数据库概览.png` | 左栏 11 张表 + 行数列数，顶部「模型已就绪」 |
| `docs/02-提问与阶段进度.png` | 5 个阶段标签，4 个已绿、1 个正在跑 |
| `docs/03-结果表格与SQL详情.png` | 结果表格 + 展开的 SQL + 证据行 |
| `docs/04-多轮追问.png` | 两轮对话，第二轮带上下文 |

截图由 `scripts/screenshot.py` 用 Playwright 生成（**会真的调模型**），
脚本里带断言：表数量必须是 11、状态灯必须显示「模型已就绪」、
结果表必须至少 1 行、SQL 区必须含 `SELECT`。

---

## 10. 已知限制

| 限制 | 原因 | 影响 |
| --- | --- | --- |
| **无鉴权** | 本机演示 | 任何能访问端口的人都能提问、能读别人的会话历史 |
| **会话不持久** | `MemorySaver` 在内存 | 服务重启丢历史；多进程部署时各进程的 `thread_id` 互不相通 |
| **历史轮次不存表格** | 表格塞进 `history` 会撑爆提示词 | 切回旧会话看不到当时的结果表（重新问一次就有） |
| **前端依赖 unpkg CDN** | 单文件零构建 | 离线环境要自己把 `vue.global.prod.js` 下到本地改 `<script src>` |
| **同会话并发会打架** | `thread_id` 共享 checkpoint | 同一会话同时发两个请求，后写的覆盖先写的 |
| **修复路径在 Chinook 上很少触发** | 表结构规整，模型一次写对的概率高 | `repair` 节点主要靠单元测试覆盖，实测轨迹里没出现过 |
| **前端不轮询服务端会话列表** | `MemorySaver` 没有公开的 thread 列表 API | 列表由浏览器自己维护，服务端删掉的会话前端可能还留着（点开是空） |

---

## 附：实测踩过的坑

| 坑 | 现象 | 解法 |
| --- | --- | --- |
| `recursion_limit` 当位置参数传 | `TypeError: astream() takes from 3 to 4 positional arguments` | 放进 config 字典 |
| `EventSource` 发不了 POST | 问答请求根本发不出去 | `fetch` + `ReadableStream` |
| `CheckpointTuple` 没有 `.values` | `AttributeError` | 用 `snapshot.checkpoint["channel_values"]` |
| `update_state` 清不掉 `history` | 历史一条没少 | `checkpointer.delete_thread()` |
| `deps.get_graph()` 需要 key | 没配 key 时连历史都查不了 | 历史接口直接读 checkpointer |
| 加载遮罩放进 `#app` | 「正在加载 Vue 3」浮在页面左上角 | 遮罩改成 `#app` 的兄弟节点 |
| `from .deps import get_graph` 不好 monkeypatch | 测试替换不了 | 改成 `from . import deps` + `deps.get_graph()` |
