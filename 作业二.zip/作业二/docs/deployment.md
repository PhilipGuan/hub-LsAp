# 部署说明

> 适用：第十三周作业二（`作业二/`）
> 作业一是命令行工具，不需要部署 —— 见文末「作业一怎么跑」。

---

## 0. 先看这里：两种启动脚本

| 脚本 | 平台 | 监听 | 谁能访问 |
| --- | --- | --- | --- |
| `start_server.bat` / `.sh` | Windows / Linux / macOS | `127.0.0.1:8000` | **只有本机** |
| `start_lan.bat` / `.sh` | Windows / Linux / macOS | `0.0.0.0:8000` | 同一网段的所有设备 |

两个脚本都会：**检查 python → 检查 `.env`（没有就从 `.env.example` 复制）→ 检查并安装依赖 → 打印访问地址 → 启动服务**。

```bash
# Windows：双击 start_server.bat，或者
start_server.bat

# Linux / macOS
chmod +x start_server.sh
./start_server.sh
```

> ⚠️ **本项目没有登录鉴权。**
> `start_lan.*` 会把接口开放给整个局域网 —— 任何同网段的人都能提问、能读你的会话历史。
> 只在可信网络里用，用完关掉。要放到公网，请看 §4 的反向代理 + 鉴权建议。

### 脚本是怎么分工的

```
start_server.bat   ← 纯 ASCII 的 8 行：切目录 → 调 Python
        ↓
scripts/launch.py  ← 真正的逻辑：查 .env、装依赖、打印地址、起服务、开浏览器
        ↓
python -m langgraph_web_agent
```

**为什么中间要垫一层 Python？** 因为 cmd.exe 读 UTF-8 批处理文件有个坑，
见下面「附录 A：cmd.exe 踩坑」。简单说：`.bat` 里放中文会被 cmd 读错位，
所以 `.bat` 保持纯 ASCII，中文提示全交给 Python（Python 走 `WriteConsoleW`，
不受控制台代码页影响）。

---

## 1. 方式 A · 本机跑（最快，30 秒）

```bash
cd 作业二
copy .env.example .env          # Windows
# cp .env.example .env          # Git Bash / macOS
# 编辑 .env，填入 SQL_AGENT_API_KEY=sk-xxx

start_server.bat                # 或 ./start_server.sh
```

浏览器打开 <http://127.0.0.1:8000>。

不想用脚本的话，等价的命令是：

```bash
pip install -r requirements.txt
PYTHONPATH=src python -X utf8 -m langgraph_web_agent --host 127.0.0.1 --port 8000
```

**资源占用**：Python 进程约 150 ~ 250 MB 内存（langchain + langgraph 导入比较重）。
第一次请求会慢 1 ~ 2 秒（要建 LLM 链），之后每轮问答 5 ~ 15 秒（取决于模型）。

---

## 2. 方式 B · 局域网访问（同事 / 手机）

```bash
start_lan.bat                   # 或 ./start_lan.sh
```

脚本会打印本机局域网 IP，直接在手机浏览器打开那个地址即可。

**连不上时按这个顺序排查**：

1. **Windows 防火墙** —— 第一次启动会弹「是否允许 Python 访问网络」，必须选**允许访问**。
   没弹窗的话手动加一条入站规则：
   ```powershell
   New-NetFirewallRule -DisplayName "Chinook Web 8000" -Direction Inbound -LocalPort 8000 -Protocol TCP -Action Allow
   ```
2. **手机和电脑要在同一个 Wi-Fi** —— 访客网络 / 4G 不通。
3. **路由器开了 AP 隔离** —— 同网段设备互相不可见，关掉它。
4. **IP 变了** —— 脚本每次启动都重新取 IP；也可以 `ipconfig`（Windows）/ `ip addr`（Linux）手动查。

> 本项目**不需要 HTTPS**：只有 `getUserMedia`（摄像头）才强制要求 secure context，
> 本作业没有摄像头功能。局域网 http 直接用就行。

---

## 3. 方式 C · Linux 云服务器（AutoDL / 阿里云 / 腾讯云）

### 3.1 拉代码 + 装依赖

```bash
# 把作业目录传上去（scp / git clone / WinSCP 都行），然后：
cd 作业二

python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements-runtime.txt      # 只装运行时依赖，不装 pytest/ruff
```

### 3.2 配 key

```bash
cp .env.example .env
vi .env       # 填 SQL_AGENT_API_KEY
chmod 600 .env
```

### 3.3 前台跑（先验证一下）

```bash
PYTHONPATH=src python -X utf8 -m langgraph_web_agent --host 0.0.0.0 --port 8000
curl http://127.0.0.1:8000/api/health
```

看到 `"status":"ok"` 就说明起来了。

### 3.4 后台常驻

**方式一：nohup（简单）**

```bash
PYTHONPATH=src nohup python -X utf8 -m langgraph_web_agent \
    --host 0.0.0.0 --port 8000 > logs/web-agent.log 2>&1 &
echo $! > logs/web-agent.pid
```

**方式二：systemd（推荐，能自动重启）**

```bash
sudo tee /etc/systemd/system/web-agent.service > /dev/null <<'EOF'
[Unit]
Description=Chinook 数据智能问答（LangGraph SQL Agent）
After=network.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=/home/ubuntu/作业二
Environment="PYTHONPATH=/home/ubuntu/作业二/src"
EnvironmentFile=/home/ubuntu/作业二/.env
ExecStart=/home/ubuntu/作业二/.venv/bin/python -X utf8 -m langgraph_web_agent --host 0.0.0.0 --port 8000
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable --now web-agent
sudo systemctl status web-agent
```

> `EnvironmentFile` 直接读 `.env` —— 不用在 service 文件里写 key。
> **不要**把 key 写进 `ExecStart` 或 `Environment=` 里（`systemctl show` 会把它显示出来）。

### 3.5 开放端口

云服务器还要在**安全组**里放行（很多人卡在这一步）：

- 阿里云 / 腾讯云：控制台 → 安全组 → 入方向规则 → 放行 TCP 8000，源 `0.0.0.0/0`（演示用；正式用请收紧）。
- AutoDL：控制台 → 自定义服务 → 添加 `8000` 端口。

### 3.6 AutoDL 特别注意

AutoDL 的容器实例重启后，**`/root/autodl-tmp` 之外的目录会被清空**。把作业放在 `/root/autodl-tmp/` 下：

```bash
cd /root/autodl-tmp
# 把作业放这里
```

---

## 4. 反向代理 + HTTPS（要给别人访问时）

```bash
sudo apt install -y nginx
sudo tee /etc/nginx/sites-available/web-agent > /dev/null <<'EOF'
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_http_version 1.1;

        # SSE 必须关掉缓冲，否则阶段进度会攒到最后一次性吐出来
        proxy_buffering off;
        proxy_cache off;
        proxy_read_timeout 300s;
        proxy_set_header Connection '';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
EOF

sudo ln -sf /etc/nginx/sites-available/web-agent /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx
```

> **`proxy_buffering off;` 这一行不能省。**
> 本项目的问答是 SSE 长连接，nginx 默认会缓冲响应 ——
> 表现是「页面一直转圈，最后一次性蹦出全部结果」，阶段进度动画完全失效。

配 HTTPS：

```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d your-domain.com
```

> ⚠️ **公网部署前先想清楚鉴权。**
> 本项目没有登录 —— 加上反代等于把「能对 chinook.db 自由查询的接口」开放给公网。
> 内网/作业演示没问题；真要长期挂公网，请在 nginx 层加一层 Basic Auth：
> ```nginx
> location / {
>     auth_basic "Restricted";
>     auth_basic_user_file /etc/nginx/.htpasswd;
>     proxy_pass http://127.0.0.1:8000;
>     ...
> }
> ```
> `sudo apt install apache2-utils && sudo htpasswd -c /etc/nginx/.htpasswd 用户名`

---

## 5. 方式 D · Docker

仓库里有 `Dockerfile`，构建和运行：

```bash
cd 作业二
docker build -t langgraph-web-agent .

docker run -d --name web-agent \
    -p 8000:8000 \
    -e SQL_AGENT_API_KEY=sk-xxx \
    -e SQL_AGENT_BASE_URL=https://api.deepseek.com/v1 \
    langgraph-web-agent
```

**key 从环境变量传，不进镜像层**（`docker history` 看不到）。

已实测：

```bash
$ curl http://127.0.0.1:8000/api/health
{"status":"ok","api_key_present":true,...,"db_path":"/app/data/chinook.db","db_tables":11}

$ docker inspect --format '{{.State.Health.Status}}' web-agent
healthy
```

镜像里已经带了本地化的 Vue（构建时自动下载），**容器内外网不通也能正常显示页面**。

**挂载自己的 `.env`**（不想在命令行里写 key 时）：

```bash
docker run -d --name web-agent -p 8000:8000 \
    --env-file .env \
    langgraph-web-agent
```

但注意：`.env` 里的 `WEB_HOST` / `WEB_PORT` 会被容器里的 `ENV` 覆盖（Dockerfile 里写死了 `0.0.0.0:8000`），
这是**故意的** —— 容器里必须监听 `0.0.0.0` 才通得了。

---

## 6. 离线 / 内网部署（前端不能连 CDN）

前端默认从 unpkg CDN 加载 Vue 3。**内网、云服务器、教室断网**的环境会白屏
（页面停在「正在加载 Vue 3 …」）。

解决：把 Vue 落到本地。

```bash
python -X utf8 scripts/vendor_vue.py
```

它会：

1. 下载 `vue.global.prod.js` 到 `frontend/vendor/`（169 KB）；
2. 把 `frontend/index.html` 的 `<script src>` 改成 `./vendor/vue.global.prod.js`。

后端**自动**挂载 `/vendor` 静态路由（`api/app.py` 里判断目录存在才挂）。
不需要额外配置。

已实测（把 CDN 请求全部 abort 掉模拟断网）：

```
渲染出的表数量: 11
加载遮罩是否还在: 0
页面 JS 异常: 无
```

**改回 CDN**：

```bash
python -X utf8 scripts/vendor_vue.py --restore
```

> ⚠️ `frontend/vendor/vue.global.prod.js` 是**第三方代码**（MIT 协议）。
> 如果作业要提交到 GitHub，建议**不要**把它入库 —— 保持仓库干净，
> 让部署的人自己跑一次 `vendor_vue.py` 即可。

---

## 7. 环境变量清单

| 变量 | 必填 | 默认 | 说明 |
| --- | --- | --- | --- |
| `SQL_AGENT_API_KEY` | ✅ | — | 模型 key。也兼容 `OPENAI_API_KEY` / `DEEPSEEK_API_KEY` / `LLM_API_KEY` |
| `SQL_AGENT_BASE_URL` | | `https://api.deepseek.com/v1` | OpenAI 兼容端点 |
| `SQL_AGENT_MODEL` | | `deepseek-v4-pro` | 选表 / 生成 / 修复 |
| `SQL_AGENT_SUMMARY_MODEL` | | `deepseek-flash` | 结果汇总 |
| `SQL_AGENT_THINKING` | | `disabled` | **必须 disabled**，否则 DeepSeek 拒绝强制 `tool_choice` |
| `SQL_AGENT_DB` | | `data/chinook.db` | 数据库路径（容器里是 `/app/data/chinook.db`） |
| `SQL_AGENT_MAX_REPAIR_ATTEMPTS` | | `3` | 修复轮数上限 |
| `SQL_AGENT_MAX_ROWS` | | `200` | 结果行数上限 |
| `SQL_AGENT_MAX_CELL_CHARS` | | `2000` | 单格字符上限 |
| `SQL_AGENT_QUERY_TIMEOUT` | | `5` | SQL 超时（秒） |
| `SQL_AGENT_REQUEST_TIMEOUT` | | `90` | 模型请求超时（秒） |
| `SQL_AGENT_LOG_LEVEL` | | `INFO` | `DEBUG` 能看到每个节点的耗时 |
| `WEB_HOST` | | `127.0.0.1` | 容器/Docker 里被覆盖成 `0.0.0.0` |
| `WEB_PORT` | | `8000` | 端口 |

---

## 8. 部署后自检清单

```bash
# 1. 服务活着吗
curl http://127.0.0.1:8000/api/health
#    期望：{"status":"ok","api_key_present":true,...,"db_tables":11}

# 2. 数据库读到了吗
curl http://127.0.0.1:8000/api/schema | head -c 200
#    期望：能看到 "name":"albums","row_count":347

# 3. 页面能打开吗（应返回 200 且是 HTML）
curl -o /dev/null -w "%{http_code}\n" http://127.0.0.1:8000/

# 4. 真问答跑得通吗
python -X utf8 -c "
import json, urllib.request
req = urllib.request.Request('http://127.0.0.1:8000/api/chat',
    data=json.dumps({'message':'总共有多少张专辑？'}, ensure_ascii=False).encode('utf-8'),
    headers={'Content-Type':'application/json'})
print(urllib.request.urlopen(req, timeout=180).read().decode('utf-8')[-300:])
"
#    期望：能看到 "answer": "总共有 347 张专辑。"

# 5. 反代之后 SSE 还正常吗（一定要关 proxy_buffering）
curl -N -X POST http://your-domain.com/api/chat \
    -H 'Content-Type: application/json' \
    -d '{"message":"总共有多少张专辑？"}'
#    期望：阶段事件一条一条出来，不是最后一次性蹦出来
```

---

## 9. 部署相关常见问题

| 现象 | 原因 | 解决 |
| --- | --- | --- |
| 页面一直显示「正在加载 Vue 3 …」 | unpkg 不可达 | 跑 `scripts/vendor_vue.py`（§6） |
| 页面全白，控制台报 `Vue is not defined` | CDN 挂了但脚本仍执行 | 同上 |
| 局域网连不上 | 防火墙 / 不同网段 / AP 隔离 | §2 的四条排查 |
| 反代后页面一直转圈，最后一次性出结果 | nginx 缓冲了 SSE | 加 `proxy_buffering off;`（§4） |
| `/api/health` 返回 `api_key_present: false` | `.env` 没配或没读到 | 检查 `.env` 位置；systemd 场景检查 `EnvironmentFile` |
| 提问报 `处理失败：...` | key 无效 / 模型名不对 | `SQL_AGENT_MODEL` 该 key 下只有 `deepseek-v4-pro` 和 `deepseek-flash` |
| 提问报 `Thinking mode does not support this tool_choice` | 思考模式没关 | `SQL_AGENT_THINKING=disabled` |
| 重启后历史没了 | `MemorySaver` 在内存里 | 设计如此；要持久化得换 `SqliteSaver` / `PostgresSaver` |
| Docker 里 `db_tables: 0` | `SQL_AGENT_DB` 指错了 | 容器里应该是 `/app/data/chinook.db` |
| Docker 起不来，报端口占用 | 宿主 8000 被占 | `-p 8080:8000` |

---

## 10. 作业一怎么跑（不需要部署）

作业一是**命令行工具**，没有 Web 服务：

```bash
cd 作业一
run.bat                                  # Windows，交互式提问
./run.sh                                 # Linux / macOS
run.bat "总共有多少张专辑？"                # 直接带问题
run.bat "总共有多少张专辑？" --then "那每个流派呢？"   # 多轮追问
```

等价的命令：

```bash
PYTHONPATH=src python -X utf8 -m langgraph_sql_agent "总共有多少张专辑？"
```

输出是一个 JSON（带 `--then` 时是 JSON 数组）。
注意：**多轮追问只能在同一次调用里做** —— `MemorySaver` 是进程内的，
`--session abc` 不能跨进程续接。

---

## 附：本次部署相关的实测记录

| 验证项 | 方法 | 结果 |
| --- | --- | --- |
| `start_server.bat` / `.sh` 的检查逻辑 | 删掉 `.env` 后跑脚本 | 正确从 `.env.example` 复制并提示填 key |
| 本地 Vue 静态挂载 | `curl /vendor/vue.global.prod.js` | `200`，172939 字节 |
| 离线渲染 | Playwright 拦截所有 unpkg 请求 | 11 张表正常渲染，无 JS 异常 |
| Docker 镜像 | `docker build` + `docker run` | `healthy`，`db_tables: 11` |
| 容器内真问答 | `POST /api/chat` | 「总共有 347 张专辑。」，SQL 与本地一致 |
| `vendor_vue.py` 幂等 | 连续跑两次 | 第二次提示「已经本地化过了」 |
| `vendor_vue.py --restore` | 恢复 CDN | index.html 复原，`vendor/` 被删除 |
| **全部 7 种脚本调用方式** | 绝对路径 / 相对路径 / `.sh` / 服务端探活 | 7/7 通过，**cmd 报错 0 条** |

---

## 附录 A：cmd.exe 踩坑（UTF-8 批处理文件会被读错位）

这一节记录本项目在 Windows 上真实踩到的坑 —— **不是理论，是复现出来的**。

### 现象

`.bat` 文件里的中文横幅打印正常，但紧接着出现这种报错：

```
'是「字节数」去续读批处理文件，' is not recognized as an internal or external command,
operable program or batch file.
'标签，不用括号块。' is not recognized as an internal or external command,
'手机访问？改跑' is not recognized as an internal or external command,
```

报错里的内容是**原命令行被拦腰截断后的后半截** —— cmd 把文件读到了错误的位置。

### 触发条件

三个条件**同时**满足才会触发（缺一不可，实测逐一验证过）：

1. `.bat` 文件是 **UTF-8 编码**且**含非 ASCII 字符**；
2. 文件里有 **`cd` 切目录**（`cd /d %~dp0`）；
3. 文件里有 **`goto` 跳标签**（或括号块）。

### 根因

cmd.exe 在 UTF-8 代码页下读批处理文件时，**按字符数记录读取位置，却按字节数去 seek**。
文件里每多一个中文字符，这个偏差就多 2~3 字节；等 cmd 需要回跳（`goto` 找标签、
`cd` 之后重新定位）时，位置就偏到了某一行中间 —— 剩下的半行被当成命令执行。

> 顺带一提：`cd /d %~dp0` 后面那个**结尾反斜杠**也是雷区之一。
> 括号块（`if ( ... )`）同样会让 cmd 用「字符数」续读文件。

### 规避办法（本项目采用）

**`.bat` / `.sh` 里不放任何非 ASCII 字符，中文提示全部交给 Python。**

```
start_server.bat       ← 纯 ASCII，CRLF，不含括号块
   ↓
scripts/launch.py      ← 中文提示在这里，Python 走 WriteConsoleW
```

这样 cmd 读到的每个字符都是 1 字节，**偏移永远不会累积**，问题从根上消失。

### 回归测试

`tests/test_scripts.py` 把这几条约束写成了断言：

| 断言 | 防的是什么 |
| --- | --- |
| `.bat` 必须是纯 ASCII | cmd 读错位 |
| `.bat` 必须是 CRLF | cmd 解析 LF-only 的批处理文件会把后续行截断 |
| `.sh` 必须是 LF | bash 下 CRLF 会报 `$'\r': command not found` |
| `.bat` 里不许有 `(` / `)` | 括号块之后的续读错位 |

### 另一个坑：LF-only 的 `.bat`

cmd.exe 对 **LF-only**（Unix 换行）的批处理文件解析有 bug，会把后续行截断。
症状是 `'b' 不是内部或外部命令`、`'cho'`、`'ll'` 这种莫名其妙的碎片。
`git` 换行符转换、某些编辑器保存都可能造成这个情况。

**`.bat` 一定要是 CRLF。** 本项目用 Python 写文件时统一 `.replace("\n", "\r\n")`。

### 排查这类问题时的一个陷阱

用 **heredoc 把脚本传给 Python** 时，反斜杠会被折叠一层：

```bash
python - <<'PY'
cmd = ".\\run.bat"     # 经过折叠 → Python 看到 ".\\run.bat" → 字符串 ".\run.bat"
PY
```

而 Python 再把 `"\r"` 读成**回车**、`"\a"` 读成**响铃**。
于是你会看到「cmd 吞掉了反斜杠」的假象：

```
'.un.bat' is not recognized ...
```

这不是 cmd 的问题，是**测试脚本自己被转义了**。验证 cmd 行为时，
用 `Path(...).absolute()` 拼路径，或者把验证脚本**用编辑器落盘**再跑，别用 heredoc 传带反斜杠的字面量。

