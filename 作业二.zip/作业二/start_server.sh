#!/usr/bin/env bash
# Chinook Data Q&A - local start, listens on 127.0.0.1 only.
# Chinese messages live in scripts/launch.py (see docs/deployment.md).
set -e
cd "$(dirname "$0")"
exec python -X utf8 scripts/launch.py --host 127.0.0.1 --port 8000
