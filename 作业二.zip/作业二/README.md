# 作业二 · LangGraph SQL Agent 的对话式前端

把「作业一」的 LangGraph 状态图包一层 **FastAPI 后端 + 单文件 Vue 3 前端**，
用户在网页上用自然语言提问，就能看到 Agent 选表、写 SQL、校验、执行的全过程，
拿到结果表格和自然语言回答，还能接着追问。

- **核心（`core/`）**：作业一 `langgraph_sql_agent` 的**完整副本**，只改了两行路径。
  一致性由 `tests/test_core_parity.py` 用逐字比对守住。
- **Web 层（`api/`）**：本作业新增。5 个接口，核心是 `POST /api/chat` 的 SSE 流式问答。
- **前端（`frontend/index.html`）**：一个文件，Vue 3 走 CDN，**零构建**，改完刷新就生效。

![首页与数据库概览](docs/01-首页与数据库概览.png)

---

## 1. 快速开始

```bash
cd "13-江洋明-第十三周作业/作业二"

# 1) 配 key（.env 不入库）
copy .env.example .env        # Windows cmd
# cp .env.example .env        # Git Bash / macOS
# 然后把 .env 里的 sk-在这里填你的_DeepSeek_Key 换成真 key

# 2) 起服务（一键：装依赖 + 查配置 + 启动 + 开浏览器）
start_server.bat             # Windows：只监听 127.0.0.1
./start_server.sh            # Linux / macOS

# 让同事 / 手机也能访问（监听 0.0.0.0，⚠️ 本项目没有鉴权）
start_lan.bat
```

不想用脚本的话，等价的命令是：

```bash
pip install -r requirements.txt
PYTHONPATH=src python -X utf8 -m langgraph_web_agent
# 或者：
PYTHONPATH=src python -X utf8 -m uvicorn langgraph_web_agent.api.app:app --host 127.0.0.1 --port 8000
```

浏览器打开 <http://127.0.0.1:8000>。

> **不用配 key 也能起**：服务照样起来，`/api/health` 会显示「未配置 API Key」，
> 只有真正提问时才需要模型。测试也**不需要 key**（LLM 全 mock）。

跑测试：

```bash
python -X utf8 -m pytest -q          # 81 个用例
python -X utf8 -m ruff check src tests
```

重新生成交付截图（**会真的调用模型**，需要 .env）：

```bash
# 先起服务，再另开一个终端
python -X utf8 scripts/screenshot.py --base http://127.0.0.1:8000
```

---

## 2. 界面说明

![结果表格与 SQL 详情](docs/03-结果表格与SQL详情.png)

| 区域 | 作用 |
| --- | --- |
| **左栏 · 会话** | 历史会话列表（存在浏览器 `localStorage`）。点一条切回去，× 删除。 |
| **左栏 · 数据库表** | 11 张业务表 + 各自的行数与列数，来自 `GET /api/schema`。 |
| **左下角** | 当前用的模型和 base_url（来自 `/api/health`）。 |
| **顶栏** | 「模型已就绪」状态灯（红 = 没配 key）、当前会话 id、新建会话 / 清空。 |
| **中间 · 对话区** | 用户气泡在右，Agent 气泡在左。Agent 气泡上方是**阶段进度标签**。 |
| **Agent 气泡** | 回答正文 → 结果表格 → 提示（caveat）→ 用到的表 → 「查看执行的 SQL」折叠区 → 证据行。 |
| **底栏** | 输入框（Enter 发送 / Shift+Enter 换行）。 |

阶段进度标签就是图节点：点亮的那个是当前在跑的，前面跑完的变绿。

![阶段进度](docs/02-提问与阶段进度.png)

多轮追问（「那……」这种省略指代的问法也能接上）：

![多轮追问](docs/04-多轮追问.png)

---

## 3. 架构

```mermaid
graph LR
    B[浏览器<br/>Vue 3 单文件] -->|fetch + SSE| F[FastAPI<br/>api/app.py]
    F -->|astream| G[LangGraph 状态图<br/>core/graph/]
    G --> C[选表 / 生成 SQL / 修复 SQL<br/>core/chains + core/agents]
    G --> V[SQL 校验<br/>EXPLAIN 只编译]
    G --> E[SQL 执行<br/>只读连接]
    V --> DB[(chinook.db<br/>SQLite)]
    E --> DB
    F -->|localStorage 会话列表| B
```

三层职责：

1. **前端**只管渲染和发请求，**不做任何业务判断**。
2. **FastAPI** 只做协议转换：HTTP → 图调用 → SSE。业务逻辑一行都没有。
3. **核心（`core/`）** 是作业一的原样拷贝，管选表、生成、校验、执行、汇总。

---

## 4. 接口

| 方法 | 路径 | 作用 | 需要 key |
| --- | --- | --- | --- |
| `GET` | `/` | 前端单文件页面 | 否 |
| `GET` | `/api/health` | 健康检查 + provider 状态 | 否 |
| `GET` | `/api/schema` | 11 张表的结构与行数 | 否 |
| `POST` | `/api/chat` | **SSE 流式问答** | 是 |
| `GET` | `/api/sessions/{sid}` | 读会话历史（问答与 SQL） | 否 |
| `DELETE` | `/api/sessions/{sid}` | 清空会话 | 否 |

`GET /api/health` **只返回 `api_key_present`（配没配），绝不返回 key 本身**。

### SSE 事件

`POST /api/chat` 返回 `text/event-stream`，帧格式：

```
event: stage
data: {"stage": "select_tables", "label": "正在选择数据表…", "session_id": "a3cf10"}

event: final
data: {"session_id": "a3cf10", "answer": "总共有 347 张专辑。", "sql": "...", "tables": ["albums"],
       "columns": ["TotalAlbums"], "rows": [["347"]], "row_count": 1, "truncated": false,
       "repair_attempts": 0, "evidence": ["TotalAlbums = 347"], "caveats": [], "error": null}
```

| 事件 | 何时发 | 载荷 |
| --- | --- | --- |
| `stage` | 每进入一个图节点 | `stage`（节点名）、`label`（中文标签）、`session_id` |
| `final` | 图跑完 | `ChatResult` 全量 |
| `error` | 中途抛异常 | `message`（含原始异常文本） |

节点名 → 中文标签的映射在 `api/app.py:STAGE_LABELS`：
`capture_question` / `select_tables` / `generate_sql` / `validate` / `execute` / `repair` / `summarize` / `finalize`。

---

## 5. 多轮会话怎么工作

三个东西配合：

| 位置 | 存什么 | 怎么用 |
| --- | --- | --- |
| **LangGraph checkpointer**（服务端内存） | 每个 `thread_id` 的完整状态，含 `history` 轮次列表 | 图节点读 `history` 拼进提示词，模型因此看得见上一轮 |
| **`thread_id`** | 就是 `session_id` | `config = {"configurable": {"thread_id": sid}}` |
| **`localStorage`**（浏览器） | 会话 id 列表 | 让用户能切回之前的会话 |

- 前端第一次提问不传 `session_id`，服务端生成一个并在 `stage` / `final` 事件里回传。
- 之后每轮都带上同一个 `session_id` → 同一个 `thread_id` → 图从 checkpoint 恢复 `history`。
- 「那按流派呢？」这种问法能接上，就是因为上一轮的问答在 `history` 里。

**限制**：`MemorySaver` 是**进程内**的。服务重启后历史就没了（`session_id` 还在，但对应的线程没了）。

---

## 6. 与作业一的关系

`src/langgraph_web_agent/core/` 是作业一 `src/langgraph_sql_agent/` 的**逐字副本**，
只有两处刻意的差异，都在 `core/config.py`：

| 差异 | 作业一 | 作业二 |
| --- | --- | --- |
| 项目根路径 | `parents[2]` | `parents[3]`（多了一层 `langgraph_web_agent/`） |
| `.env` 回退路径 | `../作业二/.env` | `../作业一/.env` |

`diff -r 作业一/src/langgraph_sql_agent 作业二/src/langgraph_web_agent/core` 的输出只有：

```
Only in 作业一/src/langgraph_sql_agent: __main__.py
Only in 作业一/src/langgraph_sql_agent: cli.py
Files 作业一/src/langgraph_sql_agent/config.py and 作业二/src/langgraph_web_agent/core/config.py differ
```

（`cli.py` / `__main__.py` 是作业一的命令行入口，作业二有自己的一套。）

**一致性由测试守住**：`tests/test_core_parity.py` 逐字比对每个文件，
把上面两处差异**白名单化**后要求完全一致 —— 改核心逻辑必须同步改两个目录。

---

## 7. 安全边界

和作业一完全一致，没被前端削弱：

| 边界 | 做法 | 代码位置 |
| --- | --- | --- |
| **数据库只读** | SQLAlchemy 用 `sqlite:///file:<abs-path>?mode=ro&uri=true`；裸 `sqlite3` 用 `Path.as_uri()?mode=ro` | `core/db/catalog.py:make_readonly_url`、`core/db/executor.py:_readonly_uri` |
| **校验器不执行 SQL** | 只 `EXPLAIN` 编译，绝不跑 | `core/db/validator.py` |
| **LLM 不批准自己的 SQL** | 校验是确定性代码，不是模型判断 | `core/graph/nodes.py` |
| **写操作拦截** | 只放行 `SELECT` / `WITH` | `core/db/validator.py` |
| **修复有上限** | 修复回边最多 3 次 | `core/graph/build.py` |
| **图有上限** | `recursion_limit=25` | `core/graph/build.py:RECURSION_LIMIT` |
| **结果截断** | 最多 200 行 / 单格 2000 字符 | `core/config.py` |
| **查询超时** | 5 秒 | `core/db/executor.py` |
| **key 不外泄** | 只从环境变量 / `.env` 读；`/api/health` 只返回 `api_key_present` | `core/config.py`、`api/app.py` |
| **前端无鉴权** | 本机演示用，没做登录 | 见「已知限制」 |

---

## 8. 配置项

全部在 `.env`，全部有默认值。见 `.env.example`。

| 变量 | 默认 | 说明 |
| --- | --- | --- |
| `SQL_AGENT_API_KEY` | — | **必填**（DeepSeek key）。也兼容 `OPENAI_API_KEY` / `DEEPSEEK_API_KEY` / `LLM_API_KEY` |
| `SQL_AGENT_BASE_URL` | `https://api.deepseek.com/v1` | OpenAI 兼容端点 |
| `SQL_AGENT_MODEL` | `deepseek-v4-pro` | 选表 / 生成 / 修复用的模型 |
| `SQL_AGENT_SUMMARY_MODEL` | `deepseek-flash` | 汇总用的模型（更便宜） |
| `SQL_AGENT_THINKING` | `disabled` | **必须 disabled**，见下 |
| `SQL_AGENT_DB` | `data/chinook.db` | 数据库路径 |
| `SQL_AGENT_MAX_REPAIR_ATTEMPTS` | `3` | 修复轮数上限 |
| `SQL_AGENT_MAX_ROWS` | `200` | 结果行数上限 |
| `SQL_AGENT_MAX_CELL_CHARS` | `2000` | 单格字符上限 |
| `SQL_AGENT_QUERY_TIMEOUT` | `5` | SQL 执行超时（秒） |
| `SQL_AGENT_LOG_LEVEL` | `INFO` | 日志级别 |
| `WEB_HOST` | `127.0.0.1` | 监听地址（局域网访问改 `0.0.0.0`） |
| `WEB_PORT` | `8000` | 端口 |

### DeepSeek 三个坑（实测）

1. `with_structured_output` **必须**传 `method="function_calling"`。
   默认的 `json_schema` 会报 `This response_format type is unavailable now`。
2. **必须**带 `extra_body={"thinking": {"type": "disabled"}}`。
   DeepSeek 默认开思考模式，而思考模式拒绝强制 `tool_choice`：
   `Thinking mode does not support this tool_choice`。
3. 这个 key 下可用的模型只有 `deepseek-v4-pro` 和 `deepseek-flash`。

---

## 9. 目录结构

```
作业二/
├── frontend/
│   └── index.html              前端单文件（Vue 3 CDN，零构建）
├── scripts/
│   ├── launch.py               启动器：查 .env / 装依赖 / 打印地址 / 起服务
│   ├── lan_ip.py               取本机局域网 IP
│   ├── screenshot.py           Playwright 截图脚本
│   └── vendor_vue.py           把 Vue 3 落到本地（离线部署用）
├── src/langgraph_web_agent/
│   ├── __init__.py
│   ├── __main__.py             python -m langgraph_web_agent 入口
│   ├── cli.py                  命令行入口（--host / --port / --reload）
│   ├── api/
│   │   ├── app.py              5 个接口 + SSE
│   │   ├── deps.py             图 / 目录 / 会话历史的依赖注入
│   │   └── schemas.py          请求响应模型
│   └── core/                   ← 作业一的逐字副本
│       ├── agents/sql_fixer.py     修复 Agent（create_agent 子图）
│       ├── chains/                 选表 / 生成 SQL / 结果汇总
│       ├── config.py               配置（唯一有差异的文件）
│       ├── db/                     目录 / 校验器 / 执行器
│       ├── graph/                  状态 / 节点 / 路由 / 编译
│       ├── llm.py                  模型接入
│       ├── models.py               Pydantic 数据契约
│       ├── prompts.py              提示词
│       ├── session.py              会话管理（checkpointer）
│       └── tools/db_tools.py       给修复 Agent 用的只读工具
├── tests/                      81 个用例，LLM 全 mock，不需要 key
├── start_server.bat / .sh      本机启动（127.0.0.1）
├── start_lan.bat / .sh         局域网启动（0.0.0.0，⚠️ 无鉴权）
├── data/chinook.db
├── docs/                       设计文档 + 部署说明 + 交付截图
├── .env.example
└── requirements.txt
```

### 启动脚本为什么这么绕

`.bat` / `.sh` 里**只有纯 ASCII 的几行**，真正带中文的提示、依赖检查、地址打印
全在 `scripts/launch.py` 里。

原因是一个实测踩到的 cmd.exe 坑：**UTF-8 批处理文件里同时出现「切换代码页 +
`cd` 切目录 + `goto` 跳标签」时，cmd.exe 会把文件的字节读取位置算错**，
把半行命令当成命令执行，报

```
'手机访问？改跑' is not recognized as an internal or external command
```

复现过程和规避办法见 `docs/deployment.md` 的「cmd.exe 踩坑」一节。
`tests/test_scripts.py` 里有对应的回归测试（纯 ASCII / CRLF / 不许有括号）。

---

## 10. 常见问题

**Q：页面一片空白？**
前端从 unpkg CDN 加载 Vue 3，断网/CDN 不可达时加载不出来。
页面会显示「正在加载 Vue 3 …」的提示 —— 换个网络或把 `vue.global.prod.js` 下到本地改 `<script src>`。

**Q：`/api/health` 显示「未配置 API Key」？**
`.env` 没建，或者 key 没填。注意 `.env` 在**作业二目录**下（也支持环境变量）。

**Q：提问报 `处理失败：...`？**
先看服务端日志。多半是 key 无效、模型名不对，或者 `SQL_AGENT_THINKING` 没设成 `disabled`。

**Q：会话列表刷新就没了？**
会话历史在服务端的 `MemorySaver` 里（进程内），服务重启即失；
左栏的**列表**在浏览器 `localStorage` 里，会话**内容**要服务端还在才读得回来。

**Q：局域网访问手机打不开？**
用 `--host 0.0.0.0`，然后访问 `http://<电脑IP>:8000`。
本项目**没有鉴权**，只在可信网络里用。

**Q：怎么确认前端没把 key 泄露出去？**
`tests/test_frontend.py::test_没有把_api_key_写进前端` 盯着这件事。

---

## 11. 已知限制

- **无鉴权**：任何能访问端口的人都能提问、能读会话历史。本机演示用。
- **会话不持久**：`MemorySaver` 在内存里，重启丢。多进程部署会各自一份历史（`thread_id` 互不相通）。
- **历史轮次只存答案与 SQL**：不存结果表格。从会话列表切回旧会话时，看得到问答和 SQL，看不到当时的表格（重新提问一次就有了）。
- **前端依赖 CDN**：Vue 3 走 unpkg，离线环境要改成本地文件。
- **单会话串行**：同一 `thread_id` 的并发请求会互相覆盖 checkpoint。

---

## 12. 交付物清单

| 类别 | 数量 | 说明 |
| --- | --- | --- |
| 后端模块 | 31 | 24 个核心模块（作业一逐字）+ 7 个 Web 层（`api/` 4 个、`cli.py`、`__main__.py`、`__init__.py`） |
| 前端 | 1 | `frontend/index.html` |
| 测试用例 | **49** | 全部通过，**不需要 API Key** |
| 设计文档 | 1 | `docs/web-chat-design.md` |
| 截图 | 4 | `docs/01` ~ `docs/04` |
| ruff | 干净 | `python -X utf8 -m ruff check src tests` |

自检：

```bash
python -X utf8 -m pytest -q
python -X utf8 -m ruff check src tests
diff -r ../作业一/src/langgraph_sql_agent src/langgraph_web_agent/core   # 只应有 cli/__main__/config.py
```
