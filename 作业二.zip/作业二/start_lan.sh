#!/usr/bin/env bash
# Chinook Data Q&A - LAN start, listens on 0.0.0.0.
# WARNING: this project has NO authentication.
# Chinese messages live in scripts/launch.py (see docs/deployment.md).
set -e
cd "$(dirname "$0")"
exec python -X utf8 scripts/launch.py --lan --port 8000
