"""用 FastAPI + Vue3 给 LangGraph SQL Agent 配的对话式前端（第十三周作业二）。

``core/`` 是作业一核心包的副本（除 ``config.py`` 的两处路径差异外逐字一致），
本目录可独立安装、独立启动，不依赖兄弟目录。
"""

from __future__ import annotations

__version__ = "0.1.0"

__all__ = ["__version__"]
