"""``python -m langgraph_web_agent`` 入口。"""

from __future__ import annotations

from .cli import main

if __name__ == "__main__":
    main()
