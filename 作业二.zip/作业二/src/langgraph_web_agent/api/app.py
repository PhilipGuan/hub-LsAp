"""FastAPI 后端入口。

路由：
    GET  /                  前端页面（单文件 index.html）
    GET  /api/health        健康检查（不含 key）+ provider 状态
    GET  /api/schema        数据库表结构概览
    POST /api/chat          SSE 流式问答（Task B3 实现）
    GET  /api/sessions/{sid}  会话历史（Task B4 实现）
    DELETE /api/sessions/{sid} 清空会话（Task B4 实现）
"""

from __future__ import annotations

import json
import logging
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles

from langgraph_web_agent.core.config import settings
from langgraph_web_agent.core.graph.build import RECURSION_LIMIT

from . import deps
from .schemas import (
    ChatRequest,
    ChatResult,
    ColumnInfo,
    HealthResponse,
    SchemaResponse,
    SessionDetail,
    SessionTurn,
    TableInfo,
)

logger = logging.getLogger(__name__)

#: frontend/ 目录
FRONTEND_DIR = Path(__file__).resolve().parents[3] / "frontend"
#: frontend/index.html
INDEX_HTML = FRONTEND_DIR / "index.html"
#: frontend/vendor/ —— 离线部署时本地化的 Vue 副本（没有这个目录就不挂载）
VENDOR_DIR = FRONTEND_DIR / "vendor"


@asynccontextmanager
async def lifespan(_app: FastAPI):
    """启动时预热数据库目录，避免第一个请求等 0.8 秒。"""

    logger.info(
        "服务启动 model=%s summary_model=%s db=%s",
        settings.primary_model,
        settings.summary_model,
        settings.db_path,
    )
    try:
        catalog = deps.get_catalog()
        logger.info("目录就绪 表数量=%d", len(catalog.table_names))
    except Exception as exc:  # noqa: BLE001 - 预热失败不阻塞启动
        logger.warning("目录预热失败：%s", exc)
    yield


app = FastAPI(
    title="Chinook 数据智能问答",
    description="用自然语言查询 Chinook 数据库的对话式前端（第十三周作业二）",
    version="0.1.0",
    lifespan=lifespan,
)

# 前端与后端同源，CORS 只是为了让本地调试方便。
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/", include_in_schema=False)
def index() -> FileResponse:
    """返回前端单文件页面。"""

    if not INDEX_HTML.is_file():
        raise FileNotFoundError(f"找不到前端页面：{INDEX_HTML}")
    return FileResponse(INDEX_HTML)


# 离线部署时（scripts/vendor_vue.py）前端会引用 ./vendor/vue.global.prod.js。
# 目录不存在就**不挂载** —— StaticFiles 在目录缺失时会直接抛错，
# 那会让「没跑过 vendor_vue.py」的默认部署起不来。
if VENDOR_DIR.is_dir():
    app.mount("/vendor", StaticFiles(directory=VENDOR_DIR), name="vendor")
    logger.info("已挂载本地 Vue：%s", VENDOR_DIR)


@app.get("/api/health", response_model=HealthResponse)
def health() -> HealthResponse:
    """健康检查。**不泄露 API key，只返回是否已配置。**"""

    try:
        tables = len(deps.get_catalog().table_names)
    except Exception:  # noqa: BLE001 - 数据库不可用时也要给出响应
        tables = 0
    return HealthResponse(
        status="ok",
        api_key_present=bool(settings.api_key.strip()),
        base_url=settings.base_url,
        primary_model=settings.primary_model,
        summary_model=settings.summary_model,
        db_path=str(settings.db_path),
        db_tables=tables,
    )


@app.get("/api/schema", response_model=SchemaResponse)
def schema() -> SchemaResponse:
    """数据库表结构概览，供前端左栏展示。"""

    catalog = deps.get_catalog()
    tables: list[TableInfo] = []
    total_rows = 0
    for profile in catalog.table_profiles():
        total_rows += profile.row_count
        tables.append(
            TableInfo(
                name=profile.name,
                row_count=profile.row_count,
                columns=[
                    ColumnInfo(
                        name=column.name,
                        type=column.type,
                        nullable=column.nullable,
                        primary_key=column.primary_key,
                    )
                    for column in profile.columns
                ],
            )
        )
    return SchemaResponse(tables=tables, total_rows=total_rows)


# --------------------------------------------------------------------------
# SSE 流式问答
# --------------------------------------------------------------------------
#: 图节点 -> 前端展示用的中文标签
STAGE_LABELS = {
    "capture_question": "正在理解问题…",
    "select_tables": "正在选择数据表…",
    "generate_sql": "正在生成 SQL…",
    "validate": "正在校验 SQL…",
    "execute": "正在执行查询…",
    "repair": "正在修复 SQL…",
    "summarize": "正在整理结果…",
    "finalize": "正在生成回答…",
}


def _sse(event: str, data: dict) -> str:
    """把一条事件序列化成 SSE 文本帧。"""

    return f"event: {event}\ndata: {json.dumps(data, ensure_ascii=False)}\n\n"


def _build_chat_result(output, execution, session_id: str) -> ChatResult:
    """把核心的输出拍平成前端要的形状。"""

    return ChatResult(
        session_id=session_id,
        answer=output.answer,
        sql=output.sql,
        tables=output.tables,
        columns=execution.columns if execution else [],
        rows=execution.rows if execution else [],
        row_count=output.row_count,
        truncated=output.truncated,
        repair_attempts=output.repair_attempts,
        evidence=output.evidence,
        caveats=output.caveats,
        error=output.error,
    )


@app.post("/api/chat")
async def chat(request: ChatRequest) -> StreamingResponse:
    """流式问答。

    用 ``graph.astream(..., stream_mode="updates")`` 逐节点拿状态增量，
    每到一个节点推一条 ``stage`` 事件；跑完后从 checkpoint 里读出完整状态，
    组装 ``ChatResult`` 推一条 ``final`` 事件。
    """

    manager = deps.get_session_manager()
    session_id = request.session_id or manager.new_session_id()
    # recursion_limit 必须放在 config 里 —— LangGraph 1.x 的 astream 不接受
    # 第三个位置参数（实测：TypeError: astream() takes from 3 to 4 positional ...）。
    config = {**manager.config(session_id), "recursion_limit": RECURSION_LIMIT}

    async def event_stream() -> AsyncIterator[str]:
        yield _sse(
            "stage",
            {"stage": "start", "label": "已收到问题…", "session_id": session_id},
        )
        try:
            graph = deps.get_graph()
            async for chunk in graph.astream(
                {"question": request.message},
                config,
                stream_mode="updates",
            ):
                # chunk 形如 {"节点名": 状态增量}
                for node_name in chunk:
                    if node_name.startswith("__"):
                        # LangGraph 的伪节点（__start__ / __end__），不展示。
                        continue
                    yield _sse(
                        "stage",
                        {
                            "stage": node_name,
                            "label": STAGE_LABELS.get(node_name, node_name),
                            "session_id": session_id,
                        },
                    )

            snapshot = await graph.aget_state(config)
            values = snapshot.values or {}
            output = values.get("output")
            if output is None:
                yield _sse(
                    "error",
                    {"message": "查询没有产生结果。", "session_id": session_id},
                )
                return
            result = _build_chat_result(output, values.get("execution"), session_id)
            yield _sse("final", result.model_dump())
        except Exception as exc:  # noqa: BLE001 - SSE 已经开始推流，只能以 error 收尾
            logger.exception("chat stream failed")
            yield _sse(
                "error",
                {"message": f"处理失败：{exc}", "session_id": session_id},
            )

    return StreamingResponse(
        event_stream(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


# --------------------------------------------------------------------------
# 会话管理
# --------------------------------------------------------------------------
@app.get("/api/sessions/{session_id}", response_model=SessionDetail)
def session_detail(session_id: str) -> SessionDetail:
    """读取某个会话的历史轮次。

    直接读 checkpointer —— 读历史不需要模型，也就不需要 API key。
    """

    turns = deps.get_session_turns(session_id)
    return SessionDetail(
        session_id=session_id,
        turns=[
            SessionTurn(
                role=turn.role,
                question=turn.question,
                answer=turn.answer,
                tables=turn.tables,
                sql=turn.sql,
            )
            for turn in turns
        ],
    )


@app.delete("/api/sessions/{session_id}")
def session_clear(session_id: str) -> dict:
    """清空某个会话。

    注意：不能用 ``graph.update_state(config, {"history": []})`` ——
    ``history`` 声明了 ``add`` reducer，空列表等于追加零条，历史不会变少。
    ``SessionManager.clear`` 内部用的是 ``checkpointer.delete_thread()``。
    """

    manager = deps.get_session_manager()
    manager.clear(session_id)
    return {"ok": True, "session_id": session_id}
