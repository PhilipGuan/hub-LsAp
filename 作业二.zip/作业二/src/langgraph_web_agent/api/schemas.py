"""API 的请求与响应模型。

``ChatResult`` 是 Web 层自己的模型：它把核心的 ``WorkflowOutput``
和 ``ExecutionResult`` 拍平成前端直接能渲染的形状 ——
核心的数据契约不因为前端需求而改动。
"""

from __future__ import annotations

from pydantic import BaseModel, Field


class ChatRequest(BaseModel):
    """发起一次提问。"""

    session_id: str | None = Field(
        default=None, max_length=64, description="会话 id；不传则新建一个"
    )
    message: str = Field(min_length=1, max_length=2000, description="自然语言问题")


class ChatResult(BaseModel):
    """一次问答的最终结果。"""

    session_id: str
    answer: str
    sql: str | None = None
    tables: list[str] = Field(default_factory=list)
    columns: list[str] = Field(default_factory=list)
    rows: list[list[str]] = Field(default_factory=list)
    row_count: int = 0
    truncated: bool = False
    repair_attempts: int = 0
    evidence: list[str] = Field(default_factory=list)
    caveats: list[str] = Field(default_factory=list)
    error: str | None = None


class HealthResponse(BaseModel):
    """健康检查。**不返回 API key 本身，只返回是否已配置。**"""

    status: str
    api_key_present: bool
    base_url: str
    primary_model: str
    summary_model: str
    db_path: str
    db_tables: int


class ColumnInfo(BaseModel):
    name: str
    type: str
    nullable: bool
    primary_key: bool


class TableInfo(BaseModel):
    name: str
    row_count: int
    columns: list[ColumnInfo]


class SchemaResponse(BaseModel):
    """数据库结构概览。"""

    tables: list[TableInfo]
    total_rows: int


class SessionTurn(BaseModel):
    role: str
    question: str
    answer: str
    tables: list[str] = Field(default_factory=list)
    sql: str = ""


class SessionDetail(BaseModel):
    session_id: str
    turns: list[SessionTurn] = Field(default_factory=list)
