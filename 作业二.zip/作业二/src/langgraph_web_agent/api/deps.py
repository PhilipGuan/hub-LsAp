"""FastAPI 依赖：图、目录、会话管理器。

全部是**进程级单例** —— 图和 catalog 都很贵（catalog 要 profile 全部表），
每个请求重建一次会把首字延迟拖垮。
"""

from __future__ import annotations

import logging

from langgraph_web_agent.core.db.catalog import SchemaCatalog
from langgraph_web_agent.core.db.catalog import get_catalog as _get_catalog
from langgraph_web_agent.core.graph.build import build_graph
from langgraph_web_agent.core.models import ConversationTurn
from langgraph_web_agent.core.session import get_session_manager

logger = logging.getLogger(__name__)

_graph = None


def get_graph():
    """返回编译好的状态图（带 checkpointer，支持多轮会话）。"""

    global _graph
    if _graph is None:
        logger.info("api building graph")
        _graph = build_graph(checkpointer=get_session_manager().checkpointer)
    return _graph


def get_catalog() -> SchemaCatalog:
    """返回数据库目录（进程内缓存）。"""

    return _get_catalog()


def get_session_turns(session_id: str) -> list[ConversationTurn]:
    """读取某个会话的历史轮次。

    **直接读 checkpointer，不经过图。**

    理由：图要建起来就得构造 LLM 链，而构造链需要 API key ——
    但「查看历史」这件事本身不需要模型。两件事混在一起会让
    「没配 key 的环境」连历史都读不了。

    checkpointer 里存的是 LangGraph 的 channel_values，键名与
    ``GraphState`` 的字段一一对应。
    """

    manager = get_session_manager()
    try:
        snapshot = manager.checkpointer.get_tuple(manager.config(session_id))
    except Exception as exc:  # noqa: BLE001 - 会话不存在等情况
        logger.debug("session history unavailable sid=%s error=%s", session_id, exc)
        return []
    if snapshot is None:
        return []
    channel_values = (snapshot.checkpoint or {}).get("channel_values") or {}
    return list(channel_values.get("history") or [])


__all__ = ["get_catalog", "get_graph", "get_session_manager", "get_session_turns"]
