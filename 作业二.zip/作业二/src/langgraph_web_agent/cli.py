"""命令行入口：``python -m langgraph_web_agent`` 启动 Web 服务。"""

from __future__ import annotations

import argparse
import os
import sys


def _force_utf8() -> None:
    """Windows 控制台默认是 GBK，切到 UTF-8 免得中文日志炸掉。"""

    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is not None:
            try:
                reconfigure(encoding="utf-8", errors="replace")
            except (ValueError, OSError):
                pass


def browse_url(host: str, port: int) -> str:
    """给人看的访问地址。

    监听 ``0.0.0.0`` 时 ``0.0.0.0`` 本身不是能打开的地址 ——
    浏览器要连的是本机回环地址，或者局域网 IP。
    """

    if host in ("0.0.0.0", "::", ""):
        return f"http://127.0.0.1:{port}"
    return f"http://{host}:{port}"


def main() -> None:
    _force_utf8()
    parser = argparse.ArgumentParser(description="Chinook 数据智能问答 Web 服务")
    parser.add_argument(
        "--host",
        default=os.getenv("WEB_HOST", "127.0.0.1"),
        help="监听地址，默认 127.0.0.1（要局域网访问用 0.0.0.0）",
    )
    parser.add_argument(
        "--port", type=int, default=int(os.getenv("WEB_PORT", "8000")), help="监听端口"
    )
    parser.add_argument(
        "--reload", action="store_true", help="改代码自动重启（开发用）"
    )
    args = parser.parse_args()

    import uvicorn

    print(f"打开 {browse_url(args.host, args.port)}", file=sys.stderr)
    uvicorn.run(
        "langgraph_web_agent.api.app:app",
        host=args.host,
        port=args.port,
        reload=args.reload,
    )


if __name__ == "__main__":
    main()
