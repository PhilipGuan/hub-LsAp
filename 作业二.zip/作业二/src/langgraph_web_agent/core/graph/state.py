"""LangGraph 状态定义。

LangGraph 1.x 原生支持用 Pydantic 模型当状态 schema。
``Annotated[list, add]`` 声明追加语义 —— checkpointer 会把每一轮 invoke
的增量合并进上一轮的状态，因此 ``history`` 与 ``attempts`` 天然跨轮累积。
"""

from __future__ import annotations

from operator import add
from typing import Annotated

from pydantic import BaseModel, Field

from ..models import (
    ConversationTurn,
    ExecutionResult,
    FinalAnswer,
    SQLAttempt,
    TableSelection,
    ValidationResult,
    WorkflowOutput,
)


class GraphState(BaseModel):
    """一次查询（可能跨多轮）的完整状态。"""

    #: 当前这一轮的用户问题
    question: str
    #: 历史对话（跨轮累积）：用户轮在 capture_question 写入，助手轮在 finalize 写入
    history: Annotated[list[ConversationTurn], add] = Field(default_factory=list)
    #: 本轮尝试过的 SQL（跨节点累积）
    attempts: Annotated[list[SQLAttempt], add] = Field(default_factory=list)

    selection: TableSelection | None = None
    schema_context: str = ""
    sql: str | None = None
    validation: ValidationResult | None = None
    execution: ExecutionResult | None = None
    answer: FinalAnswer | None = None

    #: 已用掉的修复次数（校验失败与执行失败共用同一份预算）
    repair_attempts: int = 0
    #: 修复 Agent 判定「这个问题用当前数据库回答不了」
    repair_blocked: bool = False
    #: 最近一次失败的原因（用于组装错误输出）
    error: str | None = None
    #: 最近一次走到的节点名（便于日志与前端展示）
    stage: str = "init"
    #: 面向用户的最终输出，由 finalize 节点组装
    output: WorkflowOutput | None = None
