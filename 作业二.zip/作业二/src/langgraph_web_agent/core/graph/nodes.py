"""图的 8 个节点。

每个节点是一个纯函数式的闭包工厂：``make_xxx(deps) -> Callable[[GraphState], dict]``。
节点返回**状态增量**（dict），由 LangGraph 负责合并 —— 节点自己不碰合并逻辑。

节点分工：

==============  ==========  ==================================================
节点             类型         职责
==============  ==========  ==================================================
capture_question  确定性       把本轮问题记进 history
select_tables     LLM          选最少表集合
generate_sql      LLM          生成 SQLite SELECT
validate          确定性       安全门禁 + EXPLAIN 编译
execute           确定性       只读执行
repair            LLM          按错误修复 SQL（嵌套 ReAct 子图）
summarize         LLM          结果转自然语言
finalize          确定性       组装输出 + 记录助手轮
==============  ==========  ==================================================
"""

from __future__ import annotations

import json
import logging
import time
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

from ..agents.sql_fixer import build_repair_prompt, run_fixer
from ..chains import StageChains
from ..config import settings
from ..db.catalog import SchemaCatalog
from ..db.executor import SQLExecutionError, SQLExecutor
from ..db.validator import SQLValidator
from ..models import (
    ConversationTurn,
    ErrorCode,
    ExecutionResult,
    FinalAnswer,
    SQLAttempt,
    SQLDraft,
    TableSelection,
    ValidationResult,
    WorkflowOutput,
)
from ..prompts import render_history
from .state import GraphState

logger = logging.getLogger(__name__)

#: 节点函数的统一签名
Node = Callable[[GraphState], dict]


@dataclass
class GraphDeps:
    """节点依赖的外部组件。测试时整体替换成假实现。"""

    catalog: SchemaCatalog
    validator: SQLValidator
    executor: SQLExecutor
    chains: StageChains
    #: 修复 Agent（LangGraph ReAct 子图）；None 表示惰性构造
    fixer: Any = None

    def get_fixer(self):
        """取修复 Agent；第一次调用时才真正构造。"""

        if self.fixer is None:
            from ..agents.sql_fixer import build_sql_fixer_agent
            from ..tools.db_tools import build_db_tools

            tools = build_db_tools(self.catalog, self.validator, self.executor)
            self.fixer = build_sql_fixer_agent(tools)
        return self.fixer


def _preview(text: str, limit: int = 2000) -> str:
    """日志里把多行文本压成一行，并限制长度。"""

    compact = " ".join(str(text).split())
    return compact if len(compact) <= limit else compact[:limit] + "..."


# --------------------------------------------------------------------------
# 1. 记录本轮问题
# --------------------------------------------------------------------------
def make_capture_question() -> Node:
    """把本轮用户问题写进 history。

    历史是 ``add`` reducer，所以每次 invoke 追加一条用户轮，
    再由 ``finalize`` 追加对应的助手轮。
    """

    def capture_question(state: GraphState) -> dict:
        turn = ConversationTurn(role="user", question=state.question)
        logger.info("stage=capture_question question=%s", _preview(state.question, 300))
        return {"history": [turn], "stage": "capture_question"}

    return capture_question


# --------------------------------------------------------------------------
# 2. 选表
# --------------------------------------------------------------------------
def _selection_problems(deps: GraphDeps, tables: list[str]) -> list[str]:
    """检查选出的表是否有效。"""

    if not tables:
        return ["未选择任何表"]

    unknown = sorted(set(tables) - set(deps.catalog.table_names))
    if unknown:
        return [
            f"表不存在：{', '.join(unknown)}；"
            f"可选表：{', '.join(deps.catalog.table_names)}"
        ]

    if not deps.catalog.is_connected(tables):
        return ["所选表之间没有外键连接，请重新选择可以 JOIN 的表"]
    return []


def make_select_tables(deps: GraphDeps) -> Node:
    """选出回答所需的最少表集合。

    内部带一次「重选」：模型选出的表不存在或彼此没有外键连接时，
    把问题回灌给模型再试一次（上限 2 次）。这是**节点内部**的提示词级重试，
    与图上的修复回边（SQL 修复）是两回事。
    """

    def select_tables(state: GraphState) -> dict:
        feedback = ""
        selection: TableSelection | None = None

        for attempt in range(1, 3):
            payload = {
                "question": state.question,
                "catalog": deps.catalog.render_catalog(),
                "history": render_history(state.history),
            }
            if feedback:
                payload["catalog"] += (
                    f"\n\n上一次选择的问题：\n{feedback}\n请修正后重新选择。"
                )

            started = time.perf_counter()
            selection = deps.chains.select.invoke(payload)
            if not isinstance(selection, TableSelection):
                raise TypeError("选表链返回了非 TableSelection 结果")

            logger.info(
                "stage=table_select attempt=%d tables=%s confidence=%.2f "
                "needs_clarification=%s elapsed=%.2fs reason=%s",
                attempt,
                selection.tables,
                selection.confidence,
                selection.needs_clarification,
                time.perf_counter() - started,
                _preview(selection.reason, 300),
            )

            if selection.needs_clarification:
                return {"selection": selection, "stage": "select_tables"}

            problems = _selection_problems(deps, selection.tables)
            if not problems:
                return {
                    "selection": selection,
                    "schema_context": deps.catalog.render_schema(selection.tables),
                    "stage": "select_tables",
                }

            feedback = "；".join(problems)
            logger.warning(
                "stage=table_select_invalid attempt=%d problems=%s",
                attempt,
                _preview(feedback, 300),
            )

        assert selection is not None
        return {
            "selection": selection.model_copy(
                update={
                    "needs_clarification": True,
                    "clarification_question": f"无法确定有效的查询表：{feedback}",
                }
            ),
            "stage": "select_tables",
        }

    return select_tables


# --------------------------------------------------------------------------
# 3. 生成 SQL
# --------------------------------------------------------------------------
def make_generate_sql(deps: GraphDeps) -> Node:
    """根据已选表的 schema 生成一条 SELECT。"""

    def generate_sql(state: GraphState) -> dict:
        started = time.perf_counter()
        draft = deps.chains.generate.invoke(
            {
                "question": state.question,
                "schema": state.schema_context,
                "history": render_history(state.history),
            }
        )
        if not isinstance(draft, SQLDraft):
            raise TypeError("生成链返回了非 SQLDraft 结果")
        logger.info(
            "stage=sql_generate elapsed=%.2fs sql=%s",
            time.perf_counter() - started,
            _preview(draft.sql),
        )
        return {
            "sql": draft.sql,
            "attempts": [SQLAttempt(sql=draft.sql, source="generator")],
            "stage": "generate_sql",
        }

    return generate_sql


# --------------------------------------------------------------------------
# 4. 校验（确定性）
# --------------------------------------------------------------------------
def make_validate(deps: GraphDeps) -> Node:
    """安全门禁 + EXPLAIN 编译校验。**只编译，绝不执行。**"""

    def validate(state: GraphState) -> dict:
        sql = state.sql or ""
        started = time.perf_counter()
        validation = deps.validator.validate(sql)
        logger.info(
            "stage=validate ok=%s code=%s elapsed=%.3fs message=%s",
            validation.ok,
            validation.code,
            time.perf_counter() - started,
            _preview(validation.message, 500),
        )
        updates: dict = {"validation": validation, "stage": "validate"}
        if validation.ok:
            # 规范化后的 SQL（去掉 Markdown 围栏和尾分号）才是真正要执行的
            updates["sql"] = validation.normalized_sql
        else:
            updates["error"] = validation.message
        return updates

    return validate


# --------------------------------------------------------------------------
# 5. 执行（确定性）
# --------------------------------------------------------------------------
def make_execute(deps: GraphDeps) -> Node:
    """在只读连接上执行。失败不抛异常，把错误写回状态交给修复节点。"""

    def execute(state: GraphState) -> dict:
        sql = state.sql or ""
        started = time.perf_counter()
        try:
            execution = deps.executor.execute(sql)
        except SQLExecutionError as exc:
            logger.warning(
                "stage=execute ok=false code=%s elapsed=%.3fs message=%s",
                exc.code,
                time.perf_counter() - started,
                _preview(str(exc), 500),
            )
            return {
                "execution": None,
                "error": str(exc),
                "stage": "execute",
            }
        logger.info(
            "stage=execute ok=true rows=%s truncated=%s elapsed=%.3fs",
            execution.row_count,
            execution.truncated,
            time.perf_counter() - started,
        )
        return {"execution": execution, "stage": "execute"}

    return execute


# --------------------------------------------------------------------------
# 6. 修复（LLM，嵌套 ReAct 子图）
# --------------------------------------------------------------------------
def make_repair(deps: GraphDeps) -> Node:
    """按校验/执行错误修复 SQL。

    修复 Agent 自己可以在推理循环里调 ``validate_sql`` / ``execute_sql`` /
    ``get_table_schema`` 三个工具做自检；改完交回来，编排层再判一次。
    """

    def repair(state: GraphState) -> dict:
        validation = state.validation or ValidationResult(
            ok=False, code=ErrorCode.RUNTIME, message=state.error or "未知错误"
        )
        attempt_number = state.repair_attempts + 1
        prompt = build_repair_prompt(
            question=state.question,
            schema=state.schema_context,
            sql=state.sql or "",
            validation=validation,
            attempts=state.attempts,
            attempt_number=attempt_number,
            max_attempts=settings.max_repair_attempts,
        )
        logger.info(
            "stage=sql_rewrite_started attempt=%d/%d code=%s",
            attempt_number,
            settings.max_repair_attempts,
            validation.code,
        )
        started = time.perf_counter()
        draft = run_fixer(deps.get_fixer(), prompt)
        logger.info(
            "stage=sql_rewrite_finished elapsed=%.2fs cannot_fix=%s sql=%s",
            time.perf_counter() - started,
            draft.cannot_fix,
            _preview(draft.sql),
        )

        if draft.cannot_fix:
            return {
                "repair_blocked": True,
                "error": draft.explanation or "当前数据库无法回答该问题。",
                "stage": "repair",
            }

        return {
            "sql": draft.sql,
            "repair_attempts": attempt_number,
            "repair_blocked": False,
            "error": None,
            "attempts": [SQLAttempt(sql=draft.sql, source="rewriter")],
            "stage": "repair",
        }

    return repair


# --------------------------------------------------------------------------
# 7. 汇总（LLM）
# --------------------------------------------------------------------------
def _fallback_summary(execution: ExecutionResult, error: Exception) -> FinalAnswer:
    """汇总链失败时的降级输出：直接渲染成 Markdown 表格。"""

    if not execution.rows:
        return FinalAnswer(answer="未查询到符合条件的数据。")

    header = "| " + " | ".join(execution.columns) + " |"
    divider = "| " + " | ".join("---" for _ in execution.columns) + " |"
    body = [
        "| " + " | ".join(value.replace("|", "\\|") for value in row) + " |"
        for row in execution.rows[: settings.max_summary_rows]
    ]
    note = (
        f"仅展示前 {settings.max_summary_rows} 行。"
        if execution.truncated or execution.row_count > settings.max_summary_rows
        else ""
    )
    return FinalAnswer(
        answer="\n".join(
            [f"查询返回 {execution.row_count} 行。", header, divider, *body, note]
        ),
        caveats=[f"结果汇总链调用失败，已降级为表格输出：{error}"],
    )


def make_summarize(deps: GraphDeps) -> Node:
    """把查询结果转成自然语言回答。

    结果为空时不调模型（不让模型猜原因）；汇总链失败时降级为 Markdown 表格。
    """

    def summarize(state: GraphState) -> dict:
        execution = state.execution
        assert execution is not None
        if execution.row_count == 0:
            logger.info("stage=summarize skipped reason=empty_result")
            return {
                "answer": FinalAnswer(
                    answer="未查询到符合条件的数据。",
                    caveats=["SQL 执行成功，但结果集为空。"],
                ),
                "stage": "summarize",
            }

        rows = execution.rows[: settings.max_summary_rows]
        payload = {
            "question": state.question,
            "sql": state.sql or "",
            "columns": json.dumps(execution.columns, ensure_ascii=False),
            "row_count": str(execution.row_count),
            "truncated": "是" if execution.truncated else "否",
            "max_rows": str(settings.max_summary_rows),
            "rows": json.dumps(rows, ensure_ascii=False),
        }
        try:
            started = time.perf_counter()
            final = deps.chains.summarize.invoke(payload)
            if not isinstance(final, FinalAnswer):
                raise TypeError("汇总链返回了非 FinalAnswer 结果")
            logger.info(
                "stage=summarize_finished elapsed=%.2fs evidence=%d caveats=%d",
                time.perf_counter() - started,
                len(final.evidence),
                len(final.caveats),
            )
            return {"answer": final, "stage": "summarize"}
        except Exception as exc:  # noqa: BLE001 - 汇总失败时降级输出
            logger.warning("stage=summarize_failed fallback=table error=%s", exc)
            return {"answer": _fallback_summary(execution, exc), "stage": "summarize"}

    return summarize


# --------------------------------------------------------------------------
# 8. 收尾（确定性）
# --------------------------------------------------------------------------
def build_output(state: GraphState) -> WorkflowOutput:
    """把状态组装成面向用户的输出。**由代码组装，不由模型拼接。**"""

    selection = state.selection
    execution = state.execution
    answer = state.answer

    if selection is not None and selection.needs_clarification:
        return WorkflowOutput(
            question=state.question,
            answer=selection.clarification_question
            or "无法从当前数据库确定回答该问题所需的表。",
            sql=state.sql,
            tables=selection.tables,
            repair_attempts=state.repair_attempts,
            error=state.error,
        )

    if answer is None:
        # 没走到汇总节点就结束了。按失败原因给不同的说法。
        if state.repair_blocked:
            message = state.error or "当前数据库无法回答该问题。"
        elif state.repair_attempts >= settings.max_repair_attempts:
            message = "无法生成可执行的 SQL，已达到最大修复次数。"
        else:
            message = state.error or "查询未能完成。"
        return WorkflowOutput(
            question=state.question,
            answer=message,
            sql=state.sql,
            tables=selection.tables if selection else [],
            repair_attempts=state.repair_attempts,
            error=state.error,
        )

    return WorkflowOutput(
        question=state.question,
        answer=answer.answer,
        sql=state.sql,
        tables=selection.tables if selection else [],
        row_count=execution.row_count if execution else 0,
        truncated=execution.truncated if execution else False,
        repair_attempts=state.repair_attempts,
        evidence=answer.evidence,
        caveats=answer.caveats,
        error=state.error,
    )


def make_finalize(deps: GraphDeps) -> Node:
    """组装最终输出，并把助手轮写进 history（供下一轮做上下文）。"""

    def finalize(state: GraphState) -> dict:
        output = build_output(state)
        turn = ConversationTurn(
            role="assistant",
            question=state.question,
            answer=output.answer,
            tables=output.tables,
            sql=output.sql or "",
        )
        logger.info(
            "stage=final answer=%s evidence=%d caveats=%d",
            _preview(output.answer, 500),
            len(output.evidence),
            len(output.caveats),
        )
        return {"output": output, "history": [turn], "stage": "finalize"}

    return finalize
