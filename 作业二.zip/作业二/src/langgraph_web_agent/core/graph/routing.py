"""图的条件边路由函数。

全部是**纯函数**：输入 ``GraphState``，输出下一个节点名。
把它们从节点里抽出来单独测，是这次从「手写状态机」升级到「显式图」的主要收益之一。
"""

from __future__ import annotations

from ..config import settings
from .state import GraphState

#: 路由函数可能返回的目标节点名
NEXT_SELECT = "generate_sql"
NEXT_EXECUTE = "execute"
NEXT_REPAIR = "repair"
NEXT_SUMMARIZE = "summarize"
NEXT_VALIDATE = "validate"
NEXT_FINALIZE = "finalize"


def route_after_select(state: GraphState) -> str:
    """选表之后：需要澄清或没选到表就直接收尾，否则进入生成。"""

    selection = state.selection
    if selection is None or selection.needs_clarification or not selection.tables:
        return NEXT_FINALIZE
    return NEXT_SELECT


def _repair_budget_left(state: GraphState) -> bool:
    """修复预算是否还有余额。"""

    return state.repair_attempts < settings.max_repair_attempts


def route_after_validate(state: GraphState) -> str:
    """校验之后：通过就去执行，否则修（预算耗尽则收尾）。"""

    validation = state.validation
    if validation is not None and validation.ok:
        return NEXT_EXECUTE
    if not _repair_budget_left(state):
        return NEXT_FINALIZE
    return NEXT_REPAIR


def route_after_execute(state: GraphState) -> str:
    """执行之后：拿到结果就去汇总，否则修（预算耗尽则收尾）。"""

    if state.execution is not None:
        return NEXT_SUMMARIZE
    if not _repair_budget_left(state):
        return NEXT_FINALIZE
    return NEXT_REPAIR


def route_after_repair(state: GraphState) -> str:
    """修复之后：改好了就回去重新校验，判定修不了就收尾。"""

    if state.repair_blocked:
        return NEXT_FINALIZE
    return NEXT_VALIDATE
