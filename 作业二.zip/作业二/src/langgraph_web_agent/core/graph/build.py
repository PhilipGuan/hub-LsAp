"""把节点装配成 LangGraph 状态图。

图结构（实线是无条件边，虚线是条件边）::

    START → capture_question → select_tables → generate_sql → validate
                                                          │ ok
                                                          ▼
                                                       execute ──ok──▶ summarize
                                                          │  ▲            │
                                                     错误 │  │ 修复       ▼
                                                          ▼  │        finalize
                                                       repair          │
                                                          │            ▼
                                                          └──▶ validate  END
"""

from __future__ import annotations

import logging

from langgraph.graph import END, START, StateGraph

from ..chains import build_default_chains
from ..db.catalog import SchemaCatalog, get_catalog
from ..db.executor import SQLExecutor
from ..db.validator import SQLValidator
from .nodes import (
    GraphDeps,
    make_capture_question,
    make_execute,
    make_finalize,
    make_generate_sql,
    make_repair,
    make_select_tables,
    make_summarize,
    make_validate,
)
from .routing import (
    route_after_execute,
    route_after_repair,
    route_after_select,
    route_after_validate,
)
from .state import GraphState

logger = logging.getLogger(__name__)

#: 图的递归上限。修复回边最多 3 次，加上固定节点数，25 足够富余。
RECURSION_LIMIT = 25


def default_deps() -> GraphDeps:
    """构造默认依赖（惰性构造 LLM 链，没 key 时也能导入本模块）。"""

    catalog: SchemaCatalog = get_catalog()
    return GraphDeps(
        catalog=catalog,
        validator=SQLValidator(catalog.db_path),
        executor=SQLExecutor(catalog.db_path),
        chains=build_default_chains(),
    )


def build_graph(deps: GraphDeps | None = None, *, checkpointer=None):
    """装配并编译状态图。

    ``checkpointer`` 传 ``MemorySaver`` 即可开启多轮会话：
    同一 ``thread_id`` 的多次 invoke 会累积 ``history``。
    """

    deps = deps if deps is not None else default_deps()

    graph = StateGraph(GraphState)
    graph.add_node("capture_question", make_capture_question())
    graph.add_node("select_tables", make_select_tables(deps))
    graph.add_node("generate_sql", make_generate_sql(deps))
    graph.add_node("validate", make_validate(deps))
    graph.add_node("execute", make_execute(deps))
    graph.add_node("repair", make_repair(deps))
    graph.add_node("summarize", make_summarize(deps))
    graph.add_node("finalize", make_finalize(deps))

    graph.add_edge(START, "capture_question")
    graph.add_edge("capture_question", "select_tables")
    graph.add_conditional_edges(
        "select_tables",
        route_after_select,
        {"generate_sql": "generate_sql", "finalize": "finalize"},
    )
    graph.add_edge("generate_sql", "validate")
    graph.add_conditional_edges(
        "validate",
        route_after_validate,
        {"execute": "execute", "repair": "repair", "finalize": "finalize"},
    )
    graph.add_conditional_edges(
        "execute",
        route_after_execute,
        {"summarize": "summarize", "repair": "repair", "finalize": "finalize"},
    )
    graph.add_conditional_edges(
        "repair",
        route_after_repair,
        {"validate": "validate", "finalize": "finalize"},
    )
    graph.add_edge("summarize", "finalize")
    graph.add_edge("finalize", END)

    compiled = graph.compile(checkpointer=checkpointer)
    logger.info("graph compiled recursion_limit=%d", RECURSION_LIMIT)
    return compiled


__all__ = ["RECURSION_LIMIT", "build_graph", "default_deps"]
