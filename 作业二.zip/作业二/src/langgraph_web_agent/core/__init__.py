"""用 LangGraph 复刻的 Chinook SQL Agent（第十三周作业一）。

编排层是显式的 LangGraph 状态图（8 个节点 + 条件边），
数据契约与安全边界与第十二周作业二（LangChain 版）保持一致。
"""

from __future__ import annotations

__version__ = "0.1.0"

__all__ = ["__version__"]
