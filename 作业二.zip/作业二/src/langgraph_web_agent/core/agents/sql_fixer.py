"""SQL 修复 Agent：一个嵌套的 LangGraph ReAct 子图。

``langchain.agents.create_agent`` 在 LangChain 1.x / LangGraph 1.x 下返回的
**正是** ``CompiledStateGraph``（已实测），所以修复节点本身就是一个图 ——
它的工具调用循环由 LangGraph 驱动，而不是我们自己写的 while 循环。

============  ==========================================
第十二周作业二（LangChain 版）  本版（LangGraph）
============  ==========================================
``create_agent`` + 三个工具    同左，但作为**嵌套子图**存在
``agent.invoke(...)``          同左，在 repair 节点里调用
============  ==========================================

``ToolStrategy`` 用「人工工具调用」实现结构化输出，兼容性最好：
DeepSeek / DashScope 这类 OpenAI 兼容端点都支持 function calling，
但大多不支持原生 ``response_format=json_schema``。
"""

from __future__ import annotations

import logging

from langchain.agents import create_agent
from langchain.agents.structured_output import ToolStrategy
from langchain_core.tools import BaseTool

from ..config import settings
from ..llm import build_chat_model
from ..models import SQLAttempt, SQLDraft, ValidationResult
from ..prompts import SQL_REWRITE_HUMAN, SQL_REWRITE_SYSTEM

logger = logging.getLogger(__name__)


def build_sql_fixer_agent(tools: list[BaseTool]):
    """构造修复 Agent（一个 CompiledStateGraph）。

    ``tools`` 里的工具都是确定性代码，模型只是调用方，
    无法通过工具绕过只读连接、行数上限和修复预算。
    """

    llm = build_chat_model(settings.primary_model, temperature=0.2)
    # create_agent 在 LangChain 1.x 下返回的就是 CompiledStateGraph ——
    # 所以这个「Agent」本质上是一张嵌套的 LangGraph 图。
    return create_agent(
        model=llm,
        tools=tools,
        response_format=ToolStrategy(SQLDraft),
        system_prompt=SQL_REWRITE_SYSTEM,
    )


def build_repair_prompt(
    *,
    question: str,
    schema: str,
    sql: str,
    validation: ValidationResult,
    attempts: list[SQLAttempt],
    attempt_number: int,
    max_attempts: int,
) -> str:
    """把错误上下文拼成一条 user 消息。

    注意这里的 ``history`` 是**已尝试过的 SQL 列表**（由本函数自己拼），
    与 ``prompts.render_history()`` 产出的「历史对话」不是一回事。
    """

    history = "\n".join(
        f"- [{item.source}] {item.sql}"
        + (f" | {item.code}: {item.error}" if item.error else "")
        for item in attempts[-5:]
    )
    return SQL_REWRITE_HUMAN.format(
        question=question,
        schema=schema,
        sql=sql,
        code=validation.code.value if validation.code else "unknown",
        message=validation.message,
        attempt=attempt_number,
        max_attempts=max_attempts,
        history=history or "（无）",
    )


def run_fixer(agent, prompt: str) -> SQLDraft:
    """调用修复 Agent 并取出结构化结果。

    Agent 内部会自己循环调用工具（validate_sql / execute_sql），
    ``recursion_limit`` 限制它的工具调用轮数，防止无限自检。
    """

    result = agent.invoke(
        {"messages": [{"role": "user", "content": prompt}]},
        {"recursion_limit": settings.max_fix_iterations * 2},
    )
    draft = result.get("structured_response")
    if not isinstance(draft, SQLDraft):
        raise TypeError(
            f"SQL 修复 Agent 返回了非 SQLDraft 结果：{type(draft).__name__}"
        )
    return draft


__all__ = [
    "build_repair_prompt",
    "build_sql_fixer_agent",
    "run_fixer",
]
