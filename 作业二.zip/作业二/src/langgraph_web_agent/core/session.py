"""会话管理：thread_id 与 checkpointer。

LangGraph 的 checkpointer 按 ``thread_id`` 存状态。只要用同一个
``thread_id`` 调 ``invoke``，``GraphState.history`` 就会跨轮累积
（``Annotated[list, add]`` 的语义）。

两处容易踩的坑（都已实测）：

1. **清空会话不能用 ``update_state(config, {"history": []})``** ——
   ``history`` 声明了 ``add`` reducer，写入空列表等于「追加零条」，
   历史一条都不会少（实测：清空后仍有 2 条）。
   正确做法是 ``checkpointer.delete_thread(thread_id)``，直接删掉这条会话的
   全部 checkpoint（实测：清空后为 0 条）。

2. **checkpoint 里存的是 Pydantic 模型**，LangGraph 的 JSON 序列化器
   对它们走 msgpack 通道。反序列化时如果类型不在白名单里会打警告，
   且官方说明「未来版本会直接拦掉」。
   所以 ``MemorySaver`` 显式带上 ``allowed_msgpack_modules`` 白名单。
"""

from __future__ import annotations

import logging
import uuid

from langgraph.checkpoint.memory import MemorySaver
from langgraph.checkpoint.serde.jsonplus import JsonPlusSerializer

from . import models
from .models import ConversationTurn

logger = logging.getLogger(__name__)

#: 会话 id 长度（够短，方便在前端 localStorage 里辨认）
SESSION_ID_LENGTH = 12

#: 会被写进 checkpoint 的 Pydantic 类型（msgpack 反序列化白名单）。
#: 少写一个就会在反序列化时告警，未来版本还会被直接拦掉。
CHECKPOINT_TYPES = (
    "ConversationTurn",
    "ExecutionResult",
    "FinalAnswer",
    "SQLAttempt",
    "TableSelection",
    "ValidationResult",
    "WorkflowOutput",
)


def build_checkpointer():
    """构造带 msgpack 白名单的内存 checkpointer。"""

    allowed = [(models.__name__, name) for name in CHECKPOINT_TYPES]
    return MemorySaver(serde=JsonPlusSerializer(allowed_msgpack_modules=allowed))


class SessionManager:
    """管理会话 id 与 checkpointer。"""

    def __init__(self, checkpointer=None) -> None:
        self.checkpointer = checkpointer if checkpointer is not None else build_checkpointer()

    def new_session_id(self) -> str:
        """生成一个新的会话 id。"""

        return uuid.uuid4().hex[:SESSION_ID_LENGTH]

    def config(self, session_id: str) -> dict:
        """构造 LangGraph 的调用配置。"""

        return {"configurable": {"thread_id": session_id}}

    def history(self, graph, session_id: str) -> list[ConversationTurn]:
        """读取某个会话的历史轮次。

        会话还没跑过时返回空列表（checkpointer 里没有这条 thread）。
        """

        try:
            snapshot = graph.get_state(self.config(session_id))
        except Exception as exc:  # noqa: BLE001 - 会话不存在等情况
            logger.debug("session history unavailable sid=%s error=%s", session_id, exc)
            return []
        values = getattr(snapshot, "values", None) or {}
        history = values.get("history") or []
        return list(history)

    def clear(self, session_id: str) -> None:
        """清空某个会话。

        **不能用 ``update_state({"history": []})``** —— ``history`` 有 ``add``
        reducer，空列表等于追加零条，历史不会变少。必须直接删 checkpoint。
        """

        try:
            self.checkpointer.delete_thread(session_id)
        except Exception as exc:  # noqa: BLE001 - 会话不存在等情况
            logger.debug("session clear skipped sid=%s error=%s", session_id, exc)


_manager: SessionManager | None = None


def get_session_manager() -> SessionManager:
    """进程级单例。"""

    global _manager
    if _manager is None:
        _manager = SessionManager()
    return _manager


__all__ = [
    "CHECKPOINT_TYPES",
    "SESSION_ID_LENGTH",
    "SessionManager",
    "build_checkpointer",
    "get_session_manager",
]
