"""生成 SQL 链：``prompt | llm.with_structured_output(SQLDraft)``。

与第十二周作业二的同名模块**只差一处**：human 模板多了 ``{history}`` 入参。
"""

from __future__ import annotations

from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import Runnable

from ..config import settings
from ..llm import build_structured_chain
from ..models import SQLDraft
from ..prompts import SQL_GENERATE_HUMAN, SQL_GENERATE_SYSTEM

#: 生成阶段的提示词模板。
GENERATE_PROMPT = ChatPromptTemplate.from_messages(
    [
        ("system", SQL_GENERATE_SYSTEM),
        ("human", SQL_GENERATE_HUMAN),
    ]
)


def build_generate_chain() -> Runnable:
    """返回生成链：输入 question / schema / history，输出 SQLDraft。"""

    structured = build_structured_chain(
        SQLDraft, settings.primary_model, temperature=0.0
    )
    return GENERATE_PROMPT | structured
