"""选表链：LCEL 表达式 ``prompt | llm.with_structured_output(TableSelection)``。

与第十二周作业二的同名模块**只差一处**：human 模板多了 ``{history}`` 入参，
用于多轮会话时把之前的对话作为上下文交给模型。
"""

from __future__ import annotations

from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import Runnable

from ..config import settings
from ..llm import build_structured_chain
from ..models import TableSelection
from ..prompts import TABLE_SELECT_HUMAN, TABLE_SELECT_SYSTEM

#: 选表阶段的提示词模板（可直接单测，不需要模型）。
SELECT_PROMPT = ChatPromptTemplate.from_messages(
    [
        ("system", TABLE_SELECT_SYSTEM),
        ("human", TABLE_SELECT_HUMAN),
    ]
)


def build_select_chain() -> Runnable:
    """返回选表链：输入 question / catalog / history，输出 TableSelection。"""

    structured = build_structured_chain(
        TableSelection, settings.primary_model, temperature=0.0
    )
    return SELECT_PROMPT | structured
