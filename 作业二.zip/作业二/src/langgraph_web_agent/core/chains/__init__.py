"""三条 LCEL 链的装配。

``StageChains`` 把三个阶段打包，编排层只依赖这个对象，
测试时可以整体替换成假实现。
"""

from __future__ import annotations

from dataclasses import dataclass

from langchain_core.runnables import Runnable

from .result_summary import build_summary_chain
from .sql_generate import build_generate_chain
from .table_select import build_select_chain


@dataclass
class StageChains:
    """编排层需要的三个 LLM 阶段。"""

    #: 输入 question / catalog / history -> TableSelection
    select: Runnable
    #: 输入 question / schema / history -> SQLDraft
    generate: Runnable
    #: 输入 question / sql / rows 等 -> FinalAnswer
    summarize: Runnable


def build_default_chains() -> StageChains:
    """构造默认的三条链（惰性构造 ChatOpenAI，无 key 时也能导入本包）。"""

    return StageChains(
        select=build_select_chain(),
        generate=build_generate_chain(),
        summarize=build_summary_chain(),
    )


__all__ = [
    "StageChains",
    "build_default_chains",
    "build_generate_chain",
    "build_select_chain",
    "build_summary_chain",
]
