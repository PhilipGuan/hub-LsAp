"""把 Vue 3 下载到本地，改成离线可用的前端。

**为什么需要它**：``frontend/index.html`` 默认从 unpkg CDN 加载 Vue 3。
内网、云服务器、或者教室断网的环境会加载不出来 —— 页面一直停在
「正在加载 Vue 3 …」，一片空白。

这个脚本做两件事：

1. 把 ``vue.global.prod.js`` 下载到 ``frontend/vendor/``；
2. 把 ``index.html`` 里的 ``<script src>`` 改成本地相对路径。

用法::

    python -X utf8 scripts/vendor_vue.py            # 下载并改写
    python -X utf8 scripts/vendor_vue.py --restore  # 改回 CDN

改写是可逆的：``--restore`` 把 ``<script src>`` 换回 unpkg 的地址。
"""

from __future__ import annotations

import argparse
import urllib.request
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
INDEX_HTML = PROJECT_ROOT / "frontend" / "index.html"
VENDOR_DIR = PROJECT_ROOT / "frontend" / "vendor"
VENDOR_FILE = VENDOR_DIR / "vue.global.prod.js"

CDN_URL = "https://unpkg.com/vue@3/dist/vue.global.prod.js"
LOCAL_SRC = "./vendor/vue.global.prod.js"

#: <script src="..."> 里的 src 值
SCRIPT_PATTERN = '<script src="{src}"></script>'


def _read_index() -> str:
    return INDEX_HTML.read_text(encoding="utf-8")


def _write_index(text: str) -> None:
    INDEX_HTML.write_text(text, encoding="utf-8")


def current_src() -> str | None:
    """读出 index.html 现在用的 script src。"""

    text = _read_index()
    for candidate in (CDN_URL, LOCAL_SRC):
        if SCRIPT_PATTERN.format(src=candidate) in text:
            return candidate
    return None


def download() -> None:
    """下载 Vue 到 frontend/vendor/。"""

    VENDOR_DIR.mkdir(parents=True, exist_ok=True)
    print(f"下载 {CDN_URL}")
    request = urllib.request.Request(CDN_URL, headers={"User-Agent": "vendor_vue.py"})
    with urllib.request.urlopen(request, timeout=60) as response:  # noqa: S310 - 固定 CDN
        payload = response.read()
    VENDOR_FILE.write_bytes(payload)
    size_kb = len(payload) / 1024
    print(f"已保存 {VENDOR_FILE}（{size_kb:.0f} KB）")


def switch_to_local() -> None:
    """把 index.html 的 script src 改成本地路径。"""

    text = _read_index()
    old = SCRIPT_PATTERN.format(src=CDN_URL)
    new = SCRIPT_PATTERN.format(src=LOCAL_SRC)
    if new in text:
        print("已经是本地路径了，无需改动")
        return
    if old not in text:
        print("[错误] index.html 里既没有 CDN 地址也没有本地路径，请人工检查。")
        raise SystemExit(1)
    _write_index(text.replace(old, new))
    print(f"已改写：{CDN_URL}")
    print(f"       → {LOCAL_SRC}")


def restore_cdn() -> None:
    """把 index.html 的 script src 改回 CDN。"""

    text = _read_index()
    old = SCRIPT_PATTERN.format(src=LOCAL_SRC)
    new = SCRIPT_PATTERN.format(src=CDN_URL)
    if new in text:
        print("已经是 CDN 地址了，无需改动")
        return
    if old not in text:
        print("[错误] index.html 里没有本地路径，无需恢复。")
        raise SystemExit(1)
    _write_index(text.replace(old, new))
    print(f"已恢复：{LOCAL_SRC}")
    print(f"       → {CDN_URL}")


def main() -> int:
    parser = argparse.ArgumentParser(description="把 Vue 3 本地化，让前端离线可用")
    parser.add_argument("--restore", action="store_true", help="改回 CDN 地址（不下载）")
    parser.add_argument("--keep-file", action="store_true", help="恢复时不删 vendor 目录")
    args = parser.parse_args()

    if args.restore:
        restore_cdn()
        if not args.keep_file and VENDOR_FILE.exists():
            VENDOR_FILE.unlink()
            if VENDOR_DIR.exists() and not any(VENDOR_DIR.iterdir()):
                VENDOR_DIR.rmdir()
            print("已删除 vendor 目录")
        return 0

    # 已经本地化过了就什么都不用做 —— Docker 构建时也走这条路径
    if current_src() == LOCAL_SRC and VENDOR_FILE.exists():
        print("已经本地化过了，无需改动。")
        return 0

    download()
    switch_to_local()
    print()
    print("现在前端不再依赖外网。重启服务即可生效：")
    print("    ./start_server.bat        （Windows）")
    print("    ./start_server.sh         （Linux / macOS）")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
