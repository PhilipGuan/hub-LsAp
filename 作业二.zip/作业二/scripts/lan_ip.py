"""打印本机局域网 IPv4 地址（给 ``start_lan.bat`` 用）。

用 UDP ``connect`` 探测 —— 它不会真的发包，只是让内核选一个出口网卡，
所以即使没有联网、没有默认路由也能拿到「本机视角」的局域网地址。
"""

from __future__ import annotations

import socket


def lan_ip() -> str:
    """返回本机局域网 IPv4 地址；拿不到就返回空串。"""

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.connect(("223.5.5.5", 80))
        return str(sock.getsockname()[0])
    except OSError:
        return ""
    finally:
        sock.close()


if __name__ == "__main__":
    print(lan_ip())
