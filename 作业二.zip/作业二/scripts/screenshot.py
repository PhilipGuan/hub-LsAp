"""用 Playwright 跑一遍前端，生成作业截图。

用法：
    # 先启动后端
    PYTHONPATH=src python -X utf8 -m uvicorn langgraph_web_agent.api.app:app --host 127.0.0.1 --port 8000
    # 再跑（另开一个终端）
    python -X utf8 scripts/screenshot.py --base http://127.0.0.1:8000

产出（默认写到 docs/）：
    01-首页与数据库概览.png
    02-提问与阶段进度.png
    03-结果表格与SQL详情.png
    04-多轮追问.png

注意：截图会**真的调用模型**，需要 .env 里配好 API Key。
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from playwright.sync_api import sync_playwright

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def find_chromium() -> str | None:
    """找 Playwright 已下载的 chromium。版本号可能和当前 playwright 不匹配，手动定位。"""

    root = Path.home() / "AppData" / "Local" / "ms-playwright"
    if not root.exists():
        return None
    candidates = sorted(root.glob("chromium-*/chrome-win64/chrome.exe"), reverse=True)
    return str(candidates[0]) if candidates else None


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", default="http://127.0.0.1:8000")
    parser.add_argument("--out", default=str(PROJECT_ROOT / "docs"))
    args = parser.parse_args()

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    executable = find_chromium()
    issues: list[str] = []

    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path=executable)
        ctx = browser.new_context(
            viewport={"width": 1440, "height": 900},
            device_scale_factor=1,
            locale="zh-CN",
        )
        page = ctx.new_page()
        page.on("console", lambda msg: print(f"[console] {msg.type}: {msg.text}"))
        page.on("pageerror", lambda exc: issues.append(f"页面异常：{exc}"))

        # ---- 01 首页 ----
        page.goto(args.base, wait_until="networkidle")
        page.wait_for_selector(".tbl-item", timeout=15000)
        page.wait_for_timeout(500)
        page.screenshot(path=str(out_dir / "01-首页与数据库概览.png"))
        print("已保存 01-首页与数据库概览.png")

        tables = page.locator(".tbl-item").count()
        if tables != 11:
            issues.append(f"左栏表数量是 {tables}，预期 11")
        if "模型已就绪" not in (page.locator(".pill").first.inner_text() or ""):
            issues.append("顶部没有显示「模型已就绪」")

        # ---- 02 提问与阶段进度 ----
        page.fill("textarea", "总共有多少张专辑？")
        page.click(".btn.primary")
        # 等到至少 4 个阶段标签出现 —— 说明流水线真的在跑，而不是刚起步
        page.wait_for_function(
            "() => document.querySelectorAll('.stage').length >= 4", timeout=120000
        )
        page.wait_for_timeout(300)
        page.screenshot(path=str(out_dir / "02-提问与阶段进度.png"))
        print("已保存 02-提问与阶段进度.png")

        # ---- 03 结果表格与 SQL 详情 ----
        page.wait_for_selector("table", timeout=180000)
        page.wait_for_timeout(400)
        # 展开「查看执行的 SQL」
        if page.locator("details summary").count():
            page.locator("details summary").first.click()
            page.wait_for_timeout(300)
        page.screenshot(path=str(out_dir / "03-结果表格与SQL详情.png"))
        print("已保存 03-结果表格与SQL详情.png")

        rows = page.locator("table tbody tr").count()
        if rows < 1:
            issues.append("结果表格没有数据行")
        sql_text = page.locator(".sqlbox").inner_text() if page.locator(".sqlbox").count() else ""
        if "SELECT" not in sql_text.upper():
            issues.append("SQL 详情区里没有 SELECT 语句")

        # ---- 04 多轮追问 ----
        page.fill("textarea", "那按专辑数量排名前 3 的艺术家呢？")
        page.click(".btn.primary")
        page.wait_for_selector("table", timeout=180000)
        # 等第二轮的表格出来（第一轮的表格还在，所以数表格数量）
        page.wait_for_function(
            "() => document.querySelectorAll('table').length >= 2", timeout=180000
        )
        page.wait_for_timeout(600)
        page.screenshot(path=str(out_dir / "04-多轮追问.png"))
        print("已保存 04-多轮追问.png")

        browser.close()

    if issues:
        print("\n发现问题：", file=sys.stderr)
        for item in issues:
            print(f"  - {item}", file=sys.stderr)
        return 1
    print("\n全部截图完成。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
