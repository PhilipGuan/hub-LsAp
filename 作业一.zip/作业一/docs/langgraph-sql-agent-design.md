# LangGraph 版 SQL Agent 设计文档

- 项目：第十三周作业一 —— 用 LangGraph 复现 SQL Agent
- 日期：2026-11-05
- 上游：`12-江洋明-第十二周作业/作业二`（LangChain 版 SQL Agent）

---

## 1. 目标与约束

### 1.1 背景

第十二周作业二已经用 LangChain 复刻了 `00-sql-agent`（openai-agents 版），形成一条流水线：

```text
数据库解析 → 表选择 → SQL 生成 → SQL 校验 → SQL 改写 → SQL 执行 → 结果汇总
```

第十三周作业一要求**用 LangGraph 复现**这条流水线。

### 1.2 这次复刻的增量在哪里

上一版与上一上一版的差别只在「谁来跑 LLM」；**编排层（状态机、重试预算、降级、安全门禁）
始终是手写 Python**。这在工程上是对的，但状态机的结构只存在于缩进里 —— 看不见、测不了、改不动。

LangGraph 带来的增量是把编排本身变成**显式的图**：

| 能力 | Week12 作业二（Python 编排） | Week13 作业一（LangGraph 编排） |
| --- | --- | --- |
| 阶段边界 | 函数调用栈 | 图的节点，可单独测试 |
| 分支 | `if` / `for` | 条件边，路由函数可单测 |
| 修复回边 | `for repair_index in range(...)` | 回边 + 状态里的预算计数 |
| 终止条件 | 散落在多个 `return` | 集中到路由函数 |
| 会话记忆 | 无 | checkpointer + reducer 跨轮累积 |
| 过程可观测 | 只能看日志 | `graph.stream()` 逐节点产出，可直接推给前端 |

### 1.3 明确不做的事

- 不引入新的数据库、新的模型供应商、新的业务能力。
- 不改写上一版的安全门禁（`db/` 三个模块逐字复用）。
- 不做流式 token 级输出（模型返回的是结构化结果，不是文本流；阶段级进度才是有意义的信号）。
- 不做账号体系、多用户、持久化到磁盘的会话（内存会话足够演示）。

### 1.4 硬性约束（沿用仓库既有约定）

- API key 只从环境变量 / `.env` 读，代码里不出现任何真实密钥；`.env` 不入库。
- 注释、docstring、提示词、面向用户的输出一律中文。
- 数据库访问全程只读。
- Windows 控制台打印中文需要包一层 UTF-8 包装。

---

## 2. 架构总览

### 2.1 分层

```text
┌──────────────────────────────────────────────────────────────┐
│ 编排层（本次重写的部分）                                     │
│   graph/state.py    GraphState（Pydantic + add reducer）      │
│   graph/nodes.py    8 个节点                                 │
│   graph/routing.py  4 个纯函数路由                            │
│   graph/build.py    StateGraph 装配 + 编译                    │
│   session.py        checkpointer + 会话管理                   │
└──────────────────────────────────────────────────────────────┘
┌──────────────────────────────────────────────────────────────┐
│ LLM 层（与上一版逐字相同）                                    │
│   chains/table_select.py     选表                             │
│   chains/sql_generate.py     生成 SQL                          │
│   chains/result_summary.py   结果汇总                          │
│   agents/sql_fixer.py        create_agent + ToolStrategy      │
└──────────────────────────────────────────────────────────────┘
┌──────────────────────────────────────────────────────────────┐
│ 确定性层（与上一版逐字相同）                                   │
│   db/catalog.py     解析 DB、缓存 schema / 统计 / 外键 / 样例    │
│   db/validator.py   安全门禁 + EXPLAIN 编译校验                 │
│   db/executor.py    只读执行、超时、行数与长度截断              │
│   tools/db_tools.py 给修复 Agent 的三个工具                    │
└──────────────────────────────────────────────────────────────┘
```

**分层的意义**：换框架只动最上面那层。中间层和最下面那层一字未改，
这是「安全边界没有因为换框架而松动」的直接证据。

### 2.2 数据流

```mermaid
flowchart TD
    U[用户问题] --> C[capture_question]
    C --> S[select_tables]
    S -->|需要澄清| F[finalize]
    S -->|选到表| G[generate_sql]
    G --> V[validate]
    V -->|通过| E[execute]
    V -->|不通过| R[repair]
    E -->|成功| M[summarize]
    E -->|失败| R
    R --> V
    M --> F
    F --> O[WorkflowOutput<br/>代码组装]
```

三种出口（澄清 / 修复成功 / 修复失败）**全部汇到 `finalize`**，
由状态里的 `error` 字段区分 —— 前端只需要处理一个终点。

---

## 3. 图结构设计

### 3.1 节点表

| 节点 | 类型 | 职责 | 读状态 | 写状态 |
| --- | --- | --- | --- | --- |
| `capture_question` | 确定性 | 把本轮问题记进历史 | `question` | `history`, `stage` |
| `select_tables` | LLM | 选最少表集合（内部带一次重选） | `question`, `history` | `selection`, `schema_context` |
| `generate_sql` | LLM | 生成一条 SQLite SELECT | `question`, `schema_context`, `history` | `sql`, `attempts` |
| `validate` | 确定性 | 安全门禁 + `EXPLAIN` 编译 | `sql` | `validation`, `sql`, `error` |
| `execute` | 确定性 | 只读连接上执行 | `sql` | `execution`, `error` |
| `repair` | LLM | 按错误改写 SQL（嵌套 ReAct 子图） | `sql`, `validation`, `attempts` | `sql`, `repair_attempts`, `repair_blocked`, `attempts` |
| `summarize` | LLM | 结果转自然语言 | `execution` | `answer` |
| `finalize` | 确定性 | 组装输出 + 记录助手轮 | 全部 | `output`, `history` |

### 3.2 边表

| 起点 | 类型 | 终点 | 条件 |
| --- | --- | --- | --- |
| `START` | 无条件 | `capture_question` | — |
| `capture_question` | 无条件 | `select_tables` | — |
| `select_tables` | 条件 | `generate_sql` / `finalize` | `route_after_select` |
| `generate_sql` | 无条件 | `validate` | — |
| `validate` | 条件 | `execute` / `repair` / `finalize` | `route_after_validate` |
| `execute` | 条件 | `summarize` / `repair` / `finalize` | `route_after_execute` |
| `repair` | 条件 | `validate` / `finalize` | `route_after_repair` |
| `summarize` | 无条件 | `finalize` | — |
| `finalize` | 无条件 | `END` | — |

装配代码（`graph/build.py`）：

```python
graph.add_conditional_edges(
    "validate",
    route_after_validate,
    {"execute": "execute", "repair": "repair", "finalize": "finalize"},
)
```

第三个参数是**路径映射表**：把路由函数返回的字符串映射到节点名。
路由函数只返回字符串，不返回节点对象 —— 这样路由函数可以完全脱离图来单测。

### 3.3 路由函数的判定顺序

判定顺序很重要：**先判成功，再判预算，最后才判修复**。
反过来写会在「刚好修好」的那一轮误判成预算耗尽。

```python
def route_after_validate(state: GraphState) -> str:
    validation = state.validation
    if validation is not None and validation.ok:      # ① 成功优先
        return "execute"
    if not _repair_budget_left(state):                # ② 预算耗尽
        return "finalize"
    return "repair"                                   # ③ 否则去修
```

四个路由函数：

| 路由函数 | 判定顺序 |
| --- | --- |
| `route_after_select` | ① 没选到表 / 要澄清 → `finalize`；② 否则 → `generate_sql` |
| `route_after_validate` | ① 校验通过 → `execute`；② 预算耗尽 → `finalize`；③ → `repair` |
| `route_after_execute` | ① 执行成功 → `summarize`；② 预算耗尽 → `finalize`；③ → `repair` |
| `route_after_repair` | ① 判定修不了 → `finalize`；② → `validate`（回边） |

### 3.4 修复预算的语义

- `settings.max_repair_attempts = 3`：**校验失败与执行失败共用同一份预算**。
  也就是说「校验错 2 次 + 运行错 1 次」就用完了，不是各 3 次。
- 计数方式：`repair` 节点每成功改写一次就把 `repair_attempts` 加 1，
  所以这个字段**精确等于「已经让模型改过几遍」**，不多不少。
- 图级 `RECURSION_LIMIT = 25` 是**另一层**保护，防止任何意料之外的循环。
  它不是修复预算 —— 修复预算是业务语义，这个是技术兜底。

### 3.5 选表节点内部的重试

`select_tables` 节点内部带一次「重选」：模型选出的表不存在、或彼此之间没有外键连接时，
把问题回灌给模型再试一次（上限 2 次），两次都不行就转成澄清问题。

这是**节点内部的提示词级重试**，与图上的 SQL 修复回边是两回事，不要混淆：

| | 选表内部重选 | SQL 修复回边 |
| --- | --- | --- |
| 触发 | 表名不存在 / 无外键连接 | 校验失败 / 执行失败 |
| 位置 | 节点函数内部 | 图上的回边 |
| 计数 | 局部变量 | 状态字段 `repair_attempts` |
| 出口 | 转澄清问题 | 回 `validate` |

---

## 4. 状态设计

### 4.1 `GraphState` 全字段

```python
class GraphState(BaseModel):
    question: str
    history: Annotated[list[ConversationTurn], add] = Field(default_factory=list)
    attempts: Annotated[list[SQLAttempt], add] = Field(default_factory=list)

    selection: TableSelection | None = None
    schema_context: str = ""
    sql: str | None = None
    validation: ValidationResult | None = None
    execution: ExecutionResult | None = None
    answer: FinalAnswer | None = None

    repair_attempts: int = 0
    repair_blocked: bool = False
    error: str | None = None
    stage: str = "init"
    output: WorkflowOutput | None = None
```

| 字段 | 类型 | 语义 | 谁写 | 谁读 |
| --- | --- | --- | --- | --- |
| `question` | `str` | 当前这一轮的用户问题 | 调用方 | 全部 LLM 节点 |
| `history` | `list[ConversationTurn]`，**add** | 历史对话，跨轮累积 | `capture_question` / `finalize` | `select_tables` / `generate_sql` |
| `attempts` | `list[SQLAttempt]`，**add** | 本轮尝试过的 SQL | `generate_sql` / `repair` | `repair` |
| `selection` | `TableSelection \| None` | 选表结果 | `select_tables` | `generate_sql` / `finalize` |
| `schema_context` | `str` | 已选表的详细 schema（Markdown） | `select_tables` | `generate_sql` / `repair` |
| `sql` | `str \| None` | 当前 SQL（校验通过后是规范化版本） | `generate_sql` / `validate` / `repair` | `validate` / `execute` / `repair` |
| `validation` | `ValidationResult \| None` | 校验结果 | `validate` | `repair` / 路由 |
| `execution` | `ExecutionResult \| None` | 执行结果 | `execute` | `summarize` / `finalize` |
| `answer` | `FinalAnswer \| None` | 汇总出的自然语言答案 | `summarize` | `finalize` |
| `repair_attempts` | `int` | 已用掉的修复次数 | `repair` | 路由 / `finalize` |
| `repair_blocked` | `bool` | 修复 Agent 判定「这个问题回答不了」 | `repair` | 路由 / `finalize` |
| `error` | `str \| None` | 最近一次失败的原因 | `validate` / `execute` / `repair` | `repair` / `finalize` |
| `stage` | `str` | 最近走到的节点名 | 每个节点 | 日志 / 前端 |
| `output` | `WorkflowOutput \| None` | 面向用户的最终输出 | `finalize` | 调用方 / 前端 |

### 4.2 `add` reducer 的语义

`Annotated[list[X], add]` 声明的是**追加**语义：节点返回 `{"history": [turn]}`
时，LangGraph 把这一条**追加**到已有列表后面，而不是覆盖。

两个后果：

1. **节点自己不用管合并逻辑**。节点只管「我这一段产出了什么」，
   合并由框架负责 —— 这是节点能保持纯函数的原因。
2. **跨轮累积是免费的**。checkpointer 把上一轮结束时的状态存下来，
   下一轮 `invoke` 时以它为起点，节点追加的内容自然接在后面。

### 4.3 跨轮累积的实测结论

实测（同一 `thread_id`、同一进程、两次 `invoke`）：

| 时点 | `history` 条数 | `attempts` 条数 |
| --- | --- | --- |
| 第 1 轮 `capture_question` 后 | 1（用户轮） | 0 |
| 第 1 轮 `finalize` 后 | 2（用户 + 助手） | 1（generator） |
| 第 2 轮 `capture_question` 后 | 3 | 2 |
| 第 2 轮 `finalize` 后 | 4 | 2 |

第 2 轮结束后 `history` 是 4 条 —— 正是 2 用户轮 + 2 助手轮。

> **注意**：`attempts` 也会跨轮累积，所以它同时装着「第 1 轮试过的 SQL」和「第 2 轮试过的 SQL」。
> 修复节点只用 `attempts[-5:]` 构造提示词，跨轮的旧尝试会被自然挤掉，不影响正确性。

### 4.4 Pydantic 作为状态 schema 的一个坑

LangGraph 1.x 原生支持 Pydantic 模型当状态 schema，但 Pydantic 会把
`Annotated[list[X], add]` 里的 `Annotated` **拆掉**：

```python
GraphState.model_fields["history"].annotation      # list[ConversationTurn]  ← Annotated 没了
GraphState.model_fields["history"].metadata        # [add]                   ← 元数据在这
GraphState.__annotations__["history"]               # Annotated[list[...], add] ← 原始形式在这
```

所以测试不能断言 `"Annotated" in str(field.annotation)` —— 会误判为「没声明追加语义」。
正确写法是同时断言 `__annotations__` 里的原始形式和 `metadata` 里的 `add`。
（这个坑在写 `tests/test_state.py` 时踩过，见该文件的 `test_历史与尝试记录声明了追加语义`。）

---

## 5. 多轮上下文设计

### 5.1 历史注入到哪两个节点

**只有 `select_tables` 和 `generate_sql` 会把历史交给模型。**

| 节点 | 是否注入历史 | 理由 |
| --- | --- | --- |
| `select_tables` | ✅ | 「按年份呢？」要靠上一轮知道「年份」指哪个表 |
| `generate_sql` | ✅ | 同上，生成的 SQL 要延续上一轮的查询对象 |
| `validate` | ❌ | 确定性代码，只看 SQL 本身对不对，与上下文无关 |
| `execute` | ❌ | 同上 |
| `repair` | ❌ | 修的是**具体的 SQL 错误**，不是「上一轮问了什么」 |
| `summarize` | ❌ | 汇总的是**这一轮的结果集**，历史答案反而可能误导 |
| `finalize` | ❌ | 纯代码组装 |

**为什么不进校验/执行/修复/汇总**：这三个节点处理的是「这一轮的 SQL 和结果」，
历史对它们没有帮助，注入了反而是噪声和成本。历史只回答「**用户问的是什么**」，
只有需要理解用户意图的两个节点才需要它。

### 5.2 渲染格式

`prompts.render_history()` 把 `list[ConversationTurn]` 渲染成给模型看的文本块：

```text
【历史对话（仅作上下文参考，当前问题才是要回答的）】
[第1轮] 问：总共有多少张专辑？
        答：数据库中共有 347 张专辑。
        涉及表：albums
        SQL：SELECT COUNT(*) AS TotalAlbums FROM albums
```

三个设计点：

1. **标题里写明「当前问题才是要回答的」** —— 防止模型把历史问题也当成要回答的。
2. **带上「涉及表」和「SQL」** —— 只给自然语言答案不够，
   模型需要知道上一轮实际查了什么表才能正确延续。
3. **系统提示词里也重申一遍** —— `TABLE_SELECT_SYSTEM` 规则 7、
   `SQL_GENERATE_SYSTEM` 规则 10。提示词里说一次不够，
   历史和当前问题在提示词里是相邻的两段文字，模型容易串。

### 5.3 截断策略

| 常量 | 值 | 作用 |
| --- | --- | --- |
| `MAX_HISTORY_TURNS` | 5 | 只保留最近 5 轮（`turns[-5:]`） |
| `MAX_HISTORY_ANSWER_CHARS` | 200 | 单条「问」和「答」各最多 200 字 |
| `MAX_HISTORY_SQL_CHARS` | 400 | 单条 SQL 最多 400 字 |

`_truncate()` 把多行文本压成一行再截断，避免一条长 SQL 把提示词撑爆。
没有历史时 `render_history()` 返回空字符串，此时 `{history}` 占位符渲染成空行，
不影响提示词结构。

### 5.4 `history` 这个名字的两义性

`prompts.SQL_REWRITE_HUMAN` 里也有一个 `{history}` 占位符，但它是
**已尝试过的 SQL 列表**，由 `agents/sql_fixer.py:build_repair_prompt()` 自己拼：

```text
已尝试过的 SQL：
- [generator] SELECT COUNT(*) AS TotalAlbums FROM albums
- [rewriter] SELECT COUNT(*) FROM albums WHERE ...
```

两者**完全无关**，不要混用 —— `prompts.py` 的模块 docstring 里专门写了这条警告。

---

## 6. 修复节点的嵌套子图

### 6.1 `create_agent` 本身就是一张图

`langchain.agents.create_agent` 在 LangChain 1.x / LangGraph 1.x 下返回的
**正是 `CompiledStateGraph`**（已实测确认）。所以「修复 Agent」不是一段 while 循环，
而是一张**嵌套在主图里的子图**：

```text
主图（StateGraph，8 个节点）
  └─ repair 节点
       └─ invoke 一张子图（CompiledStateGraph）
            └─ 工具调用循环：validate_sql / execute_sql / get_table_schema
```

### 6.2 为什么这件事重要

上一版（LangChain）里，修复 Agent 的工具调用循环是 LangChain 内部的黑盒；
本版把它显式暴露成了一张图，带来的直接好处是：

- **可以给它单独设上限**。子图的 `recursion_limit` 独立于主图：
  ```python
  agent.invoke(
      {"messages": [{"role": "user", "content": prompt}]},
      {"recursion_limit": settings.max_fix_iterations * 2},   # 6 × 2 = 12
  )
  ```
  主图的 `RECURSION_LIMIT = 25` 管的是「修复回边最多 3 次」，
  两者是**两个不同层级的保护**，不能互相替代。

- **嵌套边界是清晰的**。子图只看到一条 user 消息，看不到主图的状态。
  它交回来一个 `SQLDraft`，主图再判一次 —— 模型的输出仍然不能直接放行。

### 6.3 `recursion_limit` 在 LangGraph 1.x 的位置

LangGraph 1.x 的 `invoke` **不接受第三个位置参数**：

```python
# ❌ TypeError: Pregel.invoke() takes from 2 to 3 positional arguments but 4 were given
graph.invoke(inputs, config, {"recursion_limit": 25})

# ✅ 放进 config 字典
graph.invoke(inputs, {**manager.config(sid), "recursion_limit": 25})
```

主图和子图都是这样（`cli.py` 和 `agents/sql_fixer.py` 各踩过一次）。

---

## 7. 安全边界

### 7.1 为什么 `db/` 逐字复用

`db/validator.py`、`db/executor.py`、`tools/db_tools.py` 是**直接从
`12-江洋明-第十二周作业/作业二` 复制过来的**，一个字符都没改。

理由：**换框架不该动安全边界**。如果这次复刻顺手「优化」了校验规则，
两版的安全边界就不再可比了，作业的核心论证（换框架不影响安全性）也就没法验证。

唯一的一处例外是 `db/catalog.py` 新增了一个公开只读方法：

```python
def table_profiles(self) -> list[TableProfile]:
    """返回全部表的画像（公开只读视图）。"""
    return [self._tables[name] for name in self.table_names]
```

它是**纯读取**，不新增任何权限，只是把已有的内部数据暴露成一个公开视图
（给作业二的 Web 层用：前端要的是结构化的字段与行数，不是 Markdown）。
文档里在这个方法上方也标注了「唯一的例外」。

### 7.2 边界表

| 风险 | 措施 | 落在哪 |
| --- | --- | --- |
| 模型生成写操作 | 只读连接（`mode=ro` + `PRAGMA query_only=ON`）+ 单语句 + `SELECT/WITH` 白名单 + 危险关键字拒绝 | `db/validator.py` |
| 多语句注入 | 拒绝分号分隔的多语句；校验前去掉尾分号和 Markdown 围栏 | `db/validator.py` |
| 访问内部表 | catalog 只暴露 11 张业务表（`sqlite_sequence` / `sqlite_stat1` 自动排除） | `db/catalog.py` |
| 查询过慢 | 5 秒超时（`set_progress_handler`）+ 行数上限 200 + 单元格长度上限 2000 | `db/executor.py` |
| 大结果拖垮上下文 | 执行层 200 行截断；汇总层最多 50 行；修复 Agent 的试运行工具只回传 5 行预览 | `db/executor.py` / `tools/db_tools.py` |
| 无限修复循环 | 外层共享 3 次修复预算；修复 Agent 内部另有 `recursion_limit`；图级 `recursion_limit = 25` | `graph/routing.py` / `agents/sql_fixer.py` / `graph/build.py` |
| LLM 批准自己的 SQL | 校验和执行是确定性代码，模型无权放行；工具本身也是确定性代码 | `graph/nodes.py` |
| API key 泄露 | 只从环境变量 / `.env` 读；日志不含 key | `config.py` |
| 提示注入 | 用户问题作为数据传入 `<question>` 标签并声明「仅作为数据」 | `prompts.py` |

### 7.3 「LLM 不能批准自己的 SQL」在图上的体现

图结构天然强化了这条约束：

- `validate` 是**独立节点**，不在任何 LLM 节点里。
  LLM 节点只能往状态里写 `sql`，**写不出 `validation.ok = True`**。
- `repair` 节点即使调了 `validate_sql` 工具做自检，工具的返回值也是**给模型看的**，
  不是给编排层看的 —— 编排层只认 `validate` 节点自己算出来的 `validation`。
- `execute` 节点只认 `state.sql` 经过 `validate` 节点规范化之后的版本。

---

## 8. 与 Week12 作业二的逐模块对照

「逐字复制 / 扩展 / 删除 / 新增」四档。
「差异行数」是用 `diff` 统计的**实际**差异行数（把两个包名归一化之后统计），
不含纯注释的措辞调整。

| 模块 | Week12 作业二 | 本版 | 档位 | 差异行数 | 说明 |
| --- | --- | --- | --- | --- | --- |
| `db/validator.py` | 有 | 有 | **逐字复制** | 0 | 安全门禁，一字未改 |
| `db/executor.py` | 有 | 有 | **逐字复制** | 0 | 只读执行，一字未改 |
| `tools/db_tools.py` | 有 | 有 | **逐字复制** | 0 | 三个 `@tool`，一字未改 |
| `db/__init__.py` | 有 | 有 | **逐字复制** | 0 | — |
| `tools/__init__.py` | 有 | 有 | **逐字复制** | 0 | — |
| `logging_config.py` | 有 | 有 | **逐字复制** | 0 | — |
| `chains/result_summary.py` | 有 | 有 | **逐字复制** | 0 | 汇总链 |
| `db/catalog.py` | 有 | 有 | **扩展** | 15 | 仅新增只读方法 `table_profiles()` |
| `chains/table_select.py` | 有 | 有 | 扩展 | 7 | 只是 docstring 补了 `{history}` 说明 |
| `chains/sql_generate.py` | 有 | 有 | 扩展 | 4 | 同上 |
| `chains/__init__.py` | 有 | 有 | 扩展 | 4 | 同上 |
| `agents/__init__.py` | 有 | 有 | 扩展 | 4 | 同上 |
| `agents/sql_fixer.py` | 有 | 有 | 扩展 | 33 | 全是 docstring；代码逻辑一致 |
| `llm.py` | 有 | 有 | 扩展 | 2 | 只改了一处报错文案（「作业二」→「作业一」） |
| `config.py` | 有 | 有 | 扩展 | 6 | `PROJECT_ROOT` 注释 + `.env` 回退路径 |
| `models.py` | 有 | 有 | 扩展 | 29 | 删 `QueryState`，加 `ConversationTurn` |
| `prompts.py` | 有 | 有 | **扩展** | 70 | 加 `render_history()` + 两个 `{history}` 占位符 + 两条系统规则 |
| `__init__.py` | 有 | 有 | 扩展 | 13 | 包名与导出 |
| `cli.py` | 有 | 有 | **扩展** | 76 | 加 `--then`；`recursion_limit` 挪进 config |
| `__main__.py` | 有 | 有 | 扩展 | — | 同上一版 |
| `workflow.py` | **有** | **无** | **删除** | — | **被 `graph/` 整个目录取代** |
| `graph/state.py` | 无 | 有 | **新增** | — | `GraphState` |
| `graph/routing.py` | 无 | 有 | **新增** | — | 4 个纯函数路由 |
| `graph/nodes.py` | 无 | 有 | **新增** | — | 8 个节点工厂 |
| `graph/build.py` | 无 | 有 | **新增** | — | `StateGraph` 装配 |
| `session.py` | 无 | 有 | **新增** | — | checkpointer + 会话管理 |
| `graph/__init__.py` | 无 | 有 | **新增** | — | — |

一句话概括这张表：**上一版 21 个模块里，20 个留了下来（其中 7 个一字未改），
1 个（`workflow.py`）被 `graph/` 整个目录取代，新增 6 个。**

---

## 9. 实测轨迹

真实 DeepSeek 调用（`deepseek-v4-pro` 规划 / `deepseek-flash` 汇总），
数据库是自带的 `data/chinook.db`。

### 9.1 单轮

```bash
PYTHONPATH=src python -m langgraph_sql_agent "总共有多少张专辑？"
```

```json
{
  "question": "总共有多少张专辑？",
  "answer": "总共有 347 张专辑。",
  "sql": "SELECT COUNT(*) AS TotalAlbums FROM albums",
  "tables": ["albums"],
  "row_count": 1,
  "truncated": false,
  "repair_attempts": 0,
  "error": null
}
```

对应的日志：

```text
stage=catalog_ready tables=11 elapsed=0.23s
graph compiled recursion_limit=25
stage=capture_question question=总共有多少张专辑？
stage=table_select attempt=1 tables=['albums'] confidence=1.00 needs_clarification=False elapsed=2.52s reason=统计专辑总数只需查询 albums 表，通过 COUNT(*) 即可得到专辑数量。
stage=sql_generate elapsed=1.72s sql=SELECT COUNT(*) AS TotalAlbums FROM albums;
stage=validate ok=True code=None elapsed=0.004s message=
stage=execute ok=true rows=1 truncated=False elapsed=0.002s
stage=summarize_finished elapsed=1.12s evidence=1 caveats=0
stage=final answer=总共有 347 张专辑。 evidence=1 caveats=0
```

注意 `sql_generate` 那行末尾有个分号（模型原样输出），
但最终 JSON 里的 `sql` 没有 —— `validate` 节点把**规范化后的** SQL 写回状态
（去尾分号、去 Markdown 围栏），执行的一定是规范化之后的那一条。
这条约束由 `tests/test_nodes.py::test_校验通过时采用规范化后的_sql` 守着。

### 9.2 两轮（同一进程、同一 thread_id）

```bash
PYTHONPATH=src python -m langgraph_sql_agent --session demo \
  "总共有多少张专辑？" --then "那按专辑数量排名前 3 的艺术家呢？"
```

```text
--- 第1轮 ---
答案：总共有 347 张专辑。
SQL：SELECT COUNT(*) AS TotalAlbums FROM albums
表：['albums'] | 行数 1 | 修复 0 | 历史条数：2

--- 第2轮 ---
答案：按专辑数量排名前 3 的艺术家依次为：Iron Maiden（21 张）、Led Zeppelin（14 张）、Deep Purple（11 张）。
SQL：SELECT a.Name AS ArtistName, COUNT(al.AlbumId) AS AlbumCount
     FROM artists a
     JOIN albums al ON al.ArtistId = a.ArtistId
     GROUP BY a.ArtistId, a.Name
     ORDER BY AlbumCount DESC, a.Name ASC
     LIMIT 3
表：['albums', 'artists'] | 行数 3 | 修复 0 | 历史条数：4
```

**第 2 轮的历史是 4 条**（2 用户轮 + 2 助手轮）—— 第 1 轮的问答确实进了第 2 轮的上下文。
第 2 轮的问题里只有「那……排名」，模型能补全成「按专辑数量排名前 3 的艺术家」，
靠的就是这段历史；并且它自己选出了 `albums` + `artists` 两张表并写了正确的 JOIN。

### 9.3 一次真实的失败：澄清出口

用一个库里根本不存在的东西（员工薪资表）提问：

```bash
PYTHONPATH=src python -m langgraph_sql_agent "员工的薪资是多少？"
```

真实日志：

```text
stage=capture_question question=员工的薪资是多少？
stage=table_select attempt=1 tables=['employees'] confidence=0.40 needs_clarification=True elapsed=3.64s reason=问题询问员工的薪资，employees 表包含员工信息，但该表字段中没有薪资（Salary）字段。需要确认薪资数据是否存在或存储于何处。
stage=final answer=employees 表中没有薪资（Salary）字段，请问薪资数据存储在哪张表或哪个字段中？ evidence=0 caveats=0
```

输出 JSON：

```json
{
  "question": "员工的薪资是多少？",
  "answer": "employees 表中没有薪资（Salary）字段，请问薪资数据存储在哪张表或哪个字段中？",
  "sql": null,
  "tables": ["employees"],
  "row_count": 0,
  "repair_attempts": 0,
  "error": null
}
```

注意这条轨迹**根本没走到 `generate_sql`** —— 选表阶段就发现
`employees` 表里没有 `Salary` 字段，于是设 `needs_clarification=True`，
图走 `select_tables → finalize` 直接收尾。这是设计里刻意安排的**短路**：
能在选表阶段发现的语义问题，不该浪费一次 SQL 生成。

### 9.4 关于修复路径的说明

在 Chinook 这个 schema 上，模型生成的 SQL **几乎不会出错** ——
实测跑了「每年的销售总额」「按艺术家统计专辑数 Top3」
「每个流派的专辑数与歌曲数」等需要多表 JOIN 的问题，
全部一次通过校验和执行，**没有触发过修复回边**。

这不是说修复路径没用，而是说明它属于**兜底**。它由单元测试覆盖：

| 测试 | 覆盖的分支 |
| --- | --- |
| `tests/test_nodes.py::test_修复会累加修复次数` | `repair` 正常改写 |
| `tests/test_nodes.py::test_修复判定无法修复时打上标记` | `cannot_fix=True` → `repair_blocked` |
| `tests/test_nodes.py::test_校验拒绝写操作` | `UNSAFE` 错误码 |
| `tests/test_routing.py` | 4 个路由函数的每个分支（含预算耗尽） |
| `tests/test_graph.py::test_校验失败会走修复回边` | 端到端的「生成 → 校验失败 → 修复 → 重校验 → 执行」回边 |

真要人工触发一次修复，可以用 mock（把生成链的输出换成一条语法错误的 SQL），
这也是 `tests/test_graph.py` 里的做法。

### 9.5 一个踩过的坑：跨进程续接会话

最初的实现以为 `--session` 可以跨进程续接会话。实测：

```bash
python -m langgraph_sql_agent --session s1 "总共有多少张专辑？"     # 进程 A
python -m langgraph_sql_agent --session s1 "那按艺术家分组呢？"     # 进程 B
```

进程 B 的 `history` 仍然是 2 条（不是 4 条）。

**原因不是 bug**：`MemorySaver` 把 checkpoint 存在**当前进程内存**里，
进程 A 退出，状态就没了。这是 `MemorySaver` 的语义，不是本项目的实现问题。

**解决**：CLI 加了 `--then`，让多轮在**同一次调用**（同一进程）里跑完；
真正需要跨请求续接会话的场景交给作业二的 Web 服务
（常驻进程，checkpointer 一直活着）。CLI 的模块 docstring 里也写明了这一点。

> 附注：进程 B 的答案看起来「像是」理解了上下文（「那按艺术家分组呢？」被正确理解了），
> 那是模型从中文省略句的措辞里推断出来的，**不是**历史生效的证据 ——
> 判断依据要看 `history` 的条数。

---

## 10. 已知限制

| 限制 | 说明 | 缓解 |
| --- | --- | --- |
| **会话不跨进程** | `MemorySaver` 是进程内的，CLI 的 `--session` 不能跨进程续接 | CLI 用 `--then`；作业二的 Web 服务是常驻进程，跨请求可用 |
| **会话不持久化到磁盘** | 进程重启后历史全丢 | 演示足够；要做持久化需换 `SqliteSaver` / `PostgresSaver` |
| **没有账号体系** | 所有人共用一个进程，一样能互相看到会话？**不会** —— 会话按 `thread_id` 隔离，但没有任何鉴权 | 纯本地演示，不暴露到公网 |
| **不做 token 级流式** | 模型返回的是结构化结果，不是文本流 | 阶段级进度（`graph.stream()`）已经够用，也是有意义的信号 |
| **选表只重试一次** | 两次选不到有效表就转澄清 | 可接受；再多次重试收益递减 |
| **修复预算只有 3 次** | 复杂查询可能修不好 | 会明确告诉用户「已达到最大修复次数」，不静默失败 |
| **历史截断到 5 轮** | 更早的上下文看不到 | 长会话里模型可能「忘了」很早以前问过什么 |
| **`history` 与 `attempts` 跨轮累积** | 第 2 轮的 `attempts` 里也有第 1 轮的 SQL | 修复节点只用 `attempts[-5:]`，旧尝试会被自然挤掉 |
