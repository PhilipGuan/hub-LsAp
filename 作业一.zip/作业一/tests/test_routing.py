"""路由函数测试：穷举每条分支。"""

from __future__ import annotations

from langgraph_sql_agent.config import settings
from langgraph_sql_agent.graph.routing import (
    route_after_execute,
    route_after_repair,
    route_after_select,
    route_after_validate,
)
from langgraph_sql_agent.graph.state import GraphState
from langgraph_sql_agent.models import (
    ErrorCode,
    ExecutionResult,
    TableSelection,
    ValidationResult,
)


def _state(**kwargs) -> GraphState:
    return GraphState(question="q", **kwargs)


# ---- 选表之后 ----
def test_选表需要澄清时直接收尾():
    state = _state(
        selection=TableSelection(tables=[], reason="r", needs_clarification=True)
    )
    assert route_after_select(state) == "finalize"


def test_选表没选到表时直接收尾():
    state = _state(selection=TableSelection(tables=[], reason="r"))
    assert route_after_select(state) == "finalize"


def test_选表结果缺失时直接收尾():
    assert route_after_select(_state()) == "finalize"


def test_选表正常时进入生成():
    state = _state(selection=TableSelection(tables=["albums"], reason="r"))
    assert route_after_select(state) == "generate_sql"


# ---- 校验之后 ----
def test_校验通过时进入执行():
    state = _state(validation=ValidationResult(ok=True))
    assert route_after_validate(state) == "execute"


def test_校验失败且预算充足时进入修复():
    state = _state(
        validation=ValidationResult(ok=False, code=ErrorCode.SYNTAX),
        repair_attempts=0,
    )
    assert route_after_validate(state) == "repair"


def test_校验失败且预算耗尽时收尾():
    state = _state(
        validation=ValidationResult(ok=False, code=ErrorCode.SYNTAX),
        repair_attempts=settings.max_repair_attempts,
    )
    assert route_after_validate(state) == "finalize"


# ---- 执行之后 ----
def test_执行成功时进入汇总():
    state = _state(execution=ExecutionResult(columns=["n"], rows=[["1"]], row_count=1))
    assert route_after_execute(state) == "summarize"


def test_执行失败且预算充足时进入修复():
    state = _state(execution=None, repair_attempts=1)
    assert route_after_execute(state) == "repair"


def test_执行失败且预算耗尽时收尾():
    state = _state(execution=None, repair_attempts=settings.max_repair_attempts)
    assert route_after_execute(state) == "finalize"


# ---- 修复之后 ----
def test_修复成功后回到校验():
    state = _state(repair_blocked=False)
    assert route_after_repair(state) == "validate"


def test_修复判定无法修复时收尾():
    state = _state(repair_blocked=True)
    assert route_after_repair(state) == "finalize"
