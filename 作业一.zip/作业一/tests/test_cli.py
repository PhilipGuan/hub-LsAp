"""CLI 测试。"""

from __future__ import annotations

import json

import pytest

from langgraph_sql_agent import cli


def test_缺少_key_时报错退出(monkeypatch, capsys):
    from langgraph_sql_agent.llm import MissingAPIKeyError

    def boom():
        raise MissingAPIKeyError("缺少 API key。请设置环境变量 SQL_AGENT_API_KEY")

    monkeypatch.setattr(cli, "require_api_key", boom)
    # main() 会解析 sys.argv —— 换成干净的参数，免得 pytest 的 -q 混进去。
    monkeypatch.setattr("sys.argv", ["langgraph-sql-agent", "总共有多少张专辑？"])
    with pytest.raises(SystemExit) as exc:
        cli.main()
    assert exc.value.code == 1
    assert "SQL_AGENT_API_KEY" in capsys.readouterr().err


def test_没有参数时从标准输入读问题(monkeypatch):
    seen: dict = {}

    def fake_read(args):
        seen["args"] = args
        return "从 stdin 读到的问"

    monkeypatch.setattr(cli, "_read_question", fake_read)
    assert cli._read_question(["a", "b"]) == "从 stdin 读到的问"


def test_有参数时拼成一个问题():
    assert cli._read_question(["总共有多少张", "专辑？"]) == "总共有多少张 专辑？"


def test_强制_utf8_不会在重定向时炸掉():
    """Windows 控制台默认 GBK，这个函数是唯一的防线。"""

    import sys

    cli._force_utf8()
    assert getattr(sys.stdout, "encoding", "").lower().replace("-", "") == "utf8"


class FakeGraph:
    """假的 LangGraph：每次 invoke 记录问题，返回一段固定的 output。"""

    def __init__(self):
        self.questions: list[str] = []
        self.configs: list[dict] = []

    def invoke(self, payload, config=None):
        from langgraph_sql_agent.models import ConversationTurn, WorkflowOutput

        self.questions.append(payload["question"])
        self.configs.append(config or {})
        return {
            "output": WorkflowOutput(
                question=payload["question"],
                answer=f"回答：{payload['question']}",
                sql="SELECT 1",
            ),
            "history": [
                ConversationTurn(role="user", question=payload["question"]),
                ConversationTurn(role="assistant", question=payload["question"], answer="回答"),
            ],
        }


def test_then_会在同一进程里连续跑多轮(monkeypatch):
    """--then 的全部价值在于「同一个 thread_id」，所以要断言 config 一致。"""

    from langgraph_sql_agent.session import SessionManager

    graph = FakeGraph()
    monkeypatch.setattr(cli, "build_graph", lambda **kwargs: graph)
    monkeypatch.setattr(cli, "get_session_manager", SessionManager)
    monkeypatch.setattr(cli, "require_api_key", lambda: "sk-fake")

    monkeypatch.setattr(
        "sys.argv",
        ["langgraph-sql-agent", "--session", "s1", "第一问", "--then", "第二问", "--then", "第三问"],
    )
    cli.main()

    assert graph.questions == ["第一问", "第二问", "第三问"]
    thread_ids = {config["configurable"]["thread_id"] for config in graph.configs}
    assert thread_ids == {"s1"}


def test_then_多轮时输出是一个数组(monkeypatch, capsys):
    from langgraph_sql_agent.session import SessionManager

    monkeypatch.setattr(cli, "build_graph", lambda **kwargs: FakeGraph())
    monkeypatch.setattr(cli, "get_session_manager", SessionManager)
    monkeypatch.setattr(cli, "require_api_key", lambda: "sk-fake")

    monkeypatch.setattr(
        "sys.argv", ["langgraph-sql-agent", "第一问", "--then", "第二问"]
    )
    cli.main()

    payload = json.loads(capsys.readouterr().out)
    assert isinstance(payload, list)
    assert len(payload) == 2
    assert payload[0]["session_id"] == payload[1]["session_id"]
    assert payload[0]["answer"] == "回答：第一问"
    assert payload[1]["answer"] == "回答：第二问"


def test_单轮时输出是一个对象(monkeypatch, capsys):
    from langgraph_sql_agent.session import SessionManager

    monkeypatch.setattr(cli, "build_graph", lambda **kwargs: FakeGraph())
    monkeypatch.setattr(cli, "get_session_manager", SessionManager)
    monkeypatch.setattr(cli, "require_api_key", lambda: "sk-fake")

    monkeypatch.setattr("sys.argv", ["langgraph-sql-agent", "只有一问"])
    cli.main()

    payload = json.loads(capsys.readouterr().out)
    assert isinstance(payload, dict)
    assert payload["question"] == "只有一问"
    assert len(payload["history"]) == 2


def test_有_then_时不会再去读标准输入(monkeypatch):
    """加 --then 却还等着读 stdin，会让人以为程序卡住了。"""

    from langgraph_sql_agent.session import SessionManager

    def boom(args):
        raise AssertionError("不该去读 stdin")

    monkeypatch.setattr(cli, "_read_question", boom)
    monkeypatch.setattr(cli, "build_graph", lambda **kwargs: FakeGraph())
    monkeypatch.setattr(cli, "get_session_manager", SessionManager)
    monkeypatch.setattr(cli, "require_api_key", lambda: "sk-fake")

    monkeypatch.setattr("sys.argv", ["langgraph-sql-agent", "--then", "第一问"])
    cli.main()  # 不抛异常即通过
