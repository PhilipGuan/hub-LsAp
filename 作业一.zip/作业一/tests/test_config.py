"""配置层测试。"""

from __future__ import annotations

from pathlib import Path

from langgraph_sql_agent.config import Settings, _parse_env_file


def test_默认模型配置():
    settings = Settings()
    assert settings.primary_model == "deepseek-v4-pro"
    assert settings.summary_model == "deepseek-flash"
    assert settings.thinking_mode == "disabled"
    assert settings.max_repair_attempts == 3
    assert settings.max_result_rows == 200


def test_数据库路径默认指向作业一自己的副本():
    settings = Settings()
    assert settings.db_path.name == "chinook.db"
    assert settings.db_path.parent.name == "data"


def test_env_解析器忽略注释和空行(tmp_path: Path):
    env_file = tmp_path / ".env"
    env_file.write_text(
        "# 注释\n\nKEY_A=值A\nKEY_B=\"值B\"\n非法行\n", encoding="utf-8"
    )
    values = _parse_env_file(env_file)
    assert values == {"KEY_A": "值A", "KEY_B": "值B"}


def test_env_解析器对不存在的文件返回空字典(tmp_path: Path):
    assert _parse_env_file(tmp_path / "不存在.env") == {}


def test_相对数据库路径会被解析成绝对路径(monkeypatch):
    monkeypatch.setenv("SQL_AGENT_DB", "data/chinook.db")
    settings = Settings.from_env()
    assert settings.db_path.is_absolute()
    assert settings.db_path.name == "chinook.db"
