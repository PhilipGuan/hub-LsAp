"""节点测试。全部 mock 掉 LLM 与 DB。"""

from __future__ import annotations

import pytest
from conftest import FakeChain, FakeFixer

from langgraph_sql_agent.db.catalog import SchemaCatalog
from langgraph_sql_agent.db.executor import SQLExecutor
from langgraph_sql_agent.db.validator import SQLValidator
from langgraph_sql_agent.graph.nodes import (
    GraphDeps,
    build_output,
    make_capture_question,
    make_execute,
    make_finalize,
    make_generate_sql,
    make_repair,
    make_select_tables,
    make_summarize,
    make_validate,
)
from langgraph_sql_agent.graph.state import GraphState
from langgraph_sql_agent.models import (
    ErrorCode,
    ExecutionResult,
    FinalAnswer,
    SQLDraft,
    TableSelection,
    ValidationResult,
)


@pytest.fixture
def deps(catalog: SchemaCatalog, db_path) -> GraphDeps:
    from langgraph_sql_agent.chains import StageChains

    return GraphDeps(
        catalog=catalog,
        validator=SQLValidator(db_path),
        executor=SQLExecutor(db_path),
        chains=StageChains(
            select=FakeChain([]), generate=FakeChain([]), summarize=FakeChain([])
        ),
        fixer=FakeFixer([]),
    )


# ---- capture_question ----
def test_记录问题会追加一条用户轮():
    node = make_capture_question()
    update = node(GraphState(question="总共有多少张专辑？"))
    assert update["stage"] == "capture_question"
    assert len(update["history"]) == 1
    assert update["history"][0].role == "user"
    assert update["history"][0].question == "总共有多少张专辑？"


# ---- select_tables ----
def test_选表正常时直接返回(deps):
    deps.chains.select = FakeChain([TableSelection(tables=["albums"], reason="r")])
    node = make_select_tables(deps)
    update = node(GraphState(question="q"))
    assert update["selection"].tables == ["albums"]
    assert update["stage"] == "select_tables"


def test_选表成功时会带上详细_schema(deps):
    """生成节点依赖 schema_context —— 选表节点必须把它填上。"""

    deps.chains.select = FakeChain([TableSelection(tables=["albums"], reason="r")])
    node = make_select_tables(deps)
    update = node(GraphState(question="q"))
    assert "### albums" in update["schema_context"]
    assert "AlbumId" in update["schema_context"]


def test_选表需要澄清时返回澄清标记(deps):
    deps.chains.select = FakeChain(
        [
            TableSelection(
                tables=[],
                reason="r",
                needs_clarification=True,
                clarification_question="你想查什么？",
            )
        ]
    )
    node = make_select_tables(deps)
    update = node(GraphState(question="q"))
    assert update["selection"].needs_clarification is True


def test_选表遇到不存在的表会重选一次(deps):
    deps.chains.select = FakeChain(
        [
            TableSelection(tables=["不存在的表"], reason="r"),
            TableSelection(tables=["albums"], reason="r"),
        ]
    )
    node = make_select_tables(deps)
    update = node(GraphState(question="q"))
    assert update["selection"].tables == ["albums"]
    assert len(deps.chains.select.calls) == 2
    assert "上一次选择的问题" in deps.chains.select.calls[1]["catalog"]


def test_选表两次都不合法时会转成澄清(deps):
    deps.chains.select = FakeChain(
        [TableSelection(tables=["不存在"], reason="r"), TableSelection(tables=["也不存在"], reason="r")]
    )
    node = make_select_tables(deps)
    update = node(GraphState(question="q"))
    assert update["selection"].needs_clarification is True
    assert "无法确定有效的查询表" in update["selection"].clarification_question


# ---- generate_sql ----
def test_生成会写入首条尝试记录(deps):
    deps.chains.generate = FakeChain([SQLDraft(sql="SELECT 1")])
    node = make_generate_sql(deps)
    update = node(GraphState(question="q", schema_context="### albums"))
    assert update["sql"] == "SELECT 1"
    assert update["attempts"][0].source == "generator"


def test_生成会把历史带进提示词(deps):
    from langgraph_sql_agent.models import ConversationTurn

    deps.chains.generate = FakeChain([SQLDraft(sql="SELECT 1")])
    node = make_generate_sql(deps)
    state = GraphState(
        question="那按年份呢？",
        schema_context="### albums",
        history=[ConversationTurn(role="user", question="按流派统计")],
    )
    node(state)
    assert "按流派统计" in deps.chains.generate.calls[0]["history"]


# ---- validate ----
def test_校验通过时采用规范化后的_sql(deps):
    node = make_validate(deps)
    update = node(GraphState(question="q", sql="SELECT COUNT(*) FROM albums;"))
    assert update["validation"].ok is True
    assert update["sql"] == "SELECT COUNT(*) FROM albums"


def test_校验拒绝写操作(deps):
    node = make_validate(deps)
    update = node(GraphState(question="q", sql="DELETE FROM albums"))
    assert update["validation"].ok is False
    assert update["validation"].code == ErrorCode.UNSAFE


# ---- execute ----
def test_执行成功时返回结果(deps):
    node = make_execute(deps)
    update = node(GraphState(question="q", sql="SELECT COUNT(*) AS n FROM albums"))
    assert update["execution"].row_count == 1
    assert update["execution"].rows == [["347"]]


def test_执行失败时把错误写回状态(deps):
    node = make_execute(deps)
    update = node(GraphState(question="q", sql="SELECT * FROM 不存在的表"))
    assert update["execution"] is None
    assert "no such table" in update["error"]


# ---- repair ----
def test_修复会累加修复次数(deps):
    deps.fixer = FakeFixer([SQLDraft(sql="SELECT 1 FROM albums")])
    node = make_repair(deps)
    state = GraphState(
        question="q",
        sql="SELECT bad",
        validation=ValidationResult(ok=False, code=ErrorCode.SYNTAX, message="语法错误"),
    )
    update = node(state)
    assert update["repair_attempts"] == 1
    assert update["sql"] == "SELECT 1 FROM albums"
    assert update["attempts"][0].source == "rewriter"


def test_修复判定无法修复时打上标记(deps):
    deps.fixer = FakeFixer(
        [SQLDraft(sql="", explanation="库里没有员工薪资表", cannot_fix=True)]
    )
    node = make_repair(deps)
    state = GraphState(
        question="q",
        sql="SELECT Salary FROM employees",
        validation=ValidationResult(ok=False, code=ErrorCode.UNKNOWN_OBJECT),
    )
    update = node(state)
    assert update["repair_blocked"] is True
    assert "薪资表" in update["error"]


# ---- summarize ----
def test_结果为空时不调模型(deps):
    deps.chains.summarize = FakeChain([])
    node = make_summarize(deps)
    state = GraphState(
        question="q",
        execution=ExecutionResult(columns=["n"], rows=[], row_count=0),
    )
    update = node(state)
    assert update["answer"].answer == "未查询到符合条件的数据。"
    assert deps.chains.summarize.calls == []


def test_汇总链失败时降级为表格(deps):
    class Boom:
        def invoke(self, payload):
            raise RuntimeError("模型挂了")

    deps.chains.summarize = Boom()
    node = make_summarize(deps)
    state = GraphState(
        question="q",
        sql="SELECT 1",
        execution=ExecutionResult(columns=["n"], rows=[["1"]], row_count=1),
    )
    update = node(state)
    assert "| n |" in update["answer"].answer
    assert update["answer"].caveats


# ---- finalize / build_output ----
def test_收尾会追加一条助手轮(deps):
    node = make_finalize(deps)
    state = GraphState(
        question="q",
        selection=TableSelection(tables=["albums"], reason="r"),
        sql="SELECT 1",
        answer=FinalAnswer(answer="共有 347 张专辑。"),
        execution=ExecutionResult(columns=["n"], rows=[["347"]], row_count=1),
    )
    update = node(state)
    assert update["output"].answer == "共有 347 张专辑。"
    assert update["history"][0].role == "assistant"
    assert update["history"][0].tables == ["albums"]


def test_需要澄清时输出澄清问题(deps):
    state = GraphState(
        question="q",
        selection=TableSelection(
            tables=[],
            reason="r",
            needs_clarification=True,
            clarification_question="你想查什么？",
        ),
    )
    output = build_output(state)
    assert output.answer == "你想查什么？"


def test_修复耗尽时输出提示(deps):
    from langgraph_sql_agent.config import settings

    state = GraphState(
        question="q",
        selection=TableSelection(tables=["albums"], reason="r"),
        repair_attempts=settings.max_repair_attempts,
        error="语法错误",
    )
    output = build_output(state)
    assert "最大修复次数" in output.answer
    assert output.error == "语法错误"


def test_修复判定无法回答时输出该说明(deps):
    state = GraphState(
        question="q",
        selection=TableSelection(tables=["albums"], reason="r"),
        repair_blocked=True,
        error="库里没有员工薪资表",
    )
    output = build_output(state)
    assert "员工薪资表" in output.answer
    assert output.error == "库里没有员工薪资表"
