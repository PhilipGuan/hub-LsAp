"""三条 LCEL 链的装配测试。

只测模板能正确渲染（不需要模型），以及 ``history`` 入参确实接上了。
"""

from __future__ import annotations

from langgraph_sql_agent.chains.result_summary import SUMMARY_PROMPT
from langgraph_sql_agent.chains.sql_generate import GENERATE_PROMPT
from langgraph_sql_agent.chains.table_select import SELECT_PROMPT


def _render(prompt, **kwargs) -> str:
    """把 prompt 渲染成纯文本，方便断言。"""

    return str(prompt.format(**kwargs))


def test_选表模板能同时渲染问题_目录_历史():
    text = _render(
        SELECT_PROMPT,
        question="总共有多少张专辑？",
        catalog="- albums（347 行）",
        history="【历史对话】\n",
    )
    assert "总共有多少张专辑？" in text
    assert "albums（347 行）" in text
    assert "【历史对话】" in text


def test_生成模板能同时渲染问题_schema_历史():
    text = _render(
        GENERATE_PROMPT,
        question="那按艺术家分组呢？",
        schema="### albums（347 行）",
        history="【历史对话】\n",
    )
    assert "那按艺术家分组呢？" in text
    assert "### albums（347 行）" in text
    assert "【历史对话】" in text


def test_汇总模板不需要历史():
    text = _render(
        SUMMARY_PROMPT,
        question="q",
        sql="SELECT 1",
        columns='["n"]',
        row_count="1",
        truncated="否",
        max_rows="50",
        rows="[[1]]",
    )
    assert "SELECT 1" in text
    assert "history" not in text
