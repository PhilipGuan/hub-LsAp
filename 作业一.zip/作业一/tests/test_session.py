"""会话管理测试。"""

from __future__ import annotations

from conftest import FakeChain, FakeFixer
from langgraph.checkpoint.memory import MemorySaver

from langgraph_sql_agent.graph.build import build_graph
from langgraph_sql_agent.session import SessionManager, get_session_manager


def _deps(catalog, db_path, *, select=None, generate=None, summarize=None):
    from langgraph_sql_agent.chains import StageChains
    from langgraph_sql_agent.db.executor import SQLExecutor
    from langgraph_sql_agent.db.validator import SQLValidator
    from langgraph_sql_agent.graph.nodes import GraphDeps

    return GraphDeps(
        catalog=catalog,
        validator=SQLValidator(db_path),
        executor=SQLExecutor(db_path),
        chains=StageChains(
            select=FakeChain(select or []),
            generate=FakeChain(generate or []),
            summarize=FakeChain(summarize or []),
        ),
        fixer=FakeFixer([]),
    )


def test_新会话_id_长度固定且互不相同():
    manager = SessionManager()
    first = manager.new_session_id()
    second = manager.new_session_id()
    assert len(first) == 12
    assert first != second


def test_配置里带_thread_id():
    manager = SessionManager()
    assert manager.config("abc") == {"configurable": {"thread_id": "abc"}}


def test_单例可复用():
    assert get_session_manager() is get_session_manager()


def test_未跑过的会话历史为空(catalog, db_path):
    deps = _deps(catalog, db_path)
    graph = build_graph(deps, checkpointer=MemorySaver())
    manager = SessionManager(MemorySaver())
    assert manager.history(graph, "从未用过") == []


def test_清空会话会真的把历史清掉(catalog, db_path):
    """``history`` 有 add reducer，update_state 清不掉 —— 必须 delete_thread。"""

    from langgraph_sql_agent.models import FinalAnswer, SQLDraft, TableSelection

    deps = _deps(
        catalog,
        db_path,
        select=[TableSelection(tables=["albums"], reason="r")],
        generate=[SQLDraft(sql="SELECT COUNT(*) AS n FROM albums")],
        summarize=[FinalAnswer(answer="a")],
    )
    manager = SessionManager()
    graph = build_graph(deps, checkpointer=manager.checkpointer)
    config = manager.config("s1")
    graph.invoke({"question": "第一问"}, config)

    assert len(manager.history(graph, "s1")) == 2
    manager.clear("s1")
    assert manager.history(graph, "s1") == []


def test_默认_checkpointer_带_msgpack_白名单():
    """不配白名单的话，反序列化 Pydantic 类型会告警且未来会被拦掉。"""

    from langgraph_sql_agent.session import CHECKPOINT_TYPES, build_checkpointer

    checkpointer = build_checkpointer()
    allowed = checkpointer.serde._allowed_msgpack_modules
    assert ("langgraph_sql_agent.models", "ConversationTurn") in allowed
    assert ("langgraph_sql_agent.models", "SQLAttempt") in allowed
    assert len(CHECKPOINT_TYPES) == 7


def test_白名单覆盖所有会进_checkpoint的类型():
    """GraphState 里出现的 Pydantic 类型必须都在白名单里。"""

    from langgraph_sql_agent import session
    from langgraph_sql_agent.graph.state import GraphState

    for field in GraphState.model_fields.values():
        annotation = field.annotation
        # Annotated[X, add] 已经被 Pydantic 拆过，这里只看类型名。
        name = getattr(annotation, "__name__", None)
        if name is None:
            args = getattr(annotation, "__args__", ())
            for arg in args:
                name = getattr(arg, "__name__", None)
                if name:
                    break
        if name and name.endswith(("Result", "Answer", "Selection", "Turn", "Attempt", "Output")):
            assert name in session.CHECKPOINT_TYPES, f"{name} 没登记进 msgpack 白名单"
