"""LLM 工厂与 DeepSeek 适配测试。"""

from __future__ import annotations

import dataclasses

import pytest
from langchain_core.runnables import RunnableLambda

from langgraph_sql_agent import llm
from langgraph_sql_agent.config import settings
from langgraph_sql_agent.models import SQLDraft


@pytest.fixture(autouse=True)
def _清理缓存():
    llm.build_chat_model.cache_clear()
    llm.build_structured_chain.cache_clear()
    yield
    llm.build_chat_model.cache_clear()
    llm.build_structured_chain.cache_clear()


def test_缺少_key_时抛出明确异常(monkeypatch):
    # settings 是冻结 dataclass，不能直接改属性；换成一份副本。
    monkeypatch.setattr(llm, "settings", dataclasses.replace(settings, api_key=""))
    with pytest.raises(llm.MissingAPIKeyError) as exc:
        llm.require_api_key()
    assert "SQL_AGENT_API_KEY" in str(exc.value)


def test_结构化链强制使用_function_calling(monkeypatch):
    """DeepSeek 拒绝 json_schema，必须走 function_calling。"""

    captured: dict = {}

    class FakeChat:
        def __init__(self, **kwargs):
            captured.update(kwargs)

        def with_structured_output(self, schema, **kwargs):
            captured["structured_kwargs"] = kwargs
            return RunnableLambda(lambda _: None)

    monkeypatch.setattr(llm, "build_chat_model", lambda *a, **k: FakeChat())
    llm.build_structured_chain(SQLDraft, "deepseek-v4-pro", 0.0)
    assert captured["structured_kwargs"]["method"] == "function_calling"


def test_模型请求体关掉思考模式(monkeypatch):
    """思考模式拒绝强制 tool_choice，结构化输出会直接 400。"""

    captured: dict = {}

    def fake_chat_openai(**kwargs):
        captured.update(kwargs)
        return object()

    monkeypatch.setattr(
        llm, "settings", dataclasses.replace(settings, api_key="sk-test")
    )
    monkeypatch.setattr(llm, "ChatOpenAI", fake_chat_openai)
    llm.build_chat_model.cache_clear()
    llm.build_chat_model("deepseek-v4-pro")
    assert captured["extra_body"] == {"thinking": {"type": "disabled"}}


def test_模型配置快照不含_key():
    snapshot = llm.describe_model()
    assert snapshot["primary_model"] == settings.primary_model
    assert snapshot["structured_output_method"] == "function_calling"
    assert "api_key" not in snapshot
