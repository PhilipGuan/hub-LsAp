"""端到端图测试。LLM 全 mock。"""

from __future__ import annotations

import pytest
from conftest import FakeChain, FakeFixer

from langgraph_sql_agent.chains import StageChains
from langgraph_sql_agent.db.catalog import SchemaCatalog
from langgraph_sql_agent.db.executor import SQLExecutor
from langgraph_sql_agent.db.validator import SQLValidator
from langgraph_sql_agent.graph.build import build_graph
from langgraph_sql_agent.graph.nodes import GraphDeps
from langgraph_sql_agent.models import (
    FinalAnswer,
    SQLDraft,
    TableSelection,
)
from langgraph_sql_agent.session import build_checkpointer


def _deps(catalog, db_path, *, select=None, generate=None, summarize=None, fixer=None):
    return GraphDeps(
        catalog=catalog,
        validator=SQLValidator(db_path),
        executor=SQLExecutor(db_path),
        chains=StageChains(
            select=FakeChain(select or []),
            generate=FakeChain(generate or []),
            summarize=FakeChain(summarize or []),
        ),
        fixer=fixer if fixer is not None else FakeFixer([]),
    )


@pytest.fixture
def happy_graph(catalog: SchemaCatalog, db_path):
    """带 checkpointer 的正常流程图 —— 两轮都能跑。

    用 ``build_checkpointer()`` 而不是裸 ``MemorySaver()``：
    裸的没有 msgpack 白名单，反序列化 Pydantic 类型时会刷警告。
    """

    deps = _deps(
        catalog,
        db_path,
        select=[
            TableSelection(tables=["albums"], reason="r"),
            TableSelection(tables=["albums"], reason="r"),
        ],
        generate=[
            SQLDraft(sql="SELECT COUNT(*) AS TotalAlbums FROM albums"),
            SQLDraft(sql="SELECT COUNT(*) AS TotalAlbums FROM albums"),
        ],
        summarize=[
            FinalAnswer(answer="共有 347 张专辑。", evidence=["TotalAlbums = 347"]),
            FinalAnswer(answer="共有 347 张专辑。", evidence=["TotalAlbums = 347"]),
        ],
    )
    return build_graph(deps, checkpointer=build_checkpointer())


def test_正常流程一次命中(happy_graph):
    # 带 checkpointer 的图每次 invoke 都必须给 thread_id。
    result = happy_graph.invoke(
        {"question": "总共有多少张专辑？"},
        {"configurable": {"thread_id": "t-once"}},
    )
    output = result["output"]
    assert output.answer == "共有 347 张专辑。"
    assert output.tables == ["albums"]
    assert output.row_count == 1
    assert output.repair_attempts == 0
    assert output.error is None


def test_正常流程会记录历史两轮(happy_graph):
    config = {"configurable": {"thread_id": "t-history"}}
    happy_graph.invoke({"question": "总共有多少张专辑？"}, config)
    result = happy_graph.invoke({"question": "那按流派分组呢？"}, config)
    history = result["history"]
    assert len(history) == 4
    assert [turn.role for turn in history] == ["user", "assistant", "user", "assistant"]


def test_历史会累积到下一轮的提示词(catalog, db_path):
    deps = _deps(
        catalog,
        db_path,
        select=[
            TableSelection(tables=["albums"], reason="r"),
            TableSelection(tables=["albums"], reason="r"),
        ],
        generate=[
            SQLDraft(sql="SELECT COUNT(*) AS n FROM albums"),
            SQLDraft(sql="SELECT AlbumId, COUNT(*) AS n FROM albums GROUP BY AlbumId"),
        ],
        summarize=[
            FinalAnswer(answer="a"),
            FinalAnswer(answer="b"),
        ],
    )
    graph = build_graph(deps, checkpointer=build_checkpointer())
    config = {"configurable": {"thread_id": "t1"}}
    graph.invoke({"question": "总共有多少张专辑？"}, config)
    graph.invoke({"question": "那按流派分组呢？"}, config)
    second_call = deps.chains.select.calls[1]
    assert "总共有多少张专辑？" in second_call["history"]


def test_校验失败会走修复回边(catalog, db_path):
    deps = _deps(
        catalog,
        db_path,
        select=[TableSelection(tables=["albums"], reason="r")],
        summarize=[FinalAnswer(answer="好了")],
        fixer=FakeFixer([SQLDraft(sql="SELECT COUNT(*) AS n FROM albums")]),
    )
    # 让第一次校验失败：用一个语法错误的 SQL，修复 Agent 给出正确 SQL
    deps.chains.generate = FakeChain([SQLDraft(sql="SELECT COUNT(*) AS FROM albums")])
    graph = build_graph(deps)
    result = graph.invoke({"question": "q"})
    assert result["repair_attempts"] == 1
    assert result["output"].answer == "好了"


def test_修复预算耗尽会收尾(catalog, db_path):
    from langgraph_sql_agent.config import settings

    deps = _deps(
        catalog,
        db_path,
        select=[TableSelection(tables=["albums"], reason="r")],
        generate=[SQLDraft(sql="SELECT COUNT(*) AS FROM albums")],
        summarize=[],
        fixer=FakeFixer(
            [SQLDraft(sql="SELECT bad sql") for _ in range(settings.max_repair_attempts + 1)]
        ),
    )
    graph = build_graph(deps)
    result = graph.invoke({"question": "q"})
    assert result["repair_attempts"] == settings.max_repair_attempts
    assert result["output"].error is not None
    assert "最大修复次数" in result["output"].answer


def test_需要澄清时直接收尾(catalog, db_path):
    deps = _deps(
        catalog,
        db_path,
        select=[
            TableSelection(
                tables=[],
                reason="r",
                needs_clarification=True,
                clarification_question="你想查什么？",
            )
        ],
    )
    graph = build_graph(deps)
    result = graph.invoke({"question": "今天天气怎么样"})
    assert result["output"].answer == "你想查什么？"
    assert result["output"].error is None


def test_空结果不调汇总链(catalog, db_path):
    deps = _deps(
        catalog,
        db_path,
        select=[TableSelection(tables=["albums"], reason="r")],
        generate=[SQLDraft(sql="SELECT 1 AS n FROM albums WHERE 1 = 0")],
        summarize=[],
    )
    graph = build_graph(deps)
    result = graph.invoke({"question": "q"})
    assert result["output"].answer == "未查询到符合条件的数据。"
    assert deps.chains.summarize.calls == []


def test_图能逐节点流式产出(catalog, db_path):
    deps = _deps(
        catalog,
        db_path,
        select=[TableSelection(tables=["albums"], reason="r")],
        generate=[SQLDraft(sql="SELECT COUNT(*) AS n FROM albums")],
        summarize=[FinalAnswer(answer="a")],
    )
    graph = build_graph(deps)
    nodes = []
    for chunk in graph.stream({"question": "q"}, stream_mode="updates"):
        nodes.extend(chunk.keys())
    assert nodes[0] == "capture_question"
    assert "select_tables" in nodes
    assert "generate_sql" in nodes
    assert "validate" in nodes
    assert "execute" in nodes
    assert "summarize" in nodes
    assert nodes[-1] == "finalize"
