"""提示词与历史渲染测试。"""

from __future__ import annotations

from langgraph_sql_agent.models import ConversationTurn
from langgraph_sql_agent.prompts import (
    MAX_HISTORY_TURNS,
    TABLE_SELECT_HUMAN,
    render_history,
)


def test_没有历史时渲染为空字符串():
    assert render_history([]) == ""


def test_历史渲染包含问答与表():
    turns = [
        ConversationTurn(role="user", question="总共有多少张专辑？"),
        ConversationTurn(
            role="assistant",
            question="总共有多少张专辑？",
            answer="共有 347 张专辑。",
            tables=["albums"],
            sql="SELECT COUNT(*) FROM albums",
        ),
    ]
    text = render_history(turns)
    assert "总共有多少张专辑？" in text
    assert "共有 347 张专辑。" in text
    assert "albums" in text
    assert "SELECT COUNT(*) FROM albums" in text


def test_历史只保留最近若干轮():
    turns = [
        ConversationTurn(role="user", question=f"问题{i}") for i in range(MAX_HISTORY_TURNS + 3)
    ]
    text = render_history(turns)
    assert f"问题{MAX_HISTORY_TURNS + 2}" in text
    assert "问题0" not in text


def test_历史里的答案会被截断():
    turns = [
        ConversationTurn(role="assistant", question="q", answer="啊" * 5000),
    ]
    text = render_history(turns)
    assert "..." in text
    assert len(text) < 1000


def test_选表模板包含_history_占位符():
    assert "{history}" in TABLE_SELECT_HUMAN
    assert "{question}" in TABLE_SELECT_HUMAN
    assert "{catalog}" in TABLE_SELECT_HUMAN
