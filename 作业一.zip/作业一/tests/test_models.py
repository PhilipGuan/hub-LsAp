"""数据契约测试。"""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from langgraph_sql_agent.models import (
    ConversationTurn,
    ErrorCode,
    SQLDraft,
    TableSelection,
    WorkflowOutput,
)


def test_选表结果校验置信度范围():
    with pytest.raises(ValidationError):
        TableSelection(tables=["albums"], reason="r", confidence=1.5)


def test_修复草稿默认不标记无法修复():
    draft = SQLDraft(sql="SELECT 1")
    assert draft.cannot_fix is False
    assert draft.assumptions == []


def test_错误码是字符串枚举():
    assert ErrorCode.UNSAFE.value == "unsafe"
    assert ErrorCode.UNKNOWN_OBJECT == "unknown_object"


def test_对话轮次默认是用户轮():
    turn = ConversationTurn(question="总共有多少张专辑？")
    assert turn.role == "user"
    assert turn.answer == ""
    assert turn.tables == []


def test_助手轮次记录答案与表():
    turn = ConversationTurn(
        role="assistant",
        question="总共有多少张专辑？",
        answer="共有 347 张专辑。",
        tables=["albums"],
        sql="SELECT COUNT(*) FROM albums",
    )
    assert turn.role == "assistant"
    assert turn.tables == ["albums"]


def test_最终输出可序列化():
    output = WorkflowOutput(question="q", answer="a")
    payload = output.model_dump()
    assert payload["question"] == "q"
    assert payload["error"] is None
