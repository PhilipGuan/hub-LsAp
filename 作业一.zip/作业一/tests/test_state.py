"""状态定义与 reducer 测试。"""

from __future__ import annotations

from langgraph_sql_agent.graph.state import GraphState
from langgraph_sql_agent.models import ConversationTurn, SQLAttempt


def test_初始状态的必填字段只有问题():
    state = GraphState(question="总共有多少张专辑？")
    assert state.question == "总共有多少张专辑？"
    assert state.history == []
    assert state.attempts == []
    assert state.repair_attempts == 0
    assert state.stage == "init"
    assert state.output is None


def test_历史与尝试记录声明了追加语义():
    """Annotated[list, add] 是 LangGraph 跨节点/跨轮累积的关键。

    Pydantic 会把 ``Annotated`` 的第二个参数挪到 ``FieldInfo.metadata``，
    ``annotation`` 里只剩裸的 list，所以两处都要看。
    """

    import operator

    for name in ("history", "attempts"):
        assert "Annotated" in str(GraphState.__annotations__[name])
        assert operator.add in GraphState.model_fields[name].metadata


def test_状态可序列化():
    state = GraphState(
        question="q",
        history=[ConversationTurn(role="user", question="q")],
        attempts=[SQLAttempt(sql="SELECT 1", source="generator")],
    )
    payload = state.model_dump()
    assert payload["history"][0]["question"] == "q"
    assert payload["attempts"][0]["source"] == "generator"
