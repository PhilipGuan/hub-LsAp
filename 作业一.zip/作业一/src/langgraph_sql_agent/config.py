"""运行配置。

设计约定（与仓库既有做法一致）：

- **API key 只从环境变量 / 同目录 .env 读取**，代码里不出现任何真实密钥。
- 解析顺序：环境变量 > ``<项目根>/.env`` > 跨作业便利回退（见 ``_FALLBACK_ENV_FILES``）。
- 所有字段都可以用环境变量覆盖，便于同一份代码跑不同模型服务。
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

# src/langgraph_sql_agent/config.py -> parents[2] 即「作业一」目录
PROJECT_ROOT = Path(__file__).resolve().parents[2]

#: 便利回退的 .env 列表（按顺序取第一个能提供 key 的文件）。
#: 第一项是本作业自己的 .env；第二项是同期的「作业二」.env，方便本机直接跑通。
_FALLBACK_ENV_FILES = (
    PROJECT_ROOT / ".env",
    PROJECT_ROOT.parent / "作业二" / ".env",
)


def _parse_env_file(path: Path) -> dict[str, str]:
    """极简 .env 解析器：只认 KEY=VALUE，忽略注释和空行，不处理引号转义。"""

    values: dict[str, str] = {}
    if not path.is_file():
        return values
    try:
        raw = path.read_text(encoding="utf-8")
    except OSError:
        return values
    for line in raw.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        values[key.strip()] = value.strip().strip('"').strip("'")
    return values


def _load_env_files() -> dict[str, str]:
    """合并所有可读 .env；靠前的文件优先。"""

    merged: dict[str, str] = {}
    for path in reversed(_FALLBACK_ENV_FILES):
        merged.update(_parse_env_file(path))
    return merged


_FILE_ENV = _load_env_files()


def _env_str(name: str, default: str = "", *also: str) -> str:
    """读环境变量，兼容多个变量名；都没有时读 .env 文件。"""

    names = (name, *also)
    for key in names:
        value = os.getenv(key)
        if value:
            return value
    for key in names:
        if key in _FILE_ENV:
            return _FILE_ENV[key]
    return default


def _env_int(name: str, default: int) -> int:
    try:
        return int(_env_str(name, str(default)))
    except ValueError:
        return default


def _env_float(name: str, default: float) -> float:
    try:
        return float(_env_str(name, str(default)))
    except ValueError:
        return default


def _env_bool(name: str, default: bool) -> bool:
    raw = _env_str(name, "1" if default else "0").strip().lower()
    return raw in {"1", "true", "yes", "on"}


@dataclass(frozen=True)
class Settings:
    """一次运行所需的全部可调参数。"""

    # --- 模型服务 ---
    api_key: str = ""
    base_url: str = "https://api.deepseek.com/v1"
    primary_model: str = "deepseek-v4-pro"
    summary_model: str = "deepseek-flash"
    #: DeepSeek 的思考模式。工具调用强制 tool_choice 时必须关闭，否则服务端报
    #: "Thinking mode does not support this tool_choice"。
    thinking_mode: str = "disabled"
    request_timeout_seconds: float = 90.0
    max_retries: int = 1

    # --- 数据库 ---
    db_path: Path = PROJECT_ROOT / "data" / "chinook.db"

    # --- 运行控制 ---
    max_repair_attempts: int = 3
    max_result_rows: int = 200
    max_summary_rows: int = 50
    max_cell_chars: int = 2000
    query_timeout_seconds: float = 5.0
    #: 修复 Agent 内部的工具自检轮数上限（LangChain 的 create_agent 参数）。
    max_fix_iterations: int = 6

    @classmethod
    def from_env(cls) -> Settings:
        db_path = Path(_env_str("SQL_AGENT_DB", str(cls.db_path)))
        if not db_path.is_absolute():
            db_path = PROJECT_ROOT / db_path

        api_key = _env_str(
            "SQL_AGENT_API_KEY", "", "OPENAI_API_KEY", "DEEPSEEK_API_KEY", "LLM_API_KEY"
        )

        return cls(
            api_key=api_key,
            base_url=_env_str(
                "SQL_AGENT_BASE_URL",
                cls.base_url,
                "OPENAI_BASE_URL",
                "DEEPSEEK_BASE_URL",
                "LLM_BASE_URL",
            ).rstrip("/"),
            primary_model=_env_str("SQL_AGENT_MODEL", cls.primary_model),
            summary_model=_env_str(
                "SQL_AGENT_SUMMARY_MODEL", cls.summary_model
            ),
            thinking_mode=_env_str(
                "SQL_AGENT_THINKING", cls.thinking_mode
            ).strip().lower(),
            request_timeout_seconds=_env_float(
                "SQL_AGENT_REQUEST_TIMEOUT", cls.request_timeout_seconds
            ),
            max_retries=_env_int("SQL_AGENT_MAX_RETRIES", cls.max_retries),
            db_path=db_path,
            max_repair_attempts=_env_int(
                "SQL_AGENT_MAX_REPAIR_ATTEMPTS", cls.max_repair_attempts
            ),
            max_result_rows=_env_int("SQL_AGENT_MAX_ROWS", cls.max_result_rows),
            max_summary_rows=_env_int(
                "SQL_AGENT_MAX_SUMMARY_ROWS", cls.max_summary_rows
            ),
            max_cell_chars=_env_int(
                "SQL_AGENT_MAX_CELL_CHARS", cls.max_cell_chars
            ),
            query_timeout_seconds=_env_float(
                "SQL_AGENT_QUERY_TIMEOUT", cls.query_timeout_seconds
            ),
            max_fix_iterations=_env_int(
                "SQL_AGENT_MAX_FIX_ITERATIONS", cls.max_fix_iterations
            ),
        )


settings = Settings.from_env()
