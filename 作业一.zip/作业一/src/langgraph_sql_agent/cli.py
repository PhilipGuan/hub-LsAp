"""命令行入口：``python -m langgraph_sql_agent "查询问题"``。

日志走 stderr，最终 JSON 走 stdout，方便管道处理。

**关于多轮会话**（这里有个容易误解的地方）：

checkpointer 用的是 ``MemorySaver`` —— 状态只存在**当前进程内存**里。
所以「跨进程续接会话」是做不到的：两次独立的命令行调用各是一个新进程，
``--session abc`` 找不到 ``abc`` 的历史。

想在命令行里演示多轮，用 ``--then`` 在**同一次调用**里追加追问::

    python -m langgraph_sql_agent --session s1 "总共有多少张专辑？" \\
        --then "那每个艺术家各有多少张专辑？"

两轮在同一个进程、同一个 thread_id 里跑，第二轮能看到第一轮的问答。
真正的「跨请求续接会话」在作业二的 Web 服务里演示 —— 那是一个常驻进程。

输出：只有一个问题时打印一个 JSON 对象；带 ``--then`` 时打印一个 JSON 数组
（按轮次顺序）。
"""

from __future__ import annotations

import argparse
import json
import os
import sys

from .config import settings
from .graph.build import RECURSION_LIMIT, build_graph
from .llm import MissingAPIKeyError, require_api_key
from .logging_config import configure_logging
from .session import get_session_manager


def _read_question(args: list[str]) -> str:
    if args:
        return " ".join(args)
    if sys.stdin.isatty():
        print("请输入查询问题：", file=sys.stderr, end="", flush=True)
        return input()
    return sys.stdin.read().rstrip("\r\n")


def _force_utf8() -> None:
    """Windows 控制台默认是 GBK，答案里出现「ý」这类字符会直接抛 UnicodeEncodeError。

    统一把 stdout / stderr 切到 UTF-8；``errors="replace"`` 保证极端情况下
    也不至于让整个查询崩在打印这一步。
    """

    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is not None:
            try:
                reconfigure(encoding="utf-8", errors="replace")
            except (ValueError, OSError):  # 已被重定向到非文本流等情况
                pass


def _run_turns(questions: list[str], session_id: str, graph=None) -> list[dict]:
    """在同一个会话里连续跑几轮，返回每轮的结果字典。"""

    manager = get_session_manager()
    if graph is None:
        graph = build_graph(checkpointer=manager.checkpointer)
    # recursion_limit 放在 config 里（LangGraph 1.x 的写法），不能当第三个位置参数传。
    config = {**manager.config(session_id), "recursion_limit": RECURSION_LIMIT}

    payloads: list[dict] = []
    for question in questions:
        result = graph.invoke({"question": question}, config)
        output = result["output"]
        payload = output.model_dump()
        payload["session_id"] = session_id
        payload["history"] = [turn.model_dump() for turn in result.get("history", [])]
        payloads.append(payload)
    return payloads


def main() -> None:
    _force_utf8()
    parser = argparse.ArgumentParser(description="Chinook 数据库 SQL Agent（LangGraph 版）")
    parser.add_argument("text", nargs="*", help="自然语言查询问题")
    parser.add_argument(
        "--then",
        action="append",
        default=[],
        metavar="问题",
        help="在同一会话里追加一轮追问；可以重复多次",
    )
    parser.add_argument(
        "--session",
        default=None,
        help="会话 id；同一进程内的多轮共用同一个 thread_id",
    )
    parser.add_argument(
        "--log-level",
        default=os.getenv("SQL_AGENT_LOG_LEVEL", "INFO"),
        type=str.upper,
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        help="日志级别，默认读取 SQL_AGENT_LOG_LEVEL 或 INFO",
    )
    args = parser.parse_args()
    configure_logging(args.log_level)

    try:
        require_api_key()
    except MissingAPIKeyError as exc:
        print(
            f"{exc}\n"
            "  export SQL_AGENT_API_KEY=sk-...\n"
            f"  export SQL_AGENT_BASE_URL={settings.base_url}  # 可选",
            file=sys.stderr,
        )
        raise SystemExit(1) from exc

    questions: list[str] = []
    # 只有在「既没有位置参数、又没给 --then」时才去读 stdin ——
    # 否则加了 --then 却还等着读一行输入，会让人以为程序卡住了。
    if args.text or not args.then:
        questions.append(_read_question(args.text))
    questions.extend(args.then)
    manager = get_session_manager()
    session_id = args.session or manager.new_session_id()
    payloads = _run_turns(questions, session_id)

    if len(payloads) == 1:
        print(json.dumps(payloads[0], ensure_ascii=False, indent=2))
    else:
        print(json.dumps(payloads, ensure_ascii=False, indent=2))

    if any(payload["error"] for payload in payloads):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
