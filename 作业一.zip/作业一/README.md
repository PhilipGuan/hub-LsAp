# 作业一：用 LangGraph 复现 SQL Agent

第十三周作业一的实现：**把 `12-江洋明-第十二周作业/作业二`（LangChain 版）的 SQL Agent，
用 LangGraph 重写一遍**。

同一条流水线、同一套数据契约、同一套安全边界，换一套**编排**表达。
两版可以直接对着看 —— 这是这个作业的重点。

**这一版新增的东西**：显式状态图 + 条件边 + 跨轮会话记忆。
前两项是把「手写状态机」变成「一张图」，第三项是 LangGraph 带来的、
上一版没有的能力。

---

## 1. 一句话说明两版的差别

| | Week12 作业二（LangChain 版） | Week13 作业一（本目录） |
| --- | --- | --- |
| 编排 | 手写 Python 状态机 | **LangGraph 状态图**（`StateGraph`） |
| 阶段边界 | 函数调用栈 | 图节点（8 个） |
| 分支 | `if` / `for` | **条件边 + 路由函数**（4 个纯函数） |
| 修复回边 | `for repair_index in range(...)` | **回边 + 预算计数**（`repair_attempts`） |
| 终止条件 | 散落在多个 `return` | **集中到路由函数** |
| 会话记忆 | 无 | **checkpointer + `add` reducer 跨轮累积** |
| 过程可观测 | 只能看日志 | **`graph.stream()` 逐节点产出** |
| LLM 阶段 | LCEL 链 | **同一套 LCEL 链** |
| 确定性层 | `db/` + `tools/` | **逐字相同** |

最后两行才是这次复刻真正的价值所在：

- **LLM 阶段和确定性层一字未改** —— 说明换框架动的是「骨架」，不是「内脏」。
  安全边界、只读连接、校验规则、提示词全部可以对着上一版逐行检查。
- **编排层从「一坨代码」变成「一张图」** —— 手写状态机里，
  「下一步去哪」散落在 `if` 分支和 `return` 语句中；状态图里，
  4 个路由函数把全部判定收在一处，每一条边都在图上看得见。

### 一个具体的对比

上一版（LangChain）的编排长这样（简化）：

```python
for repair_index in range(settings.max_repair_attempts):
    validation = self.validator.validate(sql)
    if validation.ok:
        break
    draft = self.fixer.invoke(prompt)
    sql = draft.sql
else:
    return WorkflowOutput(answer="达到最大修复次数")
```

本版（LangGraph）把同一件事拆成节点和边：

```python
graph.add_conditional_edges(
    "validate",
    route_after_validate,                      # 纯函数：判定去 execute / repair / finalize
    {"execute": "execute", "repair": "repair", "finalize": "finalize"},
)
```

差别不只是写法。**上一版的「修复几次」是一个 `for` 循环变量，
读代码要一路顺着函数往下看才知道跑到第几次；
本版的「修复几次」是状态里的一个字段 `repair_attempts`，
任何时刻 `graph.get_state(config)` 都能读出来** —— 这是 Web 前端
（作业二）能把「已修复 N 次」实时显示出来的前提。

---

## 2. 快速开始

### 2.1 安装

```bash
cd "13-江洋明-第十三周作业/作业一"
pip install -r requirements.txt
```

Python ≥ 3.10。已在 Python 3.13 + `langgraph 1.2.9` / `langchain 1.3.x` /
`langchain-openai 1.4.x` 上验证。

### 2.2 配置

```bash
copy .env.example .env      # Windows
# cp .env.example .env     # macOS / Linux
```

然后在 `.env` 里填 DeepSeek 的 API key。**代码里不硬编码任何密钥**，
读取顺序是：环境变量 → 本目录 `.env` → 同期的 `../作业二/.env`（开发便利回退）。

也可以完全用环境变量：

```bash
export SQL_AGENT_API_KEY=sk-...
export SQL_AGENT_BASE_URL=https://api.deepseek.com/v1
```

### 2.3 运行

**一键脚本**（会自动检查 `.env`、装依赖、起交互式提问）：

```bash
# Windows：双击 run.bat，或者在 cmd 里敲
run.bat
run.bat "总共有多少张专辑？"
run.bat "第一个问题" --then "追问"

# Git Bash / Linux / macOS
./run.sh
./run.sh "总共有多少张专辑？"
./run.sh "第一个问题" --then "追问"
```

**等价的原始命令**：

```bash
# Git Bash / Linux
PYTHONPATH=src python -m langgraph_sql_agent "总共有多少张专辑？"

# cmd
set PYTHONPATH=src && python -m langgraph_sql_agent "总共有多少张专辑？"

# 或者装成命令行工具
pip install -e .
langgraph-sql-agent "每个流派的歌曲数量 Top5"
```

> Windows 上 `pip install -e .` 会把 `langgraph-sql-agent.exe` 装到
> `%APPDATA%\Python\Python313\Scripts`，该目录**可能不在 PATH 上**。
> 报「找不到命令」时，把这个目录加进 PATH，或者直接用上面的
> `PYTHONPATH=src python -m langgraph_sql_agent` 形式（推荐，跨平台一致）。

输出是结构化 JSON（stdout），日志走 stderr，方便管道处理：

```json
{
  "question": "总共有多少张专辑？",
  "answer": "总共有 347 张专辑。",
  "sql": "SELECT COUNT(*) AS TotalAlbums FROM albums",
  "tables": ["albums"],
  "row_count": 1,
  "truncated": false,
  "repair_attempts": 0,
  "evidence": ["TotalAlbums = 347"],
  "caveats": [],
  "error": null,
  "session_id": "3f2a9c1e7b04",
  "history": [
    {"role": "user", "question": "总共有多少张专辑？"},
    {"role": "assistant", "question": "总共有多少张专辑？", "answer": "总共有 347 张专辑。",
     "tables": ["albums"], "sql": "SELECT COUNT(*) AS TotalAlbums FROM albums"}
  ]
}
```

日志级别用 `--log-level DEBUG` 或 `SQL_AGENT_LOG_LEVEL` 调：

```text
stage=catalog_ready tables=11 elapsed=0.23s
graph compiled recursion_limit=25
stage=capture_question question=总共有多少张专辑？
stage=table_select attempt=1 tables=['albums'] confidence=1.00 needs_clarification=False elapsed=2.52s reason=统计专辑总数只需查询 albums 表，通过 COUNT(*) 即可得到专辑数量。
stage=sql_generate elapsed=1.72s sql=SELECT COUNT(*) AS TotalAlbums FROM albums;
stage=validate ok=True code=None elapsed=0.004s message=
stage=execute ok=true rows=1 truncated=False elapsed=0.002s
stage=summarize_finished elapsed=1.12s evidence=1 caveats=0
stage=final answer=总共有 347 张专辑。 evidence=1 caveats=0
```

> 注意 `sql_generate` 那行末尾有个分号（模型原样输出的），
> 但最终 JSON 里的 `sql` 没有 —— `validate` 节点会把规范化后的 SQL 写回状态
> （去尾分号、去 Markdown 围栏）。执行的一定是规范化之后的那一条。

### 2.4 测试

```bash
pytest -q          # 81 个用例，LLM 调用全部 mock，不需要 API key
ruff check src tests
```

---

## 3. 图结构

```mermaid
flowchart TD
    START([START]) --> C[capture_question]
    C --> S[select_tables]
    S -->|generate_sql| G[generate_sql]
    S -->|finalize（需澄清/无表）| F[finalize]
    G --> V[validate]
    V -->|execute（校验通过）| E[execute]
    V -->|repair（校验失败）| R[repair]
    V -->|finalize（预算耗尽）| F
    E -->|summarize（执行成功）| M[summarize]
    E -->|repair（执行失败）| R
    E -->|finalize（预算耗尽）| F
    R -->|validate（改好了）| V
    R -->|finalize（判定修不了）| F
    M --> F
    F --> END([END])

    subgraph 确定性层
        C
        V
        E
        F
    end
    subgraph LLM 层
        S
        G
        R
        M
    end
```

### 8 个节点的职责

| 节点 | 类型 | 职责 | 读状态 | 写状态 |
| --- | --- | --- | --- | --- |
| `capture_question` | 确定性 | 把本轮问题记进历史 | `question` | `history`, `stage` |
| `select_tables` | LLM | 选最少表集合（内部带一次重选） | `question`, `history` | `selection`, `schema_context` |
| `generate_sql` | LLM | 生成一条 SQLite SELECT | `question`, `schema_context`, `history` | `sql`, `attempts` |
| `validate` | 确定性 | 安全门禁 + `EXPLAIN` 编译（**只编译，绝不执行**） | `sql` | `validation`, `sql`, `error` |
| `execute` | 确定性 | 只读连接上执行 | `sql` | `execution`, `error` |
| `repair` | LLM | 按错误改写 SQL（嵌套 ReAct 子图） | `sql`, `validation`, `attempts` | `sql`, `repair_attempts`, `repair_blocked`, `attempts` |
| `summarize` | LLM | 结果转自然语言 | `execution` | `answer` |
| `finalize` | 确定性 | 组装输出 + 记录助手轮 | 全部 | `output`, `history` |

### 4 个路由函数的分支

| 路由函数 | 挂在哪个节点后 | 判定顺序 | 返回 |
| --- | --- | --- | --- |
| `route_after_select` | `select_tables` | ① 没选到表 / 要澄清 → ② 正常 | `finalize` / `generate_sql` |
| `route_after_validate` | `validate` | ① 校验通过 → ② 预算耗尽 → ③ 去修 | `execute` / `finalize` / `repair` |
| `route_after_execute` | `execute` | ① 执行成功 → ② 预算耗尽 → ③ 去修 | `summarize` / `finalize` / `repair` |
| `route_after_repair` | `repair` | ① 判定修不了 → ② 回校验 | `finalize` / `validate` |

四个路由函数都是**纯函数**：输入 `GraphState`，输出下一个节点名。
把它们从节点里抽出来单独测，是这次从「手写状态机」升级到「显式图」的主要收益之一
（`tests/test_routing.py` 逐个分支覆盖）。

---

## 4. 多轮会话怎么工作

这一节是本版相对上一版**唯一的新能力**。

### 机制

1. **checkpointer**：`MemorySaver` 挂在编译后的图上，状态按 `thread_id` 存。
   同一个 `thread_id` 的多次 `invoke` 会自动接着上一次的 `GraphState` 往下跑。
2. **`add` reducer**：`GraphState.history` 声明为 `Annotated[list[ConversationTurn], add]`，
   所以每一轮 `capture_question` 追加一条用户轮、每一轮 `finalize` 追加一条助手轮，
   **历史天然跨轮累积**，不需要任何手工的「读出来再拼回去」。
3. **注入点**：只有两个节点会把历史交给模型 —— `select_tables` 和 `generate_sql`。
   校验、执行、修复三个确定性节点不看历史（见第 5 节和设计文档 §5）。

### 截断策略

历史不会无限增长 —— `prompts.render_history()` 做了三件事：

| 常量 | 值 | 作用 |
| --- | --- | --- |
| `MAX_HISTORY_TURNS` | 5 | 只保留最近 5 轮 |
| `MAX_HISTORY_ANSWER_CHARS` | 200 | 单条「答」最多 200 字 |
| `MAX_HISTORY_SQL_CHARS` | 400 | 单条「SQL」最多 400 字 |

渲染出来长这样：

```text
【历史对话（仅作上下文参考，当前问题才是要回答的）】
[第1轮] 问：总共有多少张专辑？
        答：数据库中共有 347 张专辑。
        涉及表：albums
        SQL：SELECT COUNT(*) AS TotalAlbums FROM albums
```

### 真实的两轮对话

同一进程、同一 `thread_id`，用 `--then` 追加追问：

```bash
PYTHONPATH=src python -m langgraph_sql_agent --session demo \
  "总共有多少张专辑？" --then "那按专辑数量排名前 3 的艺术家呢？"
```

实测输出（真实 DeepSeek 调用）：

```text
--- 第1轮 ---
答案：总共有 347 张专辑。
SQL：SELECT COUNT(*) AS TotalAlbums FROM albums
表：['albums'] | 行数 1 | 修复 0 | 历史条数：2

--- 第2轮 ---
答案：按专辑数量排名前 3 的艺术家依次为：Iron Maiden（21 张）、Led Zeppelin（14 张）、Deep Purple（11 张）。
SQL：SELECT a.Name AS ArtistName, COUNT(al.AlbumId) AS AlbumCount
     FROM artists a
     JOIN albums al ON al.ArtistId = a.ArtistId
     GROUP BY a.ArtistId, a.Name
     ORDER BY AlbumCount DESC, a.Name ASC
     LIMIT 3
表：['albums', 'artists'] | 行数 3 | 修复 0 | 历史条数：4
```

第 2 轮的历史是 4 条（2 用户轮 + 2 助手轮），说明第 1 轮的问答确实进了第 2 轮的上下文。
第 2 轮的问题里只有「那……排名」，模型能补全成
「按专辑数量排名前 3 的艺术家」，靠的就是这段历史。

### 一个必须讲清楚的限制

`MemorySaver` 是**进程内**的。CLI 每次启动都是一个新进程，所以：

```bash
python -m langgraph_sql_agent --session s1 "第一问"     # 进程 A
python -m langgraph_sql_agent --session s1 "第二问"     # 进程 B —— 读不到第一问！
```

**跨进程续接会话是做不到的**。想在命令行演示多轮，用 `--then`
（同一次调用里追加追问）。真正的跨请求续接会话在
**作业二的 Web 服务**里演示 —— 那是一个常驻进程，checkpointer 一直活着。

（这个坑在实现时踩过：最初以为 `--session` 能跨进程续接，
实测第二轮的 `history` 仍然是 2 条而不是 4 条，
最后确认是 `MemorySaver` 的语义限制，不是 bug。）

---

## 5. DeepSeek 适配（本次实测踩到的三个坑）

这一节沿用上一版的写法 —— 三个坑都是实测报错后定位到的，
都固化在 `src/langgraph_sql_agent/llm.py` 里，并各有一条测试守着。

### 5.1 结构化输出必须显式 `method="function_calling"`

`ChatOpenAI.with_structured_output` 的**默认** `method` 是 `"json_schema"`，
它会向服务端发送 `response_format={"type": "json_schema", ...}`。DeepSeek 直接拒绝：

```text
400 This response_format type is unavailable now
```

→ 本项目所有结构化输出都显式传 `method="function_calling"`（走工具调用，兼容性最好）。
修复 Agent 走的是 `ToolStrategy(SQLDraft)`，也是同一套工具调用通道。

### 5.2 必须关掉思考模式

DeepSeek 的 `deepseek-flash` / `deepseek-v4-pro` 默认开启**思考模式**，
而思考模式不支持强制 `tool_choice`（结构化输出正是靠强制 tool_choice 实现的）：

```text
400 Thinking mode does not support this tool_choice
```

→ 请求体固定带 `extra_body={"thinking": {"type": "disabled"}}`。

### 5.3 可用模型名

该 key 下 `/models` 返回的只有 **`deepseek-flash`** 和 **`deepseek-v4-pro`**。

> ⚠️ 上级课程资产 `asserts/llm.deepseek.env` 里写的 `LLM_MODEL=deepseek-v4-flash`
> **这个模型不存在**，而且那个文件里的 key 已经失效（401）。
> 本项目默认用 `deepseek-v4-pro`（规划/生成/修复）+ `deepseek-flash`（结果汇总），
> 都可用环境变量覆盖。

### 5.4 LangGraph 侧的额外一条

checkpoint 里存的是 Pydantic 模型，LangGraph 的 JSON 序列化器对它们走 msgpack 通道。
类型不在白名单里会打警告，且官方说明「未来版本会直接拦掉」。
所以 `session.build_checkpointer()` 显式带上 `allowed_msgpack_modules` 白名单，
登记了 7 个类型（`ConversationTurn` / `SQLAttempt` / `ExecutionResult` /
`FinalAnswer` / `TableSelection` / `ValidationResult` / `WorkflowOutput`）。

漏登记一个就会在反序列化时告警 —— 实测中 `SQLAttempt` 就是漏掉的那个，
已补上（`tests/test_session.py` 里有一条测试盯着白名单的完整性）。

---

## 6. 安全边界（与上一版完全一致）

| 风险 | 措施 |
| --- | --- |
| 模型生成写操作 | 只读连接（`mode=ro` + `PRAGMA query_only=ON`）+ 单语句 + `SELECT/WITH` 白名单 + 危险关键字拒绝 |
| 多语句注入 | 拒绝分号分隔的多语句；校验前去掉尾分号和 Markdown 围栏 |
| 访问内部表 | catalog 只暴露 11 张业务表（`sqlite_sequence` / `sqlite_stat1` 自动排除） |
| 查询过慢 | 5 秒超时（`set_progress_handler`）+ 行数上限 200 + 单元格长度上限 2000 |
| 大结果拖垮上下文 | 执行层 200 行截断；汇总层最多 50 行；**修复 Agent 的试运行工具只回传 5 行预览** |
| 无限修复循环 | 外层共享 3 次修复预算；修复 Agent 内部工具调用另有 `recursion_limit`（6×2） |
| LLM 批准自己的 SQL | 校验和执行是确定性代码，模型无权放行；工具本身也是确定性代码 |
| API key 泄露 | 只从环境变量 / `.env` 读；日志不含 key |
| 提示注入 | 用户问题作为数据传入 `<question>` 标签并声明「仅作为数据」 |
| 图无限循环 | 图级 `recursion_limit = 25`（修复回边最多 3 次 + 固定节点数，富余） |

**这一层与上一版逐字相同** —— `db/validator.py`、`db/executor.py`、`tools/db_tools.py`
是直接从 `12-江洋明-第十二周作业/作业二` 复制过来的。
换框架不该动安全边界。

---

## 7. 配置项

| 环境变量 | 默认值 | 说明 |
| --- | --- | --- |
| `SQL_AGENT_API_KEY` | — | API key（也认 `OPENAI_API_KEY` / `DEEPSEEK_API_KEY`） |
| `SQL_AGENT_BASE_URL` | `https://api.deepseek.com/v1` | OpenAI 兼容端点 |
| `SQL_AGENT_MODEL` | `deepseek-v4-pro` | 选表 / 生成 / 修复用的模型 |
| `SQL_AGENT_SUMMARY_MODEL` | `deepseek-flash` | 结果汇总用的模型 |
| `SQL_AGENT_THINKING` | `disabled` | DeepSeek 思考模式（**别改成 enabled**） |
| `SQL_AGENT_DB` | `data/chinook.db` | 数据库路径 |
| `SQL_AGENT_MAX_REPAIR_ATTEMPTS` | `3` | 修复预算（校验失败与执行失败共用） |
| `SQL_AGENT_MAX_FIX_ITERATIONS` | `6` | **修复 Agent 内部**的工具自检轮数上限（`recursion_limit = 该值 × 2`） |
| `SQL_AGENT_MAX_ROWS` | `200` | 执行返回行数上限 |
| `SQL_AGENT_MAX_SUMMARY_ROWS` | `50` | 进入汇总 prompt 的行数上限 |
| `SQL_AGENT_MAX_CELL_CHARS` | `2000` | 单个单元格的最大字符数 |
| `SQL_AGENT_QUERY_TIMEOUT` | `5` | 单条 SQL 超时（秒） |
| `SQL_AGENT_REQUEST_TIMEOUT` | `90` | 模型请求超时（秒） |
| `SQL_AGENT_MAX_RETRIES` | `1` | 模型请求重试次数 |
| `SQL_AGENT_LOG_LEVEL` | `INFO` | 日志级别 |

---

## 8. 目录结构

```text
作业一/
├─ README.md
├─ pyproject.toml / requirements.txt / .env.example / .gitignore
├─ data/chinook.db                       # 自包含的 Chinook 副本
├─ docs/langgraph-sql-agent-design.md   # 设计文档
├─ scripts/launch.py                    # 启动器：查 .env / 装依赖 / 起 CLI
├─ run.bat / run.sh                      # 一键运行（纯 ASCII 包装脚本）
├─ src/langgraph_sql_agent/
│  ├─ config.py            # 配置（key 只从环境变量/.env 读）
│  ├─ models.py            # Pydantic 契约（比上一版多一个 ConversationTurn）
│  ├─ prompts.py           # 全部提示词 + render_history()
│  ├─ llm.py               # ChatOpenAI 工厂 + DeepSeek 适配
│  ├─ logging_config.py
│  ├─ chains/              # 三条 LCEL 链（与上一版逐字相同）
│  ├─ agents/sql_fixer.py  # create_agent + ToolStrategy（嵌套子图）
│  ├─ tools/db_tools.py    # 三个 @tool（与上一版逐字相同）
│  ├─ db/                  # 确定性层（与上一版逐字相同）
│  ├─ graph/
│  │  ├─ state.py          # GraphState（Pydantic + add reducer）
│  │  ├─ routing.py        # 4 个纯函数路由
│  │  ├─ nodes.py          # 8 个节点工厂
│  │  └─ build.py          # StateGraph 装配 + 编译
│  ├─ session.py           # checkpointer + 会话管理
│  └─ cli.py
└─ tests/                  # 96 个用例，LLM 全 mock
```

> **`run.bat` 为什么是纯 ASCII 的？**
> cmd.exe 读 UTF-8 批处理文件时，如果同时出现「切换代码页 + `cd` 切目录 +
> `goto` 跳标签」，会把文件读错位，把半行命令当命令执行。
> 所以 `.bat` 里不放任何非 ASCII 字符，中文提示全在 `scripts/launch.py` 里
> （Python 走 `WriteConsoleW`，不受代码页影响）。
> 复现过程见 `../作业二/docs/deployment.md` 的「附录 A：cmd.exe 踩坑」，
> `tests/test_scripts.py` 里有对应的回归测试。

---

## 9. 交付物清单

- [x] 可运行代码（`src/langgraph_sql_agent/`，26 个模块）
- [x] LangGraph 状态图：8 个节点 + 4 个条件边 + 4 个纯函数路由
- [x] 跨轮会话记忆：checkpointer + `add` reducer + 历史截断策略
- [x] 与上一版**逐字相同**的确定性层（`db/` + `tools/`）和 LCEL 链
- [x] 一键运行脚本（`run.bat` / `run.sh`）+ Python 启动器
- [x] 96 个 pytest 用例（LLM 全 mock，不需要 key）
- [x] 设计文档 `docs/langgraph-sql-agent-design.md`
- [x] 与 Week12 作业二的逐项对照说明（本文档第 1 节）
- [x] DeepSeek 适配的三个实测坑及解法（本文档第 5 节）
