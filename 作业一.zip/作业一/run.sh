#!/usr/bin/env bash
# Chinook SQL Agent (LangGraph) - command line.
# Usage: ./run.sh "question"   or   ./run.sh "q1" --then "q2"
# Chinese messages live in scripts/launch.py.
set -e
cd "$(dirname "$0")"
exec python -X utf8 scripts/launch.py "$@"
