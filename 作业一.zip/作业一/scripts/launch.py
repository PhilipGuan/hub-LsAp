"""启动前检查 + 启动命令行版 SQL Agent（作业一）。

和作业二的 ``scripts/launch.py`` 是同一个思路：**把带中文的提示逻辑放在
Python 里，``.bat`` / ``.sh`` 只留纯 ASCII 的几行。**

原因：cmd.exe 读 UTF-8 批处理文件时，如果同时出现「切换代码页 + ``cd``
切目录 + ``goto`` 跳标签」，字节读取位置会算错，把半行命令当成命令执行
（报 ``'xxx' is not recognized as an internal or external command``）。
复现过程见 ``作业二/docs/deployment.md`` 的「cmd.exe 踩坑」。

用法::

    python -X utf8 scripts/launch.py
    python -X utf8 scripts/launch.py "总共有多少张专辑？"
    python -X utf8 scripts/launch.py "第一个问题" --then "追问"
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent

# 启动前必须能 import 成功的模块 —— 缺了就装依赖
REQUIRED_MODULES = ("langgraph", "langchain_openai")
REQUIREMENTS_FILE = "requirements.txt"
ENV_FILE = ".env"
ENV_TEMPLATE = ".env.example"


def _setup_output() -> None:
    """把 stdout 改成行缓冲（原因同作业二的 launch.py）。"""

    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is not None:
            try:
                reconfigure(line_buffering=True)
            except (ValueError, OSError):  # pragma: no cover - 极端情况
                pass


def ensure_env(root: Path = PROJECT_ROOT) -> bool:
    """确保 ``.env`` 存在；不存在就从 ``.env.example`` 复制并提示填 key。"""

    env_path = root / ENV_FILE
    if env_path.exists():
        return True

    template = root / ENV_TEMPLATE
    if template.exists():
        shutil.copyfile(template, env_path)
        print("[提示] 未找到 .env，已从 .env.example 复制一份。")
    else:
        print(f"[提示] 未找到 .env，示例模板 {ENV_TEMPLATE} 也不存在。")
    print(f"       请打开 {ENV_FILE} 填入 SQL_AGENT_API_KEY 后重新运行。")
    return False


def ensure_deps(root: Path = PROJECT_ROOT) -> bool:
    """确保运行依赖已安装；缺失就执行 ``pip install``。"""

    modules = ", ".join(REQUIRED_MODULES)
    probe = subprocess.run(
        [sys.executable, "-c", f"import {modules}"],
        capture_output=True,
        cwd=str(root),
    )
    if probe.returncode == 0:
        return True

    print("[安装] 依赖缺失，正在安装，请稍候…")
    req = root / REQUIREMENTS_FILE
    if req.exists():
        cmd = [sys.executable, "-m", "pip", "install", "-r", str(req)]
    else:
        cmd = [sys.executable, "-m", "pip", "install", *REQUIRED_MODULES]
    subprocess.run(cmd, cwd=str(root))

    probe = subprocess.run(
        [sys.executable, "-c", f"import {modules}"],
        capture_output=True,
        cwd=str(root),
    )
    if probe.returncode != 0:
        print("[错误] 依赖安装失败，请手动执行：")
        print(f"       {sys.executable} -m pip install -r {REQUIREMENTS_FILE}")
        return False
    return True


def main(argv: list[str] | None = None) -> int:
    """启动器入口。``argv`` 原样透传给 SQL Agent 的命令行。"""

    args = list(sys.argv[1:] if argv is None else argv)

    _setup_output()
    print("=" * 44)
    print("  Chinook SQL Agent（LangGraph 版）· 命令行")
    print("=" * 44)
    print()

    if not ensure_env():
        return 1
    if not ensure_deps():
        return 1

    print("[启动] 开始提问…")
    print()

    env = dict(os.environ)
    src = str(PROJECT_ROOT / "src")
    old = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = f"{src}{os.pathsep}{old}" if old else src

    cmd = [sys.executable, "-X", "utf8", "-m", "langgraph_sql_agent", *args]
    return subprocess.call(cmd, cwd=str(PROJECT_ROOT), env=env)


if __name__ == "__main__":
    raise SystemExit(main())
