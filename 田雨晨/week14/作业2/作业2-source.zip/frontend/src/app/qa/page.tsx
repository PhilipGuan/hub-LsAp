"use client";

/** 多模态问答页：问题（+ 可选图片）→ 图文分段回答 + 引用；本次会话保留最近 5 条历史。 */

import { useEffect, useState } from "react";

import AnswerView from "@/components/qa/AnswerView";
import HealthStatus from "@/components/qa/HealthStatus";
import HistoryList, { type QaHistoryItem } from "@/components/qa/HistoryList";
import QuestionForm from "@/components/qa/QuestionForm";
import styles from "@/components/qa/qa.module.css";
import { API_BASE_URL, ApiError, askQuestion, deleteDocument, listDocuments } from "@/lib/api";
import { formatDateTime, documentStatusTone } from "@/lib/format";
import type { DocumentInfo } from "@/lib/types";

const HISTORY_LIMIT = 5;

const EXAMPLE_QUESTIONS = [
  "这个系统由哪些部分组成？",
  "解析失败后会自动重试几次？",
  "文档里的图片资源是如何被检索到的？",
];

/** 空状态：一行用法说明 + 示例问题按钮（点击只填入输入框，不自动提交，由用户确认后再发） */
function EmptyState({ onPick }: { onPick: (question: string) => void }) {
  return (
    <div className="empty">
      <p className={styles.emptyLead}>
        用法：输入问题（可附一张图片）→ 提交 → 查看图文分段回答与引用页码。
      </p>
      <div className={styles.exampleRow}>
        {EXAMPLE_QUESTIONS.map((example) => (
          <button
            key={example}
            type="button"
            className="btn"
            onClick={() => onPick(example)}
          >
            {example}
          </button>
        ))}
      </div>
    </div>
  );
}

export default function QaPage() {
  const [question, setQuestion] = useState("");
  const [image, setImage] = useState<File | null>(null);
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [history, setHistory] = useState<QaHistoryItem[]>([]);
  const [documents, setDocuments] = useState<DocumentInfo[]>([]);
  const [corpusError, setCorpusError] = useState<string | null>(null);
  const [selectedDocIds, setSelectedDocIds] = useState<string[]>([]);
  const [deleting, setDeleting] = useState(false);

  // 知识库文档：问答检索的是全库文档，这里先展示出来，避免不知道引用了哪些文档
  useEffect(() => {
    let cancelled = false;
    listDocuments()
      .then((response) => {
        if (!cancelled) setDocuments(response.documents);
      })
      .catch(() => {
        if (!cancelled) setCorpusError("知识库文档列表加载失败：请确认后端已启动。");
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const latest: QaHistoryItem | undefined = history[0];

  /** 勾选/取消勾选一份文档 */
  function toggleDocument(docId: string): void {
    setSelectedDocIds((previous) =>
      previous.includes(docId) ? previous.filter((id) => id !== docId) : [...previous, docId],
    );
  }

  /** 删除选中文档：逐份调后端（后端会级联清理切片/图片/解析任务/存储文件），成功后刷新列表 */
  async function handleDeleteDocuments(): Promise<void> {
    if (deleting || selectedDocIds.length === 0) return;
    const confirmed = window.confirm(
      `确定删除选中的 ${selectedDocIds.length} 份文档？会同时删除切片、图片和存储文件，不可恢复。`,
    );
    if (!confirmed) return;
    setDeleting(true);
    setCorpusError(null);
    try {
      for (const docId of selectedDocIds) {
        await deleteDocument(docId);
      }
      const response = await listDocuments();
      setDocuments(response.documents);
      setSelectedDocIds([]);
    } catch (cause) {
      setCorpusError(cause instanceof ApiError ? cause.message : "删除失败：请确认后端已启动。");
    } finally {
      setDeleting(false);
    }
  }

  async function handleSubmit(): Promise<void> {
    if (pending) return;
    const trimmed = question.trim();
    if (!trimmed) {
      setError("请先输入问题。");
      return;
    }
    setPending(true);
    setError(null);
    try {
      const response = await askQuestion(trimmed, image);
      // 最新在上，只保留最近 5 条（仅本次会话的内存数据，刷新页面即清空）
      setHistory((previous) =>
        [{ question: trimmed, response }, ...previous].slice(0, HISTORY_LIMIT),
      );
      // 问题已发出：清空输入，但保留已选图片，方便围绕同一张图继续追问
      setQuestion("");
    } catch (caught) {
      setError(
        caught instanceof ApiError
          ? caught.message
          : `无法连接后端（${API_BASE_URL}）：可能是后端未启动、CORS 被拒或后端内部错误（500），请查看浏览器控制台与后端日志。`,
      );
    } finally {
      setPending(false);
    }
  }

  return (
    <div className="page">
      <div className="row-between">
        <div>
          <h1 className="page-title">多模态问答</h1>
          <p className="page-subtitle">
            纯文本或「文本 + 图片」提问；回答按文本段与图片段混排展示，并给出引用页码。
          </p>
        </div>
        <HealthStatus />
      </div>

      <section className="card" aria-labelledby="corpus-title">
        <div className="row-between">
          <h2 className="card-title" id="corpus-title">
            知识库文档
          </h2>
          <span className="row">
            <span className="hint">
              {documents.length > 0 ? `共 ${documents.length} 份，提问在这些文档里检索` : "暂无文档"}
            </span>
            <button
              type="button"
              className="btn btn-danger"
              onClick={() => void handleDeleteDocuments()}
              disabled={deleting || selectedDocIds.length === 0}
              title="删除选中文档（连同切片、图片与存储文件，不可恢复）"
            >
              {deleting ? "删除中…" : `删除选中${selectedDocIds.length > 0 ? `（${selectedDocIds.length}）` : ""}`}
            </button>
          </span>
        </div>
        {corpusError ? (
          <p className="hint">{corpusError}</p>
        ) : documents.length === 0 ? (
          <p className="empty">知识库还没有文档：先到「上传与解析」页上传 PDF。</p>
        ) : (
          <ul className={styles.docList}>
            {documents.map((document) => (
              <li className={styles.docItem} key={document.doc_id}>
                <label className={styles.docCheck}>
                  <input
                    type="checkbox"
                    checked={selectedDocIds.includes(document.doc_id)}
                    onChange={() => toggleDocument(document.doc_id)}
                    aria-label={`选择 ${document.filename}`}
                  />
                  <span className={styles.docName} title={document.filename}>
                    {document.filename}
                  </span>
                </label>
                <span className="row">
                  <span className="muted mono">{document.pages} 页</span>
                  <span className={`badge badge-${documentStatusTone(document.status)}`}>
                    {document.display_status}
                  </span>
                </span>
              </li>
            ))}
          </ul>
        )}
      </section>

      <QuestionForm
        question={question}
        onQuestionChange={setQuestion}
        image={image}
        onImageChange={setImage}
        onSubmit={handleSubmit}
        pending={pending}
        error={error}
      />

      <section className="card" aria-labelledby="qa-answer-title" aria-busy={pending}>
        <div className="row-between">
          <h2 className="card-title" id="qa-answer-title">
            回答
          </h2>
          {latest ? <span className="hint">{formatDateTime(latest.response.created_at)}</span> : null}
        </div>

        {pending ? (
          <p className="row muted" role="status">
            <span className="spinner" aria-hidden="true" />
            正在生成回答…
          </p>
        ) : latest ? (
          <>
            <p className={styles.latestQuestion}>问题：{latest.question}</p>
            <AnswerView response={latest.response} />
          </>
        ) : (
          <EmptyState onPick={setQuestion} />
        )}
      </section>

      <HistoryList items={history} onClear={() => setHistory([])} />
    </div>
  );
}
