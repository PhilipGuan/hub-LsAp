"use client";

/**
 * 上传与解析状态页（`/`）：多选 PDF → 上传 → 汇总展示服务启动后上传的全部文档。
 * 数据来源：GET /api/documents（全部文档）；SSE 只作为「有变化就刷新」的信号，另有 5 秒轮询兜底。
 * 批次号仍写 localStorage：刷新后恢复 SSE 订阅的批次（只影响实时信号，不影响汇总数据与问答检索）。
 */

import { useCallback, useEffect, useRef, useState } from "react";

import { BatchOverview, type ConnectionMode } from "@/components/upload/BatchOverview";
import { DocumentTable } from "@/components/upload/DocumentTable";
import { FilePicker } from "@/components/upload/FilePicker";
import {
  API_BASE_URL,
  ApiError,
  listDocuments,
  retryDocument,
  subscribeBatchEvents,
  uploadBatch,
} from "@/lib/api";
import type { DocumentInfo } from "@/lib/types";

/** 刷新恢复用的 localStorage key */
const LAST_BATCH_KEY = "rag:lastBatchId";
/** 轮询兜底间隔：SSE 之外每 5 秒拉一次全量文档 */
const POLL_INTERVAL_MS = 5000;

function readStoredBatchId(): string | null {
  try {
    return window.localStorage.getItem(LAST_BATCH_KEY);
  } catch {
    // 隐私模式/存储被禁用：刷新恢复不可用，不影响上传
    return null;
  }
}

function storeBatchId(batchId: string | null): void {
  try {
    if (batchId) {
      window.localStorage.setItem(LAST_BATCH_KEY, batchId);
    } else {
      window.localStorage.removeItem(LAST_BATCH_KEY);
    }
  } catch {
    // 同上：存储失败只影响刷新恢复
  }
}

/** 请求失败的统一中文文案：业务错误用后端给的 message，其余多为网络不通。 */
function errorMessage(cause: unknown, fallback: string): string {
  if (cause instanceof ApiError) {
    // 前端已更新但后端还是旧进程时，新接口会 404 "Not Found"：直接提示重启后端，别让人猜
    if (cause.status === 404 && (cause.message === "Not Found" || cause.message.includes("Not Found"))) {
      return `${fallback}：后端接口未就绪（后端可能还没重启加载新版本），请重启后端后刷新页面。`;
    }
    return cause.message;
  }
  return `${fallback}：无法连接后端 ${API_BASE_URL}，请确认服务已启动后重试。`;
}

/**
 * 页面错误分两类，避免 5 秒轮询成功把「上传/重试失败」的提示秒清掉：
 * - action：用户操作失败（上传/重试），一直显示到下一次操作；
 * - status：状态拉取失败，下一次拉取成功即可清除。
 */
interface PageError {
  text: string;
  source: "action" | "status";
}

/** 按全部文档现算总览状态（与批次状态机无关，口径是“所有已上传文档”） */
function overallStatus(total: number, done: number, failed: number): { text: string; tone: string } {
  if (total === 0) return { text: "暂无文档", tone: "pending" };
  if (done === total) return { text: "全部解析完成", tone: "done" };
  if (failed === total) return { text: "全部解析失败", tone: "failed" };
  if (done + failed === total) return { text: "部分失败", tone: "warning" };
  return { text: "解析中", tone: "active" };
}

export default function UploadPage() {
  // 页面状态：files 是待上传选择；documents 是全量文档（服务启动后上传过的）；
  // uploading/loading/retryingDocId 是三个忙状态；error/notice 是顶部提示条。
  const [files, setFiles] = useState<File[]>([]);
  const [batchId, setBatchId] = useState<string | null>(null);
  const [documents, setDocuments] = useState<DocumentInfo[]>([]);
  const [uploading, setUploading] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<PageError | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [connection, setConnection] = useState<ConnectionMode>("connecting");
  const [retryingDocId, setRetryingDocId] = useState<string | null>(null);
  // 记录当前文档列表请求，下一次请求前 abort，防止旧响应晚到把新状态覆盖掉
  const requestRef = useRef<AbortController | null>(null);

  const loadDocuments = useCallback(async (options?: { silent?: boolean }): Promise<void> => {
    // 取消上一次未完成的请求，避免旧响应覆盖新状态
    requestRef.current?.abort();
    const controller = new AbortController();
    requestRef.current = controller;
    if (!options?.silent) setLoading(true);
    try {
      const response = await listDocuments();
      if (controller.signal.aborted) return;
      setDocuments(response.documents);
      // 只清除「状态拉取失败」；用户操作失败的提示要留到下一次操作
      setError((previous) => (previous?.source === "status" ? null : previous));
    } catch (cause) {
      if (controller.signal.aborted) return;
      const message = errorMessage(cause, "文档状态加载失败");
      setError((previous) =>
        previous?.source === "action" ? previous : { text: message, source: "status" },
      );
    } finally {
      if (!controller.signal.aborted) setLoading(false);
    }
  }, []);

  // 首次进入：恢复上次批次号（仅用于 SSE 订阅）+ 拉一次全量文档
  useEffect(() => {
    const stored = readStoredBatchId();
    if (stored) setBatchId(stored);
    void loadDocuments();
  }, [loadDocuments]);

  // 每 5 秒轮询全量文档：不依赖 SSE 是否可用，页面始终能看到最新状态（SSE 丢帧也能兜住）
  useEffect(() => {
    const timer = window.setInterval(() => {
      void loadDocuments({ silent: true });
    }, POLL_INTERVAL_MS);
    return () => window.clearInterval(timer);
  }, [loadDocuments]);

  // 有批次号时订阅 SSE：事件只当作“有变化”的信号，统一走 loadDocuments 刷新全量列表
  useEffect(() => {
    if (!batchId) {
      setConnection("polling");
      return;
    }
    setConnection("connecting");
    const unsubscribe = subscribeBatchEvents(batchId, {
      onEvent: () => {
        setConnection("live");
        void loadDocuments({ silent: true });
      },
      onError: () => {
        // EventSource 断线后浏览器会自动重连；重连期间降级为轮询兜底，推送恢复后 onEvent 会切回 live
        setConnection("polling");
      },
    });
    return () => unsubscribe();
  }, [batchId, loadDocuments]);

  const handleSelectFiles = useCallback((selected: File[]) => {
    setError(null);
    setFiles((previous) => {
      const merged = [...previous];
      for (const file of selected) {
        // 同一文件（名/大小/修改时间一致）不重复入列：否则会被后端当成多个文档重复解析
        const duplicate = merged.some(
          (item) =>
            item.name === file.name && item.size === file.size && item.lastModified === file.lastModified,
        );
        if (!duplicate) merged.push(file);
      }
      return merged;
    });
  }, []);

  const handleRemoveFile = useCallback((index: number) => {
    setFiles((previous) => previous.filter((_, position) => position !== index));
  }, []);

  const handleClearFiles = useCallback(() => {
    setFiles([]);
  }, []);

  /**
   * 上传：selected 可选——FilePicker 在“原生 input 已有文件、但 change 事件没同步到 React 状态”
   * 时会直接把读到的文件传进来兜底；不传则用当前已选文件列表。
   */
  const handleUpload = useCallback(
    async (selected?: File[]): Promise<void> => {
      const list = selected && selected.length > 0 ? selected : files;
      if (uploading) return;
      if (list.length === 0) {
        setError({ text: "请先选择 PDF 文件：点击“选择文件”，或把 PDF 拖到上传面板。", source: "action" });
        return;
      }
      setUploading(true);
      setError(null);
      setNotice(null);
      try {
        const response = await uploadBatch(list);
        storeBatchId(response.batch_id);
        setFiles([]);
        const skipped = response.duplicates.length;
        setNotice(
          `已上传 ${response.documents.length} 个 PDF，已加入下方汇总列表并进入解析队列。` +
            (skipped > 0 ? `（${skipped} 个文件内容重复，已跳过：${response.duplicates.join("、")}）` : ""),
        );
        setBatchId(response.batch_id);
        await loadDocuments({ silent: true });
      } catch (cause) {
        setError({ text: errorMessage(cause, "上传失败"), source: "action" });
      } finally {
        setUploading(false);
      }
    },
    [files, uploading, loadDocuments],
  );

  const handleRefresh = useCallback(() => {
    void loadDocuments();
  }, [loadDocuments]);

  const handleClearLocal = useCallback(() => {
    requestRef.current?.abort();
    storeBatchId(null);
    setBatchId(null);
    setLoading(false);
    setError(null);
    setNotice("已忘记上次批次（只清浏览器记录与实时推送订阅，不删除文档，汇总列表保留）。");
  }, []);

  const handleRetry = useCallback(
    async (document: DocumentInfo): Promise<void> => {
      if (retryingDocId) return;
      setRetryingDocId(document.doc_id);
      setError(null);
      setNotice(null);
      try {
        const result = await retryDocument(document.doc_id);
        setNotice(`《${document.filename}》${result.message}，正在刷新状态。`);
        // 后端重试后会推一次 SSE，这里再立刻拉一次，避免依赖推送时序
        await loadDocuments({ silent: true });
      } catch (cause) {
        setError({ text: errorMessage(cause, "重试失败"), source: "action" });
      } finally {
        setRetryingDocId(null);
      }
    },
    [retryingDocId, loadDocuments],
  );

  const total = documents.length;
  const doneCount = documents.filter((document) => document.status === "done").length;
  const failedCount = documents.filter((document) => document.status === "failed").length;
  const activeCount = total - doneCount - failedCount;
  const status = overallStatus(total, doneCount, failedCount);
  // 最近更新时间取所有文档 updated_at 的最大值
  const updatedAt = documents.reduce<string | null>(
    (latest, document) => (!latest || document.updated_at > latest ? document.updated_at : latest),
    null,
  );

  return (
    <div className="page">
      <header>
        <h1 className="page-title">上传与解析状态</h1>
        <p className="page-subtitle">
          汇总展示服务启动后上传的全部文档：SSE 实时刷新 + 每 5 秒轮询兜底；失败可重试、已完成可重新解析。
        </p>
      </header>

      {error ? (
        <div className="alert alert-error" role="alert">
          {error.text}
        </div>
      ) : null}
      {notice ? (
        <div className="alert alert-info" role="status">
          {notice}
        </div>
      ) : null}

      <div className="grid-two">
        <FilePicker
          files={files}
          uploading={uploading}
          onSelect={handleSelectFiles}
          onRemove={handleRemoveFile}
          onClear={handleClearFiles}
          onUpload={(selected) => {
            void handleUpload(selected);
          }}
        />
        <BatchOverview
          total={total}
          doneCount={doneCount}
          failedCount={failedCount}
          activeCount={activeCount}
          statusText={status.text}
          statusTone={status.tone}
          updatedAt={updatedAt}
          loading={loading}
          connection={connection}
          hasBatch={batchId !== null}
          onRefresh={handleRefresh}
          onClearLocal={handleClearLocal}
        />
      </div>

      <DocumentTable
        documents={documents}
        retryingDocId={retryingDocId}
        onRetry={(document) => {
          void handleRetry(document);
        }}
      />
    </div>
  );
}
