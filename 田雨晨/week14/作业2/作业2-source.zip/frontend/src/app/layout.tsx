/**
 * 根布局（服务端组件）：全站顶栏 / 页脚 / 全局样式入口。
 * 两个页面分别是 `/`（上传与解析状态）与 `/qa`（多模态问答）。
 */

import type { Metadata } from "next";
import Link from "next/link";
import "./globals.css";

/** 全站标题与描述（浏览器标签 + SEO） */
export const metadata: Metadata = {
  title: "多模态 RAG 问答系统",
  description: "多 PDF 上传解析状态展示 + 多模态图文问答（前端只消费后端 HTTP 接口）",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="zh-CN">
      <body>
        <header className="site-header">
          <div className="site-header-inner">
            <Link href="/" className="brand">
              <span className="brand-mark">RAG</span>
              <span>多模态问答系统</span>
            </Link>
            <nav className="site-nav">
              <Link href="/">上传与解析</Link>
              <Link href="/qa">多模态问答</Link>
            </nav>
          </div>
        </header>
        <main className="site-main">{children}</main>
        <footer className="site-footer">
          前端只消费后端接口 · Next.js 16 · 接口地址见 NEXT_PUBLIC_API_BASE_URL
        </footer>
      </body>
    </html>
  );
}
