"use client";

/**
 * 上传页底部的文档明细表格：服务启动后上传的全部文档（文件名/状态/页数/失败原因/重新解析）。
 * 数据来自 GET /api/documents；重试动作由父组件执行，这里只上抛 onRetry 并展示重试中的 spinner。
 */

import { documentStatusTone } from "@/lib/format";
import type { DocumentInfo } from "@/lib/types";

import styles from "./upload.module.css";

interface DocumentTableProps {
  /** 全部文档列表（服务启动后上传过的文档） */
  documents: DocumentInfo[];
  /** 正在重试的文档 id（null 表示空闲） */
  retryingDocId: string | null;
  onRetry: (document: DocumentInfo) => void;
}

/** 文档明细表格：文件名、状态、页数、失败原因、重新解析操作。 */
export function DocumentTable({ documents, retryingDocId, onRetry }: DocumentTableProps) {
  const retrying = retryingDocId !== null;

  return (
    <section className="card" aria-labelledby="documents-title">
      <h2 className="card-title" id="documents-title">
        文档明细
      </h2>
      <p className="card-hint">
        失败文档可重试；已完成的文档可「重新解析」（例如换了 MinerU/解析器后修正内容与页数）。
      </p>

      {documents.length === 0 ? (
        <p className="empty">还没有上传文档。</p>
      ) : (
        <div className="table-wrap">
          <table className="table">
            <caption className={styles.caption}>全部文档的解析状态、页数与失败原因</caption>
            <thead>
              <tr>
                <th scope="col">文件名</th>
                <th scope="col">状态</th>
                <th scope="col">页数</th>
                <th scope="col">失败原因</th>
                <th scope="col">操作</th>
              </tr>
            </thead>
            <tbody>
              {documents.map((document) => {
                // 失败 → 重试；已完成 → 重新解析；其余状态不可操作
                const canReparse = document.status === "failed" || document.status === "done";
                return (
                  <tr key={document.doc_id}>
                    <td className={styles.docName} title={document.filename}>
                      {document.filename}
                    </td>
                    <td>
                      <span className={`badge badge-${documentStatusTone(document.status)}`}>
                        {document.display_status}
                      </span>
                    </td>
                    <td className="mono">{document.pages > 0 ? document.pages : "-"}</td>
                    <td className={document.error ? styles.errorCell : "muted"}>{document.error || "-"}</td>
                    <td>
                      {canReparse ? (
                        <button
                          type="button"
                          className="btn btn-ghost"
                          onClick={() => onRetry(document)}
                          disabled={retrying}
                          aria-label={`${document.status === "failed" ? "重试" : "重新解析"} ${document.filename}`}
                        >
                          {retryingDocId === document.doc_id ? (
                            <>
                              <span className="spinner" aria-hidden="true" />
                              处理中…
                            </>
                          ) : document.status === "failed" ? (
                            "重试"
                          ) : (
                            "重新解析"
                          )}
                        </button>
                      ) : (
                        <span className="muted">-</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}
