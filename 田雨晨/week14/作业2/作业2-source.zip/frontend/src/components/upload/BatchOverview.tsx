"use client";

/**
 * 上传页右侧「解析状态总览」卡片：汇总展示服务启动后上传的全部文档。
 * 总数/完成/失败/处理中与总状态由父组件（app/page.tsx）按全量文档现算后传入，本组件不发请求。
 */

import { formatDateTime } from "@/lib/format";

import styles from "./upload.module.css";

/** 状态来源：SSE 实时推送 / 已降级为轮询 / 正在建连 */
export type ConnectionMode = "connecting" | "live" | "polling";

const CONNECTION_HINT: Record<ConnectionMode, string> = {
  connecting: "正在连接实时推送…",
  live: "实时推送已连接（每 5 秒仍轮询兜底）",
  polling: "实时推送不可用，已降级为 5 秒轮询",
};

const CONNECTION_TONE: Record<ConnectionMode, string> = {
  connecting: "badge-pending",
  live: "badge-done",
  polling: "badge-warning",
};

interface BatchOverviewProps {
  /** 全部文档数（服务启动后上传过的所有文档） */
  total: number;
  /** 解析完成数 */
  doneCount: number;
  /** 解析失败数 */
  failedCount: number;
  /** 处理中（排队/解析/索引/重试）数量 */
  activeCount: number;
  /** 总体状态文案（按全部文档现算） */
  statusText: string;
  /** 总体状态徽标色调（badge-<tone>） */
  statusTone: string;
  /** 最近一次文档更新时间 */
  updatedAt: string | null;
  /** 是否正在拉取文档列表（控制刷新按钮 spinner） */
  loading: boolean;
  /** 状态来源：SSE 实时 / 已降级轮询 / 建连中 */
  connection: ConnectionMode;
  /** 是否还记着上次批次（决定“忘记上次批次”按钮是否可用） */
  hasBatch: boolean;
  onRefresh: () => void;
  onClearLocal: () => void;
}

/** 解析状态总览：总状态徽标、完成进度、四项计数、连接方式与本地记录操作。 */
export function BatchOverview({
  total,
  doneCount,
  failedCount,
  activeCount,
  statusText,
  statusTone,
  updatedAt,
  loading,
  connection,
  hasBatch,
  onRefresh,
  onClearLocal,
}: BatchOverviewProps) {
  const percent = total > 0 ? Math.round((doneCount / total) * 100) : 0;

  return (
    <section className="card" aria-labelledby="batch-title">
      <div className="row-between">
        <div>
          <h2 className="card-title" id="batch-title">
            解析状态总览
          </h2>
          <p className="card-hint">记录服务启动后上传的全部文档：SSE 实时推送 + 每 5 秒轮询兜底。</p>
        </div>
        <div className="row">
          <span className={`badge ${CONNECTION_TONE[connection]}`} role="status">
            {CONNECTION_HINT[connection]}
          </span>
          <button type="button" className="btn" onClick={onRefresh} disabled={loading}>
            {loading ? (
              <>
                <span className="spinner" aria-hidden="true" />
                刷新中…
              </>
            ) : (
              "刷新"
            )}
          </button>
          <button
            type="button"
            className="btn btn-danger"
            onClick={onClearLocal}
            disabled={loading || !hasBatch}
            title="只清除浏览器里记住的批次，不会删除文档；文档可在「多模态问答」页的知识库列表里删除"
          >
            忘记上次批次
          </button>
        </div>
      </div>

      {total === 0 ? (
        <p className="empty">还没有上传文档：先在左侧选择 PDF 并上传。</p>
      ) : (
        <div className="stack">
          <div className="row">
            <span className={`badge badge-${statusTone}`}>{statusText}</span>
            <span className="muted">共 {total} 份文档</span>
          </div>

          <div>
            <div
              className={styles.progress}
              role="progressbar"
              aria-valuemin={0}
              aria-valuemax={total}
              aria-valuenow={doneCount}
              aria-label="解析完成进度"
            >
              <div className={styles.progressBar} style={{ width: `${percent}%` }} />
            </div>
            <p className="hint mt-0">
              已完成 {doneCount} / {total} 个文件（失败 {failedCount} 个，处理中 {activeCount} 个）
            </p>
          </div>

          <div className={styles.stats}>
            <div className={styles.stat}>
              <span className={styles.statValue}>{total}</span>
              <span className={styles.statLabel}>文件总数</span>
            </div>
            <div className={styles.stat}>
              <span className={styles.statValue}>{doneCount}</span>
              <span className={styles.statLabel}>解析完成</span>
            </div>
            <div className={styles.stat}>
              <span className={styles.statValue}>{activeCount}</span>
              <span className={styles.statLabel}>处理中</span>
            </div>
            <div className={styles.stat}>
              <span className={styles.statValue}>{failedCount}</span>
              <span className={styles.statLabel}>解析失败</span>
            </div>
          </div>

          <p className="hint">最后更新 {formatDateTime(updatedAt)}</p>
        </div>
      )}
    </section>
  );
}
