"use client";

/**
 * 上传页左侧「选择 PDF」面板。
 * 只负责展示已选文件与上抛事件：去重/合并/上传等业务状态都留在父组件（app/page.tsx）。
 *
 * 交互上做了三件事保证“选了文件一定能上传”：
 * 1. 点击输入框时先清空原生 value，同一文件再次选择也会触发 change；
 * 2. 支持拖拽 PDF 到面板（不依赖原生文件对话框）；
 * 3. 上传按钮始终可点；若 React 状态里还没有文件（change 事件偶发没同步，比如
 *    dev 首次编译/水合窗口内选择文件），会直接从原生 input 读取已选文件兜底。
 */

import { useEffect, useRef, useState } from "react";

import { formatBytes } from "@/lib/format";

import styles from "./upload.module.css";

interface FilePickerProps {
  /** 已选文件（合并/去重结果由父组件维护） */
  files: File[];
  /** 上传中：禁用选择、移除、清空与上传按钮 */
  uploading: boolean;
  /** 选择新文件（父组件负责去重/合并） */
  onSelect: (files: File[]) => void;
  onRemove: (index: number) => void;
  onClear: () => void;
  /** 触发上传；可选传入文件列表（用于原生 input 兜底场景） */
  onUpload: (files?: File[]) => void;
}

/** 多 PDF 选择面板：选中的文件列表、拖拽/原生两种选择方式、单个移除、清空、上传按钮。 */
export function FilePicker({ files, uploading, onSelect, onRemove, onClear, onUpload }: FilePickerProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragging, setDragging] = useState(false);

  // 文件列表被清空（上传成功 / 清空）后同步清空原生 input，避免重复选中同一批文件不触发 change
  useEffect(() => {
    if (files.length === 0 && inputRef.current) {
      inputRef.current.value = "";
    }
  }, [files.length]);

  const totalBytes = files.reduce((sum, file) => sum + file.size, 0);

  /** 兜底：优先用 React 状态；状态为空时读原生 input 的已选文件 */
  const effectiveFiles = (): File[] => {
    if (files.length > 0) return files;
    return Array.from(inputRef.current?.files ?? []);
  };

  const handleUploadClick = () => {
    const selected = effectiveFiles();
    // change 事件没同步到状态时，这里顺手补一次，让列表/计数立刻正确
    if (files.length === 0 && selected.length > 0) {
      onSelect(selected);
    }
    onUpload(selected);
  };

  const handleDrop = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    setDragging(false);
    const dropped = Array.from(event.dataTransfer.files ?? []);
    if (dropped.length > 0) {
      onSelect(dropped);
    }
  };

  return (
    <section className="card" aria-labelledby="upload-title">
      <div className="row-between">
        <div>
          <h2 className="card-title" id="upload-title">
            选择 PDF
          </h2>
          <p className="card-hint">可一次选中多个 PDF，上传后按批次排队解析。</p>
        </div>
        <span className={`badge ${files.length > 0 ? "badge-active" : "badge-pending"}`}>
          已选 {files.length} 个
        </span>
      </div>

      <div className="field">
        <label className="label" htmlFor="pdf-files">
          PDF 文件（可多选）
        </label>
        <input
          id="pdf-files"
          ref={inputRef}
          className={`input ${styles.fileInput}`}
          type="file"
          accept="application/pdf,.pdf"
          multiple
          disabled={uploading}
          aria-describedby="pdf-files-hint"
          // 打开对话框前清空 value：保证连续选同一个文件也会触发 change
          onClick={(event) => {
            event.currentTarget.value = "";
          }}
          onChange={(event) => {
            const selected = Array.from(event.target.files ?? []);
            if (selected.length > 0) onSelect(selected);
          }}
        />
        <p className="hint" id="pdf-files-hint">
          只接受 .pdf 文件；重复选择同一文件会自动去重。
        </p>
      </div>

      {/* 拖拽区域：原生文件对话框不可用/选不中时的替代方式 */}
      <div
        className={`${styles.dropZone} ${dragging ? styles.dropZoneActive : ""}`}
        role="button"
        tabIndex={0}
        aria-label="拖拽 PDF 到这里，或点击打开文件选择框"
        onClick={() => inputRef.current?.click()}
        onKeyDown={(event) => {
          if (event.key === "Enter" || event.key === " ") {
            event.preventDefault();
            inputRef.current?.click();
          }
        }}
        onDragOver={(event) => {
          event.preventDefault();
          setDragging(true);
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={handleDrop}
      >
        {dragging ? "松开即可添加 PDF" : "也可以把多个 PDF 拖到这里"}
      </div>

      <div className="row">
        <button
          type="button"
          className="btn btn-primary"
          onClick={handleUploadClick}
          disabled={uploading}
        >
          {uploading ? (
            <>
              <span className="spinner" aria-hidden="true" />
              正在上传…
            </>
          ) : files.length > 0 ? (
            `上传 ${files.length} 个文件`
          ) : (
            "上传"
          )}
        </button>
        <button type="button" className="btn" onClick={onClear} disabled={uploading || files.length === 0}>
          清空
        </button>
      </div>

      <div className="mt-12">
        {files.length === 0 ? (
          <p className="empty">尚未选择文件：点击上方输入框或把 PDF 拖到这里。</p>
        ) : (
          <>
            <p className="hint">共 {formatBytes(totalBytes)}</p>
            <ul className={styles.fileList}>
              {files.map((file, index) => (
                <li className={styles.fileItem} key={`${index}-${file.name}-${file.size}`}>
                  <span className={styles.fileName} title={file.name}>
                    {file.name}
                  </span>
                  <span className="row">
                    <span className="muted mono">{formatBytes(file.size)}</span>
                    <button
                      type="button"
                      className="btn btn-ghost"
                      onClick={() => onRemove(index)}
                      disabled={uploading}
                      aria-label={`移除 ${file.name}`}
                    >
                      移除
                    </button>
                  </span>
                </li>
              ))}
            </ul>
          </>
        )}
      </div>
    </section>
  );
}
