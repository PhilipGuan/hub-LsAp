"use client";

/**
 * 提问表单：问题文本 + 可选单张图片（缩略预览、可移除），请求中禁用并展示 spinner。
 * 表单不持有业务状态：question/image/pending/error 都由页面（app/qa/page.tsx）传入。
 */

import { useEffect, useState } from "react";

import { formatBytes } from "@/lib/format";

import styles from "./qa.module.css";

/** 与后端 settings.max_question_chars（默认 2000）保持一致，避免前端放过超长问题再被后端拒绝 */
const MAX_QUESTION_CHARS = 2000;

interface QuestionFormProps {
  /** 受控的问题文本 */
  question: string;
  onQuestionChange: (value: string) => void;
  /** 已选配图（null 表示未选） */
  image: File | null;
  onImageChange: (file: File | null) => void;
  /** 提交回调（页面负责校验、请求与错误处理） */
  onSubmit: () => void;
  /** 请求进行中：禁用输入与提交按钮，避免重复提交 */
  pending: boolean;
  /** 接口错误文案（来自 ApiError.message），用 role="alert" 展示 */
  error: string | null;
}

export default function QuestionForm({
  question,
  onQuestionChange,
  image,
  onImageChange,
  onSubmit,
  pending,
  error,
}: QuestionFormProps) {
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  // 预览地址在图片更换/卸载时 revoke：createObjectURL 创建的是进程内引用，不释放会泄漏内存
  useEffect(() => {
    if (!image) {
      setPreviewUrl(null);
      return;
    }
    const url = URL.createObjectURL(image);
    setPreviewUrl(url);
    return () => URL.revokeObjectURL(url);
  }, [image]);

  return (
    <section className="card" aria-labelledby="qa-form-title">
      <h2 className="card-title" id="qa-form-title">
        提问
      </h2>
      <p className="card-hint">支持纯文本，或「文本 + 一张图片」。Ctrl / ⌘ + Enter 可直接提交。</p>
      <form
        className="stack"
        aria-busy={pending}
        onSubmit={(event) => {
          event.preventDefault();
          onSubmit();
        }}
      >
        <div className="field">
          <label className="label" htmlFor="qa-question">
            问题
          </label>
          <textarea
            id="qa-question"
            className="textarea"
            value={question}
            rows={4}
            required
            maxLength={MAX_QUESTION_CHARS}
            disabled={pending}
            aria-describedby="qa-question-hint"
            placeholder="例如：这份文档里，图片资源是如何被检索到的？"
            onChange={(event) => onQuestionChange(event.currentTarget.value)}
            onKeyDown={(event) => {
              if (event.key === "Enter" && (event.ctrlKey || event.metaKey)) {
                event.preventDefault();
                if (!pending) onSubmit();
              }
            }}
          />
          <p className="hint" id="qa-question-hint">
            {question.trim().length} / {MAX_QUESTION_CHARS} 字符
          </p>
        </div>

        <div className="field">
          <label className="label" htmlFor="qa-image">
            配图（可选）
          </label>
          <input
            id="qa-image"
            className={styles.fileInput}
            type="file"
            accept="image/*"
            disabled={pending}
            aria-describedby="qa-image-hint"
            onChange={(event) => {
              onImageChange(event.currentTarget.files?.[0] ?? null);
              event.currentTarget.value = "";
            }}
          />
          <p className="hint" id="qa-image-hint">
            单张图片；选中后可预览、可移除，提交后仍保留以便追问。
          </p>
          {image ? (
            <div className={styles.previewRow}>
              {previewUrl ? (
                <img
                  className={styles.previewImage}
                  src={previewUrl}
                  alt={`已选图片预览：${image.name}`}
                />
              ) : null}
              <div className={styles.previewMeta}>
                <span className={styles.previewName}>{image.name}</span>
                <span className="hint">{formatBytes(image.size)}</span>
                <button
                  type="button"
                  className="btn btn-ghost"
                  disabled={pending}
                  onClick={() => onImageChange(null)}
                >
                  移除图片
                </button>
              </div>
            </div>
          ) : null}
        </div>

        {error ? (
          <p className="alert alert-error" role="alert">
            {error}
          </p>
        ) : null}

        <div className="row-between">
          <button type="submit" className="btn btn-primary" disabled={pending}>
            {pending ? (
              <>
                <span className="spinner" aria-hidden="true" />
                提问中…
              </>
            ) : (
              "提交问题"
            )}
          </button>
          {pending ? (
            <span className="hint" role="status">
              正在生成回答，请稍候…
            </span>
          ) : null}
        </div>
      </form>
    </section>
  );
}
