"use client";

/** 本次会话的历史记录（最近 5 条，最新在上），可清空。 */

import { formatDateTime } from "@/lib/format";
import type { QAResponse } from "@/lib/types";

import AnswerView from "./AnswerView";
import styles from "./qa.module.css";

export interface QaHistoryItem {
  /** 用户这次提的问题（已是 trim 后的文本） */
  question: string;
  /** 后端返回的完整问答结果，历史条目直接复用 AnswerView 渲染 */
  response: QAResponse;
}

interface HistoryListProps {
  /** 最新在前的问答记录（页面已裁剪到 5 条） */
  items: QaHistoryItem[];
  /** 清空本次会话的历史（父组件负责真正的清空动作） */
  onClear: () => void;
}

export default function HistoryList({ items, onClear }: HistoryListProps) {
  return (
    <section className="card" aria-labelledby="qa-history-title">
      <div className="row-between">
        <h2 className="card-title" id="qa-history-title">
          历史记录
        </h2>
        {items.length > 0 ? (
          <button type="button" className="btn btn-danger" onClick={onClear}>
            清空历史
          </button>
        ) : null}
      </div>
      <p className="card-hint">本次会话保留最近 5 条，最新在上；刷新页面后清空。</p>

      {items.length === 0 ? (
        <p className="empty">还没有问答记录，先在上面提一个问题吧。</p>
      ) : (
        <ol className={styles.historyList}>
          {items.map((item) => (
            <li key={item.response.qa_id} className={styles.historyItem}>
              <div className={styles.historyHead}>
                <span className={styles.historyQuestion}>{item.question}</span>
                <span className="hint">{formatDateTime(item.response.created_at)}</span>
              </div>
              <AnswerView response={item.response} />
            </li>
          ))}
        </ol>
      )}
    </section>
  );
}
