"use client";

/**
 * 一次问答的渲染：fallback 提示、answer 兜底正文、图文分段（按顺序）、引用列表。
 * 回答区（最新一条）与历史条目共用本组件，保证两处展示一致。
 */

import { useState } from "react";

import { formatCitation } from "@/lib/format";
import type { AnswerSegment, ImageSegment, QAResponse } from "@/lib/types";

import styles from "./qa.module.css";

function shortId(value: string): string {
  return value.length > 14 ? `${value.slice(0, 12)}…` : value;
}

/** 图片段来源：页码 + 缩短的文档编号 */
function imageOrigin(segment: ImageSegment): string {
  const parts: string[] = [];
  if (segment.page !== null) parts.push(`第 ${segment.page} 页`);
  if (segment.doc_id) parts.push(`文档 ${shortId(segment.doc_id)}`);
  return parts.join(" · ");
}

function segmentKey(segment: AnswerSegment, index: number): string {
  return segment.type === "text"
    ? `text-${index}`
    : `image-${index}-${segment.asset_id}-${segment.asset_url ?? "no-url"}`;
}

function ImageBlock({ segment }: { segment: ImageSegment }) {
  // 签名地址是后端短时签发的，过期后 <img> 会加载失败（也覆盖后端没给地址的情况）：
  // 用本地 broken 标记切换到文字占位，避免页面出现破图图标。
  const [broken, setBroken] = useState(false);
  const src = segment.asset_url;
  const caption = segment.caption || "文档图片";
  const origin = imageOrigin(segment);

  return (
    <figure className={styles.imageSegment}>
      {!src || broken ? (
        <div className={styles.imagePlaceholder}>
          <p className={styles.placeholderTitle}>图片加载失败</p>
          <p className={styles.placeholderText}>{caption}</p>
          <p className="hint">
            {origin ? `${origin} · ` : ""}
            {src ? "签名地址可能已过期，重新提问可获取新地址" : "后端未返回图片地址"}
          </p>
        </div>
      ) : (
        <>
          <img
            className={styles.image}
            src={src}
            alt={caption}
            loading="lazy"
            onError={() => setBroken(true)}
          />
          <figcaption className={styles.imageCaption}>
            <span>{caption}</span>
            {origin ? <span className="hint">{origin}</span> : null}
          </figcaption>
        </>
      )}
    </figure>
  );
}

function SegmentItem({ segment }: { segment: AnswerSegment }) {
  if (segment.type === "text") {
    return <p className={styles.textSegment}>{segment.text}</p>;
  }
  return <ImageBlock segment={segment} />;
}

interface AnswerViewProps {
  /** 后端 POST /api/qa 的完整响应 */
  response: QAResponse;
}

export default function AnswerView({ response }: AnswerViewProps) {
  // 结构化分段可用时只渲染分段（answer 与文本段内容重复）；否则才用 answer 兜底正文。
  // fallback 响应的分段就是 answer 本身（后端会补一个同样的文本段），故一并不再重复渲染。
  const showSegments = !response.fallback && response.segments.length > 0;

  return (
    <div className={styles.answer}>
      {response.fallback ? (
        <p className="alert alert-warning" role="status">
          智能体结构化输出失败，已回退为纯文本回答
        </p>
      ) : null}

      {showSegments ? null : (
        <section aria-label="兜底正文">
          <h3 className={styles.sectionTitle}>兜底正文</h3>
          <p className={styles.answerBody}>{response.answer}</p>
        </section>
      )}

      {showSegments ? (
        <section className={styles.segments} aria-label="图文分段">
          {response.segments.map((segment, index) => (
            <SegmentItem key={segmentKey(segment, index)} segment={segment} />
          ))}
        </section>
      ) : null}

      <section aria-label="引用">
        <h3 className={styles.sectionTitle}>引用</h3>
        {response.citations.length > 0 ? (
          <ol className={styles.citationList}>
            {response.citations.map((citation, index) => (
              <li key={citation.citation_id} className={styles.citationItem}>
                <span className={styles.citationIndex}>{index + 1}</span>
                <span>{formatCitation(citation)}</span>
              </li>
            ))}
          </ol>
        ) : (
          <p className="hint">无引用</p>
        )}
      </section>
    </div>
  );
}
