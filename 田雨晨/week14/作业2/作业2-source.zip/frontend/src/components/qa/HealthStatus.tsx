"use client";

/**
 * 页面顶部的后端健康状态徽标。
 * 只在挂载时检测一次（避免轮询给后端添压力）；失败时给出端口提示，用户可手动重新检测。
 */

import { useEffect, useState } from "react";

import { API_BASE_URL, getHealth } from "@/lib/api";

type HealthState =
  | { status: "checking" }
  | { status: "up"; appEnv: string }
  | { status: "down" };

export default function HealthStatus() {
  const [health, setHealth] = useState<HealthState>({ status: "checking" });
  const [attempt, setAttempt] = useState(0);

  useEffect(() => {
    let cancelled = false;
    setHealth({ status: "checking" });
    getHealth()
      .then((response) => {
        if (!cancelled) setHealth({ status: "up", appEnv: response.app_env });
      })
      .catch(() => {
        if (!cancelled) setHealth({ status: "down" });
      });
    return () => {
      cancelled = true;
    };
  }, [attempt]);

  if (health.status === "checking") {
    return <span className="badge badge-pending">正在检测后端</span>;
  }

  if (health.status === "down") {
    return (
      <div className="row">
        <span className="badge badge-failed">后端未连接</span>
        <span className="hint">请确认后端已在 {API_BASE_URL} 启动（8000 端口）</span>
        <button
          type="button"
          className="btn btn-ghost"
          onClick={() => setAttempt((value) => value + 1)}
        >
          重新检测
        </button>
      </div>
    );
  }

  return (
    <div className="row">
      <span className="badge badge-done">后端在线</span>
      <span className="hint">{health.appEnv}</span>
    </div>
  );
}
