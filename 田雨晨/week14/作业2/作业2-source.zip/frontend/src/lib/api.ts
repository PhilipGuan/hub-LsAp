/**
 * 后端接口封装：前端只消费 HTTP 接口，不直接访问数据库/对象存储。
 * 浏览器直连后端，因此后端必须放行前端来源（CORS_ORIGINS，默认 localhost:3000 / 127.0.0.1:3000）；
 * 所有错误统一转成 ApiError，页面据此展示后端返回的中文提示。
 */

import type {
  BatchStatusResponse,
  BatchUploadResponse,
  DeleteDocumentResponse,
  DocumentInfo,
  DocumentListResponse,
  HealthResponse,
  ImageSegment,
  QAResponse,
  RetryResponse,
  StatusEvent,
} from "./types";

/** 接口根地址：构建时由 NEXT_PUBLIC_API_BASE_URL 注入，去掉结尾斜杠避免拼出双斜杠 */
export const API_BASE_URL = (
  process.env.NEXT_PUBLIC_API_BASE_URL ?? "http://127.0.0.1:8000"
).replace(/\/+$/, "");

/** 带 HTTP 状态码的接口错误：message 已转成可直接展示的中文文案 */
export class ApiError extends Error {
  readonly status: number;

  constructor(status: number, message: string) {
    super(message);
    this.name = "ApiError";
    this.status = status;
  }
}

/**
 * 把失败响应转成 ApiError：业务错误优先取 message，
 * FastAPI 的校验错误在 detail（字符串或 [{msg}] 数组），都解析不出时用状态码兜底。
 */
async function parseError(response: Response): Promise<ApiError> {
  let message = `请求失败（${response.status}）`;
  try {
    const body: unknown = await response.json();
    const record = body as Record<string, unknown> | null;
    if (record && typeof record.message === "string" && record.message) {
      message = record.message;
    } else if (record && typeof record.detail === "string" && record.detail) {
      message = record.detail;
    } else if (record && Array.isArray(record.detail)) {
      const details = record.detail
        .map((item) => (item as Record<string, unknown>)?.msg)
        .filter((value): value is string => typeof value === "string");
      if (details.length > 0) message = details.join("；");
    }
  } catch {
    // 非 JSON 响应：保留默认文案
  }
  return new ApiError(response.status, message);
}

/** 统一请求封装：cache: "no-store" 是必须的——解析状态实时变化，浏览器缓存会读到旧状态 */
async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(`${API_BASE_URL}${path}`, { ...init, cache: "no-store" });
  if (!response.ok) {
    throw await parseError(response);
  }
  return (await response.json()) as T;
}

/** 上传多个 PDF，返回批次编号与文档列表 */
export function uploadBatch(files: File[], signal?: AbortSignal): Promise<BatchUploadResponse> {
  const form = new FormData();
  for (const file of files) {
    form.append("files", file, file.name);
  }
  return request<BatchUploadResponse>("/api/batches", { method: "POST", body: form, signal });
}

/** 批次 + 每个文档的解析状态（轮询兜底） */
export function getBatch(batchId: string, signal?: AbortSignal): Promise<BatchStatusResponse> {
  return request<BatchStatusResponse>(`/api/batches/${encodeURIComponent(batchId)}`, { signal });
}

/** 单文档详情与失败原因 */
export function getDocument(docId: string, signal?: AbortSignal): Promise<DocumentInfo> {
  return request<DocumentInfo>(`/api/documents/${encodeURIComponent(docId)}`, { signal });
}

/** 删除文档（连同切片/图片/解析任务/存储文件）：DELETE /api/documents/{doc_id} */
export function deleteDocument(docId: string): Promise<DeleteDocumentResponse> {
  return request<DeleteDocumentResponse>(`/api/documents/${encodeURIComponent(docId)}`, {
    method: "DELETE",
  });
}

/** 知识库文档列表（最近上传在前）：GET /api/documents */
export function listDocuments(limit = 200): Promise<DocumentListResponse> {
  return request<DocumentListResponse>(`/api/documents?limit=${limit}`);
}

/** 手动重试失败文档 */
export function retryDocument(docId: string): Promise<RetryResponse> {
  return request<RetryResponse>(`/api/documents/${encodeURIComponent(docId)}/retry`, { method: "POST" });
}

/** 多模态问答：问题文本 + 可选用户图片 */
export function askQuestion(
  question: string,
  image?: File | null,
  signal?: AbortSignal,
): Promise<QAResponse> {
  const form = new FormData();
  form.append("question", question);
  if (image) {
    form.append("image", image, image.name);
  }
  return request<QAResponse>("/api/qa", { method: "POST", body: form, signal });
}

/** 后端健康检查（GET /health）：页面顶部用来判断 8000 端口是否可用 */
export function getHealth(): Promise<HealthResponse> {
  return request<HealthResponse>("/health");
}

/**
 * 图片段里的签名地址由后端签发（绝对地址），直接给普通 <img> 用；
 * 不用 next/image：签名地址带过期时间、由后端动态签发，图片优化层会缓存失效地址。
 */
export function segmentImageUrl(segment: ImageSegment): string | null {
  return segment.asset_url;
}

export interface BatchEventHandlers {
  onEvent: (event: StatusEvent) => void;
  onError?: () => void;
}

/**
 * 订阅批次状态 SSE 推送（服务器推送事件）。
 * 断线重连由 EventSource 内建，这里只把「推送不可靠」告知页面，由页面降级为 5 秒轮询兜底。
 * 返回取消订阅函数；页面卸载或切换批次时记得调用。
 */
export function subscribeBatchEvents(batchId: string, handlers: BatchEventHandlers): () => void {
  const source = new EventSource(
    `${API_BASE_URL}/api/batches/${encodeURIComponent(batchId)}/events`,
  );
  const listener = (message: MessageEvent<string>) => {
    try {
      handlers.onEvent(JSON.parse(message.data) as StatusEvent);
    } catch {
      // 坏帧忽略，下一帧或轮询兜底会纠正
    }
  };
  source.addEventListener("status", listener as EventListener);
  source.onerror = () => {
    handlers.onError?.();
  };
  return () => {
    source.removeEventListener("status", listener as EventListener);
    source.close();
  };
}
