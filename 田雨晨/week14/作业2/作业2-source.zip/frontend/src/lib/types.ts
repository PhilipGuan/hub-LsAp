/**
 * 与后端 backend/app/schemas 下的 pydantic 数据结构一一对齐的前端类型。
 * 只做类型声明，不含运行时代码；字段名/枚举值必须与后端保持同步。
 */

/** 单文档解析状态机（对应后端 schemas/enums.py 的 DocumentStatus） */
export type DocumentStatus = "queued" | "parsing" | "indexing" | "retrying" | "done" | "failed";

/** 批次整体状态（对应后端 schemas/enums.py 的 BatchStatus） */
export type BatchStatus = "queued" | "parsing" | "done" | "partial_failed" | "failed";

/** PDF 内抽取资源类型（图片资源按 figure/table/image/other 分类） */
export type AssetType = "figure" | "table" | "image" | "other";

/** 批次内单个文档的摘要状态：POST /api/batches 与 GET /api/batches/{id} 的 documents 元素 */
export interface DocumentRef {
  doc_id: string;
  filename: string;
  status: DocumentStatus;
  error: string | null;
  pages: number;
  display_status: string;
}

/** 上传批次响应：POST /api/batches（一次上传多个 PDF 后立即返回批次号） */
export interface BatchUploadResponse {
  batch_id: string;
  trace_id: string;
  status: BatchStatus;
  documents: DocumentRef[];
  /** 因内容重复（sha256 相同）被跳过的文件名 */
  duplicates: string[];
  created_at: string;
  display_status: string;
}

/** 批次状态响应：GET /api/batches/{batch_id}（5 秒轮询兜底时拉取） */
export interface BatchStatusResponse {
  batch_id: string;
  status: BatchStatus;
  total: number;
  done_count: number;
  failed_count: number;
  active_count: number;
  documents: DocumentRef[];
  created_at: string;
  updated_at: string;
  display_status: string;
}

/** 单文档详情：GET /api/documents/{doc_id}（含 sha256、对象键、尝试次数等内部字段） */
export interface DocumentInfo {
  doc_id: string;
  batch_id: string;
  filename: string;
  sha256: string;
  object_key: string;
  status: DocumentStatus;
  error: string | null;
  pages: number;
  attempts: number;
  created_at: string;
  updated_at: string;
  display_status: string;
}

/** 删除文档响应：DELETE /api/documents/{doc_id} */
export interface DeleteDocumentResponse {
  doc_id: string;
  message: string;
}

/** 知识库文档列表：GET /api/documents（问答页展示当前参与检索的文档） */
export interface DocumentListResponse {
  total: number;
  documents: DocumentInfo[];
}

/** 手动重试响应：POST /api/documents/{doc_id}/retry（message 是给用户看的中文提示） */
export interface RetryResponse {
  doc_id: string;
  status: DocumentStatus;
  message: string;
  display_status: string;
}

/** SSE 推送里的单文档状态（注意：与 DocumentRef 字段不同，没有 batch_id 等冗余字段） */
export interface StatusDocumentItem {
  doc_id: string;
  filename: string;
  status: DocumentStatus;
  error: string | null;
  pages: number;
  display_status: string;
}

/**
 * SSE 推送：一次一个批次的完整状态快照（GET /api/batches/{batch_id}/events）。
 * 帧里没有 done_count/total 等计数字段，前端需按 documents 现算再合并进批次状态。
 */
export interface StatusEvent {
  event: "status";
  batch_id: string;
  status: BatchStatus;
  documents: StatusDocumentItem[];
  ts: string;
  display_status: string;
}

/** 引用条目：/api/qa 响应的 citations 元素（文档 + 页码 + 可选切片/图片资源/版面框） */
export interface Citation {
  citation_id: string;
  doc_id: string;
  doc_filename: string | null;
  chunk_id: string | null;
  asset_id: string | null;
  page: number;
  bbox: number[] | null;
}

/** 回答中的文本段（结构化分段协议的成员，type 作为判别字段） */
export interface TextSegment {
  type: "text";
  text: string;
  sources: string[];
}

/**
 * 回答中的图片段：asset_url 由后端补签（短时签名地址，会过期），
 * 智能体只返回 asset_id；sources 是引用编号列表。
 */
export interface ImageSegment {
  type: "image";
  asset_id: string;
  caption: string;
  sources: string[];
  doc_id: string | null;
  page: number | null;
  asset_url: string | null;
  asset_url_expires_at: string | null;
}

/** 判别联合：按 type 字段区分文本段/图片段，渲染顺序即数组顺序 */
export type AnswerSegment = TextSegment | ImageSegment;

/** 问答响应：POST /api/qa（问题文本 + 可选用户图片 → 结构化图文分段 + 引用） */
export interface QAResponse {
  qa_id: string;
  answer: string;
  segments: AnswerSegment[];
  citations: Citation[];
  created_at: string;
  /** 结构化输出失败、后端退回纯文本时为 true */
  fallback: boolean;
}

/** 后端健康检查响应：GET /health（页面顶部连接状态用） */
export interface HealthResponse {
  status: string;
  app_env: string;
  storage_backend: string;
  queue_backend: string;
}
