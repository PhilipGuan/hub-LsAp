/** 展示层小工具：时间、状态色调、引用文案（纯函数，无副作用，便于 SSR/CSR 结果一致）。 */

import type { BatchStatus, Citation, DocumentStatus } from "./types";

/** 徽标色调：与 globals.css 的 badge-pending/active/done/failed/warning 一一对应 */
export type StatusTone = "pending" | "active" | "done" | "failed" | "warning";

const DOCUMENT_STATUSES: readonly DocumentStatus[] = [
  "queued",
  "parsing",
  "indexing",
  "retrying",
  "done",
  "failed",
];

const BATCH_STATUSES: readonly BatchStatus[] = [
  "queued",
  "parsing",
  "done",
  "partial_failed",
  "failed",
];

/** 收窄判断：后端返回的字符串是否为文档状态（防止未知值直接当状态渲染） */
export function isDocumentStatus(value: string): value is DocumentStatus {
  return (DOCUMENT_STATUSES as readonly string[]).includes(value);
}

/** 收窄判断：后端返回的字符串是否为批次状态 */
export function isBatchStatus(value: string): value is BatchStatus {
  return (BATCH_STATUSES as readonly string[]).includes(value);
}

/** 文档状态对应的徽标色调（展示文案直接用后端给的 display_status）。 */
export function documentStatusTone(status: DocumentStatus): StatusTone {
  switch (status) {
    case "done":
      return "done";
    case "failed":
      return "failed";
    case "parsing":
    case "indexing":
    case "retrying":
      return "active";
    case "queued":
    default:
      return "pending";
  }
}

/** 批次状态徽标色调（注意取值与文档状态不同：partial_failed 是 warning 而非 failed） */
export function batchStatusTone(status: BatchStatus): StatusTone {
  switch (status) {
    case "done":
      return "done";
    case "partial_failed":
      return "warning";
    case "failed":
      return "failed";
    case "parsing":
      return "active";
    case "queued":
    default:
      return "pending";
  }
}

/** 后端时间统一 UTC ISO 串；这里用确定性格式，避免 SSR/CSR 时区不一致造成水合告警。 */
export function formatDateTime(value: string | null | undefined): string {
  if (!value) return "-";
  const compact = value.replace("T", " ").replace("Z", "");
  const withSeconds = compact.split(".")[0];
  return `${withSeconds} UTC`;
}

/** 引用文案：优先用真实文件名，查不到文档时退回文档编号，并带页码 */
export function formatCitation(citation: Citation): string {
  const source = citation.doc_filename ?? citation.doc_id ?? "未知文档";
  return `${source} · 第 ${citation.page} 页`;
}

/** 文件大小人性化展示（B / KB / MB），用于已选文件列表与上传提示 */
export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}
