# 前端（Next.js 16）

只消费后端 HTTP 接口，不直连数据库 / 对象存储。技术栈：Next.js 16（App Router）+ React 19 + TypeScript。

## 页面

| 路由 | 功能 |
| ---- | ---- |
| `/` | 多 PDF 上传（文件选择或拖拽，支持多选）、汇总展示服务启动后上传的全部文档（SSE 推送 + 5 秒轮询兜底）、失败重试与重新解析、刷新后恢复 |
| `/qa` | 多模态问答：问题文本 + 可选用户图片；图文混排分段渲染 + 引用列表 |

## 启动

```bash
cd frontend
npm install
cp .env.local.example .env.local     # 按需改 NEXT_PUBLIC_API_BASE_URL
npm run dev                          # http://localhost:3000
```

生产构建：

```bash
npm run build
npm start
```

## 依赖后端

前端会直接请求 `NEXT_PUBLIC_API_BASE_URL`（默认 `http://127.0.0.1:8000`），需要后端放行 CORS：

```bash
# 后端默认已放行 http://localhost:3000 与 http://127.0.0.1:3000；
# 换域名时启动后端前设置（逗号分隔）：
CORS_ORIGINS=http://localhost:3000,http://127.0.0.1:3000
```

后端与智能体启动方式见 [../backend/README.md](../backend/README.md)：

```bash
uvicorn backend.app.main:create_app --factory --port 8000    # 后端
uvicorn backend.agent.service:create_app --factory --port 8100  # 智能体（问答用）
# 只想看页面/联调、不想启动智能体时：AGENT_STUB=1 起后端
```

## 目录结构

```text
frontend/
├── package.json
├── next.config.ts
├── tsconfig.json
├── .env.local.example         # NEXT_PUBLIC_API_BASE_URL
└── src/
    ├── app/
    │   ├── layout.tsx         # 顶栏 / 页脚
    │   ├── globals.css        # 基础样式与通用组件类
    │   ├── page.tsx           # 上传与解析状态
    │   └── qa/page.tsx        # 多模态问答
    ├── components/
    │   ├── upload/            # 上传面板、批次状态、文档列表
    │   └── qa/                # 问答面板、图文分段渲染、引用列表
    └── lib/
        ├── types.ts           # 与后端 pydantic 数据结构对齐的 TS 类型
        ├── api.ts             # 接口封装（上传/状态/重试/问答/SSE/健康检查）
        └── format.ts          # 时间、状态色调、引用文案
```

## 接口对照

| 前端调用 | 后端接口 |
| ---- | ---- |
| `uploadBatch(files)` | `POST /api/batches` |
| `getBatch(batchId)` | `GET /api/batches/{batch_id}`（5 秒轮询兜底） |
| `subscribeBatchEvents(batchId, handlers)` | `GET /api/batches/{batch_id}/events`（SSE） |
| `getDocument(docId)` | `GET /api/documents/{doc_id}` |
| `listDocuments()` | `GET /api/documents`（知识库文档列表） |
| `deleteDocument(docId)` | `DELETE /api/documents/{doc_id}`（级联删除切片/图片/文件） |
| `retryDocument(docId)` | `POST /api/documents/{doc_id}/retry` |
| `askQuestion(question, image)` | `POST /api/qa` |
| `getHealth()` | `GET /health` |

## 实现约定

- 图片段使用后端签发的短时签名地址（`asset_url`），用普通 `<img>` 渲染；加载失败时展示说明文字占位。
- 状态以数据库为准：页面既订阅 SSE，也每 5 秒拉一次批次状态兜底；刷新后用 `localStorage` 里的批次编号恢复。
- 后端时间统一为 UTC ISO 串，展示层用确定性格式（避免 SSR/CSR 时区不一致导致水合告警）。
- 不做 SSR 数据获取：所有请求都在客户端组件里发起。
