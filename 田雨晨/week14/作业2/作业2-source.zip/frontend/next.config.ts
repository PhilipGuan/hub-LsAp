/** Next.js 配置：纯客户端消费后端接口，构建期不做任何数据获取。 */

import { networkInterfaces } from "node:os";

import type { NextConfig } from "next";

/**
 * Next.js 16 开发服务器默认拦截“跨源”的 dev 资源请求（JS chunk / HMR）：
 * 用 http://127.0.0.1:3000 或局域网 IP（如 http://192.168.x.x:3000）打开页面时，
 * 资源会被拦掉——页面看着正常，但 React 没有水合，
 * 表现为：文件选择后“已选 0 个”、上传按钮点了没反应、拖拽也收不到文件。
 * 这里把本机所有网卡 IP 与 localhost 一起放行，避免换访问地址就“失灵”。
 */
function localDevHosts(): string[] {
  const hosts = new Set(["localhost", "127.0.0.1", "::1"]);
  for (const infos of Object.values(networkInterfaces())) {
    for (const info of infos ?? []) {
      // 只放行非回环的 IPv4 地址（局域网/虚拟网卡），IPv6 暂不处理
      if (info.family === "IPv4" && !info.internal) hosts.add(info.address);
    }
  }
  return [...hosts];
}

const nextConfig: NextConfig = {
  // 开发期用严格模式提前暴露 effect 清理/重复调用等问题（生产构建无副作用）
  reactStrictMode: true,
  allowedDevOrigins: localDevHosts(),
  // 只消费后端 HTTP 接口，不做 SSR 数据获取；接口地址由 NEXT_PUBLIC_API_BASE_URL 注入
};

export default nextConfig;
