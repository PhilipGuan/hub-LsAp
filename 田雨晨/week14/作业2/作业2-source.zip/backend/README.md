# 后端 + 问答智能体（第一版最小实现）

FastAPI + pydantic + SQLAlchemy 后端，加上「固定编排 + 一次轻量决策」的问答智能体。
**默认在本机直接跑，不需要 Docker 或任何外部服务**：数据库用 SQLite、对象存储用本地目录、
消息队列用内存实现、模型可用离线假模型联调。切 Docker 时只改环境变量（见文末）。

## 运行环境

- Python 3.12：本机 conda 环境 `py312`（`D:\Anaconda\envs\py312\python.exe`），依赖见 `requirements.txt`。
- Anaconda base 环境（3.13）**没装 fastapi**，直接用它跑接口模块会 `ModuleNotFoundError`。
  `test/selfcheck.py`（仓库根的 `test/` 下）会自动检测并切换到 py312；PyCharm 里把解释器设成 py312 即可。

## 目录结构

```text
backend/
├── requirements.txt          # 依赖（本地 py312 已装齐）
├── workflow.py               # ★ 问答代码编排入口：固定顺序调用节点与工具、单步失败兜底
├── app/                      # 后端服务（接口 / 业务 / 数据结构 / 存储）
│   ├── config.py             # 配置（环境变量 / 本地默认值）
│   ├── common.py             # 编号生成、UTC 时间
│   ├── errors.py             # 业务异常 -> HTTP 状态码
│   ├── db.py                 # 引擎、会话、建表（表结构由后端负责初始化）
│   ├── main.py               # FastAPI 入口 create_app() + 路由注册
│   ├── schemas/              # ★ pydantic 数据结构（单独存放）
│   │   ├── enums.py          # 状态机枚举、前端展示映射
│   │   ├── batch.py          # 批次 / 文档 / 解析任务 / 状态响应
│   │   ├── content.py        # 文本切片 / 图片资源 / 引用 / 签名地址
│   │   ├── qa.py             # 问答请求响应 / 图文分段 / 智能体契约
│   │   └── events.py         # Kafka 消息 / 事务发件箱 / SSE 状态事件
│   ├── models/tables.py      # SQLAlchemy 表结构
│   ├── clients/              # 对象存储、消息队列、智能体 HTTP 客户端
│   ├── services/             # 上传、文档状态机、发件箱、问答、签名
│   ├── events/sse.py         # 状态推送中心（订阅 / 发布 / 心跳）
│   └── api/                  # HTTP 接口层
└── agent/                    # 问答编排智能体（独立服务 :8100，只读检索数据）
    ├── base.py               # OpenAI 兼容 chat/completions 基类（视觉可用）
    ├── config.py             # 模型密钥（读 deploy/.env 的 VLM_*/EMBEDDING_*）、检索参数
    ├── prompt_loader.py      # jinja2 渲染 prompt/*.j2
    ├── llm.py                # LLMClient 协议 + 真实 VLM + 离线假模型 StubLLM
    ├── embedding.py          # 文本向量客户端 + 余弦相似度 + 假向量
    ├── fixtures.py           # 离线自测数据（临时 SQLite）
    ├── tools/                # 文本检索 / 图片加载 / 用户图片描述 / 引用构建
    ├── graph/                # 编排节点：planner（一次决策）+ synthesizer（结构化回答 + 回退）
    ├── prompt/               # planner / synthesizer / image_caption 提示词
    └── service.py            # FastAPI 入口 POST /answer（不对外暴露）
```

## 每个文件都有 main，可直接运行自测

在**仓库根目录**执行（模块方式运行，main 里打印中文过程并做 assert 自检）：

```bash
# 后端
python -m backend.app.config            # 配置
python -m backend.app.db                # 建表与读写
python -m backend.app.schemas           # pydantic 数据结构总览
python -m backend.app.clients.storage   # 本地对象存储
python -m backend.app.clients.queue     # 内存消息队列
python -m backend.app.clients.agent     # 智能体客户端（含 MockTransport）
python -m backend.app.events.sse        # 状态推送中心
python -m backend.app.services.upload   # 上传批次（含非法文件用例）
python -m backend.app.services.document # 状态机、自动重试、死信
python -m backend.app.services.qa       # 图文问答、签名地址、回退
python -m backend.app.services.outbox   # 事务发件箱投递
python -m backend.app.services.asset    # 图片签名地址
python -m backend.app.api.upload        # 接口：上传
python -m backend.app.api.documents     # 接口：状态 / 重试 / SSE
python -m backend.app.api.qa            # 接口：问答
python -m backend.app.api.assets        # 接口：签名图片读取
python -m backend.app.main              # 打印全部路由并冒烟调用

# 问答智能体
python -m backend.agent.config          # 模型配置（密钥打码）
python -m backend.agent.prompt_loader   # 提示词渲染
python -m backend.agent.llm             # 假模型 / 消息组装
python -m backend.agent.embedding       # 假向量 + 余弦相似度
python -m backend.agent.fixtures        # 自测数据
python -m backend.agent.tools.text_search      # 向量检索 + 关键词降级
python -m backend.agent.tools.image_load       # 关联图片加载
python -m backend.agent.tools.image_caption    # 用户图片描述
python -m backend.agent.tools.citation_builder # 引用构建
python -m backend.agent.graph.planner          # 一次轻量决策
python -m backend.agent.graph.synthesizer      # 结构化回答 + 回退
python -m backend.workflow               # 完整编排（离线假模型）
python -m backend.agent.service         # 智能体 HTTP 接口自测
```

一键全部跑一遍（脚本在仓库根的 `test/selfcheck.py`，共 43 个模块）：

```bash
python test/selfcheck.py        # PASS / FAIL 汇总
python test/selfcheck.py -v     # 同时打印每个模块输出尾部
python test/selfcheck.py services   # 只跑名字含 services 的模块
python test/selfcheck.py agent      # 只跑智能体模块
```

也可以在 PyCharm 里直接 Run 单个文件（文件顶部已做 sys.path 兜底，直接运行也能找到包）。
Windows 控制台若中文乱码，先设置 `set PYTHONIOENCODING=utf-8`。

## 启动服务

> 仓库根目录还有一键启动脚本：`python start_all.py`（后端 + 解析工作器 + 智能体 + 前端），
> 支持 `--real-models` / `--no-agent` / `--no-frontend`；下面是手动分终端启动方式。

后端（端口 8000）与智能体（端口 8100）是两个进程，智能体只读数据库、不对外暴露；解析工作器（`parse-worker/`）单独一个进程，负责把上传的 PDF 解析入库。

```bash
# 1) 先起后端：会初始化数据库表
uvicorn backend.app.main:create_app --factory --host 127.0.0.1 --port 8000

# 2) 解析工作器（默认本地 PyMuPDF 文本解析 + 假向量；真实 MinerU 见 parse-worker/README.md）
WORKER_STUB_MODELS=1 python parse-worker/worker.py --serve

# 3) 再起智能体（真实模型，密钥读 deploy/.env 的 VLM_* / EMBEDDING_*）
uvicorn backend.agent.service:create_app --factory --host 127.0.0.1 --port 8100
```

- 后端接口文档：<http://127.0.0.1:8000/docs>，健康检查：<http://127.0.0.1:8000/health>
- 智能体健康检查：<http://127.0.0.1:8100/health>，契约接口：`POST /answer`
- 前端（Next.js，另开一个终端）：`cd frontend && npm install && cp .env.local.example .env.local && npm run dev`，
  页面 <http://localhost:3000>；后端已默认放行它的来源（见下方 CORS 说明）。
- 本地联调不想消耗真实模型额度时，两边都可以用离线假模型：

```bash
# 智能体用离线假模型（不调真实 VLM / embedding）
AGENT_STUB_LLM=1 uvicorn backend.agent.service:create_app --factory --port 8100
# 后端不启智能体服务时，用离线假智能体兜底问答链路
AGENT_STUB=1 uvicorn backend.app.main:create_app --factory --port 8000
```

## 接口一览

后端：

| 方法 | 路径 | 说明 |
| ---- | ---- | ---- |
| POST | `/api/batches` | 多 PDF 上传，返回批次编号与文档列表 |
| GET | `/api/batches/{batch_id}` | 批次 + 每个文档的解析状态（轮询兜底） |
| GET | `/api/batches/{batch_id}/events` | SSE 状态推送（含心跳） |
| GET | `/api/documents/{doc_id}` | 单文档详情与失败原因 |
| POST | `/api/documents/{doc_id}/retry` | 手动重试失败文档 |
| POST | `/api/qa` | 多模态问答：`question` + 可选 `image` |
| GET | `/api/assets/{asset_id}?expires=&signature=` | 短时签名图片地址 |
| GET | `/health` | 健康检查 |

智能体（内部，仅后端调用）：

| 方法 | 路径 | 说明 |
| ---- | ---- | ---- |
| POST | `/answer` | 入参 `{question, image?, top_k}`，出参 `AgentResponse`（answer + segments + citations） |
| GET | `/health` | 健康检查 |

问答返回结构化分段：`answer`（兜底正文）+ `segments`（文本段/图片段）+ `citations`（文档、页码、切片、图片资源、版面框）。
图片段里的 `asset_url` 是后端签发的短时地址，过期或被篡改返回 403。

## 智能体编排流程

```text
用户问题（+ 可选图片）
  ├─ 1. 有用户图片 → 图片描述工具（VLM）→ caption / OCR 文字
  ├─ 2. 规划节点（一次决策）→ 是否检索 + 检索查询
  ├─ 3. 文本检索工具：查询向量 → 切片余弦相似度（无向量时关键词降级）
  ├─ 4. 图片加载工具：切片直连资源 + 同文档同页邻近资源
  ├─ 5. 引用构建工具：确定性引用编号（cit_<资源编号>）
  └─ 6. 合成节点（VLM）：结构化 JSON → 校验分段/引用
           └─ 结构化失败 → 回退纯文本回答 + 引用列表
```

- 智能体只读数据库（`select`），不写业务表，也不跑建表 DDL（表结构由后端初始化）。
- 每个工具都有失败兜底：单步失败不阻断问答，编排层记录告警后继续。
- 检索先用「切片向量 + 图片说明/OCR/邻近文本」，不单独建图片向量索引。

## 状态机

```text
queued(待解析) -> parsing(解析中) -> indexing(索引中) -> done(解析完成)
                     |                  |
                     v                  v
              retrying(重试中) -> 自动重试 3 次 -> failed(解析失败) -> 死信
                                                  ^
                                    手动重试 ------+
```

- 状态只在数据库里流转，Kafka 消息只用于异步触发。
- 解析请求经**事务发件箱**落库后由 `services/outbox.py` 投递，消费端幂等。
- 失败自动重试 `MAX_PARSE_RETRIES`（默认 3）次，耗尽后写死信事件；前端可手动重试。

## 本地默认 vs Docker 部署

| 组件 | 本地默认 | Docker 阶段（未接线） |
| ---- | ---- | ---- |
| 数据库 | SQLite：`backend/data/app.db` | `DATABASE_URL=postgresql://...` + psycopg |
| 对象存储 | 本地目录：`backend/data/storage` | MinIO（`clients/storage.py` 换实现） |
| 消息队列 | 内存队列 | Kafka/Redpanda（`clients/queue.py` 已留 KafkaQueue） |
| 智能体 | 独立进程 `backend.agent.service`（:8100）；`AGENT_STUB_LLM=1` 用离线假模型 | `AGENT_SERVICE_URL=http://agent:8100` |
| 后端问答 | 走 HTTP 调智能体；`AGENT_STUB=1` 用离线假智能体 | 同左 |
| 图片地址 | 后端 HMAC 签名 + 自己转发文件 | 同上，或 MinIO 预签名 |

`APP_ENV=local`（默认）时不读 `deploy/.env`，避免连不上 Docker 内部地址；非 local 时才会加载。
模型密钥（`VLM_*` / `EMBEDDING_*`）例外：智能体从 `deploy/.env` 按需读取这几项，不会带出其它变量。
所有后端配置项见 `backend/app/config.py`，字段名大写即环境变量名。

**前端联调（CORS）**：默认放行 `http://localhost:3000` 与 `http://127.0.0.1:3000`（Next.js 开发服务器）。
换来源时用逗号分隔设置 `CORS_ORIGINS`，例如 `CORS_ORIGINS=http://localhost:3000,http://192.168.1.5:3000`；
`CORS_ORIGINS=*` 表示放开所有来源（仅本地调试用）。SSE 与签名图片地址都走同一套 CORS 配置。

## 常见问题

- **`ModuleNotFoundError: No module named 'fastapi'`**：用成了 Anaconda base 3.13。改用 py312，或直接
  `python test/selfcheck.py`（会自动切换解释器）；PyCharm 把解释器设为 conda py312。
- **`No module named backend`**：命令必须在仓库根目录（含 `backend/` 的那一层）执行，
  `python -m backend.app.xxx` 不能在 `backend/` 目录里面跑。
- **`sqlite3.OperationalError: table documents already exists`**：两个进程同时跑建表。先起后端再起智能体；
  智能体不建表。
- **问答返回 502**：智能体服务没起或地址不对，检查 `AGENT_SERVICE_URL` 与 `:8100/health`；
  本地联调可用 `AGENT_STUB=1` 跳过智能体服务。
- **前端跨域报错 / SSE 一连就断**：前端来源不在 CORS 白名单里。默认放行 `localhost:3000`、`127.0.0.1:3000`
  以及本机/局域网 IP（正则匹配），换域名或公网来源时用逗号分隔补 `CORS_ORIGINS`。
- **中文乱码**：`set PYTHONIOENCODING=utf-8`（PowerShell：`$env:PYTHONIOENCODING="utf-8"`）。
