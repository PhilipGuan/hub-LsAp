"""模型连通性封装的基类：OpenAI 兼容的 chat/completions 调用。

在链路中的位置：`backend.agent.llm.llm_from_settings` 在配置了真实 `VLM_*` 时构造
`BaseAgent`，规划节点与回答合成节点都通过它的 `chat` / `chat_json` 调模型；离线自测走
`llm.StubLLM`，不会走到这里。

模型密钥按需从环境变量或 deploy/.env 读取（不在 import 时 load_dotenv，
避免把 deploy/.env 里的 Docker 内部地址注入 os.environ）。
"""

import json
import os
from pathlib import Path

import requests

ENV_FILE = Path(__file__).resolve().parents[2] / "deploy" / ".env"


def model_env(name: str) -> str:
    """环境变量优先，其次 deploy/.env，最后空串。"""
    value = os.getenv(name, "").strip()
    if value:
        return value
    if ENV_FILE.exists():
        from dotenv import dotenv_values

        return (dotenv_values(ENV_FILE).get(name) or "").strip()
    return ""


class BaseAgent:
    """OpenAI 兼容 `/chat/completions` 的最小客户端（真实 VLM 模式用）。"""

    def __init__(self, model=None, timeout=60, base_url=None, api_key=None):
        """读取模型配置并校验；缺配置立即报错，避免运行到一半才发现没有密钥。"""
        base = base_url if base_url is not None else model_env("VLM_API_BASE")
        key = api_key if api_key is not None else model_env("VLM_API_KEY")
        if not base or not key or "REPLACE_WITH" in key:
            raise RuntimeError("VLM_API_BASE / VLM_API_KEY 未配置，请检查 deploy/.env")
        self.base_url = base.rstrip("/")
        self.api_key = key
        self.model = model or model_env("VLM_MODEL")
        if not self.model:
            raise RuntimeError("VLM_MODEL 未配置，请检查 deploy/.env")
        self.timeout = timeout

    def chat(self, messages):
        """发一次 chat/completions，返回 assistant 文本；HTTP/超时异常抛给调用方兜底。"""
        resp = requests.post(
            f"{self.base_url}/chat/completions",
            headers={"Authorization": f"Bearer {self.api_key}"},
            json={"model": self.model, "messages": messages},
            timeout=self.timeout,
        )
        resp.raise_for_status()
        return resp.json()["choices"][0]["message"].get("content") or ""

    def chat_json(self, messages):
        """把 chat 的文本解析成 dict；容忍 ```json 围栏，非 JSON/非 dict 一律返回 None。

        返回 None 是刻意设计：由规划/合成节点按“非法输出兜底”处理，不在客户端层猜内容。
        """
        text = self.chat(messages).strip()
        if text.startswith("```"):
            text = text.split("\n", 1)[-1].rsplit("```", 1)[0].strip()
        try:
            payload = json.loads(text)
        except json.JSONDecodeError:
            return None
        return payload if isinstance(payload, dict) else None

    def run(self, *args, **kwargs):
        """旧版扩展点：第一版没有任何实现，保留仅为兼容历史调用。"""
        raise NotImplementedError
