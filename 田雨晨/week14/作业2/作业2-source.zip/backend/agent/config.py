"""智能体配置：模型接口、检索参数、提示词目录。

在链路中的位置：`build_agent_settings` 供 `llm_from_settings` / `embedding_from_settings`
以及智能体服务、解析工作器复用；其中 `llm_stub` 控制是否走离线假模型（AGENT_STUB_LLM=1），
保证本地联调不产生真实模型调用。

模型密钥沿用 `deploy/.env` 里的 `VLM_*` / `EMBEDDING_*`；这里只读取这几个键，
不会把 deploy/.env 里的 `DATABASE_URL` 等 Docker 内部地址带进本地默认配置。
"""

import os
from functools import lru_cache
from pathlib import Path

from dotenv import dotenv_values
from pydantic import BaseModel, ConfigDict, Field

from backend.app.config import DEPLOY_ENV_FILE

DEFAULT_PROMPT_DIR = Path(__file__).resolve().parent / "prompt"
MODEL_ENV_KEYS = (
    "VLM_API_BASE",
    "VLM_API_KEY",
    "VLM_MODEL",
    "EMBEDDING_API_BASE",
    "EMBEDDING_API_KEY",
    "EMBEDDING_MODEL",
)


def _model_env() -> dict[str, str]:
    """deploy/.env 里的模型配置，环境变量优先。"""
    file_values = dotenv_values(DEPLOY_ENV_FILE) if DEPLOY_ENV_FILE.exists() else {}
    values: dict[str, str] = {}
    for key in MODEL_ENV_KEYS:
        values[key.lower()] = (os.getenv(key) or file_values.get(key) or "").strip()
    return values


class AgentSettings(BaseModel):
    """智能体运行配置（数据库连接复用 backend 的 Settings）。"""

    model_config = ConfigDict(arbitrary_types_allowed=True)

    # 多模态大模型 / 视觉语言模型
    vlm_api_base: str = ""
    vlm_api_key: str = ""
    vlm_model: str = "deepseek-flash"
    # 文本向量模型
    embedding_api_base: str = ""
    embedding_api_key: str = ""
    embedding_model: str = "qwen3.7-text-embedding-flash"
    # 检索参数集中在这里，工具层只读配置、不各自写死阈值，便于统一调参
    top_k: int = Field(6, ge=1, le=50)
    max_context_chunks: int = Field(8, ge=1, le=50)
    max_context_assets: int = Field(4, ge=1, le=50)
    max_citations: int = Field(8, ge=1, le=50)
    retrieval_min_score: float = Field(0.15, ge=0.0, le=1.0)
    # 调用
    llm_timeout_s: float = Field(60.0, gt=0)
    prompt_dir: Path = DEFAULT_PROMPT_DIR
    llm_stub: bool = False  # AGENT_STUB_LLM=1：本地联调用离线假模型，不产生真实调用

    @property
    def has_real_models(self) -> bool:
        """是否配置了真实 VLM（地址与密钥都非空）。"""
        return bool(self.vlm_api_base and self.vlm_api_key)

    @property
    def has_real_embedding(self) -> bool:
        """是否配置了真实向量模型（地址与密钥都非空）。"""
        return bool(self.embedding_api_base and self.embedding_api_key)

    def summary(self) -> dict:
        """打印用摘要，密钥只留尾部。"""

        def mask(value: str) -> str:
            """密钥脱敏：只留最后 4 位，空值显示未配置。"""
            if not value:
                return "<未配置>"
            return "***" + value[-4:] if len(value) > 4 else "***"

        return {
            "vlm_model": self.vlm_model,
            "vlm_api_base": self.vlm_api_base or "<未配置>",
            "vlm_api_key": mask(self.vlm_api_key),
            "embedding_model": self.embedding_model,
            "embedding_api_base": self.embedding_api_base or "<未配置>",
            "embedding_api_key": mask(self.embedding_api_key),
            "top_k": self.top_k,
            "max_context_chunks": self.max_context_chunks,
            "max_context_assets": self.max_context_assets,
            "retrieval_min_score": self.retrieval_min_score,
            "llm_stub": self.llm_stub,
            "prompt_dir": str(self.prompt_dir),
        }


def build_agent_settings(stub: bool | None = None) -> AgentSettings:
    """按 deploy/.env + 环境变量构造配置；stub 可显式指定离线假模型。"""
    env = _model_env()
    if stub is None:
        stub = os.getenv("AGENT_STUB_LLM", "").strip().lower() in {"1", "true", "yes"}
    return AgentSettings(
        vlm_api_base=env["vlm_api_base"],
        vlm_api_key=env["vlm_api_key"],
        vlm_model=env["vlm_model"] or "deepseek-flash",
        embedding_api_base=env["embedding_api_base"],
        embedding_api_key=env["embedding_api_key"],
        embedding_model=env["embedding_model"] or "qwen3.7-text-embedding-flash",
        prompt_dir=DEFAULT_PROMPT_DIR,
        llm_stub=stub,
    )


@lru_cache
def get_agent_settings() -> AgentSettings:
    """进程内缓存的配置单例（测试里用 reset_agent_settings_cache 清缓存）。"""
    return build_agent_settings()


def reset_agent_settings_cache() -> None:
    """清空配置缓存：改过环境变量或 deploy/.env 后重新读取。"""
    get_agent_settings.cache_clear()


def main() -> None:
    """自检：打印脱敏配置摘要、确认提示词齐全、确认离线假模型开关生效。"""
    settings = get_agent_settings()
    print("[agent.config] 配置摘要:")
    for key, value in settings.summary().items():
        print(f"  {key}: {value}")

    assert settings.prompt_dir.is_dir(), "提示词目录不存在"
    prompts = sorted(path.name for path in settings.prompt_dir.glob("*.j2"))
    print("[agent.config] 提示词:", prompts)
    assert len(prompts) >= 3, "提示词文件不全"

    stub = build_agent_settings(stub=True)
    print("[agent.config] 离线假模型模式:", stub.llm_stub)
    assert stub.llm_stub is True
    print("[agent.config] 自检通过")


if __name__ == "__main__":
    main()
