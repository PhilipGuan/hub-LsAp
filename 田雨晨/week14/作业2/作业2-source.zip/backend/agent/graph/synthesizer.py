"""回答合成节点：把检索上下文交给多模态大模型，产出图文混排的分段回答。

在链路中的位置：`workflow.answer` 的最后一步，输入是问题、图片描述、检索切片、
图片资源与引用列表，输出直接作为智能体服务的 `AgentResponse`。

结构化输出（JSON）不可靠，这里逐项校验：answer 必须非空，segments 必须能按判别联合
解析，图片段只能引用真实存在的图片资源，文本段必须有内容，每段的 sources 只能来自
输入引用；过滤后没有合法段就回退纯文本回答。引用列表始终原样带回输入引用——
智能体不新增引用（README：citations 原样带回）。不联网、不写库，只调用模型。
"""

if __package__ in (None, ""):  # 允许直接运行本文件
    import sys
    from pathlib import Path

    for _root in Path(__file__).resolve().parents:
        if (_root / "backend" / "app").is_dir():
            sys.path.insert(0, str(_root))
            break

import json

from pydantic import ValidationError

from backend.agent.config import AgentSettings
from backend.agent.llm import SYNTHESIZER_MARKER, LLMClient, StubLLM, build_text_messages
from backend.agent.prompt_loader import PromptLoader
from backend.app.schemas.content import Citation, ImageAsset, TextChunk
from backend.app.schemas.qa import AgentResponse, ImageSegment, TextSegment

# 结构化输出失败、纯文本回退也失败时的固定文案
FALLBACK_ANSWER = "根据提供的资料无法回答该问题。"
PLAIN_INSTRUCTION = "请直接用中文回答，不要输出 JSON 或 Markdown 代码块。"


class Synthesizer:
    """回答合成节点：结构化优先，校验不过就回退纯文本 + 引用。"""

    def __init__(self, llm: LLMClient, prompts: PromptLoader, settings: AgentSettings | None = None) -> None:
        """注入模型客户端、提示词加载器与配置（配置目前只预留，不参与校验逻辑）。"""
        self.llm = llm
        self.prompts = prompts
        # 预留配置位（如段数/上下文裁剪），当前节点只做校验与回退，不读取
        self.settings = settings

    def synthesize(
        self,
        question: str,
        image_caption: str,
        chunks: list[TextChunk],
        assets: list[ImageAsset],
        citations: list[Citation],
    ) -> AgentResponse:
        """生成结构化回答；任何模型异常都在内部兜底，不向上抛。"""
        citations = list(citations)
        prompt = self.prompts.render(
            "synthesizer",
            question=question,
            image_caption=image_caption,
            chunks=chunks,
            assets=assets,
            citations_json=json.dumps(
                [citation.model_dump(mode="json") for citation in citations], ensure_ascii=False
            ),
        )
        try:
            data = self.llm.chat_json(build_text_messages(prompt))
        except Exception as error:  # 模型超时/网络错误：直接走纯文本回退
            print(f"[agent.graph.synthesizer] 结构化输出调用失败: {error}")
            data = None

        structured = self._clean(data, assets, citations)
        if structured is not None:
            return structured
        return self._fallback(prompt, citations)

    @staticmethod
    def _clean(data: object, assets: list[ImageAsset], citations: list[Citation]) -> AgentResponse | None:
        """校验模型 JSON 并过滤非法段；返回 None 表示需要走纯文本回退。"""
        if not isinstance(data, dict):
            return None
        answer = data.get("answer")
        if not isinstance(answer, str) or not answer.strip():
            return None
        segments = data.get("segments")
        if not isinstance(segments, list):
            return None
        try:
            parsed = AgentResponse.model_validate(
                {"answer": answer.strip(), "segments": segments, "citations": citations}
            )
        except ValidationError as error:
            print(f"[agent.graph.synthesizer] 分段结构非法（{error.error_count()} 处），回退纯文本")
            return None

        asset_ids = {asset.asset_id for asset in assets}
        citation_ids = {citation.citation_id for citation in citations}
        kept: list[TextSegment | ImageSegment] = []
        for segment in parsed.segments:
            # 图片段只认上下文里真实出现过的 asset_id：模型编造的编号必须丢弃，
            # 且智能体只回编号，签名地址由后端补全（README 调用约束）
            if isinstance(segment, ImageSegment) and segment.asset_id not in asset_ids:
                print(f"[agent.graph.synthesizer] 丢弃不存在的图片段: {segment.asset_id}")
                continue
            if isinstance(segment, TextSegment) and not segment.text.strip():
                print("[agent.graph.synthesizer] 丢弃空文本段")
                continue
            # 段只能引用输入引用列表里已有的 citation_id
            segment.sources = [source for source in segment.sources if source in citation_ids]
            kept.append(segment)
        if not kept:
            print("[agent.graph.synthesizer] 过滤后没有合法分段，回退纯文本")
            return None
        # 引用强制使用输入引用：模型回传的 citations 一律忽略（智能体不新增引用）
        return AgentResponse(answer=answer.strip(), segments=kept, citations=citations)

    def _fallback(self, prompt: str, citations: list[Citation]) -> AgentResponse:
        """结构化失败后的兜底：再问一次纯文本，仍失败就用固定文案。"""
        plain = ""
        try:
            plain = self.llm.chat(
                [
                    {"role": "system", "content": prompt},
                    {"role": "user", "content": PLAIN_INSTRUCTION},
                ]
            )
        except Exception as error:  # 纯文本回退也失败：用固定文案保证节点总能返回
            print(f"[agent.graph.synthesizer] 纯文本回退失败: {error}")
        plain = (plain or "").strip()
        if not plain:
            plain = FALLBACK_ANSWER
        return AgentResponse(answer=plain, segments=[TextSegment(text=plain)], citations=citations)


class _PlainTextLLM:
    """chat_json 返回指定的（可能是非法的）结构，chat 返回纯文本：验证回退分支。"""

    def __init__(self, payload: object, plain: str) -> None:
        """保存要返回的结构化载荷与纯文本回答。"""
        self.payload = payload
        self.plain = plain

    def chat_json(self, messages: list[dict]) -> object:
        """返回预设的结构化载荷（可能是非法结构，由节点负责识别）。"""
        return self.payload

    def chat(self, messages: list[dict]) -> str:
        """返回预设的纯文本回答，模拟“结构化失败但还能说人话”的模型。"""
        return self.plain


class _BrokenLLM:
    """chat_json 与 chat 都抛异常的假模型：验证 synthesize 不把异常抛给编排层。"""

    def chat_json(self, messages: list[dict]) -> dict | None:
        """模拟模型服务不可用。"""
        raise RuntimeError("模型服务不可用")

    def chat(self, messages: list[dict]) -> str:
        """模拟模型服务不可用（纯文本回退也失败）。"""
        raise RuntimeError("模型服务不可用")


def main() -> None:
    """自检：覆盖结构化成功、非法段过滤、非 JSON 回退、异常回退、空结果回退。"""
    from backend.agent.config import build_agent_settings
    from backend.app.common import new_id

    prompts = PromptLoader()
    question = "这个系统由哪些部分组成？"
    image_caption = "用户上传了一张系统架构图"
    doc_id = new_id("doc")
    assets = [
        ImageAsset(
            asset_id=new_id("asset"),
            doc_id=doc_id,
            page=1,
            object_key="assets/demo/figure-1.png",
            caption="系统架构图",
            ocr_text="前端 后端 问答智能体 解析工作器",
            bbox=[72.0, 120.0, 480.0, 360.0],
        )
    ]
    chunks = [
        TextChunk(
            chunk_id=new_id("chunk"),
            doc_id=doc_id,
            page=1,
            seq=0,
            text="系统架构由前端网页、后端服务、问答编排智能体和解析工作器组成。",
            asset_id=assets[0].asset_id,
        ),
        TextChunk(
            chunk_id=new_id("chunk"),
            doc_id=doc_id,
            page=2,
            seq=1,
            text="解析工作器调用 MinerU 把 PDF 解析成 Markdown、版面 JSON 和图片资源。",
        ),
    ]
    citations = [
        Citation(
            citation_id=new_id("cit"),
            doc_id=doc_id,
            doc_filename="智能体自测.pdf",
            chunk_id=chunks[0].chunk_id,
            asset_id=assets[0].asset_id,
            page=1,
            bbox=assets[0].bbox,
        ),
        Citation(
            citation_id=new_id("cit"),
            doc_id=doc_id,
            doc_filename="智能体自测.pdf",
            chunk_id=chunks[1].chunk_id,
            page=2,
        ),
    ]
    valid_citation_id = citations[0].citation_id
    print(f"[agent.graph.synthesizer] 上下文: 切片 {len(chunks)} 条, 图片资源 {len(assets)} 个, 引用 {len(citations)} 条")

    print("[agent.graph.synthesizer] 场景一：默认假模型（结构化输出成功）")
    synthesizer = Synthesizer(StubLLM(), prompts, build_agent_settings(stub=True))
    response = synthesizer.synthesize(question, image_caption, chunks, assets, citations)
    print("[agent.graph.synthesizer]   回答:", response.answer, "| 分段:", [segment.type for segment in response.segments])
    assert response.answer.strip()
    assert response.citations == citations, "引用必须原样带回输入引用"
    assert any(segment.type == "text" for segment in response.segments)

    print("[agent.graph.synthesizer] 场景二：图片段的 asset_id 不存在 → 丢弃图片段")
    llm = StubLLM(
        {
            SYNTHESIZER_MARKER: {
                "answer": "看图",
                "segments": [
                    {"type": "image", "asset_id": "asset_不存在", "caption": "x"},
                    {"type": "text", "text": "有图"},
                ],
                "citations": [],
            }
        }
    )
    response = Synthesizer(llm, prompts).synthesize(question, image_caption, chunks, assets, citations)
    print("[agent.graph.synthesizer]   回答:", response.answer, "| 分段:", [segment.type for segment in response.segments])
    assert [segment.type for segment in response.segments] == ["text"]
    assert isinstance(response.segments[0], TextSegment) and response.segments[0].text == "有图"
    assert response.citations == citations

    print("[agent.graph.synthesizer] 场景三：模型没吐 JSON → 回退纯文本 + 引用")
    response = Synthesizer(StubLLM({SYNTHESIZER_MARKER: None}), prompts).synthesize(
        question, image_caption, chunks, assets, citations
    )
    print("[agent.graph.synthesizer]   回答:", response.answer)
    assert len(response.segments) == 1 and isinstance(response.segments[0], TextSegment)
    assert response.answer == response.segments[0].text and response.answer.strip()
    assert response.citations == citations

    print("[agent.graph.synthesizer] 场景四：结构化调用抛异常 → 固定文案，不向上抛")
    response = Synthesizer(_BrokenLLM(), prompts).synthesize(question, image_caption, chunks, assets, citations)
    print("[agent.graph.synthesizer]   回答:", response.answer)
    assert response.answer == FALLBACK_ANSWER
    assert isinstance(response.segments[0], TextSegment) and response.segments[0].text == FALLBACK_ANSWER
    assert response.citations == citations

    print("[agent.graph.synthesizer] 场景五：sources 过滤 + 空文本段丢弃 + 引用强制回带")
    llm = StubLLM(
        {
            SYNTHESIZER_MARKER: {
                "answer": "系统由前端、后端、问答智能体、解析工作器组成。",
                "segments": [
                    {
                        "type": "text",
                        "text": "系统由前端、后端、问答智能体、解析工作器组成。",
                        "sources": [valid_citation_id, "cit_伪造"],
                    },
                    {"type": "text", "text": "   ", "sources": [valid_citation_id]},
                    {
                        "type": "image",
                        "asset_id": assets[0].asset_id,
                        "caption": "系统架构图",
                        "sources": [valid_citation_id, "cit_伪造"],
                    },
                ],
                "citations": [],
            }
        }
    )
    response = Synthesizer(llm, prompts).synthesize(question, image_caption, chunks, assets, citations)
    print("[agent.graph.synthesizer]   回答:", response.answer, "| 分段:", [segment.type for segment in response.segments])
    assert len(response.segments) == 2, "空文本段应被丢弃"
    text_segment, image_segment = response.segments
    assert isinstance(text_segment, TextSegment) and text_segment.sources == [valid_citation_id]
    assert isinstance(image_segment, ImageSegment) and image_segment.asset_id == assets[0].asset_id
    assert image_segment.sources == [valid_citation_id], "不存在的 citation_id 应被过滤"
    assert response.citations == citations

    print("[agent.graph.synthesizer] 场景六：过滤后没有合法分段 → 回退纯文本")
    llm = _PlainTextLLM(
        {
            "answer": "有答案但分段全非法",
            "segments": [
                {"type": "image", "asset_id": "asset_不存在"},
                {"type": "text", "text": "   "},
            ],
            "citations": [],
        },
        plain="纯文本兜底回答。",
    )
    response = Synthesizer(llm, prompts).synthesize(question, image_caption, chunks, assets, citations)
    print("[agent.graph.synthesizer]   回答:", response.answer)
    assert response.answer == "纯文本兜底回答。"
    assert len(response.segments) == 1 and isinstance(response.segments[0], TextSegment)
    assert response.citations == citations

    print("[agent.graph.synthesizer] 场景七：answer 非法 / segments 不是列表 → 回退纯文本")
    invalid_payloads = (
        {"answer": None, "segments": [{"type": "text", "text": "x"}], "citations": []},
        {"answer": "x", "segments": "不是列表", "citations": []},
    )
    for payload in invalid_payloads:
        response = Synthesizer(_PlainTextLLM(payload, plain="回退回答。"), prompts).synthesize(
            question, image_caption, chunks, assets, citations
        )
        print("[agent.graph.synthesizer]   非法输出:", payload["answer"], "-> 回答:", response.answer)
        assert response.answer == "回退回答。"
        assert len(response.segments) == 1 and isinstance(response.segments[0], TextSegment)
        assert response.citations == citations

    print("[agent.graph.synthesizer] 自检通过")


if __name__ == "__main__":
    main()
