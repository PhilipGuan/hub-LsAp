"""规划节点：一次轻量决策——是否需要检索知识库，以及用什么查询文本去检索。

在链路中的位置：`workflow.answer` 的第 2 步调用本节点，它决定后续要不要跑
文本检索与图片加载；第一版刻意只做一次决策，不做多轮自主规划（README 智能体设计）。

模型输出不可靠（不是 JSON、字段类型不对、query 为空），而漏检的代价比多检索一次高，
所以这里把"需要检索"当兜底：任何非法输出都退回 `need_retrieve=True`，用问题和图片描述
拼出查询文本。不联网、不写库，只调用一次 LLM。
"""

if __package__ in (None, ""):  # 允许直接运行本文件
    import sys
    from pathlib import Path

    for _root in Path(__file__).resolve().parents:
        if (_root / "backend" / "app").is_dir():
            sys.path.insert(0, str(_root))
            break

from pydantic import BaseModel

from backend.agent.llm import PLANNER_MARKER, LLMClient, StubLLM, build_text_messages
from backend.agent.prompt_loader import PromptLoader


class PlannerDecision(BaseModel):
    """规划结果：是否检索 + 检索查询文本。"""

    need_retrieve: bool
    query: str = ""


def _text(value: object) -> str:
    """把模型给的任意值转成去空白的字符串（query 允许被写成任何类型）。"""
    return str(value).strip() if value is not None else ""


class Planner:
    """规划节点：一次决策，任何失败都兜底为"需要检索"。"""

    def __init__(self, llm: LLMClient, prompts: PromptLoader) -> None:
        """注入模型客户端与提示词加载器（都可替换，便于离线自测）。"""
        self.llm = llm
        self.prompts = prompts

    def decide(self, question: str, image_caption: str = "") -> PlannerDecision:
        """问模型一次：是否检索、检索什么；非法输出不抛异常，直接兜底。"""
        question = (question or "").strip()
        image_caption = (image_caption or "").strip()
        prompt = self.prompts.render("planner", question=question, image_caption=image_caption)
        try:
            data = self.llm.chat_json(build_text_messages(prompt))
        except Exception as error:  # 模型超时/网络错误：按非法输出兜底，不拖垮整条问答链路
            print(f"[agent.graph.planner] 模型调用失败: {error}")
            data = None

        decision = self._parse(data)
        if decision is None:
            # 宁可检索也不漏检：模型没吐 JSON、字段类型不对时一律走检索
            return PlannerDecision(need_retrieve=True, query=(question + image_caption).strip())
        if decision.need_retrieve and not decision.query:
            # 说需要检索却没给查询：用问题 + 图片描述拼一个，避免空查询检索无结果
            decision.query = (question + " " + image_caption).strip()
        return decision

    @staticmethod
    def _parse(data: object) -> PlannerDecision | None:
        """校验模型 JSON；不合法返回 None，交给调用方兜底。"""
        if not isinstance(data, dict):
            return None
        need_retrieve = data.get("need_retrieve")
        if not isinstance(need_retrieve, bool):  # "yes" / 1 / None 都算非法，不猜模型意图
            return None
        return PlannerDecision(need_retrieve=need_retrieve, query=_text(data.get("query")))


class _BrokenLLM:
    """chat_json 抛异常的假模型：验证规划节点不把异常抛给编排层。"""

    def chat_json(self, messages: list[dict]) -> dict | None:
        """模拟模型服务不可用。"""
        raise RuntimeError("模型服务不可用")

    def chat(self, messages: list[dict]) -> str:
        """模拟模型服务不可用（补全 LLMClient 协议形状）。"""
        raise RuntimeError("模型服务不可用")


def main() -> None:
    """自检：离线假模型覆盖正常决策、闲聊跳过、非法输出兜底、带图兜底、异常兜底。"""
    prompts = PromptLoader()
    question = "这个系统的解析流程是怎样的？"

    print("[agent.graph.planner] 场景一：默认假模型（把用户问题当作检索查询）")
    decision = Planner(StubLLM(), prompts).decide(question)
    print("[agent.graph.planner]   决策:", decision.model_dump())
    assert decision.need_retrieve is True and decision.query == question

    print("[agent.graph.planner] 场景二：模型判定闲聊、无需检索")
    decision = Planner(StubLLM({PLANNER_MARKER: {"need_retrieve": False, "query": ""}}), prompts).decide(question)
    print("[agent.graph.planner]   决策:", decision.model_dump())
    assert decision.need_retrieve is False and decision.query == ""

    print("[agent.graph.planner] 场景三：模型没吐 JSON → 兜底检索")
    decision = Planner(StubLLM({PLANNER_MARKER: None}), prompts).decide(question)
    print("[agent.graph.planner]   决策:", decision.model_dump())
    assert decision.need_retrieve is True and question in decision.query

    print("[agent.graph.planner] 场景四：need_retrieve 不是 bool → 兜底检索")
    decision = Planner(StubLLM({PLANNER_MARKER: {"need_retrieve": "yes"}}), prompts).decide(question)
    print("[agent.graph.planner]   决策:", decision.model_dump())
    assert decision.need_retrieve is True and question in decision.query

    print("[agent.graph.planner] 场景五：带图片描述时兜底查询并入图片描述")
    decision = Planner(StubLLM({PLANNER_MARKER: None}), prompts).decide(question, image_caption="架构图")
    print("[agent.graph.planner]   决策:", decision.model_dump())
    assert decision.need_retrieve is True and "架构图" in decision.query

    print("[agent.graph.planner] 场景六：说检索但 query 为空 → 用问题 + 图片描述补齐")
    decision = Planner(StubLLM({PLANNER_MARKER: {"need_retrieve": True, "query": "  "}}), prompts).decide(
        question, image_caption="架构图"
    )
    print("[agent.graph.planner]   决策:", decision.model_dump())
    assert decision.need_retrieve is True and question in decision.query and "架构图" in decision.query

    print("[agent.graph.planner] 场景七：模型调用抛异常 → 兜底检索，不向上抛")
    decision = Planner(_BrokenLLM(), prompts).decide(question)
    print("[agent.graph.planner]   决策:", decision.model_dump())
    assert decision.need_retrieve is True and question in decision.query

    print("[agent.graph.planner] 自检通过")


if __name__ == "__main__":
    main()
