"""编排节点包：planner（一次轻量决策）与 synthesizer（结构化回答 + 回退）。

固定编排顺序本身不在这里，而在上层的 `backend/agent/workflow.py`。
"""
