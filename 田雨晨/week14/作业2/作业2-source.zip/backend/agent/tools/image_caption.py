"""用户图片描述工具：调多模态大模型得到图片描述与识别文字。

在链路中的位置：`workflow.answer` 的第 1 步；有用户上传图片时先跑这个工具，
把 caption/ocr_text 并入规划与检索查询（README：有用户图片时图片描述并入查询）。

工具失败兜底：模型没吐 JSON、返回空字段、调用抛异常，一律返回 ok=False，
绝不把异常抛给编排层（README：智能体工具调用有超时和失败兜底）。
"""

if __package__ in (None, ""):  # 允许直接运行本文件
    import sys
    from pathlib import Path

    for _root in Path(__file__).resolve().parents:
        if (_root / "backend" / "app").is_dir():
            sys.path.insert(0, str(_root))
            break

from dataclasses import dataclass

from backend.agent.llm import LLMClient, build_vision_messages
from backend.agent.prompt_loader import PromptLoader
from backend.app.schemas.qa import AgentImage


@dataclass
class ImageCaptionResult:
    """图片描述结果；ok=False 表示工具失败，编排层用空描述继续。"""

    caption: str = ""
    ocr_text: str = ""
    ok: bool = False

    @property
    def combined_text(self) -> str:
        """caption 与 ocr_text 用空格拼接，空项不参与。"""
        return " ".join(part for part in (self.caption, self.ocr_text) if part)


def _text(value: object) -> str:
    """模型输出字段转字符串并去首尾空白；None 视为空串。"""
    return "" if value is None else str(value).strip()


class ImageCaptionTool:
    """用户图片描述工具：VLM 输出说明文字与可识别文字。"""

    def __init__(self, llm: LLMClient, prompts: PromptLoader) -> None:
        """注入模型客户端与提示词加载器（离线自测时注入 StubLLM）。"""
        self.llm = llm
        self.prompts = prompts

    def describe(self, image: AgentImage) -> ImageCaptionResult:
        """调一次图文模型；任何失败都返回 ok=False，绝不向上抛异常。"""
        try:
            prompt = self.prompts.render("image_caption")
            data = self.llm.chat_json(build_vision_messages(prompt, image))
        except Exception:  # 工具失败兜底：模型或提示词异常都不能打断编排
            return ImageCaptionResult(ok=False)
        if not isinstance(data, dict):
            return ImageCaptionResult(ok=False)
        caption = _text(data.get("caption"))
        ocr_text = _text(data.get("ocr_text"))
        # 两个字段都为空等于没拿到信息，按失败处理，让编排层当作“没有图片描述”
        return ImageCaptionResult(caption=caption, ocr_text=ocr_text, ok=bool(caption or ocr_text))


def main() -> None:
    """自检：正常输出、非 JSON、字段全空、字段拼接、模型异常。"""
    from backend.agent.llm import CAPTION_MARKER, StubLLM

    prompts = PromptLoader()
    image = AgentImage(mime_type="image/png", data_base64="aGVsbG8=")

    default_result = ImageCaptionTool(StubLLM(), prompts).describe(image)
    print("[agent.tools.image_caption] 默认假模型:", default_result)
    assert default_result.ok is True, "默认假模型应返回可用描述"
    assert default_result.combined_text, "combined_text 不应为空"
    assert default_result.caption and "离线假模型" in default_result.caption

    not_json = ImageCaptionTool(StubLLM({CAPTION_MARKER: None}), prompts).describe(image)
    print("[agent.tools.image_caption] 模型没有输出 JSON:", not_json)
    assert not_json.ok is False, "没有 JSON 时应返回 ok=False"
    assert not_json.combined_text == ""

    empty_fields = ImageCaptionTool(StubLLM({CAPTION_MARKER: {"caption": " ", "ocr_text": None}}), prompts).describe(image)
    print("[agent.tools.image_caption] 字段全空:", empty_fields)
    assert empty_fields.ok is False and empty_fields.combined_text == ""

    custom = ImageCaptionTool(
        StubLLM({CAPTION_MARKER: {"caption": "架构图", "ocr_text": "前端 后端"}}),
        prompts,
    )
    custom_result = custom.describe(image)
    print("[agent.tools.image_caption] 自定义输出:", custom_result)
    assert custom_result.ok is True
    assert custom_result.combined_text == "架构图 前端 后端", "combined_text 应用空格拼接 caption 与 ocr_text"

    stripped = ImageCaptionTool(StubLLM({CAPTION_MARKER: {"caption": "  架构图  ", "ocr_text": ""}}), prompts).describe(image)
    print("[agent.tools.image_caption] 去空白后:", stripped)
    assert stripped.caption == "架构图" and stripped.ocr_text == ""
    assert stripped.ok is True and stripped.combined_text == "架构图", "空项不应参与拼接"

    class BrokenLLM:
        """模拟模型调用直接抛异常。"""

        def chat(self, messages: list[dict]) -> str:
            """模拟模型不可用。"""
            raise RuntimeError("模型不可用")

        def chat_json(self, messages: list[dict]) -> dict | None:
            """模拟模型不可用（结构化调用同样抛异常）。"""
            raise RuntimeError("模型不可用")

    broken = ImageCaptionTool(BrokenLLM(), prompts).describe(image)
    print("[agent.tools.image_caption] 模型抛异常:", broken)
    assert broken.ok is False, "模型异常时应兜底为 ok=False"
    assert broken.combined_text == ""

    print("[agent.tools.image_caption] 自检通过")


if __name__ == "__main__":
    main()
