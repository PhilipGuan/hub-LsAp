"""文本检索工具：本地余弦相似度检索，向量不可用时降级为关键词打分。

在链路中的位置：`workflow.answer` 第 3 步调用，把查询变成文本切片上下文，
供图片加载、引用构建和回答合成使用。

智能体只读检索数据：这里只 select 切片表，不写库、不联网；向量由注入的
EmbeddingClient 提供，调用失败时降级成关键词匹配，不向编排层抛异常。
"""

if __package__ in (None, ""):  # 允许直接运行本文件
    import sys
    from pathlib import Path

    for _root in Path(__file__).resolve().parents:
        if (_root / "backend" / "app").is_dir():
            sys.path.insert(0, str(_root))
            break

from sqlalchemy import func, select

from backend.agent.config import AgentSettings
from backend.agent.embedding import EmbeddingClient, cosine
from backend.app.models.tables import Chunk, Document
from backend.app.schemas.content import TextChunk


def _bigrams(text: str) -> set[str]:
    """去掉空白并转小写后的字符二元组集合（中文检索不需要分词）。"""
    compact = "".join(ch for ch in (text or "").lower() if not ch.isspace())
    return {compact[index : index + 2] for index in range(len(compact) - 1)}


def keyword_score(query: str, text: str) -> float:
    """关键词打分：查询的字符二元组在文本中的命中比例，范围 0~1。"""
    grams = _bigrams(query)
    if not grams or not text:
        return 0.0
    return len(grams & _bigrams(text)) / len(grams)


class TextSearchTool:
    """按余弦相似度检索文本切片；没有向量或向量调用失败时降级为关键词检索。"""

    def __init__(
        self,
        session_factory,
        settings: AgentSettings | None = None,
        embedder: EmbeddingClient | None = None,
    ) -> None:
        """保存只读会话工厂、检索配置与向量客户端（embedder=None 即关键词模式）。"""
        self.session_factory = session_factory
        self.settings = settings or AgentSettings()
        self.embedder = embedder
        self.last_degraded = False  # 上一次检索是否走了关键词降级，供编排层观测

    def _query_vector(self, query: str) -> list[float] | None:
        """取查询向量；没有客户端或调用失败时返回 None，由调用方降级。"""
        if self.embedder is None:
            return None
        try:
            vectors = self.embedder.embed([query])
        except Exception:  # 工具失败兜底：向量服务不可用不能挡住检索
            return None
        if not vectors or not vectors[0]:
            return None
        return [float(value) for value in vectors[0]]

    def search(self, query: str, top_k: int | None = None) -> list[TextChunk]:
        """检索与查询最相关的切片；按分数降序返回，低于阈值的直接过滤。"""
        query = (query or "").strip()
        if not query:
            return []
        limit = self.settings.top_k if top_k is None else top_k
        if limit <= 0:
            return []

        with self.session_factory() as session:
            # ponytail: 本地全表扫描算余弦；切 PostgreSQL 时换 pgvector 的 SQL 向量检索
            chunks = list(session.scalars(select(Chunk).order_by(Chunk.created_at, Chunk.id)))
            # 文件名给回答合成用：不让模型在回答里写 doc_xxx 编号
            doc_ids = {chunk.doc_id for chunk in chunks}
            doc_names = (
                {
                    document.id: document.filename
                    for document in session.scalars(select(Document).where(Document.id.in_(doc_ids)))
                }
                if doc_ids
                else {}
            )

        query_vector = self._query_vector(query)
        self.last_degraded = query_vector is None
        scored: list[tuple[float, Chunk]] = []
        for chunk in chunks:
            if query_vector is not None and chunk.embedding:
                score = cosine(query_vector, list(chunk.embedding))
            else:
                # 任一环节缺向量（没配置/调用失败/切片没向量）都退化为关键词匹配，
                # 保证离线联调和向量库未就绪时问答仍然可用
                score = keyword_score(query, chunk.text)
                self.last_degraded = True
            if score >= self.settings.retrieval_min_score:
                scored.append((score, chunk))

        scored.sort(key=lambda item: item[0], reverse=True)
        return [
            TextChunk(
                chunk_id=chunk.id,
                doc_id=chunk.doc_id,
                doc_filename=doc_names.get(chunk.doc_id, ""),
                page=chunk.page,
                seq=chunk.seq,
                text=chunk.text,
                asset_id=chunk.asset_id,
                score=round(score, 4),
            )
            for score, chunk in scored[:limit]
        ]


def main() -> None:
    """自检：向量检索 top1、top_k 截断、排序、空查询、关键词降级、阈值过滤、只读。"""
    from backend.agent.embedding import StubEmbedding
    from backend.agent.fixtures import CHUNK_TEXTS, temp_session_factory

    factory, data = temp_session_factory(StubEmbedding(dim=8))
    tool = TextSearchTool(factory, embedder=StubEmbedding(dim=8))

    hits = tool.search(CHUNK_TEXTS[1])
    print(
        "[agent.tools.text_search] 向量检索 top1:",
        hits[0].chunk_id if hits else None,
        "| score:",
        hits[0].score if hits else None,
        "| 降级:",
        tool.last_degraded,
    )
    assert hits, "同文本切片应被检索到"
    assert hits[0].chunk_id == data.chunk_ids[1], "top1 应为同文本切片"
    assert abs(hits[0].score - 1.0) < 1e-3, "同文本余弦相似度应约等于 1"
    assert tool.last_degraded is False, "向量可用时不应降级"

    two = tool.search(CHUNK_TEXTS[1], top_k=2)
    print("[agent.tools.text_search] top_k=2:", [(hit.chunk_id, hit.score) for hit in two])
    assert len(two) == 2, "top_k=2 应返回 2 条"
    assert two[0].score >= two[1].score, "结果必须按分数降序"

    assert tool.search("") == [], "空查询应返回空列表"
    assert tool.search("   ") == [], "空白查询应返回空列表"

    keyword_tool = TextSearchTool(factory)  # embedder=None → 关键词检索
    keyword_hits = keyword_tool.search("MinerU 解析")
    print(
        "[agent.tools.text_search] 关键词检索:",
        [(hit.chunk_id, hit.score) for hit in keyword_hits],
        "| 降级:",
        keyword_tool.last_degraded,
    )
    assert keyword_hits and keyword_hits[0].chunk_id == data.chunk_ids[1], "关键词检索应命中 MinerU 切片"
    assert keyword_tool.last_degraded is True, "无向量客户端应标记降级"
    assert 0.0 <= keyword_hits[0].score <= 1.0

    class BrokenEmbedding:
        """模拟向量服务不可用。"""

        def embed(self, texts: list[str]) -> list[list[float]]:
            """模拟向量接口直接抛异常。"""
            raise RuntimeError("向量服务不可用")

    broken_tool = TextSearchTool(factory, embedder=BrokenEmbedding())
    broken_hits = broken_tool.search("MinerU 解析")
    print(
        "[agent.tools.text_search] 向量异常降级:",
        [(hit.chunk_id, hit.score) for hit in broken_hits],
        "| 降级:",
        broken_tool.last_degraded,
    )
    assert broken_hits and broken_hits[0].chunk_id == data.chunk_ids[1], "向量异常时降级仍应返回结果"
    assert broken_tool.last_degraded is True

    strict = TextSearchTool(factory, AgentSettings(retrieval_min_score=0.99), StubEmbedding(dim=8))
    assert strict.search("MinerU 解析") == [], "低于阈值的结果必须被过滤"
    strict_keyword = TextSearchTool(factory, AgentSettings(retrieval_min_score=0.99))
    assert strict_keyword.search("MinerU 解析") == [], "关键词结果低于阈值时也必须被过滤"
    print("[agent.tools.text_search] min_score=0.99 过滤生效: []")

    with factory() as session:  # 只读：检索不改变库里的行数
        assert session.scalar(select(func.count()).select_from(Chunk)) == 3
    print("[agent.tools.text_search] 自检通过")


if __name__ == "__main__":
    main()
