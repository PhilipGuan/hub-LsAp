"""图片资源加载工具：按切片加载直接关联图片与同文档同页的邻近图片。

在链路中的位置：`workflow.answer` 在文本检索之后调用，为回答合成提供图片资源
上下文；引用构建也会用到这些资源。

README 约定“不单独建图片向量，用说明文字/识别文字/邻近文本找图”，所以这里不查向量，
而是“切片关联的图片 + 同页图片”组合；图片只带 asset_id，签名地址由后端补全。

智能体只读检索数据：这里只 select 图片资源表，不写库。
顺序约定：切片直接关联的图片优先，再补同文档同页的邻近图片，最后按上限截断。
"""

if __package__ in (None, ""):  # 允许直接运行本文件
    import sys
    from pathlib import Path

    for _root in Path(__file__).resolve().parents:
        if (_root / "backend" / "app").is_dir():
            sys.path.insert(0, str(_root))
            break

from sqlalchemy import func, select

from backend.agent.config import AgentSettings
from backend.app.models.tables import Asset, Document
from backend.app.schemas.content import ImageAsset, TextChunk


class ImageLoadTool:
    """把检索到的切片转换成图片资源上下文（README：图片与页码、邻近文本关联）。"""

    def __init__(self, session_factory, settings: AgentSettings | None = None) -> None:
        """保存只读会话工厂与配置（上限来自 max_context_assets）。"""
        self.session_factory = session_factory
        self.settings = settings or AgentSettings()

    def load(self, chunks: list[TextChunk], max_assets: int | None = None) -> list[ImageAsset]:
        """加载图片资源：直接关联的在前、同页邻近的在后，按上限截断。"""
        if not chunks:
            return []
        limit = self.settings.max_context_assets if max_assets is None else max_assets
        if limit <= 0:
            return []

        linked_ids = {chunk.asset_id for chunk in chunks if chunk.asset_id}
        doc_pages = {(chunk.doc_id, chunk.page) for chunk in chunks}
        with self.session_factory() as session:
            linked = (
                {asset.id: asset for asset in session.scalars(select(Asset).where(Asset.id.in_(linked_ids)))}
                if linked_ids
                else {}
            )
            neighbors = list(
                session.scalars(
                    select(Asset)
                    .where(
                        Asset.doc_id.in_({doc_id for doc_id, _ in doc_pages}),
                        Asset.page.in_({page for _, page in doc_pages}),
                    )
                    .order_by(Asset.doc_id, Asset.page, Asset.id)
                )
            )
            ordered: list[Asset] = []
            seen: set[str] = set()
            for chunk in chunks:  # 切片直接关联的图片优先
                asset = linked.get(chunk.asset_id or "")
                if asset is not None and asset.id not in seen:
                    seen.add(asset.id)
                    ordered.append(asset)
            doc_names = {
                document.id: document.filename
                for document in session.scalars(
                    select(Document).where(Document.id.in_({asset.doc_id for asset in ordered}))
                )
            } if ordered else {}
            for asset in neighbors:  # 再补同文档同页的邻近图片（按页内顺序、去重）
                if (asset.doc_id, asset.page) in doc_pages and asset.id not in seen:
                    seen.add(asset.id)
                    ordered.append(asset)
            return [
                ImageAsset(
                    asset_id=asset.id,
                    doc_id=asset.doc_id,
                    doc_filename=doc_names.get(asset.doc_id, ""),
                    page=asset.page,
                    asset_type=asset.asset_type,
                    object_key=asset.object_key,
                    caption=asset.caption or "",
                    ocr_text=asset.ocr_text or "",
                    bbox=asset.bbox,
                    created_at=asset.created_at,
                )
                for asset in ordered[:limit]
            ]


def main() -> None:
    """自检：直接关联优先、同页邻近补齐、上限截断、空输入、只读。"""
    from backend.agent.embedding import StubEmbedding
    from backend.agent.fixtures import ASSET_CAPTIONS, temp_session_factory
    from backend.app.models.tables import Chunk

    factory, data = temp_session_factory(StubEmbedding(dim=8))
    with factory() as session:
        rows = list(session.scalars(select(Chunk).order_by(Chunk.seq)))
        chunks = [
            TextChunk(
                chunk_id=row.id,
                doc_id=row.doc_id,
                page=row.page,
                seq=row.seq,
                text=row.text,
                asset_id=row.asset_id,
            )
            for row in rows
        ]
    print("[agent.tools.image_load] 输入切片:", [(chunk.chunk_id, chunk.page, chunk.asset_id) for chunk in chunks])
    assert len(chunks) == 3

    tool = ImageLoadTool(factory)
    assets = tool.load(chunks)
    print("[agent.tools.image_load] 加载图片资源:", [(asset.asset_id, asset.page, asset.asset_type) for asset in assets])
    assert len(assets) == 2, "应加载到切片关联图片 + 同页邻近图片"
    assert assets[0].asset_id == data.linked_asset_id, "切片直接关联的图片必须排第一"
    assert assets[0].asset_type == "figure" and assets[0].page == 1
    assert assets[0].caption == ASSET_CAPTIONS[0], "说明文字应透传"
    assert assets[0].bbox == [72.0, 120.0, 480.0, 360.0], "版面框应透传"
    assert assets[1].asset_id == data.asset_ids[1], "第 2 页的 table 资源应作为邻近图片加载"
    assert assets[1].page == 2 and assets[1].asset_type == "table" and assets[1].bbox is None
    assert all(asset.object_key.startswith(f"assets/{data.doc_id}/") for asset in assets)

    single = tool.load(chunks, max_assets=1)
    print("[agent.tools.image_load] max_assets=1:", [(asset.asset_id, asset.page) for asset in single])
    assert len(single) == 1, "max_assets=1 应截断为 1 条"
    assert single[0].asset_id == data.linked_asset_id, "截断后保留优先级最高的图片"

    assert tool.load([]) == [], "空切片应返回空列表"
    print("[agent.tools.image_load] 空切片返回: []")

    with factory() as session:  # 只读：加载不改变库里的行数
        assert session.scalar(select(func.count()).select_from(Asset)) == 2
    print("[agent.tools.image_load] 自检通过")


if __name__ == "__main__":
    main()
