"""引用构建工具：把文本切片与图片资源转成确定性的引用列表。

在链路中的位置：`workflow.answer` 在检索/图片加载之后、回答合成之前调用；
合成节点拿到引用后原样带回，后端再据此渲染页码与来源。

引用编号规则固定为 `cit_<资源编号>`，同一编号只保留一次；先切片后图片，
总条数按配置上限截断。纯内存计算，不访问数据库、不写库。
"""

if __package__ in (None, ""):  # 允许直接运行本文件
    import sys
    from pathlib import Path

    for _root in Path(__file__).resolve().parents:
        if (_root / "backend" / "app").is_dir():
            sys.path.insert(0, str(_root))
            break

from backend.agent.config import AgentSettings
from backend.app.schemas.content import Citation, ImageAsset, TextChunk


class CitationBuilder:
    """生成引用列表：先切片引用、后图片引用，去重后按上限截断。"""

    def __init__(self, settings: AgentSettings | None = None) -> None:
        """保存配置（只用到 max_citations 上限）。"""
        self.settings = settings or AgentSettings()

    def build(self, chunks: list[TextChunk], assets: list[ImageAsset]) -> list[Citation]:
        """按固定顺序生成引用：切片引用在前、图片引用在后，重复编号只保留第一次。"""
        citations: list[Citation] = []
        seen: set[str] = set()

        for chunk in chunks:
            citation_id = f"cit_{chunk.chunk_id}"
            if citation_id in seen:
                continue
            seen.add(citation_id)
            citations.append(
                Citation(
                    citation_id=citation_id,
                    doc_id=chunk.doc_id,
                    doc_filename=chunk.doc_filename or None,
                    chunk_id=chunk.chunk_id,
                    asset_id=chunk.asset_id,
                    page=chunk.page,
                )
            )

        for asset in assets:
            citation_id = f"cit_{asset.asset_id}"
            if citation_id in seen:
                continue
            seen.add(citation_id)
            citations.append(
                Citation(
                    citation_id=citation_id,
                    doc_id=asset.doc_id,
                    doc_filename=asset.doc_filename or None,
                    asset_id=asset.asset_id,
                    page=asset.page,
                    bbox=asset.bbox,
                )
            )

        return citations[: self.settings.max_citations]


def main() -> None:
    """自检：编号规则与顺序确定、去重、空输入、上限截断。"""
    from sqlalchemy import select

    from backend.agent.embedding import StubEmbedding
    from backend.agent.fixtures import temp_session_factory
    from backend.app.models.tables import Asset, Chunk

    factory, data = temp_session_factory(StubEmbedding(dim=8))
    with factory() as session:
        chunk_rows = list(session.scalars(select(Chunk).order_by(Chunk.seq)))
        asset_rows = list(session.scalars(select(Asset).order_by(Asset.page, Asset.id)))
    chunks = [
        TextChunk(
            chunk_id=row.id,
            doc_id=row.doc_id,
            page=row.page,
            seq=row.seq,
            text=row.text,
            asset_id=row.asset_id,
        )
        for row in chunk_rows
    ]
    assets = [
        ImageAsset(
            asset_id=row.id,
            doc_id=row.doc_id,
            page=row.page,
            asset_type=row.asset_type,
            object_key=row.object_key,
            caption=row.caption,
            ocr_text=row.ocr_text,
            bbox=row.bbox,
            created_at=row.created_at,
        )
        for row in asset_rows
    ]

    builder = CitationBuilder()
    citations = builder.build(chunks, assets)
    print("[agent.tools.citation_builder] 引用:", [(item.citation_id, item.page) for item in citations])
    expected_ids = [f"cit_{chunk_id}" for chunk_id in data.chunk_ids] + [f"cit_{asset_id}" for asset_id in data.asset_ids]
    assert [item.citation_id for item in citations] == expected_ids, "引用编号规则与顺序必须确定"
    assert len(citations) == 5, "3 条切片 + 2 条图片资源 = 5 条引用"

    first = citations[0]
    assert first.chunk_id == data.chunk_ids[0] and first.doc_id == data.doc_id
    assert first.asset_id == data.linked_asset_id and first.page == 1
    assert first.bbox is None, "切片引用不带版面框"
    assert all(item.asset_id is None for item in citations[1:3]), "未关联图片的切片引用不带图片资源编号"

    linked_citation = citations[3]
    assert linked_citation.citation_id == f"cit_{data.asset_ids[0]}"
    assert linked_citation.asset_id == data.asset_ids[0] and linked_citation.chunk_id is None
    assert linked_citation.doc_id == data.doc_id and linked_citation.page == 1
    assert linked_citation.bbox == [72.0, 120.0, 480.0, 360.0], "图片引用的版面框应透传"
    assert citations[4].asset_id == data.asset_ids[1] and citations[4].page == 2
    assert citations[4].bbox is None

    duplicated = builder.build(chunks + chunks, assets + assets)
    print("[agent.tools.citation_builder] 重复输入后条数:", len(duplicated))
    assert len(duplicated) == 5, "同一 citation_id 只保留一次"
    assert [item.citation_id for item in duplicated] == expected_ids

    assert builder.build([], []) == [], "空输入应返回空列表"
    print("[agent.tools.citation_builder] 空输入返回: []")

    limited = CitationBuilder(AgentSettings(max_citations=1)).build(chunks, assets)
    print("[agent.tools.citation_builder] max_citations=1:", [item.citation_id for item in limited])
    assert len(limited) == 1 and limited[0].citation_id == f"cit_{data.chunk_ids[0]}", "截断保留最先出现的引用"
    only_assets = CitationBuilder(AgentSettings(max_citations=1)).build([], assets)
    assert len(only_assets) == 1 and only_assets[0].citation_id == f"cit_{data.asset_ids[0]}"

    print("[agent.tools.citation_builder] 自检通过")


if __name__ == "__main__":
    main()
