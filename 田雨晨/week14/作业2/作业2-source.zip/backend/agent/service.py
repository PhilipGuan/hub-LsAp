"""智能体 HTTP 服务：POST /answer 供后端调用，不对外暴露。

在链路中的位置：后端 `backend/app/clients/agent.py` 通过 `AGENT_SERVICE_URL`
（默认 http://agent:8100）调用这里的 `/answer`；本服务内部再走固定编排
（backend/workflow.py），只读检索数据、不写业务表、不跑建表 DDL。

启动（仓库根目录，端口与 deploy/.env 的 AGENT_SERVICE_URL 对应）：
    uvicorn backend.agent.service:create_app --factory --host 0.0.0.0 --port 8100
本地联调（不调用真实模型，用离线假模型/假向量）：
    AGENT_STUB_LLM=1 uvicorn backend.agent.service:create_app --factory --port 8100
自测（不启动服务器）：
    python -m backend.agent.service
"""

if __package__ in (None, ""):  # 允许直接运行本文件
    import sys
    from pathlib import Path

    for _root in Path(__file__).resolve().parents:
        if (_root / "backend" / "app").is_dir():
            sys.path.insert(0, str(_root))
            break

from fastapi import FastAPI

from backend.agent.config import AgentSettings, get_agent_settings
from backend.workflow import QaWorkflow
from backend.app.config import Settings, get_settings
from backend.app.db import init_db, make_engine, make_session_factory
from backend.app.schemas.qa import AgentRequest, AgentResponse


def create_app(
    settings: AgentSettings | None = None,
    *,
    db_settings: Settings | None = None,
    session_factory=None,
    llm=None,
    embedder=None,
) -> FastAPI:
    """构建智能体服务；数据库/模型依赖可注入，便于离线自测。"""
    settings = settings or get_agent_settings()
    if session_factory is None:
        # 智能体只读检索数据：表结构由后端服务负责初始化（不跑 DDL，避免和后端并发建表冲突）
        db_settings = db_settings or get_settings()
        engine = make_engine(db_settings)
        session_factory = make_session_factory(engine)
    orchestrator = QaWorkflow(session_factory, settings, llm=llm, embedder=embedder)

    app = FastAPI(
        title="多模态 RAG 问答智能体",
        version="0.1.0",
        description="固定编排 + 一次轻量决策；只读检索数据，不写业务表，不直接对外暴露。",
    )
    app.state.settings = settings
    app.state.orchestrator = orchestrator

    @app.get("/health", tags=["系统"], summary="健康检查")
    def health() -> dict:
        """健康检查：返回是否走离线假模型、是否配置了真实模型（不含密钥）。"""
        return {
            "status": "ok",
            "llm_stub": settings.llm_stub,
            "has_real_models": settings.has_real_models,
            "vlm_model": settings.vlm_model,
        }

    @app.post("/answer", response_model=AgentResponse, summary="问答编排：问题文本 + 可选用户图片")
    def answer(request: AgentRequest) -> AgentResponse:
        """问答入口：交给编排器按固定顺序处理，响应模型由 pydantic 保证结构。"""
        return orchestrator.answer(request)

    return app


def main() -> None:
    """自检：不启动服务器，用 TestClient 走通健康检查与两次问答。"""
    import base64
    import tempfile
    from pathlib import Path

    from fastapi.testclient import TestClient

    from backend.agent.config import build_agent_settings
    from backend.agent.embedding import StubEmbedding
    from backend.agent.fixtures import CHUNK_TEXTS, seed
    from backend.agent.llm import PLANNER_MARKER, SYNTHESIZER_MARKER, StubLLM

    tmp = Path(tempfile.mkdtemp(prefix="rag-agent-service-"))
    db_settings = Settings(
        database_url=f"sqlite:///{(tmp / 'agent.db').as_posix()}",
        data_dir=tmp,
    )
    engine = make_engine(db_settings)
    init_db(engine)
    session_factory = make_session_factory(engine)
    embedder = StubEmbedding(dim=8)
    with session_factory() as session:
        data = seed(session, embedder)

    citation_id = f"cit_{data.chunk_ids[1]}"
    llm = StubLLM(
        {
            PLANNER_MARKER: {"need_retrieve": True, "query": CHUNK_TEXTS[1]},
            SYNTHESIZER_MARKER: {
                "answer": "解析工作器产出 Markdown、版面 JSON 与图片资源。",
                "segments": [
                    {"type": "text", "text": "解析工作器产出 Markdown、版面 JSON 与图片资源。", "sources": [citation_id]},
                ],
                "citations": [],
            },
        }
    )
    settings = build_agent_settings(stub=True)
    app = create_app(settings, db_settings=db_settings, session_factory=session_factory, llm=llm, embedder=embedder)

    with TestClient(app) as client:
        health = client.get("/health").json()
        print("[agent.service] 健康检查:", health)
        assert health["status"] == "ok" and health["llm_stub"] is True

        payload = {
            "question": "解析工作器会产出什么？",
            "image": {
                "mime_type": "image/png",
                "data_base64": base64.b64encode(b"\x89PNG\r\n\x1a\n fake").decode("ascii"),
            },
            "top_k": 3,
        }
        response = client.post("/answer", json=payload)
        print("[agent.service] /answer 状态码:", response.status_code)
        body = response.json()
        print("[agent.service] 回答:", body["answer"])
        print("[agent.service] 分段类型:", [segment["type"] for segment in body["segments"]])
        print("[agent.service] 引用:", [citation["citation_id"] for citation in body["citations"]])
        assert response.status_code == 200
        assert body["answer"]
        assert body["segments"][0]["type"] == "text"
        assert body["citations"] and body["citations"][0]["citation_id"] == citation_id

        second = client.post("/answer", json={"question": "再问一次：解析工作器做什么？", "top_k": 3})
        print("[agent.service] 第二次问答状态码:", second.status_code, "回答:", second.json()["answer"])
        assert second.status_code == 200
    print("[agent.service] 自检通过（启动：uvicorn backend.agent.service:create_app --factory --port 8100）")


if __name__ == "__main__":
    main()
