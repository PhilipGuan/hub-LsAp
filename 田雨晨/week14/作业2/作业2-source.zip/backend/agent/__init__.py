"""问答编排智能体：固定编排 + 一次轻量决策，只读检索数据，不写业务表。

在链路中的位置：后端通过 `backend/app/clients/agent.py` 的 HTTP 客户端调用本包的
`service.create_app()`；内部节点与工具见 graph/ 与 tools/。
"""
