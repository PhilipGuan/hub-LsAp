"""模型客户端：真实 VLM（复用 BaseAgent）与离线假模型（自测/本地联调）。

在链路中的位置：规划节点、回答合成节点、用户图片描述工具都只依赖这里的 `LLMClient`
协议；`llm_from_settings` 按配置决定注入真实 `BaseAgent` 还是离线 `StubLLM`，
所以节点代码不需要关心“这次是不是真的调模型”。

`build_*_messages` 负责拼 OpenAI 兼容的消息体，用户图片用 data URL 走 image_url 消息。
"""

if __package__ in (None, ""):  # 允许直接运行本文件
    import sys
    from pathlib import Path

    for _root in Path(__file__).resolve().parents:
        if (_root / "backend" / "app").is_dir():
            sys.path.insert(0, str(_root))
            break

import json
import re
from typing import Protocol

from backend.agent.config import AgentSettings, get_agent_settings
from backend.app.schemas.qa import AgentImage

# 角色标记：提示词模板第一段都会写明角色，离线假模型据此决定返回什么
PLANNER_MARKER = "规划节点"
SYNTHESIZER_MARKER = "回答合成节点"
CAPTION_MARKER = "图片理解助手"

_QUESTION_MARKER = "用户问题："
_ASSET_ID_PATTERN = re.compile(r"asset_id=(\S+)")


def _default_planner(messages: list[dict]) -> dict:
    """默认规划：从提示词里取出用户问题，直接用它检索（让离线联调也能走检索链路）。"""
    text = "\n".join(_message_text(message) for message in messages)
    question = ""
    if _QUESTION_MARKER in text:
        question = text.split(_QUESTION_MARKER, 1)[1].strip().splitlines()[0].strip()
    return {"need_retrieve": bool(question), "query": question}


def _default_synthesizer(messages: list[dict]) -> dict:
    """默认合成：返回一段文本；上下文里有图片资源时再带一段图片，便于验证图文混排。"""
    text = "\n".join(_message_text(message) for message in messages)
    answer = "这是离线假智能体生成的回答。"
    segments: list[dict] = [{"type": "text", "text": answer, "sources": []}]
    # 只摘 asset_id：图片地址由后端签名，智能体侧不出现 URL（README 调用约束）
    asset_ids = _ASSET_ID_PATTERN.findall(text.split(SYNTHESIZER_MARKER, 1)[-1])
    if asset_ids:
        segments.append({"type": "image", "asset_id": asset_ids[0], "caption": "文档图片", "sources": []})
    return {"answer": answer, "segments": segments, "citations": []}


# 假模型的默认回应：按角色标记分发；可被 StubLLM(overrides) 逐角色覆盖
DEFAULT_STUB_RESPONSES = {
    PLANNER_MARKER: _default_planner,
    SYNTHESIZER_MARKER: _default_synthesizer,
    CAPTION_MARKER: {"caption": "离线假模型：一张示意图。", "ocr_text": ""},
}


class LLMClient(Protocol):
    """模型客户端最小接口：纯文本对话 + 结构化 JSON 输出。"""

    def chat(self, messages: list[dict]) -> str:
        """返回模型纯文本回答；调用失败直接抛异常，由使用方决定是否兜底。"""
        ...

    def chat_json(self, messages: list[dict]) -> dict | None:
        """返回模型输出的 JSON 对象；解析不出 dict 时返回 None（让节点走兜底分支）。"""
        ...


def _message_text(message: dict) -> str:
    """把一条消息的 content 拉平成纯文本（兼容 str 与 OpenAI 多段 content 两种形态）。"""
    content = message.get("content", "")
    if isinstance(content, str):
        return content
    parts = []
    for part in content or []:
        if isinstance(part, dict) and part.get("type") == "text":
            parts.append(str(part.get("text", "")))
    return "\n".join(parts)


class StubLLM:
    """离线假模型：按提示词里的角色标记返回预设 JSON，可整体替换或按角色覆盖。

    覆盖值可以是 dict/list/str，也可以是 `callable(messages) -> 任意值`；
    返回 None 模拟“模型没吐 JSON”的失败分支。自测全靠它覆盖成功/失败两条路径，
    不会产生真实网络调用。
    """

    def __init__(self, overrides: dict[str, object] | None = None) -> None:
        """在默认回应基础上按角色覆盖；记录 calls 便于自测断言调用次数/消息体。"""
        self.overrides = dict(DEFAULT_STUB_RESPONSES)
        self.overrides.update(overrides or {})
        self.calls: list[list[dict]] = []

    @staticmethod
    def detect_role(messages: list[dict]) -> str | None:
        """从消息文本里识别本次请求是哪个节点（规划/合成/图片描述）。"""
        text = "\n".join(_message_text(message) for message in messages)
        for marker in (SYNTHESIZER_MARKER, PLANNER_MARKER, CAPTION_MARKER):
            if marker in text:
                return marker
        return None

    def chat(self, messages: list[dict]) -> str:
        """按角色返回预设内容；None 表示“模拟模型输出非法文本”，由节点触发回退。"""
        self.calls.append(messages)
        role = self.detect_role(messages)
        value = self.overrides.get(role) if role else ""
        if callable(value):
            value = value(messages)
        if value is None:
            return "这段输出不是 JSON，用来触发结构化输出失败的回退分支。"
        if isinstance(value, (dict, list)):
            return json.dumps(value, ensure_ascii=False)
        return str(value)

    def chat_json(self, messages: list[dict]) -> dict | None:
        """与真实客户端行为一致：容忍 ```json 围栏，非 JSON/非 dict 返回 None。"""
        text = self.chat(messages).strip()
        if text.startswith("```"):
            text = text.split("\n", 1)[-1].rsplit("```", 1)[0].strip()
        try:
            payload = json.loads(text)
        except json.JSONDecodeError:
            return None
        return payload if isinstance(payload, dict) else None


def build_text_messages(prompt: str) -> list[dict]:
    """纯文本请求：系统提示 + 一句用户指令。"""
    return [
        {"role": "system", "content": prompt},
        {"role": "user", "content": "请严格按照系统提示的要求输出。"},
    ]


def build_vision_messages(prompt: str, image: AgentImage) -> list[dict]:
    """图文请求：系统提示 + 文本指令 + base64 图片（OpenAI 兼容 image_url）。"""
    data_url = f"data:{image.mime_type};base64,{image.data_base64}"
    return [
        {"role": "system", "content": prompt},
        {
            "role": "user",
            "content": [
                {"type": "text", "text": "请分析这张图片并按要求输出。"},
                {"type": "image_url", "image_url": {"url": data_url}},
            ],
        },
    ]


def llm_from_settings(settings: AgentSettings | None = None) -> LLMClient:
    """有真实模型配置就用 VLM，否则返回离线假模型（仅用于本地联调与自测）。"""
    settings = settings or get_agent_settings()
    if settings.llm_stub:
        return StubLLM()
    from backend.agent.base import BaseAgent

    return BaseAgent(model=settings.vlm_model, timeout=settings.llm_timeout_s)


def main() -> None:
    """自检：假模型按角色分发、非法输出返回 None、图文消息结构正确。"""
    stub = StubLLM()
    planner = stub.chat_json(build_text_messages("你是多模态 RAG 问答系统的规划节点。用户问题：系统由什么组成？"))
    print("[agent.llm] 规划节点默认返回:", planner)
    assert planner is not None and planner["need_retrieve"] is True
    assert planner["query"] == "系统由什么组成？", "默认规划应把用户问题当作检索查询"

    synthesis = stub.chat_json(build_text_messages("你是多模态 RAG 问答系统的回答合成节点。"))
    print("[agent.llm] 合成节点默认返回:", synthesis)
    assert synthesis is not None and synthesis["segments"][0]["type"] == "text"

    with_asset = stub.chat_json(
        build_text_messages("你是多模态 RAG 问答系统的回答合成节点。图片资源：[1] asset_id=asset_demo page=1")
    )
    print("[agent.llm] 有图片资源时默认合成:", with_asset)
    assert with_asset is not None and with_asset["segments"][-1]["type"] == "image", "默认合成应带图片段"

    broken = StubLLM({SYNTHESIZER_MARKER: None})
    print("[agent.llm] 非 JSON 输出:", broken.chat_json(build_text_messages("你是多模态 RAG 问答系统的回答合成节点。")))
    assert broken.chat_json(build_text_messages("你是多模态 RAG 问答系统的回答合成节点。")) is None

    custom = StubLLM({PLANNER_MARKER: {"need_retrieve": True, "query": "解析流程"}})
    decision = custom.chat_json(build_text_messages("你是规划节点"))
    assert decision == {"need_retrieve": True, "query": "解析流程"}
    print("[agent.llm] 按角色覆盖生效:", decision)

    image = AgentImage(mime_type="image/png", data_base64="aGVsbG8=")
    vision = build_vision_messages("你是图片理解助手。", image)
    print("[agent.llm] 图文消息结构:", json.dumps(vision, ensure_ascii=False)[:160])
    assert vision[1]["content"][1]["image_url"]["url"].startswith("data:image/png;base64,")
    assert len(stub.calls) >= 2
    print("[agent.llm] 自检通过")


if __name__ == "__main__":
    main()
