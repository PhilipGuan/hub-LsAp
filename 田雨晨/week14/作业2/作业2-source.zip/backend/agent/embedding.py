"""文本向量客户端：真实 OpenAI 兼容 /embeddings 接口 + 自测用确定性假向量。

在链路中的位置：智能体的文本检索工具用 `embed()` 把查询转成向量，和工作器的切片向量
做余弦相似度；解析工作器的 indexer 也用同一个客户端给切片生成向量。配置不齐时
`embedding_from_settings` 返回 None，检索工具据此降级为关键词打分（不阻断问答）。
"""

if __package__ in (None, ""):  # 允许直接运行本文件
    import sys
    from pathlib import Path

    for _root in Path(__file__).resolve().parents:
        if (_root / "backend" / "app").is_dir():
            sys.path.insert(0, str(_root))
            break

import hashlib
import math
from typing import Protocol

import requests

from backend.agent.config import AgentSettings, get_agent_settings


class EmbeddingClient(Protocol):
    """向量客户端最小接口：一批文本 → 一批等长向量。"""

    def embed(self, texts: list[str]) -> list[list[float]]:
        """把文本批量转成向量；空列表返回空列表。"""
        ...


class HttpEmbeddingClient:
    """OpenAI 兼容的文本向量接口（/embeddings）。"""

    def __init__(
        self,
        base_url: str,
        api_key: str,
        model: str,
        timeout_s: float = 60.0,
        session: requests.Session | None = None,
    ) -> None:
        """保存接口地址与密钥；缺配置直接报错，避免检索时才失败。"""
        if not base_url or not api_key:
            raise RuntimeError("EMBEDDING_API_BASE / EMBEDDING_API_KEY 未配置")
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.model = model
        self.timeout_s = timeout_s
        self._session = session or requests.Session()

    def embed(self, texts: list[str]) -> list[list[float]]:
        """批量请求 /embeddings，按 index 排序后返回；条数不符直接报错。"""
        if not texts:
            return []
        response = self._session.post(
            f"{self.base_url}/embeddings",
            headers={"Authorization": f"Bearer {self.api_key}"},
            json={"model": self.model, "input": texts},
            timeout=self.timeout_s,
        )
        response.raise_for_status()
        payload = response.json()
        items = sorted(payload.get("data") or [], key=lambda item: item.get("index", 0))
        vectors = [[float(value) for value in item["embedding"]] for item in items]
        if len(vectors) != len(texts):
            raise RuntimeError(f"向量条数不匹配：期望 {len(texts)}，实际 {len(vectors)}")
        return vectors


class StubEmbedding:
    """确定性假向量：同一文本永远得到同一向量（没有语义含义，仅用于自测）。

    维度默认 8，与工作器的假向量、智能体自测数据保持一致，保证本地链路可跑通。
    """

    def __init__(self, dim: int = 8) -> None:
        """校验维度（至少 2，才能区分不同文本的向量）。"""
        if dim < 2:
            raise ValueError("dim 至少为 2")
        self.dim = dim

    def embed(self, texts: list[str]) -> list[list[float]]:
        """逐条用 sha256 摘要生成确定性向量。"""
        return [self._one(text) for text in texts]

    def _one(self, text: str) -> list[float]:
        """把摘要字节映射到 0~1 的浮点向量（每维进一次 round，保证可复现）。"""
        digest = hashlib.sha256(text.encode("utf-8")).digest()
        return [round(digest[index] / 255.0, 6) for index in range(self.dim)]


def cosine(a: list[float], b: list[float]) -> float:
    """余弦相似度；任一向量为零向量时返回 0。"""
    if not a or not b or len(a) != len(b):
        return 0.0
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(y * y for y in b))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot / (norm_a * norm_b)


def embedding_from_settings(settings: AgentSettings | None = None) -> EmbeddingClient | None:
    """配置齐全返回真实客户端；本地假模型模式返回假向量；未配置返回 None（检索降级关键词）。"""
    settings = settings or get_agent_settings()
    if settings.llm_stub:
        return StubEmbedding()
    if not settings.has_real_embedding:
        return None
    return HttpEmbeddingClient(
        settings.embedding_api_base,
        settings.embedding_api_key,
        settings.embedding_model,
    )


def main() -> None:
    """自检：假向量确定性、余弦相似度边界、配置分支选择。"""
    embedder = StubEmbedding(dim=8)
    first, second, third = embedder.embed(["系统架构", "系统架构", "解析流程"])
    print("[agent.embedding] 向量维度:", len(first), "示例:", first[:3])
    assert first == second, "同一文本必须得到同一向量"
    assert first != third, "不同文本应得到不同向量"
    assert abs(cosine(first, second) - 1.0) < 1e-9
    assert -1e-9 <= cosine(first, third) <= 1.0
    assert cosine([1.0, 0.0], [1.0, 0.0]) == 1.0
    assert cosine([1.0, 0.0], [0.0, 1.0]) == 0.0
    assert cosine([], [1.0]) == 0.0 and cosine([0.0, 0.0], [1.0, 1.0]) == 0.0
    print("[agent.embedding] 余弦相似度自检通过")

    stub_settings = AgentSettings(llm_stub=True)
    client = embedding_from_settings(stub_settings)
    print("[agent.embedding] 假模型模式的客户端:", type(client).__name__)
    assert isinstance(client, StubEmbedding)

    no_key_settings = AgentSettings(llm_stub=False)
    print("[agent.embedding] 未配置密钥时的客户端:", embedding_from_settings(no_key_settings))
    assert embedding_from_settings(no_key_settings) is None
    assert embedder.embed([]) == []
    print("[agent.embedding] 自检通过")


if __name__ == "__main__":
    main()
