"""提示词加载：用 jinja2 渲染 `backend/agent/prompt/*.j2`。

在链路中的位置：规划节点、回答合成节点、用户图片描述工具都通过 `PromptLoader.render`
拿系统提示；模板文件名不带 `.j2` 后缀，变量名以模板为准（question / image_caption /
chunks / assets / citations_json）。
"""

if __package__ in (None, ""):  # 允许直接运行本文件
    import sys
    from pathlib import Path

    for _root in Path(__file__).resolve().parents:
        if (_root / "backend" / "app").is_dir():
            sys.path.insert(0, str(_root))
            break

from pathlib import Path

from jinja2 import Environment, FileSystemLoader, TemplateNotFound

from backend.agent.config import DEFAULT_PROMPT_DIR


class PromptLoader:
    """按名字渲染提示词模板（名字不带 .j2 后缀）。"""

    def __init__(self, prompt_dir: Path | None = None) -> None:
        """绑定模板目录并建 Jinja 环境；目录不存在直接报错（早暴露配置问题）。"""
        self.prompt_dir = Path(prompt_dir or DEFAULT_PROMPT_DIR)
        if not self.prompt_dir.is_dir():
            raise RuntimeError(f"提示词目录不存在: {self.prompt_dir}")
        self._environment = Environment(
            loader=FileSystemLoader(str(self.prompt_dir)),
            autoescape=False,
            trim_blocks=True,
            keep_trailing_newline=True,
        )

    def names(self) -> list[str]:
        """列出可用提示词名（自测里用来确认模板齐全）。"""
        return sorted(path.stem for path in self.prompt_dir.glob("*.j2"))

    def render(self, name: str, **context) -> str:
        """渲染指定模板并去掉首尾空白；模板不存在时抛 KeyError。"""
        try:
            template = self._environment.get_template(f"{name}.j2")
        except TemplateNotFound as error:
            raise KeyError(f"提示词不存在: {name}") from error
        return template.render(**context).strip()


def get_prompt_loader(prompt_dir: Path | None = None) -> PromptLoader:
    """构造提示词加载器（默认用 backend/agent/prompt 目录）。"""
    return PromptLoader(prompt_dir)


def main() -> None:
    """自检：模板齐全、变量被正确替换、不残留 Jinja 语法。"""
    from backend.agent.config import build_agent_settings

    settings = build_agent_settings(stub=True)
    loader = PromptLoader(settings.prompt_dir)
    print("[agent.prompt_loader] 可用提示词:", loader.names())
    assert {"planner", "synthesizer", "image_caption"} <= set(loader.names())

    planner = loader.render("planner", question="系统由哪些部分组成？", image_caption="")
    print("[agent.prompt_loader] planner 片段:", planner.splitlines()[0])
    assert "系统由哪些部分组成？" in planner
    assert "{{" not in planner and "{%" not in planner

    caption = loader.render("image_caption")
    print("[agent.prompt_loader] image_caption 长度:", len(caption))
    assert "caption" in caption and "{{" not in caption

    from backend.app.common import new_id
    from backend.app.schemas.content import Citation, ImageAsset, TextChunk

    chunk = TextChunk(chunk_id=new_id("chunk"), doc_id=new_id("doc"), page=1, seq=0, text="系统由前端和后端组成。")
    asset = ImageAsset(
        asset_id=new_id("asset"),
        doc_id=chunk.doc_id,
        page=1,
        object_key="assets/demo.png",
        caption="系统架构图",
        ocr_text="前端 后端",
    )
    citation = Citation(citation_id=new_id("cit"), doc_id=chunk.doc_id, chunk_id=chunk.chunk_id, page=1)
    synthesizer = loader.render(
        "synthesizer",
        question="系统由哪些部分组成？",
        image_caption="示意图",
        chunks=[chunk],
        assets=[asset],
        citations_json='[{"citation_id": "' + citation.citation_id + '"}]',
    )
    print("[agent.prompt_loader] synthesizer 片段:", synthesizer.splitlines()[0])
    assert "系统由前端和后端组成。" in synthesizer
    assert "{{" not in synthesizer
    print("[agent.prompt_loader] 自检通过")


if __name__ == "__main__":
    main()
