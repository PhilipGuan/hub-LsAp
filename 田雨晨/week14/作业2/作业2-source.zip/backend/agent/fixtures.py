"""智能体自测数据：临时 SQLite 里的批次 / 文档 / 文本切片 / 图片资源。

在链路中的位置：各节点与工具（text_search / image_load / citation_builder /
workflow / service）的 `main()` 自检都用它快速拿到一套真实表结构+数据，
不依赖外部数据库。

只在 tempfile 里建库，不会写 backend/data，也不产生任何外部模型调用。
"""

if __package__ in (None, ""):  # 允许直接运行本文件
    import sys
    from pathlib import Path

    for _root in Path(__file__).resolve().parents:
        if (_root / "backend" / "app").is_dir():
            sys.path.insert(0, str(_root))
            break

import tempfile
from dataclasses import dataclass, field
from pathlib import Path

from sqlalchemy import Engine, create_engine
from sqlalchemy.orm import Session, sessionmaker

from backend.agent.embedding import EmbeddingClient
from backend.app.common import new_id, utcnow
from backend.app.models.tables import Asset, Base, Batch, Chunk, Document

CHUNK_TEXTS = (
    "系统架构由前端网页、后端服务、问答编排智能体、解析工作器和消息队列组成。",
    "解析工作器调用 MinerU 把 PDF 解析成 Markdown、版面 JSON 和图片资源，再写入向量库。",
    "图片资源使用短时签名地址，前后端通过文档编号、页码和版面框关联。",
)
ASSET_CAPTIONS = ("系统架构图", "解析流程表")
ASSET_OCR_TEXT = ("前端 后端 问答智能体 解析工作器 消息队列", "步骤 MinerU 切片 向量库")
DOC_FILENAME = "智能体自测.pdf"


@dataclass
class SeedData:
    """一份自测数据的关键编号与文本。"""

    batch_id: str
    doc_id: str
    chunk_ids: list[str]
    asset_ids: list[str]
    texts: list[str] = field(default_factory=list)

    @property
    def linked_asset_id(self) -> str:
        """与第 1 条切片直接关联的图片资源编号。"""
        return self.asset_ids[0]


def make_temp_engine(tmp_dir: Path | str) -> Engine:
    """在临时目录建一个 SQLite 库并建表（不碰 backend/data）。"""
    tmp_dir = Path(tmp_dir)
    tmp_dir.mkdir(parents=True, exist_ok=True)
    engine = create_engine(
        f"sqlite:///{(tmp_dir / 'agent.db').as_posix()}",
        future=True,
        connect_args={"check_same_thread": False},
    )
    Base.metadata.create_all(engine)
    return engine


def seed(session: Session, embedder: EmbeddingClient | None = None) -> SeedData:
    """写入一批数据：3 条切片（第 1 条关联图片资源）+ 同文档第 2 页的图片资源。

    传入 embedder 时切片带向量（走向量检索分支）；不传时只有文本（走关键词降级分支）。
    """
    batch_id = new_id("batch")
    doc_id = new_id("doc")
    seed_time = utcnow()
    session.add(Batch(id=batch_id, trace_id=new_id("trace"), file_count=1, created_at=seed_time, updated_at=seed_time))
    session.add(
        Document(
            id=doc_id,
            batch_id=batch_id,
            filename=DOC_FILENAME,
            sha256="0" * 64,
            object_key=f"pdfs/{doc_id}.pdf",
            status="done",
            pages=10,
            created_at=seed_time,
            updated_at=seed_time,
        )
    )

    asset_ids = [new_id("asset"), new_id("asset")]
    chunk_ids = [new_id("chunk") for _ in CHUNK_TEXTS]
    embeddings = embedder.embed(list(CHUNK_TEXTS)) if embedder else [None] * len(CHUNK_TEXTS)
    for index, (chunk_id, text) in enumerate(zip(chunk_ids, CHUNK_TEXTS)):
        session.add(
            Chunk(
                id=chunk_id,
                doc_id=doc_id,
                page=index + 1,
                seq=index,
                text=text,
                asset_id=asset_ids[0] if index == 0 else None,
                embedding=embeddings[index],
                created_at=seed_time,
                updated_at=seed_time,
            )
        )

    # 第 1 页 figure + 第 2 页 table：用来验证“同页邻近图片”加载与引用构建
    for index, (asset_id, caption) in enumerate(zip(asset_ids, ASSET_CAPTIONS)):
        session.add(
            Asset(
                id=asset_id,
                doc_id=doc_id,
                page=index + 1,
                asset_type="figure" if index == 0 else "table",
                object_key=f"assets/{doc_id}/figure-{index + 1}.png",
                caption=caption,
                ocr_text=ASSET_OCR_TEXT[index],
                bbox=[72.0, 120.0, 480.0, 360.0] if index == 0 else None,
                created_at=seed_time,
                updated_at=seed_time,
            )
        )
    session.commit()
    return SeedData(batch_id=batch_id, doc_id=doc_id, chunk_ids=chunk_ids, asset_ids=asset_ids, texts=list(CHUNK_TEXTS))


def temp_session_factory(embedder: EmbeddingClient | None = None) -> tuple[sessionmaker[Session], SeedData]:
    """一行拿到临时库的会话工厂与已写入的自测数据（供各模块 main 复用）。"""
    engine = make_temp_engine(Path(tempfile.mkdtemp(prefix="rag-agent-fixture-")))
    factory = sessionmaker(bind=engine, expire_on_commit=False, class_=Session)
    with factory() as session:
        data = seed(session, embedder)
    return factory, data


def main() -> None:
    """自检：临时库里的行数、切片向量、图文关联与字段透传。"""
    from sqlalchemy import func, select

    from backend.agent.embedding import StubEmbedding

    embedder = StubEmbedding(dim=8)
    factory, data = temp_session_factory(embedder)
    print("[agent.fixtures] 批次:", data.batch_id)
    print("[agent.fixtures] 文档:", data.doc_id, "| 切片:", len(data.chunk_ids), "| 图片资源:", len(data.asset_ids))
    with factory() as session:
        counts = {
            "文档": session.scalar(select(func.count()).select_from(Document)),
            "切片": session.scalar(select(func.count()).select_from(Chunk)),
            "图片资源": session.scalar(select(func.count()).select_from(Asset)),
        }
        print("[agent.fixtures] 行数:", counts)
        assert counts == {"文档": 1, "切片": 3, "图片资源": 2}

        chunks = list(session.scalars(select(Chunk).order_by(Chunk.seq)))
        assert chunks[0].asset_id == data.linked_asset_id
        assert all(isinstance(chunk.embedding, list) and len(chunk.embedding) == 8 for chunk in chunks)
        assets = list(session.scalars(select(Asset).order_by(Asset.page)))
        assert [asset.caption for asset in assets] == list(ASSET_CAPTIONS)
        assert assets[0].bbox == [72.0, 120.0, 480.0, 360.0]
    print("[agent.fixtures] 自检通过")


if __name__ == "__main__":
    main()
