"""统一业务异常：服务层抛出，接口层转成对应 HTTP 状态码。"""


class AppError(Exception):
    """所有业务异常的基类。"""

    status_code = 400

    def __init__(self, message: str, *, detail: dict | None = None) -> None:
        """保存面向用户的 message 与可选结构化 detail，接口层原样转成 JSON。"""
        super().__init__(message)
        self.message = message
        self.detail = detail or {}


class InputError(AppError):
    """请求内容不合法：文件类型、大小、数量、空问题等。"""

    status_code = 400


class NotFoundError(AppError):
    """批次 / 文档 / 图片资源不存在。"""

    status_code = 404


class ForbiddenError(AppError):
    """签名地址无效或已过期。"""

    status_code = 403


class ConflictError(AppError):
    """当前状态不允许该操作，例如解析中的文档不能手动重试。"""

    status_code = 409


class UpstreamError(AppError):
    """下游服务异常：智能体调用失败、模型超时等。"""

    status_code = 502


def main() -> None:
    """自测：每个子类都带对应 HTTP 状态码，且都能被基类 AppError 捕获。"""
    for error_class in (InputError, ForbiddenError, NotFoundError, ConflictError, UpstreamError):
        error = error_class("示例错误", detail={"field": "demo"})
        print(f"[errors] {error_class.__name__}: status={error.status_code} message={error.message} detail={error.detail}")
        try:
            raise error
        except AppError as caught:
            assert caught.status_code == error_class.status_code
            assert caught.message == "示例错误"
    print("[errors] 自检通过")


if __name__ == "__main__":
    main()
