"""数据库引擎与会话：本地默认 SQLite，切 Docker 时只改 DATABASE_URL。"""

if __package__ in (None, ""):  # 允许直接运行本文件
    import sys
    from pathlib import Path

    for _root in Path(__file__).resolve().parents:
        if (_root / "backend" / "app").is_dir():
            sys.path.insert(0, str(_root))
            break

from pathlib import Path

from sqlalchemy import create_engine
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session, sessionmaker

from backend.app.config import Settings, get_settings
from backend.app.models.tables import Base


def make_engine(settings: Settings | None = None) -> Engine:
    """按配置创建引擎。SQLite 需要放开线程检查，FastAPI 会在不同线程里用连接。"""
    settings = settings or get_settings()
    url = settings.database_url
    if url.startswith("sqlite"):
        Path(settings.data_dir).mkdir(parents=True, exist_ok=True)
        return create_engine(url, future=True, connect_args={"check_same_thread": False})
    return create_engine(url, future=True, pool_pre_ping=True)


def make_session_factory(engine: Engine) -> sessionmaker[Session]:
    """会话工厂。expire_on_commit=False：提交后对象仍可读，服务层拼响应时不必重查。"""
    return sessionmaker(bind=engine, expire_on_commit=False, class_=Session)


def init_db(engine: Engine) -> None:
    """按 ORM 模型建表。create_all 幂等，可在启动时直接调用（生产应换迁移工具）。"""
    Base.metadata.create_all(engine)


def main() -> None:
    """自测：临时 SQLite 建表 → 写入三类行 → 读回计数并校验默认状态。"""
    import tempfile

    from sqlalchemy import func, select

    from backend.app.models.tables import Batch, Document, ParseTask

    tmp = Path(tempfile.mkdtemp(prefix="rag-db-"))
    settings = Settings(database_url=f"sqlite:///{(tmp / 'app.db').as_posix()}", data_dir=tmp)
    settings.ensure_dirs()
    engine = make_engine(settings)
    init_db(engine)
    print("[db] 数据库:", settings.database_url)
    print("[db] 已建表:", ", ".join(sorted(Base.metadata.tables)))

    factory = make_session_factory(engine)
    with factory() as session:
        session.add(Batch(id="batch_demo", trace_id="trace_demo", file_count=1))
        session.add(
            Document(
                id="doc_demo",
                batch_id="batch_demo",
                filename="demo.pdf",
                sha256="0" * 64,
                object_key="pdfs/demo.pdf",
            )
        )
        session.add(ParseTask(id="task_demo", doc_id="doc_demo", trace_id="trace_demo"))
        session.commit()

    with factory() as session:
        counts = {
            "批次": session.scalar(select(func.count()).select_from(Batch)),
            "文档": session.scalar(select(func.count()).select_from(Document)),
            "任务": session.scalar(select(func.count()).select_from(ParseTask)),
        }
        print("[db] 行数:", counts)
        assert all(value == 1 for value in counts.values()), "写入后应有数据"
        assert session.get(Document, "doc_demo").status == "queued"
    print("[db] 自检通过")


if __name__ == "__main__":
    main()
