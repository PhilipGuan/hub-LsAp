"""允许 python -m backend.app.schemas 运行数据结构自检。"""

from backend.app.schemas import main

if __name__ == "__main__":
    main()
