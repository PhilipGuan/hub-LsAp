"""文本切片、图片资源、引用等 pydantic 数据结构。"""

if __package__ in (None, ""):  # 允许直接运行本文件
    import sys
    from pathlib import Path

    for _root in Path(__file__).resolve().parents:
        if (_root / "backend" / "app").is_dir():
            sys.path.insert(0, str(_root))
            break

from datetime import datetime

from pydantic import BaseModel, Field

from backend.app.schemas.enums import AssetType


class TextChunk(BaseModel):
    """文本切片（检索结果 / 智能体上下文）。"""

    chunk_id: str
    doc_id: str
    # 文档文件名：给合成节点/前端展示用，避免回答里出现 doc_xxx 这种编号
    doc_filename: str = ""
    page: int = Field(0, ge=0)
    seq: int = Field(0, ge=0)
    text: str
    asset_id: str | None = None
    score: float | None = None


class ImageAsset(BaseModel):
    """图片资源：与文档、页码、说明文字、识别文字、版面框关联。"""

    asset_id: str
    doc_id: str
    doc_filename: str = ""
    page: int = Field(0, ge=0)
    asset_type: AssetType = AssetType.FIGURE
    object_key: str
    caption: str = ""
    ocr_text: str = ""
    bbox: list[float] | None = None
    created_at: datetime | None = None


class Citation(BaseModel):
    """引用：文档编号、页码、切片编号、图片资源编号、版面框。"""

    citation_id: str
    doc_id: str = ""
    doc_filename: str | None = None
    chunk_id: str | None = None
    asset_id: str | None = None
    page: int = Field(0, ge=0)
    bbox: list[float] | None = None


class SignedAsset(BaseModel):
    """图片资源的短时签名地址。"""

    asset_id: str
    url: str
    expires_at: datetime


def main() -> None:
    """自测：文本切片、图片资源、引用、签名地址四类结构都能正确序列化。"""
    from backend.app.common import new_id, utcnow

    chunk = TextChunk(
        chunk_id=new_id("chunk"),
        doc_id=new_id("doc"),
        page=3,
        seq=7,
        text="多模态 RAG 把文本切片和图片资源关联到同一页。",
    )
    print("[schemas.content] 文本切片:")
    print(chunk.model_dump_json(indent=2, ensure_ascii=False))
    assert chunk.page == 3 and chunk.asset_id is None

    asset = ImageAsset(
        asset_id=new_id("asset"),
        doc_id=chunk.doc_id,
        page=3,
        asset_type=AssetType.FIGURE,
        object_key="assets/demo/figure-1.png",
        caption="系统架构图",
        ocr_text="前端 后端 解析工作器",
        bbox=[72.0, 120.0, 480.0, 360.0],
        created_at=utcnow(),
    )
    print("[schemas.content] 图片资源:")
    print(asset.model_dump_json(indent=2, ensure_ascii=False))
    assert asset.asset_type is AssetType.FIGURE and asset.bbox[2] == 480.0

    citation = Citation(
        citation_id=new_id("cit"),
        doc_id=chunk.doc_id,
        doc_filename="作业2说明.pdf",
        chunk_id=chunk.chunk_id,
        asset_id=asset.asset_id,
        page=3,
        bbox=asset.bbox,
    )
    print("[schemas.content] 引用:")
    print(citation.model_dump_json(indent=2, ensure_ascii=False))
    assert citation.page == 3

    signed = SignedAsset(
        asset_id=asset.asset_id,
        url=f"http://127.0.0.1:8000/api/assets/{asset.asset_id}?expires=1&signature=abc",
        expires_at=utcnow(),
    )
    print("[schemas.content] 签名地址:", signed.url)
    print("[schemas.content] 自检通过")


if __name__ == "__main__":
    main()
