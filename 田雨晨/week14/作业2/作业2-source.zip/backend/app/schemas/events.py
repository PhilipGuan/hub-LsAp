"""消息与事件相关的 pydantic 数据结构：Kafka 元数据、发件箱、SSE 状态事件。"""

if __package__ in (None, ""):  # 允许直接运行本文件
    import sys
    from pathlib import Path

    for _root in Path(__file__).resolve().parents:
        if (_root / "backend" / "app").is_dir():
            sys.path.insert(0, str(_root))
            break

from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field, computed_field

from backend.app.schemas.enums import (
    BatchStatus,
    DocumentStatus,
    EventType,
    batch_display_status,
    document_display_status,
)


class ParseRequestMessage(BaseModel):
    """解析请求消息：只传元数据，绝不传 PDF 二进制。"""

    doc_id: str
    batch_id: str
    object_key: str
    filename: str = ""
    trace_id: str = ""
    attempt: int = Field(1, ge=1)


class DeadLetterMessage(BaseModel):
    """死信消息：自动重试耗尽后投递到 DLQ。"""

    doc_id: str
    batch_id: str = ""
    filename: str = ""
    trace_id: str = ""
    attempts: int = Field(0, ge=0)
    error: str = ""


class OutboxEventInfo(BaseModel):
    """事务发件箱中的一条待投递事件。"""

    event_id: str
    aggregate_id: str
    event_type: str
    payload: dict
    delivered: bool = False
    created_at: datetime | None = None


class DocumentStatusItem(BaseModel):
    """SSE / 轮询返回的单文档状态。"""

    doc_id: str
    filename: str
    status: DocumentStatus
    error: str | None = None
    pages: int = 0

    @computed_field
    @property
    def display_status(self) -> str:
        """前端直接展示的中文状态（单文档维度）。"""
        return document_display_status(self.status)


class StatusEvent(BaseModel):
    """服务器推送事件：一次推送一个批次的完整状态快照。"""

    event: Literal["status"] = "status"
    batch_id: str
    status: BatchStatus
    documents: list[DocumentStatusItem]
    ts: datetime

    @computed_field
    @property
    def display_status(self) -> str:
        """前端直接展示的中文状态（批次维度）。"""
        return batch_display_status(self.status)


def main() -> None:
    """自测：解析请求 / 死信 / 状态推送 / 发件箱四类结构都能正确序列化。"""
    from backend.app.common import new_id, utcnow

    message = ParseRequestMessage(
        doc_id=new_id("doc"),
        batch_id=new_id("batch"),
        object_key="pdfs/demo.pdf",
        filename="说明.pdf",
        trace_id=new_id("trace"),
    )
    print("[schemas.events] 解析请求消息:")
    print(message.model_dump_json(indent=2, ensure_ascii=False))
    assert message.attempt == 1 and b"pdf" not in message.model_dump()

    dead = DeadLetterMessage(doc_id=message.doc_id, attempts=3, error="MinerU 超时")
    print("[schemas.events] 死信消息:", dead.model_dump_json(ensure_ascii=False))

    event = StatusEvent(
        batch_id=message.batch_id,
        status=BatchStatus.PARSING,
        documents=[DocumentStatusItem(doc_id=message.doc_id, filename="说明.pdf", status=DocumentStatus.PARSING)],
        ts=utcnow(),
    )
    print("[schemas.events] 状态推送:")
    print(event.model_dump_json(indent=2, ensure_ascii=False))
    assert event.status == BatchStatus.PARSING and event.display_status == "解析中"
    assert event.documents[0].display_status == "解析中"

    outbox = OutboxEventInfo(
        event_id=new_id("evt"),
        aggregate_id=message.doc_id,
        event_type=EventType.PARSE_REQUESTED.value,
        payload=message.model_dump(mode="json"),
        created_at=utcnow(),
    )
    print("[schemas.events] 发件箱事件:", outbox.model_dump_json(ensure_ascii=False))
    assert outbox.payload["doc_id"] == message.doc_id
    print("[schemas.events] 自检通过")


if __name__ == "__main__":
    main()
