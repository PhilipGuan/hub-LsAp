"""问答相关的 pydantic 数据结构：后端 <-> 智能体契约、图文混排回答。"""

if __package__ in (None, ""):  # 允许直接运行本文件
    import sys
    from pathlib import Path

    for _root in Path(__file__).resolve().parents:
        if (_root / "backend" / "app").is_dir():
            sys.path.insert(0, str(_root))
            break

from datetime import datetime
from typing import Annotated, Literal, Union

from pydantic import BaseModel, Field

from backend.app.schemas.content import Citation


class AgentImage(BaseModel):
    """随问题一起送进智能体的用户图片（内网传输，base64）。"""

    mime_type: str
    data_base64: str


class AgentRequest(BaseModel):
    """后端调用智能体的请求。"""

    question: str
    image: AgentImage | None = None
    top_k: int = Field(6, ge=1, le=50)


class TextSegment(BaseModel):
    """回答中的文本段。"""

    type: Literal["text"] = "text"
    text: str
    sources: list[str] = Field(default_factory=list)


class ImageSegment(BaseModel):
    """回答中的图片段；asset_url 由后端补全，智能体只返回 asset_id。"""

    type: Literal["image"] = "image"
    asset_id: str
    caption: str = ""
    sources: list[str] = Field(default_factory=list)
    doc_id: str | None = None
    page: int | None = None
    asset_url: str | None = None
    asset_url_expires_at: datetime | None = None


AnswerSegment = Annotated[Union[TextSegment, ImageSegment], Field(discriminator="type")]


class AgentResponse(BaseModel):
    """智能体返回的结构化结果。"""

    answer: str
    segments: list[AnswerSegment] = Field(default_factory=list)
    citations: list[Citation] = Field(default_factory=list)


class QAResponse(BaseModel):
    """问答接口返回：兜底正文 + 分段列表 + 引用列表。"""

    qa_id: str
    answer: str
    segments: list[AnswerSegment]
    citations: list[Citation]
    created_at: datetime
    fallback: bool = False  # 结构化输出失败、退回纯文本时为 True


def main() -> None:
    """自测：三段的判别联合能按 type 还原具体类型，兜底响应只含文本段。"""
    from backend.app.common import new_id, utcnow

    agent_response = AgentResponse(
        answer="系统由前端、后端、解析工作器和智能体组成。",
        segments=[
            TextSegment(text="系统由前端、后端、解析工作器和智能体组成。", sources=["cit_demo"]),
            ImageSegment(asset_id="asset_demo", caption="系统架构图", sources=["cit_demo"]),
        ],
        citations=[
            Citation(citation_id="cit_demo", doc_id="doc_demo", doc_filename="说明.pdf", page=2)
        ],
    )
    print("[schemas.qa] 智能体结构化结果:")
    print(agent_response.model_dump_json(indent=2, ensure_ascii=False))
    assert len(agent_response.segments) == 2
    assert agent_response.segments[0].type == "text"
    assert agent_response.segments[1].type == "image"

    # 判别联合：从 JSON 反序列化时按 type 字段还原具体类型
    restored = AgentResponse.model_validate_json(agent_response.model_dump_json())
    assert isinstance(restored.segments[1], ImageSegment), "image 段应还原为 ImageSegment"

    reply = QAResponse(
        qa_id=new_id("qa"),
        answer=agent_response.answer,
        segments=agent_response.segments,
        citations=agent_response.citations,
        created_at=utcnow(),
        fallback=False,
    )
    print("[schemas.qa] 问答响应:")
    print(reply.model_dump_json(indent=2, ensure_ascii=False))
    assert reply.segments[0].type == "text"

    # 兜底：结构化输出失败时只有文本段
    fallback = QAResponse(
        qa_id=new_id("qa"),
        answer="根据提供的资料无法回答该问题。",
        segments=[TextSegment(text="根据提供的资料无法回答该问题。")],
        citations=[],
        created_at=utcnow(),
        fallback=True,
    )
    assert fallback.fallback and len(fallback.segments) == 1
    print("[schemas.qa] 自检通过")


if __name__ == "__main__":
    main()
