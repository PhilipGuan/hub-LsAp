"""批次、文档、解析任务相关的 pydantic 数据结构（接口出入参）。"""

if __package__ in (None, ""):  # 允许 python backend/app/schemas/batch.py 直接运行
    import sys
    from pathlib import Path

    for _root in Path(__file__).resolve().parents:
        if (_root / "backend" / "app").is_dir():
            sys.path.insert(0, str(_root))
            break

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field, computed_field

from backend.app.schemas.enums import (
    BatchStatus,
    DocumentStatus,
    TaskStatus,
    batch_display_status,
    document_display_status,
)


class UploadFileData(BaseModel):
    """服务层的单个上传文件（content 是二进制，不参与序列化）。"""

    model_config = ConfigDict(arbitrary_types_allowed=True)

    filename: str
    content: bytes = Field(exclude=True, repr=False)
    content_type: str | None = None


class DocumentRef(BaseModel):
    """批次状态里的一条文档摘要。"""

    doc_id: str
    filename: str
    status: DocumentStatus
    error: str | None = None
    pages: int = 0

    @computed_field
    @property
    def display_status(self) -> str:
        """前端直接展示的中文状态（单文档维度）。"""
        return document_display_status(self.status)


class BatchUploadResponse(BaseModel):
    """上传接口返回：批次编号 + 文档列表。"""

    batch_id: str
    trace_id: str
    status: BatchStatus
    documents: list[DocumentRef]
    # 因内容重复（sha256 相同）被跳过的文件名；全部重复时接口直接 400，不会返回空批次
    duplicates: list[str] = Field(default_factory=list)
    created_at: datetime

    @computed_field
    @property
    def display_status(self) -> str:
        """前端直接展示的中文状态（批次维度）。"""
        return batch_display_status(self.status)


class DocumentInfo(BaseModel):
    """单文档详情。"""

    doc_id: str
    batch_id: str
    filename: str
    sha256: str
    object_key: str
    status: DocumentStatus
    error: str | None = None
    pages: int = 0
    attempts: int = 0
    created_at: datetime
    updated_at: datetime

    @computed_field
    @property
    def display_status(self) -> str:
        """前端直接展示的中文状态（单文档维度）。"""
        return document_display_status(self.status)


class DocumentListResponse(BaseModel):
    """知识库文档列表：问答页展示当前可检索的文档。"""

    total: int
    documents: list[DocumentInfo]


class DeleteDocumentResponse(BaseModel):
    """删除文档结果。"""

    doc_id: str
    message: str


class BatchStatusResponse(BaseModel):
    """批次状态接口返回：两级状态 + 计数。"""

    batch_id: str
    status: BatchStatus
    total: int
    done_count: int
    failed_count: int
    active_count: int
    documents: list[DocumentRef]
    created_at: datetime
    updated_at: datetime

    @computed_field
    @property
    def display_status(self) -> str:
        """前端直接展示的中文状态（批次维度）。"""
        return batch_display_status(self.status)


class RetryResponse(BaseModel):
    """手动重试接口返回。"""

    doc_id: str
    status: DocumentStatus
    message: str

    @computed_field
    @property
    def display_status(self) -> str:
        """前端直接展示的中文状态（单文档维度）。"""
        return document_display_status(self.status)


class ParseTaskInfo(BaseModel):
    """解析任务详情。"""

    task_id: str
    doc_id: str
    status: TaskStatus
    attempts: int
    last_error: str | None = None
    started_at: datetime | None = None
    finished_at: datetime | None = None


def main() -> None:
    """自测：各响应结构的序列化结果与中文展示状态（display_status）。"""
    from backend.app.common import new_id, utcnow

    now = utcnow()
    ref = DocumentRef(doc_id=new_id("doc"), filename="数据结构.pdf", status=DocumentStatus.PARSING, pages=0)
    print("[schemas.batch] 文档摘要:")
    print(ref.model_dump_json(indent=2, ensure_ascii=False))
    assert ref.display_status == "解析中"

    upload = BatchUploadResponse(
        batch_id=new_id("batch"),
        trace_id=new_id("trace"),
        status=BatchStatus.PARSING,
        documents=[ref],
        created_at=now,
    )
    print("[schemas.batch] 上传响应:")
    print(upload.model_dump_json(indent=2, ensure_ascii=False))
    assert upload.display_status == "解析中"
    assert "content" not in upload.model_dump()

    status = BatchStatusResponse(
        batch_id=upload.batch_id,
        status=BatchStatus.PARTIAL_FAILED,
        total=1,
        done_count=0,
        failed_count=1,
        active_count=0,
        documents=[ref],
        created_at=now,
        updated_at=now,
    )
    print("[schemas.batch] 批次状态:")
    print(status.model_dump_json(indent=2, ensure_ascii=False))
    assert status.display_status == "部分失败"

    info = DocumentInfo(
        doc_id=ref.doc_id,
        batch_id=upload.batch_id,
        filename="数据结构.pdf",
        sha256="0" * 64,
        object_key="pdfs/demo.pdf",
        status=DocumentStatus.DONE,
        pages=12,
        attempts=1,
        created_at=now,
        updated_at=now,
    )
    print("[schemas.batch] 文档详情:")
    print(info.model_dump_json(indent=2, ensure_ascii=False))
    assert info.display_status == "解析完成"

    retry = RetryResponse(doc_id=ref.doc_id, status=DocumentStatus.QUEUED, message="已重新排队")
    print("[schemas.batch] 重试响应:", retry.model_dump_json(ensure_ascii=False))
    print("[schemas.batch] 自检通过")


if __name__ == "__main__":
    main()
