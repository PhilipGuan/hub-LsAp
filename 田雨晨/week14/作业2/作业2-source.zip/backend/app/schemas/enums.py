"""状态与类型枚举：与 README 的状态机、前端展示映射一一对应。"""

from enum import StrEnum


class DocumentStatus(StrEnum):
    """单文档内部状态（数据库为准，Kafka 消息不作为状态来源）。"""

    QUEUED = "queued"        # 排队中
    PARSING = "parsing"      # 解析中
    INDEXING = "indexing"    # 索引中
    RETRYING = "retrying"    # 重试中
    DONE = "done"            # 解析完成
    FAILED = "failed"        # 解析失败


class BatchStatus(StrEnum):
    """批次总状态，由批次下所有文档状态推导。"""

    QUEUED = "queued"
    PARSING = "parsing"
    DONE = "done"
    PARTIAL_FAILED = "partial_failed"
    FAILED = "failed"


class TaskStatus(StrEnum):
    """解析任务状态。"""

    PENDING = "pending"
    RUNNING = "running"
    SUCCEEDED = "succeeded"
    FAILED = "failed"


class AssetType(StrEnum):
    """图片资源类型（MinerU 产物分类）。"""

    FIGURE = "figure"
    TABLE = "table"
    IMAGE = "image"
    OTHER = "other"


class EventType(StrEnum):
    """事务发件箱 / Kafka 事件类型。"""

    PARSE_REQUESTED = "parse.requested"
    PARSE_DEAD_LETTER = "parse.dead_letter"


DOCUMENT_DISPLAY = {
    DocumentStatus.QUEUED: "待解析",
    DocumentStatus.PARSING: "解析中",
    DocumentStatus.INDEXING: "解析中",
    DocumentStatus.RETRYING: "解析中",
    DocumentStatus.DONE: "解析完成",
    DocumentStatus.FAILED: "解析失败",
}

BATCH_DISPLAY = {
    BatchStatus.QUEUED: "待解析",
    BatchStatus.PARSING: "解析中",
    BatchStatus.DONE: "解析完成",
    BatchStatus.PARTIAL_FAILED: "部分失败",
    BatchStatus.FAILED: "解析失败",
}

ACTIVE_STATUSES = frozenset(
    {DocumentStatus.QUEUED, DocumentStatus.PARSING, DocumentStatus.INDEXING, DocumentStatus.RETRYING}
)
PROCESSING_STATUSES = frozenset(
    {DocumentStatus.PARSING, DocumentStatus.INDEXING, DocumentStatus.RETRYING}
)
TERMINAL_STATUSES = frozenset({DocumentStatus.DONE, DocumentStatus.FAILED})


def document_display_status(status: str | DocumentStatus) -> str:
    """单文档状态转前端中文文案；传入未知状态值时抛 ValueError。"""
    return DOCUMENT_DISPLAY[DocumentStatus(status)]


def batch_display_status(status: str | BatchStatus) -> str:
    """批次状态转前端中文文案。"""
    return BATCH_DISPLAY[BatchStatus(status)]


def is_terminal(status: str | DocumentStatus) -> bool:
    """是否终态（解析完成 / 解析失败）；轮询与批次汇总用它判断还要不要继续等。"""
    return DocumentStatus(status) in TERMINAL_STATUSES


def derive_batch_status(statuses: list[DocumentStatus]) -> BatchStatus:
    """把批次下所有文档状态汇总成批次状态：排队 → 解析中 → 完成/部分失败/失败。"""
    if not statuses:
        return BatchStatus.QUEUED
    if any(status in PROCESSING_STATUSES for status in statuses):
        return BatchStatus.PARSING
    if all(status in TERMINAL_STATUSES for status in statuses):
        if all(status == DocumentStatus.DONE for status in statuses):
            return BatchStatus.DONE
        if all(status == DocumentStatus.FAILED for status in statuses):
            return BatchStatus.FAILED
        return BatchStatus.PARTIAL_FAILED
    return BatchStatus.QUEUED


def main() -> None:
    """自测：状态到中文文案的映射，以及批次状态的汇总规则。"""
    print("[enums] 单文档状态 -> 前端展示:")
    for status in DocumentStatus:
        print(f"  {status.value:10s} -> {document_display_status(status)}")

    print("[enums] 批次状态 -> 前端展示:")
    for status in BatchStatus:
        print(f"  {status.value:15s} -> {batch_display_status(status)}")

    assert derive_batch_status([]) == BatchStatus.QUEUED
    assert derive_batch_status([DocumentStatus.QUEUED, DocumentStatus.QUEUED]) == BatchStatus.QUEUED
    assert derive_batch_status([DocumentStatus.DONE, DocumentStatus.DONE]) == BatchStatus.DONE
    assert derive_batch_status([DocumentStatus.DONE, DocumentStatus.FAILED]) == BatchStatus.PARTIAL_FAILED
    assert derive_batch_status([DocumentStatus.FAILED, DocumentStatus.PARSING]) == BatchStatus.PARSING
    assert derive_batch_status([DocumentStatus.FAILED]) == BatchStatus.FAILED
    assert derive_batch_status([DocumentStatus.DONE, DocumentStatus.QUEUED]) == BatchStatus.QUEUED
    assert derive_batch_status([DocumentStatus.FAILED, DocumentStatus.QUEUED]) == BatchStatus.QUEUED
    assert is_terminal(DocumentStatus.DONE) and not is_terminal(DocumentStatus.PARSING)
    assert document_display_status("queued") == "待解析"
    print("[enums] 自检通过")


if __name__ == "__main__":
    main()
