"""pydantic 数据结构统一出口：`from backend.app.schemas import DocumentInfo`。"""

from backend.app.schemas.batch import (
    BatchStatusResponse,
    BatchUploadResponse,
    DeleteDocumentResponse,
    DocumentInfo,
    DocumentListResponse,
    DocumentRef,
    ParseTaskInfo,
    RetryResponse,
    UploadFileData,
)
from backend.app.schemas.content import Citation, ImageAsset, SignedAsset, TextChunk
from backend.app.schemas.enums import (
    ACTIVE_STATUSES,
    BATCH_DISPLAY,
    DOCUMENT_DISPLAY,
    TERMINAL_STATUSES,
    AssetType,
    BatchStatus,
    DocumentStatus,
    EventType,
    TaskStatus,
    batch_display_status,
    derive_batch_status,
    document_display_status,
    is_terminal,
)
from backend.app.schemas.events import (
    DeadLetterMessage,
    DocumentStatusItem,
    OutboxEventInfo,
    ParseRequestMessage,
    StatusEvent,
)
from backend.app.schemas.qa import (
    AgentImage,
    AgentRequest,
    AgentResponse,
    AnswerSegment,
    ImageSegment,
    QAResponse,
    TextSegment,
)

__all__ = [
    "ACTIVE_STATUSES",
    "BATCH_DISPLAY",
    "DOCUMENT_DISPLAY",
    "TERMINAL_STATUSES",
    "AgentImage",
    "AgentRequest",
    "AgentResponse",
    "AnswerSegment",
    "AssetType",
    "BatchStatus",
    "BatchStatusResponse",
    "BatchUploadResponse",
    "Citation",
    "DeadLetterMessage",
    "DocumentInfo",
    "DocumentRef",
    "DocumentStatus",
    "DocumentStatusItem",
    "EventType",
    "ImageAsset",
    "ImageSegment",
    "OutboxEventInfo",
    "ParseRequestMessage",
    "ParseTaskInfo",
    "QAResponse",
    "RetryResponse",
    "SignedAsset",
    "StatusEvent",
    "TaskStatus",
    "TextChunk",
    "TextSegment",
    "UploadFileData",
    "batch_display_status",
    "derive_batch_status",
    "document_display_status",
    "is_terminal",
]


def main() -> None:
    """自测：__all__ 里的名字都真的导出，并能实例化一个示例结构。"""
    print("[schemas] 已导出", len(__all__), "个数据结构")
    for name in __all__:
        assert name in globals(), f"缺少导出: {name}"
    sample = DocumentRef(doc_id="doc_demo", filename="a.pdf", status="done")
    print("[schemas] 示例:", sample.model_dump_json(ensure_ascii=False))
    print("[schemas] 自检通过")


if __name__ == "__main__":
    main()
