"""上传服务：校验 PDF 并落库批次、文档、解析任务与事务发件箱事件。

流程：校验文件 → 写对象存储 → 同一事务写 Batch/Document/ParseTask/outbox → 提交。
顺序是“存储先写、数据库后提交”，所以数据库事务失败时会尽力删除已写对象，避免孤儿文件。
"""

if __package__ in (None, ""):  # 允许直接运行本文件
    import sys
    from pathlib import Path

    for _root in Path(__file__).resolve().parents:
        if (_root / "backend" / "app").is_dir():
            sys.path.insert(0, str(_root))
            break

import hashlib
from collections.abc import Sequence

from sqlalchemy import select
from sqlalchemy.orm import Session

from backend.app.clients.storage import ObjectStorage
from backend.app.common import new_id
from backend.app.config import Settings, get_settings
from backend.app.errors import InputError
from backend.app.models.tables import Batch, Document, ParseTask
from backend.app.schemas.batch import BatchUploadResponse, DocumentRef, UploadFileData
from backend.app.schemas.enums import BatchStatus, DocumentStatus, EventType, TaskStatus
from backend.app.schemas.events import ParseRequestMessage
from backend.app.services.outbox import enqueue

PDF_SUFFIX = ".pdf"
PDF_MAGIC = b"%PDF-"
ALLOWED_CONTENT_TYPES = frozenset({"application/pdf", "application/octet-stream"})


def validate_files(files: Sequence[UploadFileData], settings: Settings | None = None) -> list[UploadFileData]:
    """校验上传文件：数量、扩展名、PDF 魔数、单文件大小、content_type。"""
    settings = settings or get_settings()
    items = list(files)
    if not items:
        raise InputError("至少上传一个 PDF 文件")
    if len(items) > settings.max_batch_files:
        raise InputError(f"单批次最多 {settings.max_batch_files} 个文件，本次 {len(items)} 个")
    for item in items:
        filename = item.filename or ""
        if not filename.lower().endswith(PDF_SUFFIX):
            raise InputError(f"{filename}: 只支持 PDF 文件")
        if not item.content or not item.content.startswith(PDF_MAGIC):
            raise InputError(f"{filename}: 不是有效的 PDF 文件")
        if len(item.content) > settings.max_upload_bytes:
            raise InputError(f"{filename}: 超过 {settings.max_upload_mb}MB 上限")
        if item.content_type and item.content_type not in ALLOWED_CONTENT_TYPES:
            raise InputError(f"{filename}: 不支持的文件类型 {item.content_type}")
    return items


def create_batch(
    session: Session,
    settings: Settings,
    files: Sequence[UploadFileData],
    storage: ObjectStorage,
) -> BatchUploadResponse:
    """校验并创建上传批次：按 sha256 去重（已存在的内容跳过），写存储后单事务落库。"""
    items = validate_files(files, settings)

    # sha256 去重：同一份 PDF 只解析一次，避免知识库里出现重复文档。
    # 同一批次内重复的选择也在这里合并；已存在的文档（任意状态）同样跳过。
    candidate_shas = {hashlib.sha256(item.content).hexdigest() for item in items}
    existing_shas = set(
        session.scalars(select(Document.sha256).where(Document.sha256.in_(candidate_shas))).all()
    )
    prepared: list[tuple[UploadFileData, str]] = []
    duplicates: list[str] = []
    seen: set[str] = set()
    for item in items:
        sha256 = hashlib.sha256(item.content).hexdigest()
        if sha256 in existing_shas or sha256 in seen:
            duplicates.append(item.filename)
            continue
        seen.add(sha256)
        prepared.append((item, sha256))
    if not prepared:
        raise InputError("这些文件之前已经上传过（内容相同，sha256 一致），无需重复上传；可用「重新解析」更新已有文档")

    batch_id = new_id("batch")
    trace_id = new_id("trace")
    batch = Batch(id=batch_id, trace_id=trace_id, file_count=len(prepared))
    session.add(batch)
    documents: list[DocumentRef] = []
    written_keys: list[str] = []
    try:
        for item, sha256 in prepared:
            doc_id = new_id("doc")
            # key 里带新生成的 doc_id：同一份 PDF 重复上传也不会互相覆盖
            object_key = f"pdfs/{doc_id}.pdf"
            storage.put(object_key, item.content, "application/pdf")
            written_keys.append(object_key)
            session.add(
                Document(
                    id=doc_id,
                    batch_id=batch_id,
                    filename=item.filename,
                    sha256=sha256,
                    object_key=object_key,
                    status=DocumentStatus.QUEUED.value,
                )
            )
            session.add(
                ParseTask(
                    id=new_id("task"),
                    doc_id=doc_id,
                    status=TaskStatus.PENDING.value,
                    trace_id=trace_id,
                )
            )
            message = ParseRequestMessage(
                doc_id=doc_id,
                batch_id=batch_id,
                object_key=object_key,
                filename=item.filename,
                trace_id=trace_id,
            )
            enqueue(
                session,
                aggregate_id=doc_id,
                event_type=EventType.PARSE_REQUESTED,
                payload=message.model_dump(mode="json"),
            )
            documents.append(DocumentRef(doc_id=doc_id, filename=item.filename, status=DocumentStatus.QUEUED))
        session.commit()
    except Exception:
        # 存储已写成功但数据库事务失败：尽力删除已写对象，避免留下孤儿文件；
        # 删除失败不覆盖原始异常，调用方仍能看到失败原因。
        session.rollback()
        for key in written_keys:
            try:
                storage.delete(key)
            except Exception:
                pass
        raise
    return BatchUploadResponse(
        batch_id=batch_id,
        trace_id=trace_id,
        status=BatchStatus.QUEUED,
        documents=documents,
        duplicates=duplicates,
        created_at=batch.created_at,
    )


def main() -> None:
    """自测：正常上传（落库 + 写存储 + 发件箱），再模拟提交失败验证孤儿对象清理。"""
    import tempfile
    from pathlib import Path

    from sqlalchemy import func, select

    from backend.app.clients.storage import LocalStorage
    from backend.app.db import init_db, make_engine, make_session_factory
    from backend.app.models.tables import OutboxEvent

    class _FailingSession:
        """提交必失败的会话包装：验证“存储已写、事务失败”时的孤儿文件清理。"""

        def __init__(self, session: Session) -> None:
            """包一层真实会话，只在 commit 上做手脚，其他属性原样透传。"""
            self._session = session

        def __getattr__(self, name: str):
            """除 commit 外的会话属性全部委托给真实会话。"""
            return getattr(self._session, name)

        def commit(self) -> None:
            """模拟数据库提交失败，触发调用方的回滚与对象清理分支。"""
            raise RuntimeError("模拟数据库提交失败")

    tmp = Path(tempfile.mkdtemp(prefix="rag-upload-"))
    settings = Settings(
        database_url=f"sqlite:///{(tmp / 'app.db').as_posix()}",
        data_dir=tmp,
        storage_dir=tmp / "storage",
        max_upload_mb=100,
        max_batch_files=20,
    )
    settings.ensure_dirs()
    engine = make_engine(settings)
    init_db(engine)
    factory = make_session_factory(engine)
    storage = LocalStorage(settings.storage_path)
    print("[services.upload] 临时数据库:", settings.database_url)
    print("[services.upload] 临时存储目录:", settings.storage_path)

    files = [
        UploadFileData(filename="第一份.pdf", content=b"%PDF-1.7\n" + b"0" * 256, content_type="application/pdf"),
        UploadFileData(
            filename="第二份.PDF",
            content=b"%PDF-1.5\n" + b"1" * 256,
            content_type="application/octet-stream",
        ),
    ]
    with factory() as session:
        response = create_batch(session, settings, files, storage)
    print("[services.upload] 上传响应:")
    print(response.model_dump_json(indent=2, ensure_ascii=False))
    assert response.status == BatchStatus.QUEUED and len(response.documents) == 2
    assert all(ref.status == DocumentStatus.QUEUED for ref in response.documents)
    assert response.created_at is not None

    with factory() as session:
        counts = {
            "批次": session.scalar(select(func.count()).select_from(Batch)),
            "文档": session.scalar(select(func.count()).select_from(Document)),
            "任务": session.scalar(select(func.count()).select_from(ParseTask)),
            "发件箱事件": session.scalar(select(func.count()).select_from(OutboxEvent)),
        }
        print("[services.upload] 数据库行数:", counts)
        assert counts == {"批次": 1, "文档": 2, "任务": 2, "发件箱事件": 2}, counts

        documents = list(session.scalars(select(Document)))
        assert all(document.status == DocumentStatus.QUEUED.value for document in documents)
        for document in documents:
            assert storage.exists(document.object_key), f"对象未写入: {document.object_key}"
            assert hashlib.sha256(storage.get(document.object_key)).hexdigest() == document.sha256
        print("[services.upload] 存储中的 PDF 与 sha256 一致")

        tasks = list(session.scalars(select(ParseTask)))
        assert all(task.status == TaskStatus.PENDING.value for task in tasks)
        events = list(session.scalars(select(OutboxEvent)))
        assert all(event.event_type == EventType.PARSE_REQUESTED.value and not event.delivered for event in events)
        for event in events:
            assert event.payload["batch_id"] == response.batch_id
            assert event.payload["attempt"] == 1
            assert event.payload["object_key"].startswith("pdfs/doc_")
        print("[services.upload] 任务全部 pending，发件箱事件全部 parse.requested 且未投递")

    # sha256 去重：同一份内容再传一次直接拒绝（不建批次、不写存储）
    with factory() as session:
        try:
            create_batch(session, settings, [files[0]], storage)
        except InputError as error:
            print("[services.upload] 完全重复的上传被拒绝:", error)
        else:
            raise AssertionError("内容完全重复时应被拒绝")
    assert len(list((settings.storage_path / "pdfs").glob("*.pdf"))) == 2, "重复上传不应写入新对象"

    # 混合上传：新文件正常入库，重复文件只记在 duplicates 里
    mixed_files = [
        files[0],
        UploadFileData(filename="第三份.pdf", content=b"%PDF-1.7\n" + b"2" * 256, content_type="application/pdf"),
    ]
    with factory() as session:
        mixed = create_batch(session, settings, mixed_files, storage)
    print("[services.upload] 混合上传 duplicates:", mixed.duplicates, "| 新文档:", [ref.filename for ref in mixed.documents])
    assert mixed.duplicates == ["第一份.pdf"] and len(mixed.documents) == 1

    # 存储已写、数据库提交失败：对象应被清理，数据库不留半成品
    with factory() as session:
        try:
            create_batch(
                _FailingSession(session),
                settings,
                [UploadFileData(filename="孤儿.pdf", content=b"%PDF-1.7\nlost", content_type="application/pdf")],
                storage,
            )
        except RuntimeError as error:
            print("[services.upload] 模拟数据库提交失败:", error)
        else:
            raise AssertionError("数据库提交失败时应抛出异常")
    with factory() as session:
        rolled_back = {
            "批次": session.scalar(select(func.count()).select_from(Batch)),
            "文档": session.scalar(select(func.count()).select_from(Document)),
            "任务": session.scalar(select(func.count()).select_from(ParseTask)),
            "发件箱事件": session.scalar(select(func.count()).select_from(OutboxEvent)),
        }
        print("[services.upload] 回滚后数据库行数:", rolled_back)
        assert rolled_back == {"批次": 2, "文档": 3, "任务": 3, "发件箱事件": 3}, rolled_back
    assert len(list((settings.storage_path / "pdfs").glob("*.pdf"))) == 3, "提交失败后应删除已写入的对象"
    print("[services.upload] 提交失败后未留下孤儿对象")

    valid = UploadFileData(filename="合法.pdf", content=b"%PDF-1.7\n", content_type="application/pdf")
    strict = Settings(max_batch_files=1, max_upload_mb=1, data_dir=tmp)
    cases = [
        ("空列表", [], settings),
        ("非 PDF 扩展名", [UploadFileData(filename="说明.txt", content=b"%PDF-1.7\n")], settings),
        ("非 PDF 内容", [UploadFileData(filename="假.pdf", content=b"hello", content_type="application/pdf")], settings),
        ("超出单文件上限", [UploadFileData(filename="大.pdf", content=b"%PDF-1.7" + b"0" * (1024 * 1024))], strict),
        ("不支持的 content_type", [UploadFileData(filename="类型.pdf", content=b"%PDF-1.7\n", content_type="text/plain")], settings),
        ("超出单批次数量", [valid, valid], strict),
    ]
    for label, case_files, case_settings in cases:
        try:
            validate_files(case_files, case_settings)
        except InputError as error:
            print(f"[services.upload] 拒绝{label}: {error}")
        else:
            raise AssertionError(f"{label} 应被拒绝")
    assert len(list((settings.storage_path / "pdfs").glob("*.pdf"))) == 3
    print("[services.upload] 自检通过")


if __name__ == "__main__":
    main()
