"""文档与批次状态机服务：状态以数据库为准，Kafka 只负责异步触发。

成功链路：queued → parsing → indexing → done；
失败链路：parsing/indexing → retrying（自动重试，重新投递解析请求）→ failed（重试耗尽，投递死信）。
所有写操作由本模块自行提交，读操作不提交。
"""

if __package__ in (None, ""):  # 允许直接运行本文件
    import sys
    from pathlib import Path

    for _root in Path(__file__).resolve().parents:
        if (_root / "backend" / "app").is_dir():
            sys.path.insert(0, str(_root))
            break

from datetime import datetime, timezone

from sqlalchemy import delete, func, select
from sqlalchemy.orm import Session

from backend.app.common import utcnow
from backend.app.config import Settings, get_settings
from backend.app.errors import ConflictError, NotFoundError
from backend.app.models.tables import Asset, Batch, Chunk, Citation, Document, ParseTask
from backend.app.schemas.batch import BatchStatusResponse, DocumentInfo, DocumentRef, RetryResponse
from backend.app.schemas.enums import DocumentStatus, EventType, TaskStatus, derive_batch_status
from backend.app.schemas.events import DeadLetterMessage, DocumentStatusItem, ParseRequestMessage, StatusEvent
from backend.app.services.outbox import enqueue


def _utc(moment: datetime) -> datetime:
    """SQLite 读回的时间不带时区，统一补成 UTC，避免同一响应里 naive/aware 混用。"""
    return moment if moment.tzinfo else moment.replace(tzinfo=timezone.utc)


def _require_batch(session: Session, batch_id: str) -> Batch:
    """取批次；不存在抛 NotFoundError（接口层转 404）。"""
    batch = session.get(Batch, batch_id)
    if batch is None:
        raise NotFoundError(f"批次不存在: {batch_id}")
    return batch


def _require_document(session: Session, doc_id: str) -> Document:
    """取文档；不存在抛 NotFoundError。"""
    document = session.get(Document, doc_id)
    if document is None:
        raise NotFoundError(f"文档不存在: {doc_id}")
    return document


def _latest_task(session: Session, doc_id: str) -> ParseTask | None:
    """按创建时间倒序取该文档最新的一条解析任务；没有则返回 None。"""
    statement = (
        select(ParseTask)
        .where(ParseTask.doc_id == doc_id)
        .order_by(ParseTask.created_at.desc())
        .limit(1)
    )
    return session.scalars(statement).first()


def _require_task(session: Session, doc_id: str) -> ParseTask:
    """取该文档最新的解析任务；不存在抛 NotFoundError。"""
    task = _latest_task(session, doc_id)
    if task is None:
        raise NotFoundError(f"解析任务不存在: {doc_id}")
    return task


def _documents_of(session: Session, batch_id: str) -> list[Document]:
    """按创建顺序取批次下的全部文档；排序保证同一批次响应里文档顺序稳定。"""
    statement = (
        select(Document)
        .where(Document.batch_id == batch_id)
        .order_by(Document.created_at, Document.id)
    )
    return list(session.scalars(statement))


def _to_info(document: Document, task: ParseTask | None) -> DocumentInfo:
    """ORM 行转接口结构；尝试次数取最新解析任务，没有任务时按 0 次算。"""
    return DocumentInfo(
        doc_id=document.id,
        batch_id=document.batch_id,
        filename=document.filename,
        sha256=document.sha256,
        object_key=document.object_key,
        status=DocumentStatus(document.status),
        error=document.error,
        pages=document.pages,
        attempts=task.attempts if task else 0,
        created_at=_utc(document.created_at),
        updated_at=_utc(document.updated_at),
    )


def get_batch(session: Session, batch_id: str) -> BatchStatusResponse:
    """批次总状态 + 两级状态里的文档摘要。"""
    batch = _require_batch(session, batch_id)
    documents = _documents_of(session, batch_id)
    statuses = [DocumentStatus(document.status) for document in documents]
    done_count = sum(1 for status in statuses if status is DocumentStatus.DONE)
    failed_count = sum(1 for status in statuses if status is DocumentStatus.FAILED)
    updated_at = _utc(batch.updated_at)
    # 批次更新时间取批次与文档的最大值：任一文档变了，前端都该看到批次已更新
    for document in documents:
        updated_at = max(updated_at, _utc(document.updated_at))
    return BatchStatusResponse(
        batch_id=batch.id,
        status=derive_batch_status(statuses),
        total=len(documents),
        done_count=done_count,
        failed_count=failed_count,
        active_count=len(documents) - done_count - failed_count,
        documents=[
            DocumentRef(
                doc_id=document.id,
                filename=document.filename,
                status=DocumentStatus(document.status),
                error=document.error,
                pages=document.pages,
            )
            for document in documents
        ],
        created_at=_utc(batch.created_at),
        updated_at=updated_at,
    )


def delete_documents(session: Session, storage: object, doc_ids: list[str]) -> list[str]:
    """删除文档及其切片/图片/解析任务/引用与对象存储文件，返回实际删除的文档编号。

    只允许删除不在解析/索引中的文档：否则会和 worker 并发写同一文档，产生孤儿切片。
    批次下所有文档都被删掉时，批次行一并删除，避免留下空批次。
    先提交数据库再删对象存储：文件删失败最多留孤儿文件，不会出现“记录还在但文件没了”。
    """
    documents: list[Document] = []
    for doc_id in dict.fromkeys(doc_ids):  # 去重且保序
        document = session.get(Document, doc_id)
        if document is None:
            raise NotFoundError(f"文档不存在: {doc_id}")
        if document.status in (DocumentStatus.PARSING.value, DocumentStatus.INDEXING.value):
            raise ConflictError("文档正在解析/索引，等解析结束后再删除")
        documents.append(document)

    storage_keys: list[str] = []
    deleted: list[str] = []
    for document in documents:
        chunk_ids = list(session.scalars(select(Chunk.id).where(Chunk.doc_id == document.id)))
        if chunk_ids:
            session.execute(delete(Citation).where(Citation.chunk_id.in_(chunk_ids)))
        assets = list(session.scalars(select(Asset).where(Asset.doc_id == document.id)))
        if assets:
            session.execute(delete(Citation).where(Citation.asset_id.in_([asset.id for asset in assets])))
        session.execute(delete(Chunk).where(Chunk.doc_id == document.id))
        session.execute(delete(Asset).where(Asset.doc_id == document.id))
        session.execute(delete(ParseTask).where(ParseTask.doc_id == document.id))

        batch_id = document.batch_id
        session.execute(delete(Document).where(Document.id == document.id))
        remaining = session.scalar(
            select(func.count()).select_from(Document).where(Document.batch_id == batch_id)
        )
        if remaining == 0:
            session.execute(delete(Batch).where(Batch.id == batch_id))

        storage_keys.append(document.object_key)
        storage_keys.extend(asset.object_key for asset in assets)
        deleted.append(document.id)

    session.commit()
    for key in storage_keys:
        try:
            storage.delete(key)
        except (OSError, ValueError):
            # 对象存储删除失败只留下孤儿文件，不影响数据库一致性
            pass
    return deleted


def list_documents(session: Session, limit: int = 200) -> list[DocumentInfo]:
    """最近上传的文档（创建时间倒序），供前端展示知识库里有哪些文档。

    ponytail: 每个文档再查一次 parse_task（N+1）；本地文档量小够用，文档多了再改 join。
    """
    documents = session.scalars(
        select(Document).order_by(Document.created_at.desc(), Document.id.desc()).limit(limit)
    ).all()
    return [_to_info(document, _latest_task(session, document.id)) for document in documents]


def get_document(session: Session, doc_id: str) -> DocumentInfo:
    """单文档详情，尝试次数取该文档最新的解析任务。"""
    document = _require_document(session, doc_id)
    return _to_info(document, _latest_task(session, doc_id))


def retry_document(session: Session, doc_id: str, settings: Settings | None = None) -> RetryResponse:
    """手动重试失败文档：重置文档与任务，重新投递解析请求（attempt=1）。"""
    # settings 暂未使用：保留入参是为了接口层所有服务调用方式一致
    document = _require_document(session, doc_id)
    # 失败的可重试；已完成的允许“重新解析”（例如换了 MinerU/解析器后修正内容与页数）
    if DocumentStatus(document.status) not in (DocumentStatus.FAILED, DocumentStatus.DONE):
        raise ConflictError("只有已解析完成或解析失败的文档可以重新解析")
    task = _require_task(session, doc_id)
    document.status = DocumentStatus.QUEUED.value
    document.error = None
    task.status = TaskStatus.PENDING.value
    # attempts 归零：手动重试算新一轮尝试，否则下一次失败会立刻被判成重试耗尽
    task.attempts = 0
    task.last_error = None
    task.started_at = None
    task.finished_at = None
    message = ParseRequestMessage(
        doc_id=document.id,
        batch_id=document.batch_id,
        object_key=document.object_key,
        filename=document.filename,
        trace_id=task.trace_id,
        attempt=1,
    )
    enqueue(
        session,
        aggregate_id=document.id,
        event_type=EventType.PARSE_REQUESTED,
        payload=message.model_dump(mode="json"),
    )
    session.commit()
    return RetryResponse(doc_id=document.id, status=DocumentStatus.QUEUED, message="已重新排队")


def mark_parsing(session: Session, doc_id: str) -> DocumentInfo:
    """开始解析：queued/retrying → parsing；已是 parsing 时幂等返回。"""
    document = _require_document(session, doc_id)
    task = _require_task(session, doc_id)
    status = DocumentStatus(document.status)
    if status is DocumentStatus.PARSING:
        return _to_info(document, task)  # 重复消息，不重复累加尝试次数
    if status not in (DocumentStatus.QUEUED, DocumentStatus.RETRYING):
        raise ConflictError(f"当前状态 {status.value}，不能开始解析")
    document.status = DocumentStatus.PARSING.value
    task.status = TaskStatus.RUNNING.value
    task.attempts += 1
    task.started_at = utcnow()
    session.commit()
    return _to_info(document, task)


def mark_indexing(session: Session, doc_id: str) -> DocumentInfo:
    """解析产物落库：parsing → indexing。"""
    document = _require_document(session, doc_id)
    task = _require_task(session, doc_id)
    if DocumentStatus(document.status) is not DocumentStatus.PARSING:
        raise ConflictError(f"当前状态 {document.status}，不能进入索引阶段")
    document.status = DocumentStatus.INDEXING.value
    session.commit()
    return _to_info(document, task)


def mark_done(session: Session, doc_id: str, pages: int) -> DocumentInfo:
    """解析完成：parsing/indexing → done。"""
    document = _require_document(session, doc_id)
    task = _require_task(session, doc_id)
    status = DocumentStatus(document.status)
    if status not in (DocumentStatus.PARSING, DocumentStatus.INDEXING):
        raise ConflictError(f"当前状态 {status.value}，不能标记为解析完成")
    document.status = DocumentStatus.DONE.value
    document.pages = pages
    document.error = None
    task.status = TaskStatus.SUCCEEDED.value
    task.last_error = None
    task.finished_at = utcnow()
    session.commit()
    return _to_info(document, task)


def record_failure(session: Session, doc_id: str, error: str, settings: Settings | None = None) -> str:
    """记录解析失败：未用尽自动重试则转 retrying 并重投，否则转 failed 并投死信。"""
    settings = settings or get_settings()
    document = _require_document(session, doc_id)
    status = DocumentStatus(document.status)
    if status not in (DocumentStatus.PARSING, DocumentStatus.INDEXING):
        raise ConflictError(f"当前状态 {status.value}，不能记录解析失败")
    task = _require_task(session, doc_id)
    attempts = task.attempts
    task.last_error = error
    # attempts 已在 mark_parsing 里 +1：未达上限就再投一次解析请求，达到上限才进死信
    if attempts < settings.max_parse_retries:
        document.status = DocumentStatus.RETRYING.value
        task.status = TaskStatus.PENDING.value
        message = ParseRequestMessage(
            doc_id=document.id,
            batch_id=document.batch_id,
            object_key=document.object_key,
            filename=document.filename,
            trace_id=task.trace_id,
            attempt=attempts + 1,
        )
        enqueue(
            session,
            aggregate_id=document.id,
            event_type=EventType.PARSE_REQUESTED,
            payload=message.model_dump(mode="json"),
        )
        session.commit()
        return "retrying"
    document.status = DocumentStatus.FAILED.value
    document.error = error
    task.status = TaskStatus.FAILED.value
    task.finished_at = utcnow()
    dead_letter = DeadLetterMessage(
        doc_id=document.id,
        batch_id=document.batch_id,
        filename=document.filename,
        trace_id=task.trace_id,
        attempts=attempts,
        error=error,
    )
    enqueue(
        session,
        aggregate_id=document.id,
        event_type=EventType.PARSE_DEAD_LETTER,
        payload=dead_letter.model_dump(mode="json"),
    )
    session.commit()
    return "failed"


def batch_status_event(session: Session, batch_id: str) -> StatusEvent:
    """服务器推送事件用的批次状态快照（只读，不提交）。"""
    _require_batch(session, batch_id)
    documents = _documents_of(session, batch_id)
    statuses = [DocumentStatus(document.status) for document in documents]
    return StatusEvent(
        batch_id=batch_id,
        status=derive_batch_status(statuses),
        documents=[
            DocumentStatusItem(
                doc_id=document.id,
                filename=document.filename,
                status=DocumentStatus(document.status),
                error=document.error,
                pages=document.pages,
            )
            for document in documents
        ],
        ts=utcnow(),
    )


def main() -> None:
    """自测：完整成功链路、自动重试耗尽进死信、手动重试与非法状态流转。"""
    import tempfile
    from pathlib import Path

    from sqlalchemy import func, select

    from backend.app.clients.storage import LocalStorage
    from backend.app.db import init_db, make_engine, make_session_factory
    from backend.app.models.tables import OutboxEvent
    from backend.app.schemas.batch import UploadFileData
    from backend.app.schemas.enums import BatchStatus
    from backend.app.services.upload import create_batch

    tmp = Path(tempfile.mkdtemp(prefix="rag-document-"))
    settings = Settings(
        database_url=f"sqlite:///{(tmp / 'app.db').as_posix()}",
        data_dir=tmp,
        storage_dir=tmp / "storage",
        max_parse_retries=3,
    )
    settings.ensure_dirs()
    engine = make_engine(settings)
    init_db(engine)
    factory = make_session_factory(engine)
    storage = LocalStorage(settings.storage_path)
    print("[services.document] 临时数据库:", settings.database_url)
    print("[services.document] 临时存储目录:", settings.storage_path)

    # ---------- 成功链路：queued → parsing → indexing → done ----------
    with factory() as session:
        uploaded = create_batch(
            session,
            settings,
            [UploadFileData(filename="成功链路.pdf", content=b"%PDF-1.7\nhello", content_type="application/pdf")],
            storage,
        )
    batch_id = uploaded.batch_id
    doc_id = uploaded.documents[0].doc_id
    print("[services.document] 已上传成功文档:", doc_id, "批次:", batch_id)

    with factory() as session:
        status = get_batch(session, batch_id)
        print("[services.document] 上传后批次状态:", status.status, status.display_status, "总数:", status.total)
        assert status.status == BatchStatus.QUEUED
        assert (status.total, status.done_count, status.failed_count, status.active_count) == (1, 0, 0, 1)

        info = get_document(session, doc_id)
        print("[services.document] 上传后文档状态:", info.status, info.display_status, "attempts:", info.attempts)
        assert info.status == DocumentStatus.QUEUED and info.attempts == 0

        info = mark_parsing(session, doc_id)
        print("[services.document] 开始解析:", info.status, "attempts:", info.attempts)
        assert info.status == DocumentStatus.PARSING and info.attempts == 1

        again = mark_parsing(session, doc_id)
        print("[services.document] 重复 mark_parsing 幂等:", again.status, "attempts:", again.attempts)
        assert again.status == DocumentStatus.PARSING and again.attempts == 1

        event = batch_status_event(session, batch_id)
        print("[services.document] SSE 状态事件:")
        print(event.model_dump_json(indent=2, ensure_ascii=False))
        assert event.event == "status" and event.display_status == "解析中"
        assert event.status == BatchStatus.PARSING
        assert event.documents[0].status == DocumentStatus.PARSING

        info = mark_indexing(session, doc_id)
        print("[services.document] 进入索引:", info.status, info.display_status)
        assert info.status == DocumentStatus.INDEXING

        info = mark_done(session, doc_id, pages=5)
        print("[services.document] 解析完成:", info.status, info.display_status, "页数:", info.pages)
        assert info.status == DocumentStatus.DONE and info.pages == 5

        task = session.scalars(select(ParseTask).where(ParseTask.doc_id == doc_id)).one()
        print("[services.document] 任务状态:", task.status, "开始于:", task.started_at, "结束于:", task.finished_at)
        assert task.status == TaskStatus.SUCCEEDED and task.finished_at is not None

        status = get_batch(session, batch_id)
        print("[services.document] 完成后批次状态:", status.status, status.display_status, "完成数:", status.done_count)
        assert status.status == BatchStatus.DONE and status.done_count == 1 and status.active_count == 0

    # ---------- 失败链路：自动重试 3 次耗尽后进入死信 ----------
    with factory() as session:
        second = create_batch(
            session,
            settings,
            [UploadFileData(filename="失败链路.pdf", content=b"%PDF-1.4\nbroken", content_type="application/pdf")],
            storage,
        )
    failed_batch_id = second.batch_id
    failed_doc_id = second.documents[0].doc_id
    print("[services.document] 已上传待失败文档:", failed_doc_id, "批次:", failed_batch_id)

    with factory() as session:
        for attempt in range(1, 4):
            info = mark_parsing(session, failed_doc_id)
            assert info.status == DocumentStatus.PARSING and info.attempts == attempt
            outcome = record_failure(session, failed_doc_id, "MinerU 解析超时")
            print(f"[services.document] 第 {attempt} 次解析失败 ->", outcome)
            assert outcome == ("retrying" if attempt < 3 else "failed")

        info = get_document(session, failed_doc_id)
        print(
            "[services.document] 失败文档最终状态:",
            info.status,
            info.display_status,
            "错误:",
            info.error,
            "attempts:",
            info.attempts,
        )
        assert info.status == DocumentStatus.FAILED and info.error == "MinerU 解析超时" and info.attempts == 3

        task = session.scalars(select(ParseTask).where(ParseTask.doc_id == failed_doc_id)).one()
        assert task.status == TaskStatus.FAILED and task.finished_at is not None

        dead_letters = list(
            session.scalars(select(OutboxEvent).where(OutboxEvent.event_type == EventType.PARSE_DEAD_LETTER.value))
        )
        print("[services.document] 死信事件数:", len(dead_letters), "payload:", dead_letters[0].payload if dead_letters else None)
        assert len(dead_letters) == 1 and dead_letters[0].aggregate_id == failed_doc_id
        assert dead_letters[0].payload["attempts"] == 3 and dead_letters[0].payload["error"] == "MinerU 解析超时"

        requested = session.scalar(
            select(func.count())
            .select_from(OutboxEvent)
            .where(
                OutboxEvent.aggregate_id == failed_doc_id,
                OutboxEvent.event_type == EventType.PARSE_REQUESTED.value,
            )
        )
        print("[services.document] 解析请求事件数（首次 + 自动重试）:", requested)
        assert requested == 3

        status = get_batch(session, failed_batch_id)
        print("[services.document] 失败批次状态:", status.status, status.display_status, "失败数:", status.failed_count)
        assert status.status == BatchStatus.FAILED and status.failed_count == 1

    # ---------- 手动重试：failed → queued，attempts 归零 ----------
    with factory() as session:
        retried = retry_document(session, failed_doc_id)
        print("[services.document] 手动重试:", retried.status, retried.display_status, retried.message)
        assert retried.status == DocumentStatus.QUEUED

        info = get_document(session, failed_doc_id)
        assert info.status == DocumentStatus.QUEUED and info.attempts == 0 and info.error is None

        task = session.scalars(select(ParseTask).where(ParseTask.doc_id == failed_doc_id)).one()
        print("[services.document] 重置后任务:", task.status, "attempts:", task.attempts, "错误:", task.last_error)
        assert task.status == TaskStatus.PENDING and task.attempts == 0
        assert task.last_error is None and task.started_at is None and task.finished_at is None

        retry_event = session.scalars(
            select(OutboxEvent)
            .where(
                OutboxEvent.aggregate_id == failed_doc_id,
                OutboxEvent.event_type == EventType.PARSE_REQUESTED.value,
            )
            .order_by(OutboxEvent.created_at.desc())
            .limit(1)
        ).first()
        print("[services.document] 手动重试发件箱 payload:", retry_event.payload)
        assert retry_event.payload["attempt"] == 1
        retried_batch = get_batch(session, failed_batch_id)
        assert retried_batch.status == BatchStatus.QUEUED and retried_batch.failed_count == 0

    # ---------- 完成文档重新解析 ----------
    with factory() as session:
        # 已完成的文档允许“重新解析”：换解析器后可修正内容与页数
        reparse = retry_document(session, doc_id)
        print("[services.document] 完成文档重新解析:", reparse.status, reparse.message)
        assert reparse.status == DocumentStatus.QUEUED

    # ---------- 错误用例 ----------
    with factory() as session:

        try:
            mark_done(session, failed_doc_id, pages=1)  # 手动重试后处于 queued
        except ConflictError as error:
            print("[services.document] 非法状态流转被拒绝:", error)
        else:
            raise AssertionError("排队中的文档不应能直接标记完成")

        for label, query in (
            ("批次", lambda: get_batch(session, "batch_missing")),
            ("文档", lambda: get_document(session, "doc_missing")),
        ):
            try:
                query()
            except NotFoundError as error:
                print(f"[services.document] 查询不存在的{label}被拒绝:", error)
            else:
                raise AssertionError(f"不存在的{label}应抛出 NotFoundError")
    print("[services.document] 自检通过")


if __name__ == "__main__":
    main()
