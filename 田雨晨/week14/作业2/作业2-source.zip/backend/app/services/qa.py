"""多模态问答服务：校验输入、存用户图片、调用智能体、规范化分段与引用、落库。"""

if __package__ in (None, ""):  # 允许直接运行本文件
    import sys
    from pathlib import Path

    for _root in Path(__file__).resolve().parents:
        if (_root / "backend" / "app").is_dir():
            sys.path.insert(0, str(_root))
            break

import base64

from sqlalchemy.orm import Session

from backend.app.clients.agent import AgentClient
from backend.app.common import new_id
from backend.app.config import Settings
from backend.app.errors import InputError, UpstreamError
from backend.app.models.tables import Asset, Document
from backend.app.models.tables import Citation as CitationRow
from backend.app.models.tables import QaRecord
from backend.app.schemas.content import Citation
from backend.app.schemas.qa import (
    AgentImage,
    AgentRequest,
    AgentResponse,
    AnswerSegment,
    ImageSegment,
    QAResponse,
    TextSegment,
)
from backend.app.services.asset import sign_asset

FALLBACK_ANSWER = "根据提供的资料无法回答该问题。"
AGENT_TOP_K = 6
USER_IMAGE_PREFIX = "user_uploads"


def _normalize_citations(session: Session, citations: list[Citation]) -> list[Citation]:
    """用文档表补全文件名；智能体没给引用编号时补一个。"""
    normalized: list[Citation] = []
    for citation in citations:
        document = session.get(Document, citation.doc_id) if citation.doc_id else None
        normalized.append(
            citation.model_copy(
                update={
                    "citation_id": citation.citation_id or new_id("cit"),
                    # 查不到文档时保留 None：不把智能体给的文件名当真
                    "doc_filename": document.filename if document else None,
                }
            )
        )
    return normalized


def _normalize_segments(
    session: Session, settings: Settings, segments: list[AnswerSegment]
) -> list[AnswerSegment]:
    """文本段原样保留；图片段只保留库里存在的资源，并补签名地址。"""
    normalized: list[AnswerSegment] = []
    for segment in segments:
        if isinstance(segment, TextSegment):
            normalized.append(segment)
            continue
        asset = session.get(Asset, segment.asset_id) if segment.asset_id else None
        if asset is None:
            continue  # 未知资源不能回给前端
        signed = sign_asset(settings, asset.id, ttl_seconds=settings.asset_signed_url_ttl)
        normalized.append(
            ImageSegment(
                asset_id=asset.id,
                caption=segment.caption,
                sources=segment.sources,
                doc_id=asset.doc_id,
                page=asset.page,
                asset_url=signed.url,
                asset_url_expires_at=signed.expires_at,
            )
        )
    return normalized


def ask(
    session: Session,
    settings: Settings,
    storage,
    agent: AgentClient,
    question: str,
    image: bytes | None = None,
    image_mime: str | None = None,
) -> QAResponse:
    """一次多模态问答：校验 -> 存图 -> 调智能体 -> 规范化 -> 落库 -> 返回。"""
    question = (question or "").strip()
    if not question:
        raise InputError("问题不能为空")
    if len(question) > settings.max_question_chars:
        raise InputError(f"问题长度不能超过 {settings.max_question_chars} 个字符")

    if image:
        if not (image_mime or "").startswith("image/"):
            raise InputError("提问图片类型必须是图片（image/*）")
        if len(image) > settings.max_question_image_bytes:
            raise InputError(f"提问图片不能超过 {settings.max_question_image_mb} MB")
    else:
        image = None

    qa_id = new_id("qa")
    image_key: str | None = None
    if image:
        # key 用 qa_id 命名：问答记录里只存 key，后续可按 qa_id 定位原图（当前没有单独取原图的路由）
        image_key = f"{USER_IMAGE_PREFIX}/{qa_id}.bin"
        storage.put(image_key, image, image_mime)

    agent_request = AgentRequest(
        question=question,
        image=(
            # 用户图片用 base64 随请求一起发给智能体，避免为此再暴露一个下载接口
            AgentImage(
                mime_type=image_mime or "",
                data_base64=base64.b64encode(image).decode("ascii"),
            )
            if image
            else None
        ),
        top_k=AGENT_TOP_K,
    )
    # 智能体故障（UpstreamError）属于下游不可用，直接向上抛，不伪装成兜底回答
    response = agent.answer(agent_request)

    citations = _normalize_citations(session, response.citations)
    segments = _normalize_segments(session, settings, response.segments)

    answer = response.answer.strip()
    if not answer:
        answer = "".join(segment.text for segment in segments if isinstance(segment, TextSegment))

    # 分段全部失效（比如引用的图片已不在库）时退回纯文本兜底，保证前端总有内容可渲染
    fallback = not segments
    if fallback:
        answer = answer or FALLBACK_ANSWER
        segments = [TextSegment(text=answer)]

    record = QaRecord(
        id=qa_id,
        question=question,
        image_key=image_key,
        answer=answer,
        segments=[segment.model_dump(mode="json") for segment in segments],
        fallback=fallback,
    )
    session.add(record)
    for citation in citations:
        session.add(
            CitationRow(
                # 行 id 用独立编号：citation_id 是按 chunk/asset 派生的稳定引用编号，
                # 同一 chunk 被不同问答引用时必然重复，直接当主键会在第二次问答时撞 UNIQUE。
                id=new_id("cit"),
                qa_id=qa_id,
                doc_id=citation.doc_id,
                chunk_id=citation.chunk_id,
                asset_id=citation.asset_id,
                page=citation.page,
                bbox=citation.bbox,
            )
        )
    session.commit()

    return QAResponse(
        qa_id=qa_id,
        answer=answer,
        segments=segments,
        citations=citations,
        created_at=record.created_at,
        fallback=fallback,
    )


def main() -> None:
    """自测：正常问答、带图提问、三类非法输入、结构化兜底与智能体故障上抛。"""
    import tempfile
    from pathlib import Path

    from sqlalchemy import func, select

    from backend.app.clients.agent import StubAgentClient
    from backend.app.clients.storage import LocalStorage
    from backend.app.db import init_db, make_engine, make_session_factory
    from backend.app.models.tables import Batch
    from backend.app.schemas.enums import AssetType, DocumentStatus
    from backend.app.services.asset import verify_asset

    tmp = Path(tempfile.mkdtemp(prefix="rag-qa-"))
    settings = Settings(
        database_url=f"sqlite:///{(tmp / 'app.db').as_posix()}",
        data_dir=tmp,
        storage_dir=tmp / "storage",
        public_base_url="http://127.0.0.1:8000",
        asset_signing_secret="qa-selftest-secret",
    )
    settings.ensure_dirs()
    engine = make_engine(settings)
    init_db(engine)
    storage = LocalStorage(settings.storage_path)
    factory = make_session_factory(engine)
    print("[services.qa] 临时数据库:", settings.database_url)
    print("[services.qa] 临时存储目录:", storage.root)

    # 准备解析完成的文档 + 一张已入库的图片资源
    batch_id = new_id("batch")
    doc_id = new_id("doc")
    asset_id = new_id("asset")
    citation_id = new_id("cit")
    png_bytes = b"\x89PNG\r\n\x1a\n" + b"\x00" * 32
    asset_key = f"assets/{doc_id}/figure-1.png"
    storage.put(asset_key, png_bytes, "image/png")
    with factory() as session:
        session.add(Batch(id=batch_id, trace_id=new_id("trace"), file_count=1))
        session.add(
            Document(
                id=doc_id,
                batch_id=batch_id,
                filename="说明.pdf",
                sha256="a" * 64,
                object_key=f"pdfs/{doc_id}.pdf",
                status=DocumentStatus.DONE.value,
                pages=5,
            )
        )
        session.add(
            Asset(
                id=asset_id,
                doc_id=doc_id,
                page=2,
                asset_type=AssetType.FIGURE.value,
                object_key=asset_key,
                caption="系统架构图",
                bbox=[72.0, 120.0, 480.0, 360.0],
            )
        )
        session.commit()
    print("[services.qa] 预置文档:", doc_id, "| 图片资源:", asset_id)

    stub = StubAgentClient(
        AgentResponse(
            answer="系统由前端、后端、解析工作器和智能体组成。",
            segments=[
                TextSegment(
                    text="系统由前端、后端、解析工作器和智能体组成。", sources=[citation_id]
                ),
                ImageSegment(asset_id=asset_id, caption="系统架构图", sources=[citation_id]),
            ],
            citations=[
                Citation(citation_id=citation_id, doc_id=doc_id, page=2, asset_id=asset_id)
            ],
        )
    )
    with factory() as session:
        reply = ask(session, settings, storage, stub, "系统由哪些组件组成？")
        print("[services.qa] QAResponse JSON:")
        print(reply.model_dump_json(indent=2, ensure_ascii=False))

        assert reply.fallback is False, "分段齐全时不应兜底"
        assert len(reply.segments) == 2, "应保留文本段 + 图片段"
        assert reply.segments[0].type == "text"
        image_segment = reply.segments[1]
        assert isinstance(image_segment, ImageSegment)
        assert image_segment.asset_url and "/api/assets/" in image_segment.asset_url
        assert image_segment.doc_id == doc_id and image_segment.page == 2, "图片段应补文档与页码"
        expires = image_segment.asset_url.split("expires=")[1].split("&")[0]
        signature = image_segment.asset_url.split("signature=")[1]
        assert verify_asset(settings, asset_id, expires, signature) is True, "签名地址应校验通过"
        assert reply.citations[0].doc_filename == "说明.pdf", "引用应补全文档文件名"
        assert stub.calls[0].top_k == AGENT_TOP_K and stub.calls[0].image is None
        print("[services.qa] 图片段签名地址校验通过:", image_segment.asset_url)

        with factory() as check_session:
            qa_count = check_session.scalar(select(func.count()).select_from(QaRecord))
            citation_count = check_session.scalar(select(func.count()).select_from(CitationRow))
        print("[services.qa] 落库行数: qa_records", qa_count, "| citations", citation_count)
        assert qa_count == 1 and citation_count == 1, "问答与引用应各落库 1 行"

        # 回归：同一 citation_id 被第二次问答引用时，落库行 id 必须各自唯一，不能撞 UNIQUE 主键
        second_reply = ask(session, settings, storage, stub, "再问一次：系统由哪些组件组成？")
        assert second_reply.citations[0].citation_id == reply.citations[0].citation_id, "引用编号应保持稳定"
        with factory() as check_session:
            citation_count = check_session.scalar(select(func.count()).select_from(CitationRow))
        print("[services.qa] 重复引用后 citations 行数:", citation_count)
        assert citation_count == 2, "同一引用被两次问答使用时每次都应独立落库"

        # 带用户图片提问：图片先写对象存储，并以 base64 送进智能体
        image_stub = StubAgentClient(
            AgentResponse(answer="图片已收到。", segments=[TextSegment(text="图片已收到。")])
        )
        image_reply = ask(
            session,
            settings,
            storage,
            image_stub,
            "这张图片画的是什么？",
            image=png_bytes,
            image_mime="image/png",
        )
        image_key = f"{USER_IMAGE_PREFIX}/{image_reply.qa_id}.bin"
        print("[services.qa] 用户图片对象 key:", image_key)
        assert storage.exists(image_key), "用户提问图片应写入对象存储"
        assert storage.get(image_key) == png_bytes
        sent_image = image_stub.calls[0].image
        assert sent_image is not None and sent_image.mime_type == "image/png"
        assert base64.b64decode(sent_image.data_base64) == png_bytes

        # 非法输入：空问题
        try:
            ask(session, settings, storage, stub, "   ")
        except InputError as error:
            print("[services.qa] 空问题被拒绝:", error.message)
        else:
            raise AssertionError("空问题应抛 InputError")

        # 非法输入：非图片类型
        try:
            ask(session, settings, storage, stub, "看图", image=png_bytes, image_mime="application/pdf")
        except InputError as error:
            print("[services.qa] 非图片类型被拒绝:", error.message)
        else:
            raise AssertionError("非图片类型应抛 InputError")

        # 非法输入：图片超限（限制 1MB，传 2MB）
        tiny_settings = Settings(
            database_url=settings.database_url,
            data_dir=tmp,
            storage_dir=tmp / "storage",
            max_question_image_mb=1,
        )
        try:
            ask(
                session,
                tiny_settings,
                storage,
                stub,
                "这张图片画的是什么？",
                image=b"\x00" * (2 * 1024 * 1024),
                image_mime="image/png",
            )
        except InputError as error:
            print("[services.qa] 图片超限被拒绝:", error.message)
        else:
            raise AssertionError("超大图片应抛 InputError")

        # 结构化失败回退：唯一图片段指向不存在的资源 -> 丢弃后只剩兜底文本
        broken_stub = StubAgentClient(
            AgentResponse(
                answer="",
                segments=[ImageSegment(asset_id="asset_not_exist", caption="不存在的图片")],
                citations=[],
            )
        )
        broken_reply = ask(session, settings, storage, broken_stub, "系统架构图在哪里？")
        print("[services.qa] 兜底回答:", broken_reply.answer)
        assert broken_reply.fallback is True, "结构化分段全部失效时应兜底"
        assert len(broken_reply.segments) == 1 and broken_reply.segments[0].type == "text"
        assert broken_reply.segments[0].text == FALLBACK_ANSWER
        assert broken_reply.citations == []

        # 下游故障：智能体异常直接向上抛，不伪装成兜底回答、也不落库
        class FailingAgent:
            """永远抛 UpstreamError 的假智能体，用来验证下游故障不会落库。"""

            def answer(self, request: AgentRequest) -> AgentResponse:
                """直接抛 UpstreamError，模拟智能体调用超时。"""
                raise UpstreamError("智能体调用超时")

        try:
            ask(session, settings, storage, FailingAgent(), "会失败的问题")
        except UpstreamError as error:
            print("[services.qa] 智能体故障直接上抛:", error.message)
        else:
            raise AssertionError("智能体故障应抛 UpstreamError")
        with factory() as check_session:
            final_qa_count = check_session.scalar(select(func.count()).select_from(QaRecord))
        assert final_qa_count == 4, "失败的问答不应落库"

    print("[services.qa] 自检通过")


if __name__ == "__main__":
    main()
