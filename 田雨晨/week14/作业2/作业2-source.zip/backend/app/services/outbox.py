"""事务发件箱：业务事务内落库，后台轮询投递到消息队列（Kafka 阶段直接替换队列实现）。"""

if __package__ in (None, ""):  # 允许直接运行本文件
    import sys
    from pathlib import Path

    for _root in Path(__file__).resolve().parents:
        if (_root / "backend" / "app").is_dir():
            sys.path.insert(0, str(_root))
            break

from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from backend.app.common import new_id, utcnow
from backend.app.config import Settings, get_settings
from backend.app.models.tables import OutboxEvent
from backend.app.schemas.enums import EventType


def enqueue(
    session: Session,
    *,
    aggregate_id: str,
    event_type: EventType | str,
    payload: dict,
) -> OutboxEvent:
    """在调用方的事务里追加一条待投递事件（不提交）。"""
    event = OutboxEvent(
        id=new_id("evt"),
        aggregate_id=aggregate_id,
        event_type=EventType(event_type).value,
        payload=payload,
    )
    session.add(event)
    return event


def pending_events(session: Session, limit: int = 100) -> list[OutboxEvent]:
    """取未投递事件，按创建时间排序（即投递顺序），避免同一文档的重试消息乱序。"""
    statement = (
        select(OutboxEvent)
        .where(OutboxEvent.delivered.is_(False))
        .order_by(OutboxEvent.created_at)
        .limit(limit)
    )
    return list(session.scalars(statement))


def topic_for(event_type: EventType | str, settings: Settings | None = None) -> str:
    """事件类型映射到主题：重试耗尽的死信走 DLQ，其余走解析请求主题。"""
    settings = settings or get_settings()
    event_type = EventType(event_type)
    if event_type is EventType.PARSE_DEAD_LETTER:
        return settings.kafka_dlq_topic
    return settings.kafka_parse_topic


def publish_pending(session: Session, queue: Any, settings: Settings | None = None, limit: int = 100) -> int:
    """把未投递事件发到队列并标记已投递，返回条数。

    语义是至少一次：发布过程中抛异常则本次一条都不提交，下轮重投，
    因此消费端必须幂等（README 已要求）。
    """
    settings = settings or get_settings()
    events = pending_events(session, limit)
    # 先全部投递、再统一标记提交：中途抛异常则一条都不标，下轮整批重投（至少一次）
    for event in events:
        queue.publish(topic_for(event.event_type, settings), event.aggregate_id, event.payload)
    if events:
        for event in events:
            event.delivered = True
            event.delivered_at = utcnow()
        session.commit()
    return len(events)


def main() -> None:
    """自测：入箱两条事件 → 投递 → 校验主题、标记已投递且不再出现在待投递列表。"""
    import tempfile
    from pathlib import Path

    from sqlalchemy import create_engine, select
    from sqlalchemy.orm import Session

    from backend.app.models.tables import Base, OutboxEvent

    class FakeQueue:
        """记录投递结果的假队列，只用于自测里断言主题与顺序。"""

        def __init__(self) -> None:
            """初始化空的消息记录列表。"""
            self.messages: list[tuple[str, str, dict]] = []

        def publish(self, topic: str, key: str, payload: dict) -> None:
            """把 (topic, key, payload) 记下来并打印，模拟一次投递。"""
            self.messages.append((topic, key, payload))
            print("[services.outbox] 投递 topic=", topic, "key=", key, "payload=", payload)

    tmp = Path(tempfile.mkdtemp(prefix="rag-outbox-"))
    engine = create_engine(f"sqlite:///{(tmp / 'demo.db').as_posix()}")
    Base.metadata.create_all(engine)
    settings = Settings()
    queue = FakeQueue()

    with Session(engine) as session:
        enqueue(
            session,
            aggregate_id="doc_1",
            event_type=EventType.PARSE_REQUESTED,
            payload={"doc_id": "doc_1", "batch_id": "batch_1", "object_key": "pdfs/doc_1.pdf"},
        )
        enqueue(
            session,
            aggregate_id="doc_2",
            event_type=EventType.PARSE_DEAD_LETTER,
            payload={"doc_id": "doc_2", "attempts": 3, "error": "解析超时"},
        )
        session.commit()

        pending = pending_events(session)
        print("[services.outbox] 待投递事件数:", len(pending))
        assert len(pending) == 2

        published = publish_pending(session, queue, settings)
        print("[services.outbox] 本轮投递:", published)
        assert published == 2
        assert [m[0] for m in queue.messages] == [settings.kafka_parse_topic, settings.kafka_dlq_topic]

        assert pending_events(session) == [], "已投递事件不应再出现在待投递列表"
        delivered = session.scalar(select(OutboxEvent).limit(1))
        assert delivered.delivered is True and delivered.delivered_at is not None
        print("[services.outbox] 事件已标记投递:", delivered.id)
    print("[services.outbox] 自检通过")


if __name__ == "__main__":
    main()
