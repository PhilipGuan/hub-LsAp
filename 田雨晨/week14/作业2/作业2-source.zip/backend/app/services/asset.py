"""图片资源短时签名地址：HMAC-SHA256 签名 + 过期时间校验，后端统一鉴权。"""

if __package__ in (None, ""):  # 允许直接运行本文件
    import sys
    from pathlib import Path

    for _root in Path(__file__).resolve().parents:
        if (_root / "backend" / "app").is_dir():
            sys.path.insert(0, str(_root))
            break

import hashlib
import hmac
import time
from datetime import datetime, timezone

from backend.app.config import Settings, get_settings
from backend.app.schemas.content import SignedAsset

MIN_TTL_SECONDS = 1
MAX_TTL_SECONDS = 86400


def _secret(settings: Settings) -> bytes:
    """取签名密钥；未配置直接报错，避免用空密钥静默签出可伪造的地址。"""
    if not settings.asset_signing_secret:
        raise RuntimeError("ASSET_SIGNING_SECRET 未配置")
    return settings.asset_signing_secret.encode("utf-8")


def sign(secret: bytes, asset_id: str, expires: int) -> str:
    """对 "asset_id:expires" 做 HMAC-SHA256；过期时间也在签名范围内，改它同样会失效。"""
    message = f"{asset_id}:{expires}".encode("utf-8")
    return hmac.new(secret, message, hashlib.sha256).hexdigest()


def sign_asset(settings: Settings | None = None, asset_id: str = "", ttl_seconds: int | None = None) -> SignedAsset:
    """生成短时签名地址，形如 {public_base_url}/api/assets/{asset_id}?expires=..&signature=.."""
    settings = settings or get_settings()
    if not asset_id:
        raise ValueError("asset_id 不能为空")
    ttl = int(ttl_seconds if ttl_seconds is not None else settings.asset_signed_url_ttl)
    if not MIN_TTL_SECONDS <= ttl <= MAX_TTL_SECONDS:
        raise ValueError(f"签名有效期应在 {MIN_TTL_SECONDS}~{MAX_TTL_SECONDS} 秒之间")
    expires = int(time.time()) + ttl
    signature = sign(_secret(settings), asset_id, expires)
    base = settings.public_base_url.rstrip("/")
    url = f"{base}/api/assets/{asset_id}?expires={expires}&signature={signature}"
    return SignedAsset(
        asset_id=asset_id,
        url=url,
        expires_at=datetime.fromtimestamp(expires, tz=timezone.utc),
    )


def verify_asset(settings: Settings | None, asset_id: str, expires: str | int, signature: str | None) -> bool:
    """校验签名与有效期；任何异常都视为无效。"""
    settings = settings or get_settings()
    try:
        expires_int = int(expires)
    except (TypeError, ValueError):
        return False
    if expires_int < int(time.time()):
        return False
    expected = sign(_secret(settings), asset_id, expires_int)
    # 常量时间比较：避免按字节提前返回，泄露正确签名长什么样
    return hmac.compare_digest(expected, signature or "")


def main() -> None:
    """自测：签名/校验通过，并覆盖篡改签名、换资源、过期、非法参数等拒绝分支。"""
    settings = Settings(public_base_url="http://127.0.0.1:8000")
    asset_id = "asset_demo"
    signed = sign_asset(settings, asset_id)
    print("[services.asset] 签名地址:", signed.url)
    print("[services.asset] 过期时间:", signed.expires_at.isoformat())
    assert signed.url.startswith("http://127.0.0.1:8000/api/assets/asset_demo?expires=")

    expires = signed.url.split("expires=")[1].split("&")[0]
    signature = signed.url.split("signature=")[1]
    assert verify_asset(settings, asset_id, expires, signature) is True
    print("[services.asset] 签名校验通过")

    assert verify_asset(settings, asset_id, expires, signature[:-2] + "00") is False
    print("[services.asset] 篡改签名被拒绝")
    assert verify_asset(settings, "asset_other", expires, signature) is False
    print("[services.asset] 换资源编号被拒绝")
    assert verify_asset(settings, asset_id, int(expires) - 10**6, sign(_secret(settings), asset_id, int(expires) - 10**6)) is False
    print("[services.asset] 过期地址被拒绝")
    assert verify_asset(settings, asset_id, "not-a-number", signature) is False
    print("[services.asset] 非法过期参数被拒绝")

    try:
        sign_asset(settings, asset_id, ttl_seconds=0)
    except ValueError as error:
        print("[services.asset] 非法有效期被拒绝:", error)
    else:
        raise AssertionError("0 秒有效期应被拒绝")

    short = sign_asset(settings, asset_id, ttl_seconds=1)
    print("[services.asset] 1 秒短时地址:", short.url)
    print("[services.asset] 自检通过")


if __name__ == "__main__":
    main()
