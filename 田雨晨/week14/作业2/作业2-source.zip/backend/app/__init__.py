"""多模态 RAG 问答系统后端。

分层：api（HTTP 接口）→ services（业务逻辑与状态机）→ models（ORM 表）；
clients 封装外部依赖（对象存储 / 队列 / 智能体），events 负责状态推送，
schemas 是贯穿各层的 pydantic 数据结构。
"""
