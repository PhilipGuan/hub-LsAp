"""FastAPI 应用入口。

启动服务（在仓库根目录执行）：
    uvicorn backend.app.main:create_app --factory --host 0.0.0.0 --port 8000
自测（打印路由并冒烟调用，不启动服务器）：
    python -m backend.app.main
"""

if __package__ in (None, ""):  # 允许直接运行本文件
    import sys
    from pathlib import Path

    for _root in Path(__file__).resolve().parents:
        if (_root / "backend" / "app").is_dir():
            sys.path.insert(0, str(_root))
            break

import traceback

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from backend.app.api import assets, documents, qa, upload
from backend.app.api.deps import SettingsDep
from backend.app.clients.agent import AgentClient, StubAgentClient, agent_from_settings
from backend.app.clients.queue import MessageQueue, queue_from_settings
from backend.app.clients.storage import ObjectStorage, storage_from_settings
from backend.app.config import Settings, get_settings
from backend.app.db import init_db, make_engine, make_session_factory
from backend.app.errors import AppError
from backend.app.events.sse import StatusHub


def create_app(
    settings: Settings | None = None,
    *,
    storage: ObjectStorage | None = None,
    agent: AgentClient | None = None,
    queue: MessageQueue | None = None,
    status_hub: StatusHub | None = None,
) -> FastAPI:
    """构建应用；依赖可在测试时注入（临时库、假智能体等）。"""
    settings = settings or get_settings()
    settings.ensure_dirs()
    engine = make_engine(settings)
    init_db(engine)

    app = FastAPI(
        title="多模态 RAG 问答系统 API",
        version="0.1.0",
        description="多 PDF 上传解析 + 批次/单文件状态 + 多模态图文问答（第一版最小实现）",
    )
    # 依赖统一挂在 app.state：接口层用 Depends 取，测试可整体替换成假实现
    app.state.settings = settings
    app.state.engine = engine
    app.state.session_factory = make_session_factory(engine)
    app.state.storage = storage or storage_from_settings(settings)
    app.state.queue = queue or queue_from_settings(settings)
    # 智能体服务（agent 目录）还没接上时，AGENT_STUB=1 用离线假智能体联调问答链路
    app.state.agent = agent or (StubAgentClient() if settings.agent_stub else agent_from_settings(settings))
    app.state.status_hub = status_hub or StatusHub()

    # 允许前端（Next.js，默认 :3000）跨域调用；来源由 CORS_ORIGINS 配置，
    # 另外放行本机/局域网开发来源（CORS_ORIGIN_REGEX），用 127.0.0.1 或局域网 IP 打开前端都能调
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origin_list,
        allow_origin_regex=settings.cors_origin_regex or None,
        allow_methods=["*"],
        allow_headers=["*"],
        expose_headers=["X-Request-Id"],
    )

    @app.exception_handler(AppError)
    async def handle_app_error(_: Request, error: AppError) -> JSONResponse:
        """业务异常统一转成 JSON，前端按 message 展示失败原因。"""
        return JSONResponse(
            status_code=error.status_code,
            content={"message": error.message, "detail": error.detail},
        )

    @app.exception_handler(Exception)
    async def handle_unexpected_error(_: Request, error: Exception) -> JSONResponse:
        """兜底异常：打印堆栈并返回 JSON 500。

        没有这个处理器时，未捕获异常由 Starlette 最外层直接返回纯文本 500、不带 CORS 头，
        浏览器会把它报成跨域失败，前端只能提示“请放行 CORS”，掩盖真正原因。
        """
        traceback.print_exc()
        return JSONResponse(status_code=500, content={"message": "服务器内部错误，请查看后端日志"})

    @app.get("/health", tags=["系统"], summary="健康检查")
    def health(settings_dep: SettingsDep) -> dict:
        """探活接口：回显运行模式与当前使用的存储/队列后端，供部署检查。"""
        return {
            "status": "ok",
            "app_env": settings_dep.app_env,
            "storage_backend": settings_dep.storage_backend,
            "queue_backend": settings_dep.queue_backend,
        }

    app.include_router(upload.router)
    app.include_router(documents.router)
    app.include_router(qa.router)
    app.include_router(assets.router)
    return app


def main() -> None:
    """自测：临时库起应用，打印路由并冒烟走通健康检查 / 上传 / 查状态。"""
    import tempfile
    from pathlib import Path

    from fastapi.testclient import TestClient

    from backend.app.clients.agent import StubAgentClient

    tmp = Path(tempfile.mkdtemp(prefix="rag-app-"))
    settings = Settings(
        database_url=f"sqlite:///{(tmp / 'app.db').as_posix()}",
        data_dir=tmp,
        storage_dir=tmp / "storage",
        public_base_url="http://127.0.0.1:8000",
    )
    app = create_app(settings, agent=StubAgentClient())
    print("[main] 已注册路由:")
    for path, operations in app.openapi().get("paths", {}).items():
        methods = ",".join(sorted(method.upper() for method in operations))
        print(f"  {methods:14s} {path}")

    with TestClient(app) as client:
        health = client.get("/health").json()
        print("[main] 健康检查:", health)
        assert health["status"] == "ok"

        created = client.post(
            "/api/batches",
            files=[("files", ("示例.pdf", b"%PDF-1.7\n" + b"0" * 100, "application/pdf"))],
        )
        print("[main] 上传状态码:", created.status_code)
        body = created.json()
        print("[main] 批次:", body["batch_id"], body["status"], body["display_status"])
        assert created.status_code == 200 and len(body["documents"]) == 1

        detail = client.get(f"/api/documents/{body['documents'][0]['doc_id']}").json()
        print("[main] 文档状态:", detail["status"], detail["display_status"])
        print("[main] OpenAPI 文档:", client.get("/openapi.json").status_code)
    print("[main] 自检通过（启动服务：uvicorn backend.app.main:create_app --factory）")


if __name__ == "__main__":
    main()
