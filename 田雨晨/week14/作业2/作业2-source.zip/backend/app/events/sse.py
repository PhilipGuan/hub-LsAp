"""状态事件推送：把批次状态快照广播给所有 SSE 订阅者，带心跳与断开自动注销。"""

if __package__ in (None, ""):  # 允许直接运行本文件
    import sys
    from pathlib import Path

    for _root in Path(__file__).resolve().parents:
        if (_root / "backend" / "app").is_dir():
            sys.path.insert(0, str(_root))
            break

import asyncio
import threading
from collections.abc import AsyncIterator
from typing import NamedTuple

from backend.app.common import utcnow
from backend.app.schemas.enums import BatchStatus, DocumentStatus
from backend.app.schemas.events import DocumentStatusItem, StatusEvent


def format_sse(event: StatusEvent) -> str:
    """一条 SSE 帧：event 行 + data 行 + 空行，data 是状态快照的 JSON。"""
    return f"event: {event.event}\ndata: {event.model_dump_json()}\n\n"


class _Subscriber(NamedTuple):
    """一个 SSE 连接：订阅时的事件循环 + 自己的有界队列。"""

    loop: asyncio.AbstractEventLoop
    queue: asyncio.Queue


class StatusHub:
    """按批次广播状态事件。

    publish 可以在同步线程（接口、后台线程）里调用，投递通过订阅者自己的事件循环完成；
    stream 必须在事件循环里跑，先注册再收事件，断开时在 finally 里注销。
    """

    def __init__(self, queue_size: int = 100) -> None:
        """初始化订阅表；queue_size 是单个订阅者的有界队列长度，满了丢事件而不是阻塞发布方。"""
        self._queue_size = queue_size
        self._lock = threading.Lock()
        self._subscribers: dict[str, set[_Subscriber]] = {}
        self.dropped = 0  # 队列满而丢弃的事件数，只用于观测

    def subscriber_count(self, batch_id: str) -> int:
        """当前批次仍在线的订阅者数，供测试与观测使用。"""
        with self._lock:
            return len(self._subscribers.get(batch_id, ()))

    def publish(self, event: StatusEvent) -> int:
        """广播给该批次的所有订阅者，返回已交给订阅者事件循环的订阅者数（不阻塞）。"""
        with self._lock:
            subscribers = list(self._subscribers.get(event.batch_id, ()))
        delivered = 0
        for subscriber in subscribers:
            try:
                # 发布方可能在同步线程（接口/后台线程），必须切回订阅者自己的事件循环再入队
                subscriber.loop.call_soon_threadsafe(self._offer, subscriber, event)
            except RuntimeError:  # 订阅者的事件循环已经关了
                self.dropped += 1
                continue
            delivered += 1
        return delivered

    def _offer(self, subscriber: _Subscriber, event: StatusEvent) -> None:
        """在订阅者的事件循环线程里真正入队；队列满就丢，绝不阻塞发布方。"""
        try:
            subscriber.queue.put_nowait(event)
        except asyncio.QueueFull:
            self.dropped += 1  # ponytail: 观测计数，在事件循环线程里累加即可

    async def stream(self, batch_id: str, *, heartbeat_s: float = 15.0) -> AsyncIterator[str]:
        """订阅一个批次的状态事件；空闲超过 heartbeat_s 发心跳注释，断开时自动注销。"""
        subscriber = _Subscriber(loop=asyncio.get_running_loop(), queue=asyncio.Queue(maxsize=self._queue_size))
        with self._lock:
            self._subscribers.setdefault(batch_id, set()).add(subscriber)
        try:
            while True:
                try:
                    event = await asyncio.wait_for(subscriber.queue.get(), timeout=heartbeat_s)
                except TimeoutError:
                    # 空闲发 SSE 注释帧心跳：代理和浏览器在长时间无数据时会主动断连
                    yield ": ping\n\n"
                else:
                    yield format_sse(event)
        finally:
            # 客户端断开/生成器被关闭时执行：注销订阅，批次没人订阅了就把 key 一起删掉
            with self._lock:
                subscribers = self._subscribers.get(batch_id)
                if subscribers is not None:
                    subscribers.discard(subscriber)
                    if not subscribers:
                        self._subscribers.pop(batch_id, None)


async def _collect(hub: StatusHub, batch_id: str, chunks: int, heartbeat_s: float = 15.0) -> list[str]:
    """收满 chunks 条就退出；退出时关闭生成器，验证 finally 里的注销。"""
    stream = hub.stream(batch_id, heartbeat_s=heartbeat_s)
    received: list[str] = []
    try:
        async for chunk in stream:
            received.append(chunk)
            if len(received) >= chunks:
                break
    finally:
        await stream.aclose()
    return received


async def _demo() -> None:
    """在单个事件循环里验证：帧格式、多订阅者广播、心跳、队列满丢弃、断开自动注销。"""
    batch_id = "batch_demo"
    event = StatusEvent(
        batch_id=batch_id,
        status=BatchStatus.PARSING,
        documents=[DocumentStatusItem(doc_id="doc_demo", filename="说明.pdf", status=DocumentStatus.PARSING)],
        ts=utcnow(),
    )

    frame = format_sse(event)
    print("[events.sse] 单条 SSE 帧:")
    print(frame)
    assert frame.startswith("event: status\ndata: ") and frame.endswith("\n\n"), "SSE 帧格式不对"
    assert StatusEvent.model_validate_json(frame.split("data: ", 1)[1].strip()).batch_id == batch_id, "data 应能还原事件"

    hub = StatusHub()
    assert hub.subscriber_count(batch_id) == 0
    print("[events.sse] 两个订阅者订阅同一批次")

    tasks = [asyncio.create_task(_collect(hub, batch_id, 1)) for _ in range(2)]
    for _ in range(20):  # 等生成器跑到注册之后
        if hub.subscriber_count(batch_id) == 2:
            break
        await asyncio.sleep(0)
    print("[events.sse] 当前订阅者数:", hub.subscriber_count(batch_id))
    assert hub.subscriber_count(batch_id) == 2

    delivered = await asyncio.to_thread(hub.publish, event)  # 模拟同步线程里推送状态
    print("[events.sse] 同步线程发布，投递订阅者数:", delivered)
    assert delivered == 2

    results = await asyncio.wait_for(asyncio.gather(*tasks), timeout=5.0)
    for index, chunks in enumerate(results, start=1):
        print(f"[events.sse] 订阅者{index} 收到:", chunks[0].replace("\n", "\\n"))
        assert chunks[0] == frame, "两条订阅者都应收到同一条事件"
        assert "event: status" in chunks[0] and batch_id in chunks[0]
    print("[events.sse] 收完后订阅者数:", hub.subscriber_count(batch_id))
    assert hub.subscriber_count(batch_id) == 0, "生成器关闭后应自动注销"

    ping = await asyncio.wait_for(_collect(hub, "batch_idle", 1, heartbeat_s=0.05), timeout=5.0)
    print("[events.sse] 空闲 0.05 秒收到心跳帧:", ping[0].replace("\n", "\\n"))
    assert ping[0] == ": ping\n\n", "空闲超时应该发 SSE 心跳注释"
    assert hub.subscriber_count("batch_idle") == 0

    drop_hub = StatusHub(queue_size=1)
    stream = drop_hub.stream(batch_id, heartbeat_s=5.0)
    head = asyncio.create_task(anext(stream))
    for _ in range(20):
        if drop_hub.subscriber_count(batch_id) == 1:
            break
        await asyncio.sleep(0)
    assert drop_hub.subscriber_count(batch_id) == 1
    for _ in range(3):  # 容量 1 的队列连发 3 条，后两条应被丢弃且不阻塞
        drop_hub.publish(event)
    for _ in range(20):
        if drop_hub.dropped == 2:
            break
        await asyncio.sleep(0)
    print("[events.sse] 队列容量 1 连发 3 条，丢弃计数:", drop_hub.dropped)
    assert drop_hub.dropped == 2, "队列满应丢弃并计数，且不阻塞发布方"
    assert await asyncio.wait_for(head, timeout=5.0) == frame, "队列里留下的应是第一条"
    await stream.aclose()
    assert drop_hub.subscriber_count(batch_id) == 0

    print("[events.sse] 状态推送 / 心跳 / 丢弃 / 注销 全部符合预期")


def main() -> None:
    """自测入口：跑 _demo 并加总超时，实现挂死时直接失败而不是卡住。"""
    print("[events.sse] StatusHub 自测开始")
    try:
        asyncio.run(asyncio.wait_for(_demo(), timeout=20.0))
    except TimeoutError as error:  # 只有实现挂死才会走到这里
        raise SystemExit("[events.sse] 自测超时：订阅者可能没有注销") from error
    print("[events.sse] 自检通过")


if __name__ == "__main__":
    main()
