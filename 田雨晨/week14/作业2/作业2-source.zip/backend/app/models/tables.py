"""SQLAlchemy 表结构：与 schemas 里的 pydantic 数据结构一一对应。"""

if __package__ in (None, ""):  # 允许直接运行本文件
    import sys
    from pathlib import Path

    for _root in Path(__file__).resolve().parents:
        if (_root / "backend" / "app").is_dir():
            sys.path.insert(0, str(_root))
            break

from datetime import datetime

from sqlalchemy import JSON, Boolean, DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column

from backend.app.common import utcnow


class Base(DeclarativeBase):
    """所有 ORM 模型的声明式基类；metadata 收集全表，供 init_db 统一建表。"""


class TimestampMixin:
    """通用时间戳列：创建/更新时间由 ORM 默认值自动维护，业务代码不用手写。"""
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utcnow, onupdate=utcnow, nullable=False
    )


class Batch(TimestampMixin, Base):
    """批次表。"""

    __tablename__ = "batches"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    trace_id: Mapped[str] = mapped_column(String(64), default="", nullable=False)
    file_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)


class Document(TimestampMixin, Base):
    """文档表：状态以本表为准。"""

    __tablename__ = "documents"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    batch_id: Mapped[str] = mapped_column(ForeignKey("batches.id"), index=True, nullable=False)
    filename: Mapped[str] = mapped_column(String(512), nullable=False)
    sha256: Mapped[str] = mapped_column(String(64), default="", nullable=False)
    object_key: Mapped[str] = mapped_column(String(1024), nullable=False)
    # status 建索引：批次状态汇总与“未完成文档”查询都按状态过滤
    status: Mapped[str] = mapped_column(String(32), default="queued", index=True, nullable=False)
    error: Mapped[str | None] = mapped_column(Text, default=None)
    pages: Mapped[int] = mapped_column(Integer, default=0, nullable=False)


class ParseTask(TimestampMixin, Base):
    """解析任务表：记录尝试次数与错误。"""

    __tablename__ = "parse_tasks"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    doc_id: Mapped[str] = mapped_column(ForeignKey("documents.id"), index=True, nullable=False)
    status: Mapped[str] = mapped_column(String(32), default="pending", nullable=False)
    attempts: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    last_error: Mapped[str | None] = mapped_column(Text, default=None)
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), default=None)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), default=None)
    trace_id: Mapped[str] = mapped_column(String(64), default="", nullable=False)


class Chunk(TimestampMixin, Base):
    """文本切片表。"""

    __tablename__ = "chunks"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    doc_id: Mapped[str] = mapped_column(ForeignKey("documents.id"), index=True, nullable=False)
    page: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    seq: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    text: Mapped[str] = mapped_column(Text, default="", nullable=False)
    asset_id: Mapped[str | None] = mapped_column(String(64), default=None, index=True)
    # ponytail: 向量先以 JSON 存；切 PostgreSQL 时换成 pgvector 的 Vector(1024) 列
    embedding: Mapped[list[float] | None] = mapped_column(JSON, default=None)


class Asset(TimestampMixin, Base):
    """图片资源表：图片与文档、页码、说明文字、识别文字、版面框关联。"""

    __tablename__ = "assets"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    doc_id: Mapped[str] = mapped_column(ForeignKey("documents.id"), index=True, nullable=False)
    page: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    asset_type: Mapped[str] = mapped_column(String(16), default="figure", nullable=False)
    object_key: Mapped[str] = mapped_column(String(1024), nullable=False)
    caption: Mapped[str] = mapped_column(Text, default="", nullable=False)
    ocr_text: Mapped[str] = mapped_column(Text, default="", nullable=False)
    bbox: Mapped[list[float] | None] = mapped_column(JSON, default=None)


class QaRecord(TimestampMixin, Base):
    """问答记录表。"""

    __tablename__ = "qa_records"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    question: Mapped[str] = mapped_column(Text, nullable=False)
    image_key: Mapped[str | None] = mapped_column(String(1024), default=None)
    answer: Mapped[str] = mapped_column(Text, default="", nullable=False)
    segments: Mapped[list] = mapped_column(JSON, default=list, nullable=False)
    fallback: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)


class Citation(TimestampMixin, Base):
    """引用表。"""

    __tablename__ = "citations"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    qa_id: Mapped[str] = mapped_column(ForeignKey("qa_records.id"), index=True, nullable=False)
    doc_id: Mapped[str] = mapped_column(String(64), default="", nullable=False)
    chunk_id: Mapped[str | None] = mapped_column(String(64), default=None)
    asset_id: Mapped[str | None] = mapped_column(String(64), default=None)
    page: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    bbox: Mapped[list[float] | None] = mapped_column(JSON, default=None)


class OutboxEvent(TimestampMixin, Base):
    """事务发件箱表：业务事务内落库，轮询投递到 Kafka。"""

    __tablename__ = "outbox_events"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    aggregate_id: Mapped[str] = mapped_column(String(64), index=True, nullable=False)
    event_type: Mapped[str] = mapped_column(String(64), nullable=False)
    payload: Mapped[dict] = mapped_column(JSON, default=dict, nullable=False)
    # delivered 建索引：轮询只扫未投递的行，表变大后依然快
    delivered: Mapped[bool] = mapped_column(Boolean, default=False, index=True, nullable=False)
    delivered_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), default=None)


class ConsumerIdempotency(Base):
    """消费幂等表（预留）：同一消费者重复收到同一消息时不重复处理。

    第一版消费幂等由 parse-worker 的“先删后写”保证，这张表还没有接入读写；
    接 Kafka 消费者时用它做 (consumer, message_key) 去重。
    """

    __tablename__ = "consumer_idempotency"

    consumer: Mapped[str] = mapped_column(String(64), primary_key=True)
    # (consumer, message_key) 复合主键天然去重：同一条消息重复消费时插入即冲突
    message_key: Mapped[str] = mapped_column(String(128), primary_key=True)
    processed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)


def main() -> None:
    """自测：建全部表 → 各表写一行 → 读回计数并校验默认状态。"""
    import tempfile
    from pathlib import Path

    from sqlalchemy import create_engine, func, select
    from sqlalchemy.orm import Session

    from backend.app.common import new_id

    tmp = Path(tempfile.mkdtemp(prefix="rag-tables-"))
    engine = create_engine(f"sqlite:///{(tmp / 'demo.db').as_posix()}")
    Base.metadata.create_all(engine)
    print("[models.tables] 建表:", ", ".join(sorted(Base.metadata.tables)))

    batch_id = new_id("batch")
    doc_id = new_id("doc")
    with Session(engine) as session:
        session.add(Batch(id=batch_id, trace_id=new_id("trace"), file_count=1))
        session.add(
            Document(
                id=doc_id,
                batch_id=batch_id,
                filename="说明.pdf",
                sha256="a" * 64,
                object_key=f"pdfs/{doc_id}.pdf",
            )
        )
        session.add(ParseTask(id=new_id("task"), doc_id=doc_id, trace_id=new_id("trace")))
        session.add(Chunk(id=new_id("chunk"), doc_id=doc_id, page=1, seq=0, text="示例切片"))
        session.add(
            Asset(
                id=new_id("asset"),
                doc_id=doc_id,
                page=1,
                asset_type="figure",
                object_key="assets/demo.png",
                caption="示例图片",
                bbox=[0.0, 0.0, 100.0, 100.0],
            )
        )
        session.add(
            OutboxEvent(
                id=new_id("evt"),
                aggregate_id=doc_id,
                event_type="parse.requested",
                payload={"doc_id": doc_id},
            )
        )
        session.commit()

    with Session(engine) as session:
        tables = {
            "batches": select(func.count()).select_from(Batch),
            "documents": select(func.count()).select_from(Document),
            "parse_tasks": select(func.count()).select_from(ParseTask),
            "chunks": select(func.count()).select_from(Chunk),
            "assets": select(func.count()).select_from(Asset),
            "outbox_events": select(func.count()).select_from(OutboxEvent),
        }
        for name, statement in tables.items():
            count = session.scalar(statement)
            print(f"[models.tables] {name}: {count} 行")
            assert count == 1, f"{name} 应写入 1 行"
        document = session.get(Document, doc_id)
        print("[models.tables] 文档状态:", document.status, "| 页数:", document.pages)
        assert document.status == "queued"
    print("[models.tables] 自检通过")


if __name__ == "__main__":
    main()
