"""SQLAlchemy 表结构包。"""
