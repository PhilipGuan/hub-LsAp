"""公共小工具：编号生成与 UTC 时间。

接口层、服务层、模型默认值共用这一份实现：编号格式全链路一致，
时间统一为带时区的 UTC，避免同一份响应里 naive/aware 时间混用。
"""

from datetime import datetime, timezone
from uuid import uuid4

ID_PREFIXES = ("batch", "doc", "task", "chunk", "asset", "qa", "cit", "evt", "trace")


def new_id(prefix: str) -> str:
    """生成带业务前缀的编号，例如 doc_3f2a...。"""
    if not prefix:
        raise ValueError("前缀不能为空")
    return f"{prefix}_{uuid4().hex}"


def utcnow() -> datetime:
    """当前 UTC 时间（带时区）；全后端统一入口，避免各处混用本地时间。"""
    return datetime.now(timezone.utc)


def iso(moment: datetime | None) -> str | None:
    """时间转 ISO 字符串，None 原样返回，方便直接塞进日志或响应。"""
    return moment.isoformat() if moment else None


def main() -> None:
    """自测：编号唯一且格式正确、时间带时区并能安全序列化。"""
    ids = [new_id("doc") for _ in range(3)]
    print("[common] 示例编号:", ids)
    assert len(set(ids)) == 3, "编号必须唯一"
    assert all(i.startswith("doc_") and len(i) == 36 for i in ids), "编号格式不正确"

    now = utcnow()
    print("[common] 当前 UTC 时间:", now.isoformat())
    print("[common] 序列化时间:", iso(now), "/ 空值:", iso(None))
    assert now.tzinfo is not None, "时间必须带时区"
    assert iso(None) is None
    print("[common] 自检通过")


if __name__ == "__main__":
    main()
