"""智能体客户端：后端调用问答编排智能体的 HTTP 客户端，外加离线确定性假智能体。"""

if __package__ in (None, ""):  # 允许直接运行本文件
    import sys
    from pathlib import Path

    for _root in Path(__file__).resolve().parents:
        if (_root / "backend" / "app").is_dir():
            sys.path.insert(0, str(_root))
            break

from typing import Protocol

import httpx
from pydantic import ValidationError

from backend.app.common import new_id
from backend.app.config import Settings, get_settings
from backend.app.errors import UpstreamError
from backend.app.schemas.content import Citation
from backend.app.schemas.qa import AgentRequest, AgentResponse, ImageSegment, TextSegment

DEFAULT_TIMEOUT_S = 120.0
FALLBACK_ANSWER = "根据提供的资料无法回答该问题。"


class AgentClient(Protocol):
    """问答编排智能体的最小接口：后端只关心“问题进、结构化回答出”。"""

    def answer(self, request: AgentRequest) -> AgentResponse:
        """提交一次问答请求，返回结构化回答；失败时抛 UpstreamError。"""
        ...


class HttpAgentClient:
    """真实智能体客户端：POST {base_url}/answer，任何失败都转成 UpstreamError。"""

    def __init__(
        self,
        base_url: str,
        timeout_s: float = DEFAULT_TIMEOUT_S,
        client: httpx.Client | None = None,
    ) -> None:
        """记录服务地址与超时；可注入 httpx.Client，测试用 MockTransport 替换网络。"""
        self.base_url = base_url.rstrip("/")
        self.timeout_s = timeout_s
        self._client = client if client is not None else httpx.Client(timeout=timeout_s)

    def answer(self, request: AgentRequest) -> AgentResponse:
        """调用智能体并校验返回结构；网络/状态码/解析失败统一转 UpstreamError（接口层 → 502）。"""
        url = f"{self.base_url}/answer"
        try:
            response = self._client.post(
                url, json=request.model_dump(mode="json"), timeout=self.timeout_s
            )
        except httpx.HTTPError as error:  # 连接失败、超时等网络异常
            raise UpstreamError(f"智能体调用失败: {error}") from error
        if not response.is_success:
            raise UpstreamError(f"智能体返回错误状态 {response.status_code}: {response.text[:200]}")
        try:
            return AgentResponse.model_validate(response.json())
        except (ValueError, ValidationError) as error:  # 非 JSON 或结构与契约不符
            raise UpstreamError(f"智能体返回内容无法解析: {error}") from error


class StubAgentClient:
    """离线确定性假智能体：不联网，便于自测、演示与本地联调。"""

    def __init__(self, response: AgentResponse | None = None) -> None:
        """默认返回兜底文案；calls 记录收到的请求，便于断言传参。"""
        self.response = response if response is not None else AgentResponse(
            answer=FALLBACK_ANSWER,
            segments=[TextSegment(text=FALLBACK_ANSWER)],
            citations=[],
        )
        self.calls: list[AgentRequest] = []

    def answer(self, request: AgentRequest) -> AgentResponse:
        """记录请求并原样返回预置回答（不产生任何 IO）。"""
        self.calls.append(request)
        return self.response


def agent_from_settings(settings: Settings | None = None) -> AgentClient:
    """按配置装配真实智能体客户端。"""
    settings = settings or get_settings()
    return HttpAgentClient(settings.agent_service_url, settings.agent_timeout_s)


def main() -> None:
    """自测：假智能体行为、真实客户端成功路径，以及四类失败都转 UpstreamError。"""
    citation_id = new_id("cit")
    demo_request = AgentRequest(question="系统由哪些组件组成？")
    demo_response = AgentResponse(
        answer="系统由前端、后端、解析工作器和智能体组成。",
        segments=[
            TextSegment(text="系统由前端、后端、解析工作器和智能体组成。", sources=[citation_id]),
            ImageSegment(asset_id="asset_demo", caption="系统架构图", sources=[citation_id]),
        ],
        citations=[Citation(citation_id=citation_id, doc_id="doc_demo", page=2)],
    )

    stub = StubAgentClient(demo_response)
    print("[clients.agent] 请求 JSON:")
    print(demo_request.model_dump_json(indent=2, ensure_ascii=False))
    stub_result = stub.answer(demo_request)
    print("[clients.agent] 假智能体响应 JSON:")
    print(stub_result.model_dump_json(indent=2, ensure_ascii=False))
    assert stub.calls == [demo_request], "假智能体应记录调用参数"
    assert len(stub_result.segments) == 2
    assert stub_result.segments[0].type == "text" and stub_result.segments[1].type == "image"

    default_result = StubAgentClient().answer(AgentRequest(question="随便问问"))
    print("[clients.agent] 默认兜底回答:", default_result.answer)
    assert default_result.answer == FALLBACK_ANSWER
    assert len(default_result.segments) == 1 and default_result.segments[0].type == "text"
    assert default_result.citations == []

    seen: list[httpx.Request] = []

    def ok_handler(request: httpx.Request) -> httpx.Response:
        """返回 200 + 预置响应，并记录请求以便断言最终调用的 URL。"""
        seen.append(request)
        return httpx.Response(200, json=demo_response.model_dump(mode="json"))

    with httpx.Client(transport=httpx.MockTransport(ok_handler)) as mock_client:
        agent = HttpAgentClient("http://agent.local/v1/", timeout_s=3, client=mock_client)
        result = agent.answer(demo_request)
    print("[clients.agent] 200 请求地址:", seen[0].url)
    assert str(seen[0].url) == "http://agent.local/v1/answer", "应拼出 /answer 地址"
    assert result.answer == demo_response.answer
    assert isinstance(result.segments[1], ImageSegment), "响应应还原为结构化分段"

    def server_error_handler(request: httpx.Request) -> httpx.Response:
        """模拟下游返回 500。"""
        return httpx.Response(500, json={"detail": "模型超时"})

    def broken_json_handler(request: httpx.Request) -> httpx.Response:
        """模拟 200 但响应体不是 JSON。"""
        return httpx.Response(200, text="这不是 JSON")

    def invalid_schema_handler(request: httpx.Request) -> httpx.Response:
        """模拟 200 但缺少契约必填字段。"""
        return httpx.Response(200, json={"segments": []})  # 缺 answer 字段

    def offline_handler(request: httpx.Request) -> httpx.Response:
        """模拟连接失败（服务没起或端口不通）。"""
        raise httpx.ConnectError("连接被拒绝", request=request)

    failing_cases = (
        ("500", server_error_handler),
        ("非 JSON", broken_json_handler),
        ("结构不合法", invalid_schema_handler),
        ("网络异常", offline_handler),
    )
    for label, handler in failing_cases:
        with httpx.Client(transport=httpx.MockTransport(handler)) as error_client:
            try:
                HttpAgentClient("http://agent.local", timeout_s=1, client=error_client).answer(demo_request)
            except UpstreamError as error:
                print(f"[clients.agent] {label} -> UpstreamError:", error.message)
            else:
                raise AssertionError(f"{label} 应转成 UpstreamError")

    settings = Settings(agent_service_url="http://127.0.0.1:8100")
    from_settings = agent_from_settings(settings)
    print("[clients.agent] agent_from_settings 地址:", from_settings.base_url)
    assert from_settings.base_url == "http://127.0.0.1:8100"
    print("[clients.agent] 自检通过")


if __name__ == "__main__":
    main()
