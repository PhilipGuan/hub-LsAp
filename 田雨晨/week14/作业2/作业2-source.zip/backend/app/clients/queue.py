"""消息队列适配：本地用内存队列，Docker 阶段换成 Kafka，调用方只依赖 publish/fetch。"""

if __package__ in (None, ""):  # 允许直接运行本文件
    import sys
    from pathlib import Path

    for _root in Path(__file__).resolve().parents:
        if (_root / "backend" / "app").is_dir():
            sys.path.insert(0, str(_root))
            break

import json
import sys
import threading
from collections import defaultdict, deque
from copy import deepcopy
from typing import Any, Protocol

from backend.app.config import Settings, get_settings


class MessageQueue(Protocol):
    """消息队列最小接口：同一主题内 FIFO，payload 只放元数据，不放 PDF 二进制。"""

    def publish(self, topic: str, key: str, payload: dict) -> None:
        """投递一条消息；返回即代表已交给队列（内存实现是入队，Kafka 实现会 flush）。"""
        ...

    def fetch(self, topic: str, max_messages: int = 10) -> list[dict]:
        """最多取 max_messages 条消息；没有消息时返回空列表而不是阻塞。"""
        ...


class InMemoryQueue:
    """进程内队列：线程安全、取出即移除，重启即丢，只用于本地开发与自测。"""

    def __init__(self) -> None:
        """建一个空队列；一把进程内锁保护所有主题，本地开发够用。"""
        self._lock = threading.Lock()
        self._topics: dict[str, deque[dict]] = defaultdict(deque)

    def publish(self, topic: str, key: str, payload: dict) -> None:
        """投递到主题尾部；深拷贝入队，避免发布方后续修改影响消费端。"""
        with self._lock:
            self._topics[topic].append(deepcopy(payload))  # 与调用方隔离

    def fetch(self, topic: str, max_messages: int = 10) -> list[dict]:
        """取出即移除，每条都是 payload 深拷贝，调用方随便改都不影响队列与发布方。"""
        with self._lock:
            messages = self._topics[topic]
            batch = [messages.popleft() for _ in range(min(max_messages, len(messages)))]
        return [deepcopy(message) for message in batch]


class KafkaQueue:
    """Kafka 实现：构造只记参数，首次 publish/fetch 才导入 kafka 并建立连接。"""

    def __init__(self, brokers: str) -> None:
        """只记录 broker 列表；producer/consumer 延迟到首次收发给，避免本地未装 kafka 就失败。"""
        self.brokers = brokers
        self._producer: Any = None
        self._consumers: dict[str, Any] = {}

    def _module(self) -> Any:
        try:
            import kafka
        except ImportError as error:  # 本地没装 kafka-python-ng
            raise RuntimeError("未安装 kafka-python-ng，本地开发请用 memory 队列") from error
        return kafka

    def publish(self, topic: str, key: str, payload: dict) -> None:
        """发送一条消息并 flush；producer 懒创建，保证本方法返回时消息已交给 broker。"""
        kafka = self._module()
        if self._producer is None:
            # json.dumps 返回 str，kafka-python 要求 bytes，因此套一层编码
            self._producer = kafka.KafkaProducer(
                bootstrap_servers=self.brokers,
                value_serializer=lambda value: json.dumps(value, ensure_ascii=False).encode("utf-8"),
            )
        self._producer.send(topic, key=key.encode("utf-8"), value=payload)
        self._producer.flush()

    def fetch(self, topic: str, max_messages: int = 10) -> list[dict]:
        """取最多 max_messages 条并提交位点；无新消息时按 consumer_timeout_ms 结束迭代。"""
        kafka = self._module()
        consumer = self._consumers.get(topic)
        if consumer is None:
            consumer = kafka.KafkaConsumer(
                topic,
                bootstrap_servers=self.brokers,
                group_id="rag-backend",
                auto_offset_reset="earliest",
                consumer_timeout_ms=1000,
                value_deserializer=json.loads,
            )
            self._consumers[topic] = consumer
        messages: list[dict] = []
        for record in consumer:  # 没有新消息时按 consumer_timeout_ms 结束迭代
            messages.append(record.value)
            # 逐条提交位点：进程崩了最多重放一条，消费端必须幂等（当前由 parse-worker 的“先删后写”兜住）
            consumer.commit()
            if len(messages) >= max_messages:
                break
        return messages


def queue_from_settings(settings: Settings | None = None) -> MessageQueue:
    """按配置选实现：memory 走进程内队列，kafka 走真实消息队列。"""
    settings = settings or get_settings()
    if settings.queue_backend == "memory":
        return InMemoryQueue()
    if settings.queue_backend == "kafka":
        return KafkaQueue(settings.kafka_brokers)
    raise ValueError(f"未知队列后端: {settings.queue_backend!r}，只支持 memory / kafka")


def main() -> None:
    """自测：FIFO、主题隔离、深拷贝、并发发布不丢消息、未知后端被拒绝。"""
    queue = queue_from_settings(Settings(queue_backend="memory"))
    print("[clients.queue] queue_backend=memory ->", type(queue).__name__)
    assert isinstance(queue, InMemoryQueue)

    for index in range(1, 4):
        queue.publish("parse.requested", f"doc_{index}", {"doc_id": f"doc_{index}", "attempt": 1})
        queue.publish("parse.dlq", f"doc_{index}", {"doc_id": f"doc_{index}", "attempts": 3, "error": "解析超时"})
    print("[clients.queue] 已投递: parse.requested=3 条, parse.dlq=3 条")

    fetched = queue.fetch("parse.requested", max_messages=2)
    print("[clients.queue] 先取 2 条:", [message["doc_id"] for message in fetched])
    assert [message["doc_id"] for message in fetched] == ["doc_1", "doc_2"], "FIFO 顺序不对"

    rest = queue.fetch("parse.requested")
    print("[clients.queue] 再取剩余:", [message["doc_id"] for message in rest])
    assert [message["doc_id"] for message in rest] == ["doc_3"], "取出即移除后应只剩 1 条"
    assert queue.fetch("parse.requested") == [], "取空后应返回空列表"

    dlq = queue.fetch("parse.dlq", max_messages=10)
    print("[clients.queue] 另一个主题消息数:", len(dlq), "首条:", dlq[0])
    assert len(dlq) == 3, "主题之间不能串消息"
    assert dlq[0] == {"doc_id": "doc_1", "attempts": 3, "error": "解析超时"}, "payload 内容应与发布时一致"

    original = {"doc_id": "doc_copy"}
    queue.publish("parse.requested", "doc_copy", original)
    original["doc_id"] = "被改坏了"
    copied = queue.fetch("parse.requested")
    print("[clients.queue] 发布后修改原对象，取回内容:", copied[0])
    assert copied[0]["doc_id"] == "doc_copy", "取出的必须是发布时的深拷贝"

    def _publish_many(worker: int) -> None:
        for number in range(25):
            queue.publish("thread", f"doc_{worker}_{number}", {"worker": worker, "number": number})

    workers = [threading.Thread(target=_publish_many, args=(worker,)) for worker in range(4)]
    for worker in workers:
        worker.start()
    for worker in workers:
        worker.join()
    concurrent = queue.fetch("thread", max_messages=1000)
    print("[clients.queue] 4 线程各发 25 条，收到:", len(concurrent))
    assert len(concurrent) == 100, "加锁后并发发布不应丢消息"

    try:
        queue_from_settings(Settings(queue_backend="redis"))
    except ValueError as error:
        print("[clients.queue] 非法后端被拒绝:", error)
    else:
        raise AssertionError("未知队列后端应抛 ValueError")

    kafka_imported = "kafka" in sys.modules
    kafka_queue = KafkaQueue("127.0.0.1:9092")
    print("[clients.queue] queue_backend=kafka ->", type(kafka_queue).__name__, "brokers=", kafka_queue.brokers)
    assert kafka_queue.brokers == "127.0.0.1:9092"
    assert ("kafka" in sys.modules) == kafka_imported, "构造 KafkaQueue 不应导入 kafka 模块"
    print("[clients.queue] 说明: KafkaQueue 构造不联网、不导入 kafka；真正调用 publish/fetch 时")
    print("[clients.queue]       本地未安装 kafka-python-ng，会抛 RuntimeError('未安装 kafka-python-ng，本地开发请用 memory 队列')")
    print("[clients.queue] 自检通过")


if __name__ == "__main__":
    main()
