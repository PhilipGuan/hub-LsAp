"""对象存储适配：默认写本地目录，Docker 阶段替换为 MinIO（同一套方法签名）。"""

if __package__ in (None, ""):  # 允许直接运行本文件
    import sys
    from pathlib import Path

    for _root in Path(__file__).resolve().parents:
        if (_root / "backend" / "app").is_dir():
            sys.path.insert(0, str(_root))
            break

import re
from pathlib import Path
from typing import Protocol

from backend.app.config import Settings, get_settings

_KEY_PATTERN = re.compile(r"^[A-Za-z0-9._/-]+$")


class ObjectStorage(Protocol):
    """对象存储最小接口：MinIO 实现照此补齐即可。"""

    def put(self, key: str, data: bytes, content_type: str | None = None) -> str:
        """写入对象，返回 key；key 非法时抛 ValueError。"""
        ...

    def get(self, key: str) -> bytes:
        """读取对象字节；不存在时由具体实现抛异常（本地实现抛 FileNotFoundError）。"""
        ...

    def exists(self, key: str) -> bool:
        """对象是否存在。"""
        ...

    def delete(self, key: str) -> None:
        """删除对象；不存在时静默成功，便于清理逻辑重复执行。"""
        ...


def validate_key(key: str) -> str:
    """防路径穿越：key 只能是普通相对路径。"""
    if not key or key.startswith("/") or "\\" in key or ".." in key.split("/") or not _KEY_PATTERN.match(key):
        raise ValueError(f"非法对象存储 key: {key!r}")
    return key


class LocalStorage:
    """本地文件系统实现，用于不需要 MinIO 的开发与自测。"""

    def __init__(self, root: Path | str) -> None:
        """绑定存储根目录（不存在则创建）；所有 key 都相对这个根解析。"""
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)

    def _path(self, key: str) -> Path:
        path = (self.root / validate_key(key)).resolve()
        # resolve 之后再比对根目录：对软链接/特殊路径做第二道越界检查
        if self.root not in path.parents:
            raise ValueError(f"对象路径越界: {key!r}")
        return path

    def put(self, key: str, data: bytes, content_type: str | None = None) -> str:
        """写入对象字节并返回 key；content_type 本地实现用不到，留给 MinIO 对应参数。"""
        path = self._path(key)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
        return key

    def get(self, key: str) -> bytes:
        """读取对象字节；key 非法抛 ValueError，文件不存在抛 FileNotFoundError。"""
        return self._path(key).read_bytes()

    def exists(self, key: str) -> bool:
        """对象是否存在（只判断普通文件，目录不算）。"""
        return self._path(key).is_file()

    def delete(self, key: str) -> None:
        """删除对象；不存在时静默成功，便于清理流程重复执行。"""
        self._path(key).unlink(missing_ok=True)


def storage_from_settings(settings: Settings | None = None) -> ObjectStorage:
    """按配置构造存储实现：当前只有本地目录，切 Docker 时换 MinIO 版本。"""
    settings = settings or get_settings()
    settings.ensure_dirs()
    return LocalStorage(settings.storage_path)


def main() -> None:
    """自测：写入/读取/删除一致，以及路径穿越类非法 key 被拒绝。"""
    import tempfile

    tmp = Path(tempfile.mkdtemp(prefix="rag-storage-"))
    storage = LocalStorage(tmp / "objects")
    key = "pdfs/demo.pdf"
    data = b"%PDF-1.7 demo"

    stored = storage.put(key, data, "application/pdf")
    print("[clients.storage] 写入:", stored, "字节数:", len(data))
    assert storage.exists(key)
    assert storage.get(key) == data
    print("[clients.storage] 读取一致:", storage.get(key))

    for bad_key in ("../secret.txt", "/etc/passwd", "a\\b.txt", ""):
        try:
            storage.get(bad_key)
        except ValueError as error:
            print("[clients.storage] 拒绝非法 key:", bad_key or "<空>", "->", error)
        else:
            raise AssertionError(f"应当拒绝 {bad_key!r}")

    storage.delete(key)
    assert not storage.exists(key)
    print("[clients.storage] 自检通过")


if __name__ == "__main__":
    main()
