"""多模态问答接口：问题文本 + 可选用户图片，返回图文混排回答。"""

if __package__ in (None, ""):  # 允许直接运行本文件
    import sys
    from pathlib import Path

    for _root in Path(__file__).resolve().parents:
        if (_root / "backend" / "app").is_dir():
            sys.path.insert(0, str(_root))
            break

from fastapi import APIRouter, File, Form, UploadFile

from backend.app.api.deps import AgentDep, SessionDep, SettingsDep, StorageDep
from backend.app.schemas.qa import QAResponse
from backend.app.services import qa as qa_service

router = APIRouter(prefix="/api", tags=["问答"])


@router.post("/qa", response_model=QAResponse, summary="多模态问答（纯文本或图文）")
def ask_question(
    session: SessionDep,
    settings: SettingsDep,
    storage: StorageDep,
    agent: AgentDep,
    question: str = Form(..., description="问题文本"),
    image: UploadFile | None = File(None, description="可选用户图片"),
) -> QAResponse:
    """多模态问答入口：读入可选图片后转交服务层，返回图文混排回答。"""
    image_bytes = None
    image_mime = None
    if image is not None:
        image_bytes = image.file.read()
        image_mime = image.content_type
    return qa_service.ask(
        session,
        settings,
        storage,
        agent,
        question,
        image=image_bytes,
        image_mime=image_mime,
    )


def main() -> None:
    """自测：上传预设数据后调 /api/qa，校验图片段签名地址、引用文件名与空问题拒绝。"""
    import base64
    import tempfile
    from pathlib import Path as _Path
    from urllib.parse import urlparse

    from fastapi.testclient import TestClient

    from backend.app.clients.agent import StubAgentClient
    from backend.app.common import new_id
    from backend.app.config import Settings as _Settings
    from backend.app.main import create_app
    from backend.app.models.tables import Asset, Batch, Document
    from backend.app.schemas.content import Citation
    from backend.app.schemas.qa import AgentResponse, ImageSegment, TextSegment

    png = base64.b64decode(
        "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=="
    )
    tmp = _Path(tempfile.mkdtemp(prefix="rag-api-qa-"))
    settings = _Settings(
        database_url=f"sqlite:///{(tmp / 'app.db').as_posix()}",
        data_dir=tmp,
        storage_dir=tmp / "storage",
    )

    batch_id = new_id("batch")
    doc_id = new_id("doc")
    asset_id = new_id("asset")
    citation_id = new_id("cit")
    stub = StubAgentClient(
        AgentResponse(
            answer="系统由前端、后端、解析工作器三部分组成，架构见图。",
            segments=[
                TextSegment(text="系统由前端、后端、解析工作器三部分组成。", sources=[citation_id]),
                ImageSegment(asset_id=asset_id, caption="系统架构图"),
            ],
            citations=[Citation(citation_id=citation_id, doc_id=doc_id, page=2)],
        )
    )
    app = create_app(settings, agent=stub)
    with app.state.session_factory() as session:
        session.add(Batch(id=batch_id, trace_id="trace_demo", file_count=1))
        session.add(
            Document(
                id=doc_id,
                batch_id=batch_id,
                filename="系统说明.pdf",
                sha256="0" * 64,
                object_key=f"pdfs/{doc_id}.pdf",
                status="done",
                pages=10,
            )
        )
        asset_key = f"assets/{doc_id}/figure-1.png"
        app.state.storage.put(asset_key, png, "image/png")
        session.add(
            Asset(
                id=asset_id,
                doc_id=doc_id,
                page=2,
                asset_type="figure",
                object_key=asset_key,
                caption="系统架构图",
            )
        )
        session.commit()

    with TestClient(app) as client:
        response = client.post(
            "/api/qa",
            data={"question": "这个系统由哪些部分组成？"},
            files={"image": ("question.png", png, "image/png")},
        )
        print("[api.qa] 状态码:", response.status_code)
        body = response.json()
        print("[api.qa] 分段数:", len(body["segments"]), "引用数:", len(body["citations"]), "兜底:", body["fallback"])
        print("[api.qa] 回答:", body["answer"])
        assert response.status_code == 200
        assert body["segments"][1]["type"] == "image"
        image_segment = body["segments"][1]
        assert image_segment["asset_url"] and "/api/assets/" in image_segment["asset_url"]
        assert body["citations"][0]["doc_filename"] == "系统说明.pdf"
        print("[api.qa] 图片签名地址:", image_segment["asset_url"])
        print("[api.qa] 引用页码:", body["citations"][0]["page"])

        parsed = urlparse(image_segment["asset_url"])
        asset_response = client.get(parsed.path + "?" + parsed.query)
        print("[api.qa] 按签名地址读取图片:", asset_response.status_code, asset_response.headers["content-type"])
        assert asset_response.status_code == 200 and asset_response.content == png

        empty = client.post("/api/qa", data={"question": "   "})
        print("[api.qa] 空问题拒绝:", empty.status_code, empty.json())
        assert empty.status_code == 400
    print("[api.qa] 自检通过")


if __name__ == "__main__":
    main()
