"""图片资源接口：按短时签名地址读取图片，后端统一鉴权。"""

if __package__ in (None, ""):  # 允许直接运行本文件
    import sys
    from pathlib import Path

    for _root in Path(__file__).resolve().parents:
        if (_root / "backend" / "app").is_dir():
            sys.path.insert(0, str(_root))
            break

import mimetypes

from fastapi import APIRouter, Query
from fastapi.responses import Response

from backend.app.api.deps import SessionDep, SettingsDep, StorageDep
from backend.app.errors import ForbiddenError, NotFoundError
from backend.app.models.tables import Asset
from backend.app.services.asset import verify_asset

router = APIRouter(prefix="/api", tags=["图片资源"])


@router.get("/assets/{asset_id}", summary="按签名地址读取图片资源")
def read_asset(
    asset_id: str,
    session: SessionDep,
    settings: SettingsDep,
    storage: StorageDep,
    expires: str = Query(..., description="过期时间戳（秒）"),
    signature: str = Query(..., description="HMAC-SHA256 签名"),
) -> Response:
    """校验签名后流式返回图片字节；签名失效抛 ForbiddenError，资源不存在抛 NotFoundError。"""
    if not verify_asset(settings, asset_id, expires, signature):
        raise ForbiddenError("图片地址签名无效或已过期")
    asset = session.get(Asset, asset_id)
    if asset is None:
        raise NotFoundError(f"图片资源不存在: {asset_id}")
    data = storage.get(asset.object_key)
    media_type = mimetypes.guess_type(asset.object_key)[0] or "application/octet-stream"
    # private + 短缓存：签名地址只让本机浏览器缓存，60 秒内重复打开不必再打接口
    return Response(
        content=data,
        media_type=media_type,
        headers={"Cache-Control": "private, max-age=60"},
    )


def main() -> None:
    """自测：有效签名能读到图片；篡改/过期签名 403，签名有效但资源不存在 404。"""
    import base64
    import tempfile
    from pathlib import Path as _Path
    from urllib.parse import urlparse

    from fastapi.testclient import TestClient

    from backend.app.clients.agent import StubAgentClient
    from backend.app.common import new_id
    from backend.app.config import Settings as _Settings
    from backend.app.main import create_app
    from backend.app.models.tables import Asset, Batch, Document
    from backend.app.services.asset import sign_asset

    png = base64.b64decode(
        "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=="
    )
    tmp = _Path(tempfile.mkdtemp(prefix="rag-api-assets-"))
    settings = _Settings(
        database_url=f"sqlite:///{(tmp / 'app.db').as_posix()}",
        data_dir=tmp,
        storage_dir=tmp / "storage",
        public_base_url="http://127.0.0.1:8000",
    )
    app = create_app(settings, agent=StubAgentClient())

    batch_id = new_id("batch")
    doc_id = new_id("doc")
    asset_id = new_id("asset")
    object_key = f"assets/{doc_id}/figure-1.png"
    with app.state.session_factory() as session:
        session.add(Batch(id=batch_id, trace_id="trace_demo", file_count=1))
        session.add(
            Document(
                id=doc_id,
                batch_id=batch_id,
                filename="系统说明.pdf",
                sha256="0" * 64,
                object_key=f"pdfs/{doc_id}.pdf",
                status="done",
            )
        )
        app.state.storage.put(object_key, png, "image/png")
        session.add(
            Asset(
                id=asset_id,
                doc_id=doc_id,
                page=2,
                asset_type="figure",
                object_key=object_key,
                caption="系统架构图",
                bbox=[72.0, 120.0, 480.0, 360.0],
            )
        )
        session.commit()

    signed = sign_asset(settings, asset_id)
    parsed = urlparse(signed.url)
    with TestClient(app) as client:
        print("[api.assets] 签名地址:", signed.url)
        response = client.get(parsed.path + "?" + parsed.query)
        print("[api.assets] 读取状态码:", response.status_code, "内容类型:", response.headers["content-type"])
        assert response.status_code == 200
        assert response.headers["content-type"] == "image/png"
        assert response.content == png

        tampered = client.get(parsed.path + "?" + parsed.query.replace("signature=", "signature=0"))
        print("[api.assets] 篡改签名:", tampered.status_code, tampered.json())
        assert tampered.status_code == 403

        expired = client.get(parsed.path + "?expires=1&signature=deadbeef")
        print("[api.assets] 过期/伪造签名:", expired.status_code, expired.json())
        assert expired.status_code == 403

        other = sign_asset(settings, new_id("asset"))
        other_parsed = urlparse(other.url)
        missing = client.get(other_parsed.path + "?" + other_parsed.query)
        print("[api.assets] 签名有效但资源不存在:", missing.status_code, missing.json())
        assert missing.status_code == 404
    print("[api.assets] 自检通过")


if __name__ == "__main__":
    main()
