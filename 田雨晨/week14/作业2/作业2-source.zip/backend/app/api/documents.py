"""文档状态接口：批次状态、单文档详情、手动重试、SSE 状态推送。"""

if __package__ in (None, ""):  # 允许直接运行本文件
    import sys
    from pathlib import Path

    for _root in Path(__file__).resolve().parents:
        if (_root / "backend" / "app").is_dir():
            sys.path.insert(0, str(_root))
            break

from fastapi import APIRouter
from fastapi.responses import StreamingResponse

from backend.app.api.deps import SessionDep, StatusHubDep, StorageDep
from backend.app.events.sse import format_sse
from backend.app.schemas.batch import (
    BatchStatusResponse,
    DeleteDocumentResponse,
    DocumentInfo,
    DocumentListResponse,
    RetryResponse,
)
from backend.app.services import document as document_service

router = APIRouter(prefix="/api", tags=["文档状态"])


@router.get("/batches/{batch_id}", response_model=BatchStatusResponse, summary="批次下所有文档状态")
def read_batch(batch_id: str, session: SessionDep) -> BatchStatusResponse:
    """批次总状态 + 文档摘要；批次不存在时服务层抛 NotFoundError。"""
    return document_service.get_batch(session, batch_id)


@router.get("/documents", response_model=DocumentListResponse, summary="知识库文档列表")
def list_documents(session: SessionDep, limit: int = 200) -> DocumentListResponse:
    """最近上传的文档（倒序），前端用来展示知识库里有哪些文档会参与检索。"""
    documents = document_service.list_documents(session, limit=max(1, min(limit, 500)))
    return DocumentListResponse(total=len(documents), documents=documents)


@router.get("/documents/{doc_id}", response_model=DocumentInfo, summary="单文档解析状态与错误信息")
def read_document(doc_id: str, session: SessionDep) -> DocumentInfo:
    """单文档详情（含尝试次数）；文档不存在时抛 NotFoundError。"""
    return document_service.get_document(session, doc_id)


@router.post("/documents/{doc_id}/retry", response_model=RetryResponse, summary="手动重试失败文档")
def retry_document(doc_id: str, session: SessionDep, status_hub: StatusHubDep) -> RetryResponse:
    """把失败文档重新排队；非 failed 状态抛 ConflictError。写库后推一次状态快照。"""
    response = document_service.retry_document(session, doc_id)
    info = document_service.get_document(session, doc_id)
    # 推送一次最新快照，前端不必等 5 秒轮询兜底
    status_hub.publish(document_service.batch_status_event(session, info.batch_id))
    return response


@router.delete("/documents/{doc_id}", response_model=DeleteDocumentResponse, summary="删除文档")
def delete_document(doc_id: str, session: SessionDep, storage: StorageDep) -> DeleteDocumentResponse:
    """删除文档及切片/图片/解析任务/引用/对象存储文件；解析中的文档拒绝删除（409）。"""
    document_service.delete_documents(session, storage, [doc_id])
    return DeleteDocumentResponse(doc_id=doc_id, message="文档已删除")


@router.get("/batches/{batch_id}/events", summary="批次状态 SSE 推送（前端 5 秒轮询兜底）")
async def batch_events(batch_id: str, session: SessionDep, status_hub: StatusHubDep) -> StreamingResponse:
    """建立 SSE 长连接：先发当前快照，再持续推送该批次的后续状态变化。"""
    # 先发一帧当前快照，再订阅后续变化；快照与订阅之间理论上最多丢一帧，
    # 由前端的 5 秒轮询兜底补齐（README 状态展示流程）。
    snapshot = document_service.batch_status_event(session, batch_id)

    async def generator():
        """快照帧 + 订阅流；客户端断开时生成器被关闭，StatusHub 自动注销订阅。"""
        yield format_sse(snapshot)
        async for chunk in status_hub.stream(batch_id):
            yield chunk

    return StreamingResponse(
        generator(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no", "Connection": "keep-alive"},
    )


def main() -> None:
    """自测：查批次/文档、排队中重试被拒、连续失败进 failed 后可手动重试。"""
    import tempfile
    from pathlib import Path as _Path

    from fastapi.testclient import TestClient

    from backend.app.clients.agent import StubAgentClient
    from backend.app.config import Settings as _Settings
    from backend.app.main import create_app
    from backend.app.services import document as _document_service

    tmp = _Path(tempfile.mkdtemp(prefix="rag-api-docs-"))
    settings = _Settings(
        database_url=f"sqlite:///{(tmp / 'app.db').as_posix()}",
        data_dir=tmp,
        storage_dir=tmp / "storage",
    )
    app = create_app(settings, agent=StubAgentClient())
    with TestClient(app) as client:
        created = client.post(
            "/api/batches",
            files=[("files", ("状态机.pdf", b"%PDF-1.7\n" + b"0" * 100, "application/pdf"))],
        ).json()
        batch_id = created["batch_id"]
        doc_id = created["documents"][0]["doc_id"]
        batch_paths = [path for path in app.openapi().get("paths", {}) if "batches" in path]
        print("[api.documents] 批次相关路由:", batch_paths)

        batch = client.get(f"/api/batches/{batch_id}").json()
        print("[api.documents] 批次状态:", batch["status"], batch["display_status"], batch["documents"])
        assert batch["status"] == "queued" and batch["total"] == 1

        detail = client.get(f"/api/documents/{doc_id}").json()
        print("[api.documents] 文档详情:", detail["status"], detail["display_status"], "attempts=", detail["attempts"])
        assert detail["status"] == "queued"

        corpus = client.get("/api/documents").json()
        print("[api.documents] 知识库文档列表:", corpus["total"], [item["filename"] for item in corpus["documents"]])
        assert corpus["total"] == 1 and corpus["documents"][0]["doc_id"] == doc_id

        conflict = client.post(f"/api/documents/{doc_id}/retry")
        print("[api.documents] 排队中文档重试被拒:", conflict.status_code, conflict.json())
        assert conflict.status_code == 409

        # 模拟解析工作器：解析失败 3 次后进入失败状态
        with app.state.session_factory() as session:
            for _ in range(3):
                _document_service.mark_parsing(session, doc_id)
                result = _document_service.record_failure(session, doc_id, "MinerU 解析超时")
                print("[api.documents] 工作器记录失败 ->", result)
                assert result == "retrying" or result == "failed"
        failed = client.get(f"/api/documents/{doc_id}").json()
        print("[api.documents] 失败后详情:", failed["status"], failed["display_status"], "错误:", failed["error"])
        assert failed["status"] == "failed" and failed["display_status"] == "解析失败"

        retried = client.post(f"/api/documents/{doc_id}/retry")
        print("[api.documents] 手动重试:", retried.status_code, retried.json())
        assert retried.status_code == 200 and retried.json()["status"] == "queued"

        missing = client.get("/api/batches/batch_not_exist")
        print("[api.documents] 不存在的批次:", missing.status_code, missing.json())
        assert missing.status_code == 404

        # 解析中的文档不允许删除（避免和 worker 并发写冲突）
        with app.state.session_factory() as session:
            _document_service.mark_parsing(session, doc_id)
        conflict_delete = client.delete(f"/api/documents/{doc_id}")
        print("[api.documents] 解析中文档删除被拒:", conflict_delete.status_code, conflict_delete.json())
        assert conflict_delete.status_code == 409

        # 解析结束后先标完成，再验证“已完成的文档允许重新解析”
        with app.state.session_factory() as session:
            _document_service.mark_indexing(session, doc_id)
            _document_service.mark_done(session, doc_id, pages=3)
        reparsed = client.post(f"/api/documents/{doc_id}/retry")
        print("[api.documents] 已完成文档重新解析:", reparsed.status_code, reparsed.json())
        assert reparsed.status_code == 200 and reparsed.json()["status"] == "queued"
        with app.state.session_factory() as session:
            _document_service.mark_parsing(session, doc_id)
            _document_service.mark_indexing(session, doc_id)
            _document_service.mark_done(session, doc_id, pages=3)

        # 解析结束后可以删除：文档、切片、图片、任务、引用与批次一并清理
        deleted = client.delete(f"/api/documents/{doc_id}")
        print("[api.documents] 删除文档:", deleted.status_code, deleted.json())
        assert deleted.status_code == 200
        assert client.get(f"/api/documents/{doc_id}").status_code == 404
        assert client.get("/api/documents").json()["total"] == 0
        # 批次下没有文档后，批次行也删掉
        assert client.get(f"/api/batches/{batch_id}").status_code == 404
    print("[api.documents] 自检通过")


if __name__ == "__main__":
    main()
