"""上传接口：一次上传多个 PDF，返回批次编号与文档列表。"""

if __package__ in (None, ""):  # 允许直接运行本文件
    import sys
    from pathlib import Path

    for _root in Path(__file__).resolve().parents:
        if (_root / "backend" / "app").is_dir():
            sys.path.insert(0, str(_root))
            break

from fastapi import APIRouter, File, UploadFile

from backend.app.api.deps import SessionDep, SettingsDep, StatusHubDep, StorageDep
from backend.app.schemas.batch import BatchUploadResponse, UploadFileData
from backend.app.services import document as document_service
from backend.app.services import upload as upload_service

router = APIRouter(prefix="/api", tags=["上传"])


@router.post("/batches", response_model=BatchUploadResponse, summary="上传多个 PDF")
def create_batch(
    session: SessionDep,
    settings: SettingsDep,
    storage: StorageDep,
    status_hub: StatusHubDep,
    files: list[UploadFile] = File(..., description="多个 PDF 文件"),
) -> BatchUploadResponse:
    """接收多个 PDF 并创建批次；校验失败抛 InputError，成功后推一次状态快照。"""
    # ponytail: 当前一次性读入内存（上限 100MB/文件）；要支持超大文件时改成流式写对象存储
    payload = [
        UploadFileData(
            filename=item.filename or "",
            content=item.file.read(),
            content_type=item.content_type,
        )
        for item in files
    ]
    response = upload_service.create_batch(session, settings, payload, storage)
    # 新批次先推一次状态快照，订阅 SSE 的页面能立刻看到“待解析”
    status_hub.publish(document_service.batch_status_event(session, response.batch_id))
    return response


def main() -> None:
    """自测：多文件上传成功且状态为待解析；非 PDF 与空文件列表被拒绝。"""
    import tempfile
    from pathlib import Path as _Path

    from fastapi.testclient import TestClient

    from backend.app.clients.agent import StubAgentClient
    from backend.app.config import Settings as _Settings
    from backend.app.main import create_app

    tmp = _Path(tempfile.mkdtemp(prefix="rag-api-upload-"))
    settings = _Settings(
        database_url=f"sqlite:///{(tmp / 'app.db').as_posix()}",
        data_dir=tmp,
        storage_dir=tmp / "storage",
    )
    app = create_app(settings, agent=StubAgentClient())
    with TestClient(app) as client:
        files = [
            ("files", ("第一份.pdf", b"%PDF-1.7\n" + b"0" * 200, "application/pdf")),
            ("files", ("第二份.pdf", b"%PDF-1.7\n" + b"1" * 200, "application/pdf")),
        ]
        response = client.post("/api/batches", files=files)
        print("[api.upload] 上传状态码:", response.status_code)
        body = response.json()
        print("[api.upload] 响应:", body)
        assert response.status_code == 200
        assert len(body["documents"]) == 2 and body["status"] == "queued"
        assert body["display_status"] == "待解析"
        assert all(item["display_status"] == "待解析" for item in body["documents"])

        batch_id = body["batch_id"]
        status = client.get(f"/api/batches/{batch_id}").json()
        print("[api.upload] 批次状态:", status["status"], status["display_status"], "文档数:", status["total"])
        assert status["total"] == 2 and status["status"] == "queued"

        duplicate = client.post("/api/batches", files=files)
        print("[api.upload] 重复内容上传:", duplicate.status_code, duplicate.json())
        assert duplicate.status_code == 400 and "已经上传过" in duplicate.json()["message"]

        bad = client.post("/api/batches", files=[("files", ("说明.txt", b"not a pdf", "text/plain"))])
        print("[api.upload] 非 PDF 拒绝:", bad.status_code, bad.json())
        assert bad.status_code == 400

        empty = client.post("/api/batches", files=[])
        print("[api.upload] 空上传拒绝:", empty.status_code, empty.json())
        assert empty.status_code in (400, 422)
    print("[api.upload] 自检通过")


if __name__ == "__main__":
    main()
