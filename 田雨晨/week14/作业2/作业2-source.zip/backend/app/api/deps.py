"""接口层依赖：统一从 app.state 取配置、会话、存储、智能体、状态推送中心。"""

if __package__ in (None, ""):  # 允许直接运行本文件
    import sys
    from pathlib import Path

    for _root in Path(__file__).resolve().parents:
        if (_root / "backend" / "app").is_dir():
            sys.path.insert(0, str(_root))
            break

from collections.abc import Iterator
from typing import Annotated

from fastapi import Depends, Request
from sqlalchemy.orm import Session

from backend.app.clients.agent import AgentClient
from backend.app.clients.storage import ObjectStorage
from backend.app.config import Settings
from backend.app.events.sse import StatusHub


def get_settings_dep(request: Request) -> Settings:
    """当前应用的配置对象（create_app 时放进 app.state，测试可整体替换）。"""
    return request.app.state.settings


def get_session(request: Request) -> Iterator[Session]:
    """每个请求一个会话，请求结束即关闭；服务层自行 commit，这里只负责归还连接。"""
    factory = request.app.state.session_factory
    with factory() as session:
        yield session


def get_storage(request: Request) -> ObjectStorage:
    """当前装配的对象存储实现（本地目录或 MinIO）。"""
    return request.app.state.storage


def get_agent(request: Request) -> AgentClient:
    """当前装配的智能体客户端（真实 HTTP 或离线假智能体）。"""
    return request.app.state.agent


def get_status_hub(request: Request) -> StatusHub:
    """进程内状态推送中心，上传/重试接口用它推一次快照给 SSE 订阅者。"""
    return request.app.state.status_hub


SettingsDep = Annotated[Settings, Depends(get_settings_dep)]
SessionDep = Annotated[Session, Depends(get_session)]
StorageDep = Annotated[ObjectStorage, Depends(get_storage)]
AgentDep = Annotated[AgentClient, Depends(get_agent)]
StatusHubDep = Annotated[StatusHub, Depends(get_status_hub)]


def main() -> None:
    """用一个只依赖配置的极小应用验证依赖注入能工作。"""
    from fastapi import FastAPI
    from fastapi.testclient import TestClient

    app = FastAPI()
    app.state.settings = Settings(app_env="selfcheck")

    @app.get("/demo")
    def demo(settings: SettingsDep) -> dict:
        """示例路由：只回显配置项，用来确认依赖注入链路可用。"""
        return {"app_env": settings.app_env}

    with TestClient(app) as client:
        payload = client.get("/demo").json()
    print("[api.deps] 依赖注入结果:", payload)
    assert payload == {"app_env": "selfcheck"}
    print("[api.deps] 已注册依赖:", ", ".join(sorted(
        name for name in ("SettingsDep", "SessionDep", "StorageDep", "AgentDep", "StatusHubDep")
    )))
    print("[api.deps] 自检通过")


if __name__ == "__main__":
    main()
