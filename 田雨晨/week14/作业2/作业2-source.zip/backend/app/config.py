"""后端配置：本地默认值即可跑通，Docker 部署时用环境变量覆盖。"""

import os
from functools import lru_cache
from pathlib import Path

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

PROJECT_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_DATA_DIR = PROJECT_ROOT / "backend" / "data"
DEPLOY_ENV_FILE = PROJECT_ROOT / "deploy" / ".env"


class Settings(BaseSettings):
    """全部配置项。字段名大写即环境变量名（如 DATABASE_URL）。"""

    model_config = SettingsConfigDict(extra="ignore", case_sensitive=False)

    app_env: str = "local"
    data_dir: Path = DEFAULT_DATA_DIR
    database_url: str = f"sqlite:///{(DEFAULT_DATA_DIR / 'app.db').as_posix()}"
    storage_dir: Path | None = None

    storage_backend: str = "local"
    queue_backend: str = "memory"

    asset_signing_secret: str = "dev-insecure-secret"
    asset_signed_url_ttl: int = Field(600, ge=1)
    public_base_url: str = "http://127.0.0.1:8000"
    # 允许跨域的前端地址（逗号分隔；Next.js 开发服务器默认 3000 端口）
    cors_origins: str = "http://localhost:3000,http://127.0.0.1:3000"
    # 本地/局域网开发来源正则：前端用局域网 IP（如 http://192.168.1.5:3000）打开时也能调后端
    # （CORS 不允许对 IP 用通配符，只能列出或正则匹配；设为空字符串可关闭）
    cors_origin_regex: str = (
        r"^http://(localhost|127\.0\.0\.1|\[::1\]"
        r"|10\.\d{1,3}\.\d{1,3}\.\d{1,3}"
        r"|172\.(1[6-9]|2\d|3[01])\.\d{1,3}\.\d{1,3}"
        r"|192\.168\.\d{1,3}\.\d{1,3})(:\d{1,5})?$"
    )

    max_upload_mb: int = Field(100, ge=1, le=2048)
    max_batch_files: int = Field(20, ge=1, le=100)

    agent_service_url: str = "http://127.0.0.1:8100"
    agent_timeout_s: float = Field(120.0, gt=0)
    agent_stub: bool = False  # 本地联调开关：智能体服务未启动时用离线假智能体
    max_question_chars: int = Field(2000, ge=1)
    max_question_image_mb: int = Field(10, ge=1)

    kafka_brokers: str = "redpanda:9092"
    kafka_parse_topic: str = "parse.requested"
    kafka_dlq_topic: str = "parse.dlq"
    max_parse_retries: int = Field(3, ge=0, le=10)

    @property
    def storage_path(self) -> Path:
        """对象存储根目录：显式配置优先，否则落在数据目录下的 storage/。"""
        return Path(self.storage_dir) if self.storage_dir else Path(self.data_dir) / "storage"

    @property
    def cors_origin_list(self) -> list[str]:
        """把逗号分隔的 CORS_ORIGINS 拆成列表；支持 * 表示放开所有来源。"""
        origins = [item.strip() for item in self.cors_origins.split(",") if item.strip()]
        return origins or ["http://localhost:3000", "http://127.0.0.1:3000"]

    @property
    def max_upload_bytes(self) -> int:
        """单文件大小上限（字节），供上传校验直接比较。"""
        return self.max_upload_mb * 1024 * 1024

    @property
    def max_question_image_bytes(self) -> int:
        """用户提问图片大小上限（字节）。"""
        return self.max_question_image_mb * 1024 * 1024

    def ensure_dirs(self) -> None:
        """本地存储与 SQLite 文件需要目录先存在。"""
        Path(self.data_dir).mkdir(parents=True, exist_ok=True)
        self.storage_path.mkdir(parents=True, exist_ok=True)


def _env_file() -> Path | None:
    """只在非本地模式读 deploy/.env（里面是 Docker 内部服务地址）。"""
    is_local = os.getenv("APP_ENV", "local").strip().lower() == "local"
    return None if is_local else (DEPLOY_ENV_FILE if DEPLOY_ENV_FILE.exists() else None)


@lru_cache
def get_settings() -> Settings:
    """返回进程内唯一的配置实例；lru_cache 保证各处读到同一份（改环境变量后要清缓存）。"""
    return Settings(_env_file=_env_file())


def reset_settings_cache() -> None:
    """清空配置缓存，供测试在改环境变量或换 Settings 后重新读取。"""
    get_settings.cache_clear()


def main() -> None:
    """自测：打印生效配置并校验本地模式的目录与数据库地址。"""
    settings = get_settings()
    print("[config] 模式:", settings.app_env)
    print("[config] 项目根目录:", PROJECT_ROOT)
    print("[config] 数据库:", settings.database_url)
    print("[config] 本地存储目录:", settings.storage_path)
    print("[config] 队列后端:", settings.queue_backend)
    print("[config] 图片签名地址有效期(秒):", settings.asset_signed_url_ttl)
    print("[config] 上传限制: 单文件", settings.max_upload_mb, "MB / 单批次", settings.max_batch_files, "个")
    print("[config] 智能体地址:", settings.agent_service_url)
    print("[config] 允许跨域的前端地址:", settings.cors_origin_list)

    settings.ensure_dirs()
    assert settings.database_url.startswith("sqlite:"), "本地模式应使用 SQLite，检查 DATABASE_URL"
    assert settings.storage_path.is_dir(), "本地存储目录创建失败"
    if settings.asset_signing_secret == "dev-insecure-secret":
        print("[config] 提示: 正在使用默认签名密钥，生产部署请设置 ASSET_SIGNING_SECRET")
    print("[config] 自检通过")


if __name__ == "__main__":
    main()
