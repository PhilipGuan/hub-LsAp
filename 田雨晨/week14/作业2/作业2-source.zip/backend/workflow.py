"""问答 workflow：代码编排入口——固定顺序调用节点与工具，单步失败就地兜底。

编排顺序：用户图片描述 → 规划（一次轻量决策）→ 文本检索 → 图片加载 → 引用构建 → 回答合成。
节点实现在 `graph/`（planner / synthesizer），工具在 `tools/`，本文件只负责把它们的
调用顺序、降级与失败兜底串起来，是整条问答链路的唯一编排定义。

在链路中的位置：智能体服务 `service.py` 的 `POST /answer` 直接调用这里的 `answer()`。

第一版刻意不做并行工具调度与多轮自主规划（README：固定编排 + 一次轻量决策）：
串行虽然多花一点延迟，但链路可预测、单步失败能就地兜底，不会因为一个工具超时
就让整条问答失败。智能体只读检索数据，不写业务表。
"""

if __package__ in (None, ""):  # 允许直接运行本文件
    import sys
    from pathlib import Path

    for _root in Path(__file__).resolve().parents:
        if (_root / "backend" / "app").is_dir():
            sys.path.insert(0, str(_root))
            break

from dataclasses import dataclass, field

from backend.agent.config import AgentSettings, get_agent_settings
from backend.agent.embedding import EmbeddingClient, embedding_from_settings
from backend.agent.graph.planner import Planner, PlannerDecision
from backend.agent.graph.synthesizer import Synthesizer
from backend.agent.llm import LLMClient, llm_from_settings
from backend.agent.prompt_loader import PromptLoader, get_prompt_loader
from backend.agent.tools.citation_builder import CitationBuilder
from backend.agent.tools.image_caption import ImageCaptionResult, ImageCaptionTool
from backend.agent.tools.image_load import ImageLoadTool
from backend.agent.tools.text_search import TextSearchTool
from backend.app.schemas.content import Citation, ImageAsset, TextChunk
from backend.app.schemas.qa import AgentRequest, AgentResponse


@dataclass
class WorkflowTrace:
    """一次问答的中间结果，供自测/日志观察（不返回给后端）。"""

    image_caption: ImageCaptionResult | None = None
    decision: PlannerDecision | None = None
    chunks: list[TextChunk] = field(default_factory=list)
    assets: list[ImageAsset] = field(default_factory=list)
    citations: list[Citation] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)


class QaWorkflow:
    """把各工具/节点按固定顺序串起来；依赖可注入，便于离线自测。"""

    def __init__(
        self,
        session_factory,
        settings: AgentSettings | None = None,
        *,
        llm: LLMClient | None = None,
        embedder: EmbeddingClient | None = None,
        prompts: PromptLoader | None = None,
    ) -> None:
        """按配置构造各工具/节点；llm/embedder/prompts 可注入假实现做离线自测。"""
        self.settings = settings or get_agent_settings()
        self.prompts = prompts or get_prompt_loader(self.settings.prompt_dir)
        self.llm = llm or llm_from_settings(self.settings)
        # embedder=None 有两种含义：调用方显式传 None（走关键词降级）或配置没有向量模型
        self.embedder = embedder if embedder is not None else embedding_from_settings(self.settings)
        self.caption_tool = ImageCaptionTool(self.llm, self.prompts)
        self.planner = Planner(self.llm, self.prompts)
        self.text_search = TextSearchTool(session_factory, self.settings, self.embedder)
        self.image_load = ImageLoadTool(session_factory, self.settings)
        self.citation_builder = CitationBuilder(self.settings)
        self.synthesizer = Synthesizer(self.llm, self.prompts, self.settings)
        self.last_trace: WorkflowTrace | None = None

    def answer(self, request: AgentRequest) -> AgentResponse:
        """走完整条固定编排；每个工具各自 try/except，失败只记告警、继续往下走。"""
        trace = WorkflowTrace()
        self.last_trace = trace

        # 1. 有用户图片：先拿到图片描述/识别文字，并入后续检索查询
        if request.image is not None:
            try:
                trace.image_caption = self.caption_tool.describe(request.image)
            except Exception as error:  # 工具失败兜底，不阻断问答
                trace.warnings.append(f"用户图片描述失败: {error}")
        caption_text = trace.image_caption.combined_text if trace.image_caption else ""

        # 2. 一次轻量决策：要不要检索、用什么查询
        try:
            trace.decision = self.planner.decide(request.question, caption_text)
        except Exception as error:
            # 规划失败同样按“宁可检索也不漏检”处理，保证知识问题不会静默变成闲聊
            trace.warnings.append(f"规划失败: {error}")
            trace.decision = PlannerDecision(
                need_retrieve=True,
                query=f"{request.question} {caption_text}".strip(),
            )

        # 3. 文本检索；4. 按切片加载关联图片
        if trace.decision.need_retrieve:
            try:
                trace.chunks = self.text_search.search(trace.decision.query, top_k=request.top_k)
                trace.chunks = trace.chunks[: self.settings.max_context_chunks]
            except Exception as error:
                trace.warnings.append(f"文本检索失败: {error}")
            try:
                trace.assets = self.image_load.load(trace.chunks)
            except Exception as error:
                trace.warnings.append(f"图片加载失败: {error}")

        # 5. 引用构建（失败也要继续合成：没有引用总比没有回答好）
        try:
            trace.citations = self.citation_builder.build(trace.chunks, trace.assets)
        except Exception as error:
            trace.warnings.append(f"引用构建失败: {error}")
            trace.citations = []

        # 6. 回答合成（内部对结构化输出失败做纯文本回退，再失败用固定文案）
        return self.synthesizer.synthesize(
            request.question,
            caption_text,
            trace.chunks,
            trace.assets,
            trace.citations,
        )


def build_workflow(
    session_factory,
    settings: AgentSettings | None = None,
    *,
    llm: LLMClient | None = None,
    embedder: EmbeddingClient | None = None,
) -> QaWorkflow:
    """构造编排器（服务与自测共用的简单工厂）。"""
    return QaWorkflow(session_factory, settings, llm=llm, embedder=embedder)


def main() -> None:
    """自检：图文问答走通检索→引用→图文混排，闲聊跳过检索走纯文本。"""
    import base64
    import tempfile
    from pathlib import Path as _Path

    from backend.agent.embedding import StubEmbedding
    from backend.agent.fixtures import CHUNK_TEXTS, temp_session_factory
    from backend.agent.llm import CAPTION_MARKER, PLANNER_MARKER, SYNTHESIZER_MARKER, StubLLM
    from backend.agent.config import build_agent_settings
    from backend.app.schemas.qa import AgentImage

    embedder = StubEmbedding(dim=8)
    factory, data = temp_session_factory(embedder)

    # 规划命中第 2 条切片（同一文本的余弦相似度为 1），并返回一条文本段 + 一条图片段
    linked_citation = f"cit_{data.chunk_ids[1]}"
    nearby_asset = data.asset_ids[1]  # 第 2 页的表格资源，会作为“邻近图片”被加载
    llm = StubLLM(
        {
            PLANNER_MARKER: {"need_retrieve": True, "query": CHUNK_TEXTS[1]},
            SYNTHESIZER_MARKER: {
                "answer": "解析工作器调用 MinerU 生成 Markdown、版面 JSON 与图片资源。",
                "segments": [
                    {"type": "text", "text": "解析工作器调用 MinerU 生成 Markdown、版面 JSON 与图片资源。", "sources": [linked_citation]},
                    {"type": "image", "asset_id": nearby_asset, "caption": "解析流程表", "sources": [linked_citation]},
                ],
                "citations": [],
            },
            CAPTION_MARKER: {"caption": "用户上传的流程图", "ocr_text": "MinerU"},
        }
    )
    settings = build_agent_settings(stub=True)
    orchestrator = QaWorkflow(factory, settings, llm=llm, embedder=embedder)

    image_bytes = base64.b64encode(b"\x89PNG\r\n\x1a\n fake png").decode("ascii")
    request = AgentRequest(
        question="解析工作器会产出什么？",
        image=AgentImage(mime_type="image/png", data_base64=image_bytes),
        top_k=3,
    )
    response = orchestrator.answer(request)
    print("[workflow] 回答:", response.answer)
    print("[workflow] 分段:", [segment.type for segment in response.segments])
    print("[workflow] 引用:", [citation.citation_id for citation in response.citations])
    assert response.answer
    assert response.segments[0].type == "text"
    assert response.segments[1].type == "image" and response.segments[1].asset_id == nearby_asset
    assert response.citations, "命中切片后应有引用"
    trace = orchestrator.last_trace
    assert trace is not None
    assert trace.image_caption is not None and trace.image_caption.ok
    assert trace.chunks and trace.chunks[0].chunk_id == data.chunk_ids[1]
    assert nearby_asset in [asset.asset_id for asset in trace.assets]
    print("[workflow] 命中切片:", trace.chunks[0].chunk_id, "| score:", trace.chunks[0].score)
    print("[workflow] 告警:", trace.warnings)

    # 闲聊：规划判定不检索，返回纯文本回答
    chat_llm = StubLLM({PLANNER_MARKER: {"need_retrieve": False, "query": ""}})
    chat_orchestrator = QaWorkflow(factory, settings, llm=chat_llm, embedder=embedder)
    chat_response = chat_orchestrator.answer(AgentRequest(question="你好"))
    print("[workflow] 闲聊回答:", chat_response.answer)
    assert chat_response.segments[0].type == "text"
    assert chat_orchestrator.last_trace is not None
    assert chat_orchestrator.last_trace.chunks == []
    print("[workflow] 自检通过")


if __name__ == "__main__":
    main()
