# AGENTS.md

## Current repo state
- `docs/README.md` is the authoritative spec (architecture, env vars, state machine, data model, API, agent design). Read it before implementing.
- 后端已实现：`backend/app/`（FastAPI 接口层、pydantic 数据结构单独存放、SQLAlchemy 表 + SQLite 本地默认、事务发件箱、SSE 状态推送、图片 HMAC 签名地址、多模态问答服务）。
- 问答智能体已实现：`backend/agent/`（`service.py` 提供内部 `POST /answer`，端口 8100；**问答代码编排在 `backend/workflow.py`（单文件）**，节点在 `backend/agent/graph/`、工具在 `backend/agent/tools/`；固定编排 + 一次轻量决策；只读数据库、不跑建表 DDL；工具失败有兜底；离线假模型 `AGENT_STUB_LLM=1` 可联调）。后端通过 `backend/app/clients/agent.py` 的 HTTP 客户端调用它。
- 解析工作器已实现：`parse-worker/`（`worker.py --serve` 按数据库状态机取待解析文档 → MinerU 解析（无 `MINERU_API_URL` 时用离线 mock）→ 切片/图片入库（幂等）→ 状态流转回写；`indexer.py` 生成向量）。`WORKER_STUB_MODELS=1` 用假向量（与智能体 `AGENT_STUB_LLM=1` 维度一致），可离线跑通"上传→解析→入库→检索→问答"全链路。
- 仍缺：`deploy/docker-compose.yml`/`init.sql`/`nginx.conf`（Docker 一键部署）；`parse-worker` 的 Kafka 消费者模式（当前最小实现按数据库轮询，README 允许）。
- 每个后端/智能体/工作器文件都有 `if __name__ == "__main__": main()` 自检；`test/selfcheck.py` 一键跑全部 43 个模块（`python test/selfcheck.py -v`）。改动后先跑它。
- 本地默认不依赖 Docker/Postgres/MinIO/Kafka：SQLite + 本地目录 + 内存队列；`AGENT_STUB_LLM=1` 智能体用离线假模型，`AGENT_STUB=1` 后端跳过智能体服务。配置见 `backend/app/config.py`（字段名大写即环境变量名）与 `backend/agent/config.py`（模型密钥读 `deploy/.env` 的 `VLM_*`/`EMBEDDING_*`），`backend/README.md` 有运行说明。
- 前端已实现：`frontend/`（Next.js 16 App Router + React 19 + TypeScript，只消费后端 HTTP 接口）。`/` 上传与解析状态页（SSE + 5 秒轮询 + 重试 + 刷新恢复），`/qa` 多模态问答页（图文分段渲染 + 引用 + 回退提示）。接口地址用 `NEXT_PUBLIC_API_BASE_URL`（默认 `http://127.0.0.1:8000`），后端 CORS 默认放行 `localhost:3000` / `127.0.0.1:3000`；`frontend/README.md` 有启动与接口对照。
- 前端构建/类型检查：`cd frontend && npx tsc --noEmit`、`npm run build`（Next 16 会改写 tsconfig/next-env，属预期）；`npm run dev` 起 :3000。
- 一键启动：仓库根 `python start_all.py`（后端 8000 + 解析工作器 + 智能体 8100 + 前端 3000，支持 `--real-models` / `--no-agent` / `--no-frontend`；日志 `.run/logs/`，`Ctrl+C` 停止全部）。
- Python：conda 环境 `py312`（`D:\Anaconda\envs\py312\python.exe`）。Anaconda base 3.13 缺 fastapi，`python test/selfcheck.py` 会自动检测并切到 py312，单个文件自测则要显式用 py312。后端依赖见 `backend/requirements.txt`。

## Non-negotiable design constraints
- Kafka carries metadata only (doc/batch IDs, object-store paths, trace ID) — never PDF or image binaries. Parse status comes from the DB state machine, never from Kafka.
- Status is two-level: batch + per-file. Internal states: 排队中 → 解析中 → 索引中 → 解析完成, with failure → retry (3 automatic) → DLQ, plus manual retry.
- Write parse requests through a transactional outbox; consumers must be idempotent (redelivery must not create duplicate chunks).
- The Q&A agent uses fixed orchestration + one lightweight decision, is not externally exposed, and only reads retrieval data (never writes business tables). It emits structured text/image segments + citations, falling back to plain text + citations if structured output fails.
- No separate image vector index: find images via captions, OCR text, and nearby text. Image assets are returned as short-lived, backend-signed URLs.
- First version is deliberately minimal: no chunked/resumable upload, no multi-tenant RBAC, no long-term memory, no parallel tool scheduling.

## Planned toolchain (not yet scaffolded)
- React + Vite / FastAPI + SQLAlchemy / Kafka or Redpanda / PostgreSQL 16 + pgvector / MinIO / Redis / MinerU / Docker Compose.
- Documented local startup once `../deploy` exists: `cd deploy && cp .env.example .env && docker compose up -d` (UI :3000, API docs :8000/docs, MinIO console :9001).
